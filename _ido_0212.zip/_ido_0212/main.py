# -*- coding: utf-8 -*-
"""
@author: Yanagisawa
"""
import os
import numpy as np
import sys
import pandas as pd
import torch
import random
import matplotlib.pyplot as plt
import time
os.chdir(r'C:\Users\猛\Desktop\yoshiki_study\timeseries forecasting')
from data import data_generator
from model.trainer import Trainer 

df_org = pd.read_csv('data/index_data.csv', encoding = 'utf-8').set_index('Date')
df = df_org.copy()

def convert(x):
    if x[0] == 1:
        x = x[1:]
    elif x[0] == 2:
        x = x[1:].diff()
    elif x[0] == 3:
        # x = x[1:] - x[1:].rolling(10).mean()
        x = x[1:].pct_change().rolling(10).mean()        
        # x = x[1:].pct_change()
    else:
        sys.exit('Codeは1~3の値を選択')
    return x

target_names = ['AUD Curncy', 'CAD Curncy', 'MXN Curncy']
# target_names = ['SPX Index', 'TPX Index']
df_org.loc['Code', target_names] = 1
df = df_org.apply(convert).replace([np.inf, -np.inf], np.nan).dropna()
# df = df.iloc[:,0:5]
df = df.iloc[:,10:15]
df.index = pd.to_datetime(df.index)

config = {
    'model_name'  : 'deep_factors',
    'random_seed' : 777,
    'time_steps'  : 5,        
    'len_train'   : 100,
    'len_val'     : 30,
    'len_test'    : 30,
    'batch_size'  : 32,
    'device'      : torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    }

train_start_index = 10
dg = data_generator.DataGenerator(config['random_seed'], config['time_steps'], train_start_index,
                                  config['len_train'], config['len_test'], df.index, config['len_val'], is_val = False)
loader_train, loader_train_fit, loader_test, loader_test_fit = \
    dg.make_dataloader(dg, df, config['batch_size'], target_names, is_target_scale=True)

#%%
hyperparms = {
    'lr' : 1e-4,
    'noise_nlayers'      : 2,
    'noise_hidden_size'  : 50,
    'global_nlayers'     : 2,
    'global_hidden_size' : 100,
    'n_global_factors'   : 20,
    'target_num'         : len(target_names),
    'dropout'            : 0.3,
    }

epoch = 100
tr = Trainer(hyperparms, epoch, loader_train, config)
model, hist_loss = tr.train(True)

# check
mu, sigma = tr.predict_params(loader_train_fit)
pred = tr.sample(loader_train_fit, num_samples=1000)
for x, y_true in loader_train_fit:pass
for i in range(y_true.size(1)):
    df_pred = pd.DataFrame([y_true[:,i].detach().numpy().copy(), 
                            pred[:,i].detach().numpy().copy()],
                           index=['true', 'pred']).T
    df_pred.plot()
    plt.title(target_names[i])