'''
Pytorch Implementation of Deep Factors For Forecasting
Paper Link: https://arxiv.org/pdf/1905.12417.pdf
AppendixのA.1. DF-RNN: Gaussian noise process as the local modelの実装
'''
import torch
from torch import nn
import torch.nn.functional as F 
from torch.autograd import Variable

import numpy as np
import utils

class DeepFactor(nn.Module):
    def __init__(self, input_size, global_nlayers, global_hidden_size, n_global_factors, dropout):
        super(DeepFactor, self).__init__()
        self.lstm = nn.LSTM(input_size, global_hidden_size, global_nlayers, 
                            dropout=dropout, bias=True, batch_first=True)
        self.factor = nn.Linear(global_hidden_size, n_global_factors)

    def forward(self, X):       
        _, (h, c) = self.lstm(X)
        ht = h[-1, :, :]
        # ht = _[:, -1, :]        
        ht = F.relu(ht)
        gt = self.factor(ht)
                
        return gt

class Noise(nn.Module):
    def __init__(self, input_size, noise_nlayers, noise_hidden_size, dropout):
        super(Noise, self).__init__()
        self.lstm = nn.LSTM(input_size, noise_hidden_size, noise_nlayers,
                            dropout=dropout, bias=True, batch_first=True)
        self.affine = nn.Linear(noise_hidden_size, 1)

    def forward(self, X):
        _, (h, c) = self.lstm(X)
        ht = h[-1, :, :] # num_ts, global factors
        ht = F.relu(ht)
        sigma_t = self.affine(ht)
        sigma_t = torch.log(1 + torch.exp(sigma_t))
        return sigma_t

class DFRNN(nn.Module):
    def __init__(self, input_size, hyperparms, device):
        '''DF-RNN: Gaussian noise process as the local model
        https://arxiv.org/pdf/1905.12417.pdfのP12参照

        Parameters
        ----------
        input_size         : 特徴量の数        
        hyperparms : ハイパーパラメータ
            noise_nlayers      : ランダム効果のRNNの層数
            noise_hidden_size  : ランダム効果のRNNのユニット数
            global_nlayers     : グローバル効果のRNNの層数
            global_hidden_size : グローバル効果のRNNのユニット数
            n_global_factors   : グローバル効果の出力次元（固定効果の項の数）
        device : TYPE
            CPU or GPU.
        '''        
        super(DFRNN, self).__init__()
        self.noise = Noise(input_size, hyperparms['noise_hidden_size'], hyperparms['noise_nlayers'], hyperparms['dropout'])
        self.noise_list = nn.ModuleList([self.noise for i in range(hyperparms['target_num'])]) 
        self.global_factor = DeepFactor(input_size, hyperparms['global_nlayers'], 
                                        hyperparms['global_hidden_size'], hyperparms['n_global_factors'], hyperparms['dropout'])
        self.embed = nn.Linear(hyperparms['n_global_factors'], 1)
        self.embed_list = nn.ModuleList([self.embed for i in range(hyperparms['target_num'])])     
        self.device = device
    
    def forward(self, X):
        mu = []
        for i in range(X.size(3)):
            gt_i = self.global_factor(X[:,:,:,i])
            ft_i = self.embed_list[i](gt_i)
            mu_i = ft_i.sum(dim=1).view(-1, 1)
            mu.append(mu_i)
            
        sigma = [noise(X[:,:,:,i]) for i, noise in enumerate(self.noise_list)]
               
        return mu, sigma
    
    def predict_params(self, X):
        mu_, sigma_ = self.forward(X)
                
        num_t = mu_[0].shape[0]
        num_t_series = len(mu_)
        mu = torch.zeros(num_t, num_t_series)
        sigma = torch.zeros(num_t, num_t_series)        
        
        for i, [mu_i, sigma_i] in enumerate(zip(mu_, sigma_)):  
            mu[:,i] = mu_i.squeeze()
            sigma[:,i] = sigma_i.squeeze()            
            
        return mu, sigma
    
    def sample(self, X, num_samples):
        mu, sigma = self.forward(X)
                
        num_t = mu[0].shape[0]
        num_t_series = len(mu)
        z = torch.zeros(num_t, num_t_series)
        
        for i, [mu_i, sigma_i] in enumerate(zip(mu, sigma)):  
            for _ in range(num_samples):
                dist = torch.distributions.normal.Normal(loc=mu_i, scale=sigma_i)
                zs = dist.sample().view(num_t)
                z[:, i] += zs
                
            z[:, i] = z[:, i] / num_samples
            
        return z
        

class Kalman(nn.Module):
    def __init__(self, mu0, V0, A, b, Q, R):
        super(Kalman, self).__init__()
        self.A = Variable(torch.from_numpy(A).double(), requires_grad=False)
        self.b = Variable(torch.from_numpy(b).double(), requires_grad=False)
        self.Q = Variable(torch.from_numpy(Q).double(), requires_grad=False)
        self.R = Variable(torch.from_numpy(R).double(), requires_grad=False)

        self.mu = Variable(torch.from_numpy(mu0).double(), requires_grad=False)
        self.V = Variable(torch.from_numpy(V0).double(), requires_grad=False)

    def forward(self, x):
        x = Variable(torch.from_numpy(x).double(), requires_grad=False)

        self.mu = self.A @ self.mu + self.b
        self.V = self.A @ self.V @ self.A.t() + self.Q

        return self.mu, self.V

    
class DFLDS(nn.Module):
    def __init__(self, input_size, hyperparms, device):
        '''DF-RNN: Gaussian noise process as the local model
        https://arxiv.org/pdf/1905.12417.pdfのP12参照

        Parameters
        ----------
        input_size         : 特徴量の数        
        hyperparms : ハイパーパラメータ
            noise_nlayers      : ランダム効果のRNNの層数
            noise_hidden_size  : ランダム効果のRNNのユニット数
            global_nlayers     : グローバル効果のRNNの層数
            global_hidden_size : グローバル効果のRNNのユニット数
            n_global_factors   : グローバル効果の出力次元（固定効果の項の数）
        device : TYPE
            CPU or GPU.
        '''        
        super(DFLDS, self).__init__()
        self.noise = Noise(input_size, hyperparms['noise_hidden_size'], hyperparms['noise_nlayers'], hyperparms['dropout'])
        self.noise_list = nn.ModuleList([self.noise for i in range(hyperparms['target_num'])]) 
        self.global_factor = DeepFactor(input_size, hyperparms['global_nlayers'], 
                                        hyperparms['global_hidden_size'], hyperparms['n_global_factors'], hyperparms['dropout'])
        self.embed = nn.Linear(hyperparms['n_global_factors'], 1)
        self.embed_list = nn.ModuleList([self.embed for i in range(hyperparms['target_num'])])     
        self.device = device
    
    def forward(self, X):
        mu = []
        for i in range(X.size(3)):
            gt_i = self.global_factor(X[:,:,:,i])
            ft_i = self.embed_list[i](gt_i)
            mu_i = ft_i.sum(dim=1).view(-1, 1)
            mu.append(mu_i)
            
        sigma = [noise(X[:,:,:,i]) for i, noise in enumerate(self.noise_list)]
               
        return mu, sigma
    
    def predict_params(self, X):
        mu_, sigma_ = self.forward(X)
                
        num_t = mu_[0].shape[0]
        num_t_series = len(mu_)
        mu = torch.zeros(num_t, num_t_series)
        sigma = torch.zeros(num_t, num_t_series)        
        
        for i, [mu_i, sigma_i] in enumerate(zip(mu_, sigma_)):  
            mu[:,i] = mu_i.squeeze()
            sigma[:,i] = sigma_i.squeeze()            
            
        return mu, sigma
    
    def sample(self, X, num_samples):
        mu, sigma = self.forward(X)
                
        num_t = mu[0].shape[0]
        num_t_series = len(mu)
        z = torch.zeros(num_t, num_t_series)
        
        for i, [mu_i, sigma_i] in enumerate(zip(mu, sigma)):  
            for _ in range(num_samples):
                dist = torch.distributions.normal.Normal(loc=mu_i, scale=sigma_i)
                zs = dist.sample().view(num_t)
                z[:, i] += zs
                
            z[:, i] = z[:, i] / num_samples
            
        return z
        