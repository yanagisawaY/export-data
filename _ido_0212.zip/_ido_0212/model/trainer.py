# -*- coding: utf-8 -*-
"""
@author: Yangisawa
"""
import numpy as np
import torch
import time
import random
import matplotlib.pyplot as plt
from model import deep_factors
import sys

class Trainer:
    def __init__(self, hyperparms, epoch, loader_train, config):
        '''
            学習を行うクラス            
        '''            
        self.hyperparms = hyperparms            
        self.epoch = epoch
        self.loader_train = loader_train
        self.config = config
        for temp, _ in loader_train:pass
        input_size = temp.shape[2]
        self.model_name = self.config['model_name']
        self.random_seed = config['random_seed']

        if config['model_name'] == 'deep_factors':
            self.model = deep_factors.DFRNN(input_size, hyperparms, config['device'])
        else:
            sys.exit('config内のmodel_nameに想定外のインプットが入っています')
         
    def train(self, is_plot_hist = False):            
        '''
            損失関数を最小化するようモデルの学習を行う

        hist_loss : TYPE
            各エポック処理後の損失関数.
        '''
        # 乱数の設定
        np.random.seed(self.random_seed)
        random.seed(self.random_seed)
        torch.manual_seed(self.random_seed)
        torch.cuda.manual_seed(self.random_seed)

        optimizer = torch.optim.Adam(self.model.parameters(), lr = self.hyperparms['lr'])
            
        start = time.time()
        hist_loss = []
        print('訓練開始… ', self.model_name)
        for epoch_i in range(self.epoch):
            for t, [_X_train, _Y_train] in enumerate(self.loader_train):
                mu, sigma = self.model(_X_train)
                
                loss = 0
                for i, [mu_i, sigma_i] in enumerate(zip(mu, sigma)):
                    loss += self.gaussian_likelihood_loss(_Y_train[:,i], mu_i, sigma_i)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                
            hist_loss.append(loss.item())
            elapsed_time = time.time() - start
            print(f'Epoch {epoch_i+1} {round(elapsed_time/60,1)}min loss: {loss.item()} mu: {mu_i[0].item()} sigma: {sigma_i[0].item()}')
            
        print(f'{self.model_name} 実行終了：{round(elapsed_time/60,1)}min')                 
        if is_plot_hist:
            plt.plot(hist_loss)
            if self.epoch > 10:
                plt.xlim(10, len(hist_loss))
                plt.ylim(min(hist_loss[10:]), max(hist_loss[10:]))             
            plt.ylabel('loss')  
            plt.xlabel('epoch')              
            plt.show()
            
        return self.model, hist_loss
    
    def predict_params(self, loader_fit):
        '''予測分布の平均と標準偏差
        loader_fit : 特徴量データ
        '''        
        for t, [_X, _Y] in enumerate(loader_fit):
            if t==0:
                mu, sigma = self.model.predict_params(_X)
            else:
                raise ValueError('loader_fitのエポック数は1とする')
            
        return mu, sigma
    
    def sample(self, loader_fit, num_samples=100):
        '''予測分布のサンプリング
        loader_fit : 特徴量データ
        '''
        for t, [_X, _Y] in enumerate(loader_fit):
            if t==0:
                samples = self.model.sample(_X, num_samples)
            else:
                raise ValueError('loader_fitのエポック数は1とする')
            
        return samples
    
    def gaussian_likelihood_loss(self, z, mu, sigma):
        '''
        Gaussian Liklihood Loss
        Args:
        z (tensor): true observations, shape (num_ts, num_periods)
        mu (tensor): mean, shape (num_ts, num_periods)
        sigma (tensor): standard deviation, shape (num_ts, num_periods)
        '''
        # negative_likelihood = 2*torch.log(sigma) + (z - mu)**2 / (2*sigma**2)
        negative_likelihood = torch.log(sigma) +  0.5*((z - mu)/sigma)**2
        return negative_likelihood.mean()        
        
    def gaussian_likelihood_loss_(self, z, mu, sigma):
        '''
        Gaussian Liklihood Loss
        Args:
        z (tensor): true observations, shape (num_ts, num_periods)
        mu (tensor): mean, shape (num_ts, num_periods)
        sigma (tensor): standard deviation, shape (num_ts, num_periods)
    
        likelihood: 
        (2 pi sigma^2)^(-1/2) exp(-(z - mu)^2 / (2 sigma^2))
    
        log likelihood:
        -1/2 * (log (2 pi) + 2 * log (sigma)) - (z - mu)^2 / (2 sigma^2)
        '''
        negative_likelihood = torch.log(sigma + 1) + (z - mu) ** 2 / (2 * sigma ** 2) + 6
        return negative_likelihood.mean()    
    