# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文をコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Note : 
    Diversifier
        Diversification Strategyを実施するクラス
    Company
        Companyにおける各機能を搭載するクラス
        Traderの機能はCompanyクラスのテンソル計算に包含されている
"""
import numpy as np
import pandas as pd
import seaborn as sns
import random
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LassoCV, Lasso
import scipy.optimize as sco
from sklearn.cluster import KMeans
from utils.cluster import cluster_KMeans_base
from  warnings import simplefilter
from sklearn.exceptions import ConvergenceWarning
simplefilter("ignore", category=ConvergenceWarning)

class Diversifier:
    def __init__(self, hyperparms_company_common):
        '''Diversification Strategyを実施するクラス        
        '''
        self.hyperparms_company_common = hyperparms_company_common
        
        if hyperparms_company_common['max_factors']=='auto':
            self.max_factors = 1/3
        else:
            self.max_factors = hyperparms_company_common['max_factors']            
            assert not isinstance(self.max_factors, str)
            assert self.max_factors>0 and self.max_factors<=1
            
    @staticmethod    
    def weight_adjust(x):
        '''ウェイトがマイナスになったものは絶対値に置き換え，合計が1になるように正規化
        '''
        x_max = [np.abs(i) for i in x]
        weight = x_max/sum(x_max)
        
        return weight
    
    def make_distance_mat(self, port_return):
        '''
            各戦略のポートフォリオのリターンから相関係数行列を算出し，
            相関係数行列を距離の公理を満たす値に変換後，距離行列を作成

        Parameters
        ----------
        port_return : np.array
            各投資戦略のポートフォリオリターン.(戦略,時点)

        Returns
        -------
        corr_distance : np.array
            距離行列.
        '''
        corr_distance = 0.5*(1-np.corrcoef(port_return))**0.5
        
        return corr_distance
    
    def cluster(self, corr_distance, is_visulaize=False):
        '''
            距離行列をもとにK-means++によりクラスタリング

        Parameters
        ----------
        corr_distance : np.array
            距離行列.

        Returns
        -------
        clusters : dict
            各クラスターに属するID番号.
        '''


        corr_resort, clusters, silh = cluster_KMeans_base(corr_distance, 
                                                          self.hyperparms_company_common['min_num_clusters'],
                                                          self.hyperparms_company_common['max_num_clusters'],
                                                          self.hyperparms_company_common['n_init_clusters'], 
                                                          self.hyperparms_company_common['random_seed'])
                
        if is_visulaize:
            sns.heatmap(corr_resort)
        
        return clusters
    
    def get_factor_subsample(self, clusters):
        '''
            n_subgroupごとに割り当てられたファクター番号をサンプリング

        Parameters
        ----------
        clusters : dict
            各クラスターに属するID番号.

        Returns
        -------
        factor_subgroup : np.array
            n_subgroupごとに割り当てられたファクター番号. (n_subgroup, サンプリングされたファクター数) 
        '''
        factor_subgroup = []
        for n_subgroup in range(self.hyperparms_company_common['n_subgroup']):
            factor_list = []
            for i, (key, val) in enumerate(clusters.items()):
                np.random.seed(self.hyperparms_company_common['random_seed'] + i + n_subgroup)
                factor_list += list(np.random.choice(val, size=int(len(val)*self.max_factors), replace=False))
            factor_subgroup.append(factor_list)
        
        factor_subgroup = np.array(factor_subgroup)
        
        return factor_subgroup

    def assign_factor_group(self, factor_return, traders_sector, factor_subgroup, factor_subgroup_weight):
        '''
            各トレーダーのファクターのサブグループを付与

        Parameters
        ----------
        factor_return : np.array
            ファクター値に基づくLSポートフォリオのリターン.(ファクター数,時点)
        traders_sector : list
            各トレーダーに付与されたセクター.
        factor_subgroup : np.array
             n_subgroupごとに割り当てられたファクター番号. (n_subgroup, サンプリングされたファクター数) 
        factor_subgroup_weight : np.array
            サブサンプルごとのファクターウェイト.(サブサンプル,割り当てられたファクター数)

        Returns
        -------
        traders_factor : np.array
            トレーダーごとに割り当てられたファクター.(トレーダー,割り当てられたファクター数)
        traders_factor_weight :np.array
            トレーダーごとに割り当てられたファクターウェイト.(トレーダー,割り当てられたファクター数)
        traders_info : np.array
            各トレーダーに付与されたセクター(0行目)とファクターサブサンプルの割り当て値(1行目)と.(2, トレーダー数)
        '''        
        sector_all = np.unique(traders_sector)
        traders_factor = np.array(traders_sector)
        traders_factor = np.zeros((len(traders_sector), factor_subgroup.shape[1]))
        traders_factor_weight = np.zeros((len(traders_sector), factor_subgroup.shape[1]))
        for i, sector in enumerate(sector_all):
            traders_extracted = np.where(np.array(traders_sector)==sector)[0]
            count = len(traders_extracted)
            subgroup_id = list(range(self.hyperparms_company_common['n_subgroup']))
            np.random.seed(self.hyperparms_company_common['random_seed'] + i)
            subgroup_list = list(np.random.choice(subgroup_id, size=count, replace=True))
            for j, subgroup in enumerate(subgroup_list):
                traders_factor[traders_extracted[j],:] = factor_subgroup[subgroup,:]
                traders_factor_weight[traders_extracted[j],:] = factor_subgroup_weight[subgroup,:]
        
        traders_info = np.array([traders_sector, subgroup_list])
        
        return traders_factor, traders_factor_weight, traders_info
            
    def init_factor_weight(self, X_train, y_train, factor_subgroup):
        '''
            サブグループごとにファクターウェイトを付与

        Parameters
        ----------
        X_train : np.array
            ファクターリターン.(ファクター数,時点,銘柄)
        y_train : np.array
            各アセットのリターン.(時点,銘柄)
        factor_subgroup : np.array
             n_subgroupごとに割り当てられたファクター番号. (n_subgroup, サンプリングされたファクター数) 
             
        Returns
        -------
        factor_subgroup_weight : np.array
            サブサンプルごとのファクターウェイト.(サブサンプル,割り当てられたファクター数)
        '''        
        factor_subgroup_weight = np.zeros(factor_subgroup.shape)
        y_train_ = y_train.reshape(-1)        
        for i in range(factor_subgroup.shape[0]):
            subgroup = factor_subgroup[i,:]
            X_train_ = X_train[subgroup,:,:].reshape(-1, X_train.shape[1]*X_train.shape[2]).T
            y_train_scaled = (y_train_ - np.mean(y_train_))/np.std(y_train_)
            
            alphas_ = [10**(-i) for i in range(3, 6)]
            reg = LassoCV(cv=5, random_state=self.hyperparms_company_common['random_seed'], alphas=alphas_).fit(X_train_, y_train_scaled)
            if sum(reg.coef_) == 0:
                reg = Lasso(random_state=self.hyperparms_company_common['random_seed'], alpha=0).fit(X_train_, y_train_scaled)
                
            factor_subgroup_weight[i,:] = reg.coef_
            
            min_val_minus = min_val_plus = 0
            minus_flag = factor_subgroup_weight[i,:]<0
            if sum(minus_flag) > 0:
                min_val_minus = np.min(factor_subgroup_weight[i, minus_flag])

            plus_flag = factor_subgroup_weight[i,:]>0
            if sum(plus_flag) > 0:                
                min_val_plus = np.min(factor_subgroup_weight[i, plus_flag])  
                
            count_zero = sum(factor_subgroup_weight[i,:]==0)
            samples = min_val_minus + np.random.random_sample(count_zero)*(min_val_plus - min_val_minus)
            
            factor_subgroup_weight[i,factor_subgroup_weight[i,:]==0] = samples
        
        return factor_subgroup_weight

class Company(Diversifier):
    def __init__(self, hyperparms_company_common, factor_num):   
        '''
        Parameters
        ----------
        hyperparms_company_common : dict
            トレーダに関する共通のハイパーパラメータ.
        factor_num : int
            ファクターの数            
        '''
        super().__init__(self.hyperparms_company_common)  
        self.hyperparms_company_common = hyperparms_company_common
        self.factor_num = factor_num
        self.trader_type = hyperparms_company_common['trader_type']
        self.long_ratio = hyperparms_company_common['trader_long']
        self.short_ratio = hyperparms_company_common['trader_short']
        self.cost = hyperparms_company_common['cost']
        
    @staticmethod
    def make_onehot_factor(x, max_num, random_seed):
        random.seed(random_seed)
        string = list('1'*x+'0'*(max_num-x))
        random.shuffle(string)
        return [int(x) for x in string]

    @staticmethod    
    def make_onehot_factor_diversified(x, max_num, trader_factor, random_seed):
        random.seed(random_seed)    
        sampling = np.random.choice(trader_factor, size=x)
        string = list('0'*max_num)
        for i in sampling:
            string[int(i)] = '1'    
        return [int(x) for x in string]

    @staticmethod
    def make_onehot_NA(x, max_num):
        string = '1'*x+'0'*(max_num-x)
        return [int(x) if int(x) == 1 else np.nan for x in string]

    @staticmethod    
    def softmax_weight(x):
        '''NA値を除き，ソフトマックス関数により変換
        '''        
        x_dropna = [i for i in x if np.isnan(i) == False]        
        weight = np.exp(x_dropna)/np.sum(np.exp(x_dropna))
        weight = [weight[i] if np.isnan(num) == False else 0 for i, num in enumerate(x)]
        
        return weight

    @staticmethod    
    def weight_norm(x):
        '''ウェイトがマイナスになったものは0.01に置き換え，合計が1になるように正規化
            ⇒戦略ウェイトを0とすると，以降戦略数が減ってしまうため，0.01に置き換える
            ⇒xの要素が0より大きい前提で合計1となるような正規化を実施
        '''
        x_max = [max(i, 0.01) if i!=0 else 0 for i in x]
        weight = [max(i, 0.01)/sum(x_max) if i!=0 else 0 for i in x]
        
        return weight
    
    @staticmethod    
    def check_numpy_fillna(y_train):
        if not isinstance(y_train, np.ndarray):
            y_train = np.array(y_train)
            
        # 欠損値を0に置き換え
        y_train = np.nan_to_num(y_train)
        
        return y_train

    def check_ticker_info(self, ticker_info):
        '''
            ticker_infoとstock_listにある銘柄情報が互いに包含できているかを確認

        Parameters
        ----------
        ticker_info : dict
            ティッカー情報の辞書.

        Returns
        -------
        ticker_info_list : list
            ティッカー情報に格納された銘柄リスト.
        '''
        # stock_listと対応させる
        ticker_info_list = [key for key, val in ticker_info.items() if key in self.stock_list]
        assert len(ticker_info_list)==len(self.stock_list) , 'ticker_infoがstock_listにある銘柄情報を包含できていません'
        assert len(ticker_info)==len(self.stock_list) , 'stock_listがticker_infoにある銘柄情報を包含できていません'

    def calc_factor_return(self, X_train, y_train):
        '''
            ファクター値が大きい銘柄順にソートし，上位をロング，下位をショートするLSポートフォリオを構築

        Parameters
        ----------
        X_train : np.array
            ファクターリターン.(ファクター数,時点,銘柄)
        y_train : np.array
            各アセットのリターン.(時点,銘柄)

        Returns
        -------
        factor_return : np.array
            ファクター値に基づくLSポートフォリオのリターン.(ファクター数,時点)
        '''
        def calc_weight(scores, ratio, flag='Long'):
            # 閾値を超えた銘柄に対し，等ウェイトポートフォリオを構築
            if flag=='Long':
                target = 1*(scores>=ratio)
            elif flag=='Short':
                target = 1*(scores<=ratio)*(scores>=0)
            target_num = target.sum(2)[:,:,np.newaxis]
            target_num = np.repeat(target_num, scores.shape[2], axis=2)
            target = target/target_num
        
            return target
        
        weight = calc_weight(scores=X_train, ratio=self.long_ratio, flag='Long') \
            - calc_weight(scores=X_train, ratio=self.short_ratio, flag='Short')
        factor_return = np.einsum("kts, ts->kts", weight, y_train).sum(2)
        
        return factor_return
            
    def get_factors_init(self, X_train, y_train, traders_sector):
        '''
            各ファクター戦略への投資ウェイトに応じて各トレーダーが着目するファクターの初期値を生成

        Parameters
        ----------
        X_train : np.array
            ファクターリターン.
        y_train : np.array
            各アセットのリターン.
        traders_sector : dict
            トレーダーの担当セクター
            
        Returns
        -------
        mask_factor : np.array
            ファクターマスク.(ファクター数,戦略,トレーダー)
        traders_info : np.array
            各トレーダーに付与されたセクター(0行目)とファクターサブサンプルの割り当て値(1行目)と.(2, トレーダー数)            
        traders_factor_weight :np.array
            トレーダーごとに割り当てられたファクターウェイト.(トレーダー,割り当てられたファクター数)
        factor_subgroup : np.array
             n_subgroupごとに割り当てられたファクター番号. (n_subgroup, サンプリングされたファクター数)
        '''
        factor_return = self.calc_factor_return(X_train, y_train)
        corr_distance = self.make_distance_mat(factor_return)
        clusters = self.cluster(corr_distance)
        factor_subgroup = self.get_factor_subsample(clusters)
        factor_subgroup_weight = self.init_factor_weight(X_train, y_train, factor_subgroup)
        traders_factor, traders_factor_weight, traders_info = self.assign_factor_group(factor_return, traders_sector, factor_subgroup, factor_subgroup_weight)
        
        mask_factor = [[self.make_onehot_factor_diversified(np.random.randint(1, self.hyperparms_company_common['K_factor']+1),
                                                            self.factor_num,
                                                            traders_factor[trader_j,:],
                                                            random_seed=self.hyperparms_company_common['random_seed']+i+trader_j*self.hyperparms_company_common['M_strategy']) \
                        for i in range(self.hyperparms_company_common['M_strategy'])] \
                        for trader_j in range(self.hyperparms_company_common['N_trader'])]
        
        mask_factor = np.array(mask_factor)
        
        return mask_factor, traders_info, traders_factor_weight, factor_subgroup
            
    def get_all_traders_init(self, X_train, y_train, traders_sector):
        '''
            全トレーダーの戦略の初期値を取得
        
        Parameters
        ----------
        X_train : np.array
            ファクターリターン.
        y_train : np.array
            各アセットのリターン.
        traders_sector : dict
            トレーダーの担当セクター
            
        Returns
        -------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト
        mask_factor : np.array
            ファクターマスク.(ファクター数,戦略,トレーダー)
        mask_strategy : np.array
            ストラテジーマスク.(トレーダー, 戦略数)
        traders_info : np.array
            各トレーダーに付与されたセクター(0行目)とファクターサブサンプルの割り当て値(1行目)と.(2, トレーダー数)                        
        '''        
        random.seed(self.hyperparms_company_common['random_seed'])
        np.random.seed(self.hyperparms_company_common['random_seed'])
        
        mask_factor, traders_info, traders_factor_weight, factor_subgroup = self.get_factors_init(X_train, y_train, traders_sector)
        
        mask_strategy = [self.make_onehot_NA(np.random.randint(1, self.hyperparms_company_common['M_strategy']+1),
                                             self.hyperparms_company_common['M_strategy']) \
                         for _ in range(self.hyperparms_company_common['N_trader'])]
        mask_strategy = np.array(mask_strategy)
        
        # factor_weightはLASSOCVによる重みづけをもとに設定
        factor_weight = np.zeros((self.hyperparms_company_common['N_trader'],
                                  self.hyperparms_company_common['M_strategy'],
                                  self.factor_num))
        
        for i in range(self.hyperparms_company_common['N_trader']):
            factor_weight[i,:, factor_subgroup[int(traders_info[1,i]),:]] = np.tile(traders_factor_weight[i,:], (2, 1)).T

        factor_weight = mask_factor*np.array(factor_weight)        
        
        # 0~1 の一様乱数とマスク情報をもとに，NA値を除いたソフトマックス関数により変換した値を生成
        strategy_weight = [self.softmax_weight(np.random.rand(self.hyperparms_company_common['M_strategy'])*mask_strategy[i,:]) \
                           for i in range(self.hyperparms_company_common['N_trader'])]
                 
        strategy_weight = np.array(strategy_weight)                 
                                   
        return factor_weight, strategy_weight, mask_factor, mask_strategy, traders_info
    
    def make_screaning_mask(self, ticker_info, time_num, stock_num, traders_sector=[]):
        '''
            スクリーニングマスクの作成 (トレーダー,　時点, 銘柄)
            各トレーダーの担当セクターをランダムに設定
            ⇒事前に指定することも可能ではあるが現状その機能はいれていない
        Parameters
        ----------
        ticker_info : dict
            各銘柄のセクター情報.
        time_num : int
            時点数（マスクのサイズ指定に使用）
        stock_num : int
            銘柄数（マスクのサイズ指定に使用）
        traders_sector : 
            トレーダーの担当セクターを事前に与える
            ※ 現状，スクリーニングにはセクター情報しか使っていないが，機能変更も可能            
        Returns
        -------
        screaning_mask : np.array
            スクリーニングマスク. (トレーダー,　時点, 銘柄)
        '''
        if len(ticker_info) > 0:
            # ticker_infoとstock_listにある銘柄情報の包含関係を確認
            self.check_ticker_info(ticker_info)
            
            ticker_info = {key : val for key, val in ticker_info.items() if key in self.stock_list}
            info_unique = sorted(set(ticker_info.values()))
            info_dict = dict(zip(info_unique, [[] for _ in info_unique]))
            for key, val in ticker_info.items():
                info_dict[val] += [key]            
                
            # 訓練データの場合，トレーダーの担当セクターをランダムに生成
            # テストデータの場合，訓練データ使用時のものを使用
            if len(traders_sector) == 0:
                # 各トレーダーの担当セクターをランダムに設定
                np.random.seed(self.hyperparms_company_common['random_seed'])        
                info_dict_count = [len(val)/stock_num for key, val in info_dict.items()]
                traders_sector = list(np.random.choice(info_unique, p=info_dict_count, size=self.hyperparms_company_common['N_trader']))
    
           # マスクされたテンソルの作成
            screaning_mask = np.zeros((self.hyperparms_company_common['N_trader'], time_num, stock_num))
            for i, key in enumerate(traders_sector):
                index_ = [np.where(np.array(self.stock_list)==x)[0][0] for x in info_dict[key]]
                screaning_mask[i:i+1, :, index_] = np.ones((time_num, len(index_)))
        else:
            print('スクリーニングの設定なし')
            screaning_mask = np.ones((self.hyperparms_company_common['N_trader'], time_num, stock_num))        
            if len(traders_sector) == 0:            
                # 各トレーダーは全ユニバースを対象
                traders_sector = ['All' for _ in range(self.hyperparms_company_common['N_trader'])]
                
        return screaning_mask, traders_sector

    def make_tradable_mask(self, y_train={}, X_test={}):
        '''
            トレーダブルマスクの作成 (時点，銘柄)

        Parameters
        ----------
        y_train : pd.DataFrame
            各アセットのリターン情報.
        X_test : np.darray
            テストデータ時の特徴量データ⇒特徴量データからマスクを作成
            
        Returns
        -------
        tradable_mask : np.array
            トレーダブルマスク
        '''
        if len(X_test) == 0:
            tradable_mask = (y_train!=np.nan).values*1
        else:
            tradable_mask = np.ones((X_test.shape[1], X_test.shape[2]))
        
        return tradable_mask
    
    def make_universe_mask(self, screaning_mask, tradable_mask):
        '''
            ユニバースマスクの作成 (トレーダー, 時点，銘柄)

        Parameters
        ----------
        screaning_mask : np.array
            スクリーニングマスク. (トレーダー,　時点, 銘柄)
        tradable_mask : np.array
            トレーダブルマスク

        Returns
        -------
        universe_mask : np.array
            ユニバースマスク(トレーダー, 時点，銘柄)
        '''
        universe_mask = np.einsum("mts, ts->mts", screaning_mask, tradable_mask)
        
        return universe_mask

    def make_scores(self, factor_weight, universe_mask, factor_tables):
        '''
            各時点，銘柄ごとのスクリーニング後の相対的魅力度スコアを算出
            (0以上の値が取引対象（0より小さい値は取引対象外）となるようにスコアを調整)
        Parameters
        ----------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト　(トレーダー, 戦略, ファクター数)
        universe_mask : np.array
            ユニバースマスク (トレーダー, 時点，　銘柄)            
        factor_tables : np.array
            各銘柄のファクタースコア（≒ X_train）  (ファクター数, 時点， 銘柄)
            
        Returns
        -------
        scores : numpy.array
            各時点，銘柄ごとの相対的魅力度スコア.  (トレーダー, 戦略, 時点， 銘柄)
        universe_mask_weight : numpy.array
            各トレーダーがマスクしない銘柄に関するウェイト(トレーダー,)            
        '''
        strategy_num = factor_weight.shape[1]
        stock_num = factor_tables.shape[2]
        
        scores = np.einsum("nmk,kts->nmts", factor_weight, factor_tables)

        # 各トレーダーにおけるマスク銘柄数 + 1 (トレーダー,)
        universe_mask_num = stock_num - universe_mask.sum(2)[:,0]
        
        # 各トレーダーがマスクしない銘柄が1以上となるようなウェイトを計算        
        universe_mask_weight = 1/(universe_mask_num + 1)

        # スコアの単調性を維持しつつ，0より大きい数値に変換        
        scores = (scores - np.min(scores))+0.1
        
        # マスク値の設定⇒マスク値は0，それ以外は0より大きい数とする
        universe_mask = universe_mask[:,np.newaxis,:,:]
        universe_mask = np.repeat(universe_mask, strategy_num, axis=1)
        scores = universe_mask*scores
        
        # 0以上の値が取引対象となるようにスコアを調整
        scores = np.einsum("nmts, n->nmts", np.argsort(np.argsort(scores, axis=3), axis=3) + 1, universe_mask_weight) - 1
                
        return scores, universe_mask_weight
    
    def calc_traders_weight(self, scores, universe_mask_weight):
        '''
            各時点，銘柄ごとの投資ウェイト（LS戦略）を算出

        Parameters
        ----------
        scores : np.array (トレーダー, 戦略, 時点， 銘柄)
            各時点，銘柄ごとの相対的魅力度スコア.
        universe_mask_weight : numpy.array
            各トレーダーがマスクしない銘柄に関するウェイト(トレーダー,)            
            
        Returns
        -------
        traders_weight : np.array (トレーダー, 戦略, 時点， 銘柄)
            各時点，銘柄ごとの投資ウェイト.
        '''               
        def repeat_axis(x):
            x = x[:,np.newaxis,np.newaxis,np.newaxis]
            for i in range(1, 3):
                x = np.repeat(x, scores.shape[i], axis=i)
            return x
        
        def calc_weight(scores, ratio, flag='Long'):
            # 閾値を超えた銘柄に対し，等ウェイトポートフォリオを構築
            if flag=='Long':
                target = 1*(scores>=ratio)
                target_num = target.sum(3)[:,:,:,np.newaxis]
                target_num = np.repeat(target_num, scores.shape[3], axis=3)
                target = target/target_num
            elif flag=='Short':
                target = 1*(scores<=ratio)*(scores>=0)
                target_num = target.sum(3)[:,:,:,np.newaxis]
                target_num = np.repeat(target_num, scores.shape[3], axis=3)
                target = target/target_num
            
            return target

        stock_num = scores.shape[3]
        long_ratio = self.long_ratio*(stock_num*universe_mask_weight - 1)
        long_ratio = repeat_axis(long_ratio)
        
        if self.trader_type == 'LongShort':
            short_ratio = self.short_ratio*(stock_num*universe_mask_weight - 1)
            short_ratio = repeat_axis(short_ratio)
            traders_weight = calc_weight(scores, long_ratio, flag='Long') - calc_weight(scores, short_ratio, flag='Short')
        elif self.trader_type == 'Long':
            traders_weight = calc_weight(scores, long_ratio, flag='Long')
        else:
            raise ValueError('trader_typeに予想外のインプットが入力されています')
        
        return traders_weight

    def calc_traders_weight_all(self, traders_weight, strategy_weight):
        '''
            トレーダーの全戦略の投資ウェイトを算出する

        Parameters
        ----------
        traders_weight : np.array
            各時点，銘柄ごとの投資ウェイト. : (トレーダー, 戦略, 時点， 銘柄)
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト.(トレーダー, 戦略)

        Returns
        -------
        traders_weight_all : np.array
            トレーダーの全戦略の投資ウェイト. : (トレーダー, 時点, 銘柄)
        '''
        traders_weight_all = np.einsum("nmts, nm->nmts", traders_weight, strategy_weight).sum(1)
        
        return traders_weight_all

    def calc_return_traders(self, traders_weight_all, y_train):
        '''
            戦略ウェイト統合後のトレーダーのリターンを算出

        Parameters
        ----------
        traders_weight : np.array
            各時点，銘柄ごとの投資ウェイト. : (トレーダー, 時点， 銘柄)
        y_train : np.array or pd.DataFrame
            各アセットのリターン. : (時点， 銘柄)

        Returns
        -------
        traders_return : np.array
            トレーダーごとの取引コスト控除後リターン. : (時点, トレーダー)
        '''
        y_train = self.check_numpy_fillna(y_train)
        zeros = np.zeros((traders_weight_all.shape[0], 1))
        cost = np.concatenate([zeros, (np.abs(np.diff(traders_weight_all, n=1, axis=1))*self.cost).sum(axis=2)], axis=1)
        traders_return = np.einsum("nts, ts->nts", traders_weight_all, y_train).sum(2) - cost
        # 行方向に時点がくるように転置する
        traders_return = traders_return.T
                
        return traders_return
    
    def calc_return_strategy(self, traders_weight, y_train):
        '''
            トレーダーの各戦略のリターンを算出

        Parameters
        ----------
        traders_weight : np.array
            各時点，銘柄ごとの投資ウェイト. : (トレーダー, 戦略, 時点， 銘柄)
        y_train : TYPE
            各アセットのリターン. : (時点， 銘柄)

        Returns
        -------
        traders_return_all : np.array
            トレーダーの各戦略の取引コスト控除後リターン. : (トレーダー, 戦略, 時点)
        '''
        y_train = self.check_numpy_fillna(y_train)        
        zeros = np.zeros((traders_weight.shape[0], traders_weight.shape[1], 1))
        cost = np.concatenate([zeros, (np.abs(np.diff(traders_weight, n=1, axis=2))*self.cost).sum(axis=3)], axis=2)
        traders_return_all = np.einsum("nmts, ts->nmts", traders_weight, y_train).sum(3) - cost
        
        return traders_return_all

    def calc_return_company(self, company_weight, y_train):
        '''
            カンパニーの投資ウェイトからリターンを算出する

        Parameters
        ----------
        traders_weight : np.array
            各時点，銘柄ごとの投資ウェイト. : (時点， 銘柄)
        y_train : np.array or pd.DataFrame
            各アセットのリターン. : (時点， 銘柄)

        Returns
        -------
        traders_return_all : np.array
            取引コスト控除後リターン. : (時点)
        '''
        y_train = self.check_numpy_fillna(y_train)                
        zeros = np.zeros((1))
        cost = np.concatenate([zeros, (np.abs(np.diff(company_weight, n=1, axis=0))*self.cost).sum(axis=1)], axis=0)
        traders_return_all = np.einsum("ts, ts->ts", company_weight, y_train).sum(1) - cost
        
        return traders_return_all
    
    def calc_return_from_all(self, traders_return_all, strategy_weight):
        '''
            トレーダーの各戦略のリターンから，トレーダーの全戦略を統合したリターンを算出

        Parameters
        ----------
        traders_return_all : np.array
            トレーダーの各戦略のリターン.　 (トレーダー, 戦略, 時点)
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト.　(トレーダー, 戦略)

        Returns
        -------
        traders_return : np.array (時点, トレーダー)
            トレーダーの全戦略を統合したリターン.
        '''
        traders_return = np.einsum("nmt, nm->nmt", traders_return_all, strategy_weight).sum(1)
        # 行方向に時点がくるように転置する
        traders_return = traders_return.T
        
        return traders_return
        
    def calc_return(self, factor_weight, strategy_weight, universe_mask, X_train, y_train):
        '''
            トレーダーの全戦略を統合したリターンを算出        

        Parameters
        ----------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト (トレーダー, 戦略, ファクター)
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト (トレーダー, 戦略)
        universe_mask : np.array
            ユニバースマスク(トレーダー, 時点，銘柄)            
        X_train : np.array
            ファクターリターン.
        y_train : np.array or pd.DataFrame
            各アセットのリターン.

        Returns
        -------
        traders_return : np.array
            トレーダーの全戦略を統合したリターン.
        '''        
        traders_return = self.calc_return_traders(self.calc_traders_weight_all(\
                        self.calc_traders_weight(*self.make_scores(factor_weight, universe_mask, X_train)),
                        strategy_weight), y_train)
        
        return traders_return

    def update_weight(self, each_strategy_return):  
        '''
            各戦略へのウェイトを標準化された接点ポートフォリオを基準に更新する
            （※リスクフリーレートを0としたときの接点ポートフォリオの解析解を使用）
            以下ドキュメントP.5の式を参考に更新
            https://repository.tku.ac.jp/dspace/bitstream/11150/11454/1/keizai305-03.pdf
        Parameters
        ----------
        each_strategy_return : pandas.DataFrame
            各戦略の実績リターン.    
            
        Returns
        -------

        '''
        r = each_strategy_return.mean(1)
        try:
            sigma = np.cov(each_strategy_return)
            sigma_T = np.linalg.inv(sigma)
            numerator = sigma_T@r
            weight = sigma_T@r /sum(numerator)
        except:
            print('逆行列を含む計算過程でエラーが発生しました．代わりに戦略ウェイトを等ウェイトとして出力します．')
            weight = [1/len(r) for _ in range(len(r))]
        
        return weight
    
    def measure_trader_return(self, traders_return, method_measure):        
        '''
            トレーダーのパフォーマンスを測定

        Parameters
        ----------
        traders_return : TYPE (トレーダー, 時点)
            全時点，全トレーダーのハイパーパラメータ.
        method_measure : TYPE
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ

        Returns
        -------
        traders_performance : np.array
            各トレーダーのパフォーマンス
        '''                        
        if method_measure == 'CR':
            # 累積リターン
            traders_return_cumsum = traders_return.cumsum(0)
            traders_performance = traders_return_cumsum[-1,:]
        elif method_measure == 'SR':
            # シャープレシオ            
            traders_return_mean = traders_return.mean(0)
            traders_return_sd = traders_return.std(0)            
            traders_performance = traders_return_mean/traders_return_sd
        elif method_measure == 'DDR':
            # DDレシオ            
            traders_return_mean = traders_return.mean(0)
            traders_return_DD = np.sqrt(np.sum((traders_return[traders_return<0] ** 2))/len(traders_return))
            traders_performance = traders_return_mean/traders_return_DD            
        else:
            raise ValueError(f'"method_measure"は，{method_measure}には対応していません')            
        
        return traders_performance
    
    def collect_bad_traders(self, traders_return, method_measure, traders_info):
        '''
            サブサンプルごとにパフォーマンスの悪いトレーダーを抽出し，フラグを作成
            
        Parameters
        ----------
        traders_return : np.array
            全時点，全トレーダーのハイパーパラメータ.(時点,トレーダー)
        method_measure : str, optional
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ
        traders_info : np.array
            各トレーダーに付与されたセクター(0行目)とファクターサブサンプルの割り当て値(1行目)と.(2, トレーダー数)
            
        Returns
        -------
        is_bad_traders : list
            パフォーマンスの悪いトレーダーのフラグ.
        '''
        traders_performance = self.measure_trader_return(traders_return, method_measure=method_measure)        
        subsamples_unique = np.unique(traders_info[1,:])
        
        bottom_quantile_save = 0
        is_bad_traders = np.zeros((len(traders_performance)))
        for subsample in subsamples_unique:
            traders_extracted = subsample==traders_info[1,:]
            bottom_quantile = np.quantile(traders_performance[traders_extracted], 
                                          self.hyperparms_company_common['Q_quantile_educate'])
            bottom_quantile_save += bottom_quantile
            is_bad_traders[traders_extracted] = list(traders_performance[traders_extracted] <= bottom_quantile)

        print(f'bottom quantile: {method_measure} - {round(bottom_quantile_save/len(subsamples_unique), 5)}') 
        
        return is_bad_traders, traders_performance

    def make_parameters_list(self, factor_weight, strategy_weight, traders_info):
        '''
            各トレーダーのパラメータをデータフレーム形式(numpy)で出力        

        Parameters
        ----------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト
        traders_info : np.array
            各トレーダーに付与されたセクター(0行目)とファクターサブサンプルの割り当て値(1行目)と.(2, トレーダー数)
            
        Returns
        -------
        df : np.array
            各トレーダーのパラメータ
            (トレーダーID, strategy_ID, sector, subgroup, factor_ID, factor_weight, stategy_weight)
        '''
        df = []
        for n in range(strategy_weight.shape[0]):
            strategy_list = np.where(strategy_weight[n,:]!=0)[0]
            for m in range(len(strategy_list)):
                factor_list = np.where(factor_weight[n,m,:]!=0)[0]
                for k in range(len(factor_list)):
                    factor_ID = factor_list[k]
                    df.append([n, m, traders_info[0, n], traders_info[1, n], factor_ID, factor_weight[n,m,factor_ID], strategy_weight[n,m]])
        
        df = np.array(df)
        
        return df

    def make_tensor_from_params(self, df_params):
        '''
            パラメータが格納された行列をfactor_weightとstrategy_weightに変換

        Parameters
        ----------
        df_params : np.array
            各トレーダーのパラメータ

        Returns
        -------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト
        '''
        TRADERS_ID_COL = 0
        STRATEGY_ID_COL = 1
        FACTOR_ID_COL = 4        
        FACTOR_WEIGHT_COL = 5
        STRATEGY_WEIGHT_COL = 6
        
        factor_weight_ = np.zeros((self.hyperparms_company_common['N_trader'],
                                   self.hyperparms_company_common['M_strategy'], 
                                   self.factor_num))
        strategy_weight_ = np.zeros((self.hyperparms_company_common['N_trader'],
                                     self.hyperparms_company_common['M_strategy']))        
                
        for i in range(df_params.shape[0]):
            if strategy_weight_[int(df_params[i,TRADERS_ID_COL]), int(df_params[i,STRATEGY_ID_COL])]==0:
                strategy_weight_[int(df_params[i,TRADERS_ID_COL]), int(df_params[i,STRATEGY_ID_COL])] \
                    = float(df_params[i,STRATEGY_WEIGHT_COL])
            else:
                strategy_weight_[int(df_params[i,TRADERS_ID_COL]), int(df_params[i,1])] \
                    = (strategy_weight_[int(df_params[i,TRADERS_ID_COL]), int(df_params[i,STRATEGY_ID_COL])] \
                       + float(df_params[i,STRATEGY_WEIGHT_COL]))/2
            factor_weight_[int(df_params[i,TRADERS_ID_COL]), int(df_params[i,STRATEGY_ID_COL]), int(df_params[i,FACTOR_ID_COL])] = float(df_params[i,FACTOR_WEIGHT_COL])
        
        strategy_weight_ = np.array([self.weight_norm(strategy_weight_[i,:]) for i in range(strategy_weight_.shape[0])])
                            
        return factor_weight_, strategy_weight_

    def extract_traders(self, df_params, traders_ID):
        '''
            該当するトレーダーIDのパラメータ情報を抽出

        Parameters
        ----------
        df_params : np.array
            各トレーダーのパラメータ
        traders_ID : np.array
            トレーダーのID.

        Returns
        -------
        traders : np.array
            トレーダーの情報行列.
        '''
        traders = []
        for id_ in traders_ID:
            traders.append(df_params[df_params[:,0]==str(id_)])
        
        traders = np.concatenate(traders)                
        
        return traders
      
    def sample_gaussian_mix(self, good_traders, bad_traders, traders_info, random_seed):
        '''
            パフォーマンスのよいパラメータ値をサブサンプルごとにサンプリング

        Parameters
        ----------
        good_traders : np.array
            フィッテイング対象となるトレーダー（パフォーマンスのよいトレーダー情報）
        bad_traders : np.array
            サンプリング対象のトレーダーID（パフォーマンスのわるいトレーダーのID）
        traders_info : np.array
            各トレーダーに付与されたセクター(0行目)とファクターサブサンプルの割り当て値(1行目)と.(2, トレーダー数)            
        random_seed : int
            乱数シード.

        Returns
        -------
        bad_traders : np.array
            サンプリングされたbad tradersのパラメータ.
        '''        
        subsamples_unique = np.unique(traders_info[1,:])
        SUBSAMPLE_COL = 3
        bad_traders_new = np.array([[] for _ in range(good_traders.shape[1])]).T
        
        for i, subsample in enumerate(subsamples_unique):
            good_traders_subsample = good_traders[good_traders[:,SUBSAMPLE_COL]==subsample,:]            
            bad_traders_subsample = bad_traders[bad_traders[:,SUBSAMPLE_COL]==subsample,:]
            
            if good_traders_subsample.shape[0] < 3:
                import pdb
                pdb.set_trace()
            
            bad_traders_new_ = self.get_samples_gaussian_mix(good_traders_subsample, bad_traders_subsample, random_seed+i)
            bad_traders_new = np.append(bad_traders_new, bad_traders_new_, axis=0)
            
        return bad_traders_new

    def get_samples_gaussian_mix(self, good_traders, bad_traders, random_seed):
        '''
            パフォーマンスのよいパラメータ値を混合正規分布にあてはめ，サンプリング
            ※ 離散値を標準化⇒混合正規分布にフィット⇒逆変換後の値からもっとも近い離散値を新たらパラメータとして採用
            　　したがって，銘柄インデックスの最小値（最大値）は，フィットさせた確率分布でその値を下（上）回る累積確率分多く採用される傾向にあることに注意
              ⇒理想は混合切断正規分布のようなものからサンプリング．

        Parameters
        ----------
        good_traders : np.array
            フィッテイング対象となるトレーダー（パフォーマンスのよいトレーダー情報）
        bad_traders : np.array
            サンプリング対象のトレーダーID（パフォーマンスのわるいトレーダーのID）
        random_seed : int
            乱数シード.

        Returns
        -------
        bad_traders_new : np.array
            サンプリングされたbad tradersのパラメータ.
        '''
        # factor_idは順序性のない離散値であるため，数値を意図的にシャッフルする
        # ⇒もとのファクターの並び順に対し，ランダムに混合正規分布をフィットさせる
        unique_dict = {}
        list_temp = {}        
        
        # サンプリング対象のうち離散値の項目
        shuffle_dict = {
            'factor_id'     : 4,
            }
        
        good_traders_copy = good_traders.copy()
        for name, id_num in shuffle_dict.items():
            random.seed(random_seed + id_num)
            unique_names = np.unique(good_traders_copy[:,id_num])
            len_unique_names = len(unique_names)
            unique_names = random.sample(list(unique_names), len_unique_names)
            list_temp[name] = list(range(len(unique_names)))
            convert_dict = dict(zip(unique_names, list(range(len_unique_names))))
            unique_dict[name] = convert_dict       
            good_traders_copy[:,id_num] = np.array([convert_dict[x] for x in good_traders_copy[:,id_num]])

        random.seed(random_seed)
        FACTOR_ID_COL = 4
        gmm = GaussianMixture(n_components=self.hyperparms_company_common['GMM_n_components'], covariance_type='spherical', random_state=random_seed)
        sc = StandardScaler()
        sc.fit(good_traders_copy[:,FACTOR_ID_COL:])
        good_traders_scaled = sc.transform(good_traders_copy[:,FACTOR_ID_COL:])
        fitted = gmm.fit(good_traders_scaled)
        samples = sc.inverse_transform(fitted.sample(len(bad_traders))[0])
        samples[:,0] = np.round(samples[:,0]) # factor_idは整数化
        bad_traders_new = np.concatenate([bad_traders[:,0:FACTOR_ID_COL], samples], axis=1)

        def get_swap_dict(d):
            return {v: k for k, v in d.items()}
        
        def find_nearest(array, value):
            array = np.asarray(array)
            idx = (np.abs(array - value)).argmin()
            return array[idx]            
                
        # factor_idのindexで近い数のものを取り出し，それに対応するIDをconvert_dictから取り出す
        for name, id_num in shuffle_dict.items():
            bad_traders_new[:,id_num] = [int(get_swap_dict(unique_dict[name])[find_nearest(list_temp[name], int(float(x)))]) \
                                         for x in bad_traders_new[:,id_num]]
                    
        return bad_traders_new
    
    def opt_SR(self, mean, cov):
        '''
            シャープレシオ最大化によるポートフォリオ最適化を実施（下限制約あり）

        Parameters
        ----------
        mean : np.array
            投資対象の平均.
        cov : np.array
            投資対象の分散共分散行列.

        Returns
        -------
        weight : np.array
            ポートフォリオのウェイト.
        '''
        x0 = [1. / len(mean)] * len(mean)
        def min_func_var(weights):
            return np.dot(weights.T, np.dot(cov, weights))
        
        cons = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1}, 
                {'type': 'eq', 'fun': lambda x: np.sum(mean * x) - 1}]
        
        bnds = [(0, None)] * len(mean)
        opts = sco.minimize(fun=min_func_var, x0=x0, method='SLSQP', bounds=bnds, constraints=cons)
        
        w_ = opts['x']
        weight = w_/sum(w_)
        
        return weight
       
    def aggregate_traders_weight_cluster(self, traders_return_train, traders_weight_train, y_train):
        '''
            トレーダーの投資ウェイトにさらにカンパニーが加重するウェイトを計算
            各トレーダーのリターンをクラスタリング⇒クラスターごとの等ウェイトポートフォリオを構築し，
            各クラスターに対し，シャープレシオが最大化となるウェイトを算出する

        Parameters
        ----------
        traders_return_train : np.array (時点, トレーダー)
            トレーダーの全戦略を統合したリターン.（訓練時のデータ）
        traders_weight_train : np.array(トレーダー, 時点, 銘柄)
            トレーダーの全戦略の投資ウェイト. （訓練時のデータ）
        y_train : np.array(時点, 銘柄)
            予測対象の各銘柄リターン.（訓練時のデータ）

        Returns
        -------
        company_traders_weight : np.array(トレーダー,）
            トレーダーの投資ウェイトにさらにカンパニーが加重するウェイト.
        '''
        corr_distance = self.make_distance_mat(traders_return_train.T)
        _, clusters, _ = cluster_KMeans_base(corr_distance, 
                                                    self.hyperparms_company_common['min_num_clusters'],
                                                    self.hyperparms_company_common['max_num_clusters'],
                                                    self.hyperparms_company_common['n_init_clusters'], 
                                                    self.hyperparms_company_common['random_seed'])
                    
        weight_summary = []
        cluster_return = np.zeros((y_train.shape[0], len(clusters)))
        for i, val in clusters.items():
            weight_mean = np.mean(traders_weight_train[val,:,:], 0)
            cluster_return[:, i] = self.calc_return_company(weight_mean, y_train)
            weight_summary.append(weight_mean)
        
        cluster_cov = np.cov(cluster_return.T)
        cluster_mean = cluster_return.mean(0)
       
        cluster_weight = self.opt_SR(cluster_mean, cluster_cov)                
        
        company_traders_weight = np.zeros((self.traders_return.shape[1]))
        for i, val in clusters.items():            
            company_traders_weight[val] += cluster_weight[i]*(1/len(val))
        
        return company_traders_weight

    def aggregate_traders_weight_quantile(self):
        '''
            aggregate_methodをquantileとした場合の処理
            パフォーマンスが上位Aggregate_quantile以上のトレーダーのウェイトの平均値を返す

        Returns
        -------
        company_traders_weight : np.array(トレーダー,）
            トレーダーの投資ウェイトにさらにカンパニーが加重するウェイト.
        '''
        performance = self.measure_trader_return(self.traders_return, self.hyperparms_company_common['method_measure'])
        quan_threshold = np.quantile(performance, self.hyperparms_company_common['Aggregate_quantile'])
        trader_ID = np.where(performance>=quan_threshold)
        company_traders_weight = np.zeros((self.traders_return.shape[1]))
        company_traders_weight[trader_ID] += (performance[trader_ID]>=quan_threshold)/sum(performance[trader_ID]>=quan_threshold)
        
        return company_traders_weight



