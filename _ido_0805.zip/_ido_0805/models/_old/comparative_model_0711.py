# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    本コードで使用しているクラス
    ComparativeModel
        比較モデルを実施するクラス
"""
import numpy as np
import pandas as pd
from sklearn.linear_model import LassoCV
from sklearn.ensemble import RandomForestRegressor
import lightgbm as lgb

class ComparativeModel:
    def __init__(self, hyperparms_comparative):
        '''
            シミュレーションデータを用いてモデル検証を実施するクラス
        
        Parameters
        ----------        
            hyperparms_company_common : モデルのパラメータ        
        '''
        self.hyperparms_comparative = hyperparms_comparative
        try:
            self.stock_list = hyperparms_comparative['stock_list']
        except:
            raise ValueError('hyperparms_comparative内でstock_listを指定してください')
            
    def calc_weight_all_model(self, X_train, X_test, y_train, y_test, stock_num : int):
        '''
            hyperparms_comparative['model_list']で指定した比較モデルの全パターンについて，
            訓練データを用いて学習した結果をもとにテストデータにおけるポートフォリオウェイトを算出

        Parameters
        ----------
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
        stock_num : int
            銘柄数

        Returns
        -------
        weight_dict : dict
            比較モデルごとのポートフォリオウェイト.
        '''
        def make_strategy(model_type):
            print(f'比較モデル学習中 : {model_type}')
            y_pred = self.predict(X_train, y_train, X_test, model_type)
            y_pred = self.reshape_return(y_pred, stock_num)
            weight = self.calc_weight(y_pred)
            weight = pd.DataFrame(weight)
            weight.columns = self.stock_list
            weight.index = self.test_index
        
            return weight
        
        weight_dict = {model_type : make_strategy(model_type) for model_type in self.hyperparms_comparative['model_list']}
        y_test = self.reshape_return(y_test, stock_num)
        
        return weight_dict
        
    def reshape_return(self, y, stock_num : int):
        '''
            予測値のサイズをreshapeする
             (時点*銘柄数,) -> (時点, 銘柄数)

        Parameters
        ----------
        y : np.array
            リターン値. 次元数 -> (時点*銘柄数,)
        stock_num : int
            銘柄数.

        Returns
        -------
        y_pred : np.array
            (時点, 銘柄数)にreshapeされた予測値
        '''
        y = y.reshape(int(len(y)/stock_num), stock_num)
        
        return y
    
    def predict(self, X_train, y_train, X_test, model_type : str):
        '''
            モデルタイプを指定し，リターン予測を実施

        Parameters
        ----------
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        model_type : str
            モデルタイプを文字列で指定.
            lasso        : らっそ回帰
            randomforest : ランダムフォレスト回帰

        Returns
        -------
        y_pred : np.array
            予測値. 
        '''
        if model_type == 'lasso':
            y_pred = self.predict_lasso(X_train, y_train, X_test)
        elif model_type == 'randomforest':
            y_pred = self.predict_randomforest(X_train, y_train, X_test)
        elif model_type == 'lightgbm':
            y_pred = self.predict_lightgbm(X_train, y_train, X_test)
        else:
            raise ValueError('{model_type} is not supported in this version of ComparativeModel Class.') 
            
        return y_pred
    
    def predict_lasso(self, X_train, y_train, X_test):
        '''Lasso回帰による予測値算出
        '''        
        reg = LassoCV(**self.hyperparms_comparative['params_lasso']).fit(X_train, y_train)
        y_pred = reg.predict(X_test)
        
        return y_pred

    def predict_randomforest(self, X_train, y_train, X_test):
        '''ランダムフォレストによる予測値算出
        '''
        reg = RandomForestRegressor(**self.hyperparms_comparative['params_randomforest'])
        reg.fit(X_train, y_train)
        y_pred = reg.predict(X_test)
        
        return y_pred
    
    def predict_lightgbm(self, X_train, y_train, X_test):
        '''LightGBMによる予測値算出
        '''       
        reg = lgb.LGBMRegressor(**self.hyperparms_comparative['params_lightgbm'])
        reg.fit(X_train, y_train)
        y_pred = reg.predict(X_test)
        
        return y_pred    
    
    def calc_weight(self, y_pred):
        '''
            予測リターンをもとにポートフォリオをもとに構築

        Parameters
        ----------
        y_pred : np.array
            モデルの予測リターン.

        Returns
        -------
        weight : np.array
            ポートフォリオのウェイト.
        '''
        stock_num = y_pred.shape[1]
        
        def calc_score(y_pred, ratio, port_direction=1):
            assert port_direction==1 or port_direction==-1
            percentile = np.percentile(y_pred, ratio*100, axis=1)
            percentile = percentile[:,np.newaxis]
            score  = port_direction*(y_pred - np.repeat(percentile, repeats=y_pred.shape[1], axis=1))
            
            return score
                        
        if self.hyperparms_comparative['portfolio_type'] == 'LongShort':
            score_long  = calc_score(y_pred, self.hyperparms_comparative['long_ratio'], port_direction=1)
            score_short  = calc_score(y_pred, self.hyperparms_comparative['short_ratio'], port_direction=-1)
            long_num = np.tile((1*(score_long>=0)).sum(1), stock_num).reshape(y_pred.shape)
            short_num = np.tile((1*(score_short>=0)).sum(1), stock_num).reshape(y_pred.shape)
            weight = (score_long>=0)/long_num - 1*(score_short>=0)/short_num
        elif self.hyperparms_comparative['portfolio_type'] == 'Long':
            score_long  = calc_score(y_pred, self.hyperparms_comparative['long_ratio'], port_direction=1)
            long_num = np.tile((1*(score_long>=0)).sum(1), stock_num).reshape(y_pred.shape)
            weight = 1*(score_long>=0)/long_num
        else:
            raise ValueError(f'portfolio_type must be long_ratio or short_ratio. : {self.hyperparms_comparative["portfolio_type"]}')
            
        return weight
        
    def set_index(self, y_train, y_test):
        '''訓練データとテストデータのインデックスをクラス内変数にて保持
        '''        
        assert isinstance(y_train, pd.DataFrame)
        assert isinstance(y_test, pd.DataFrame)        
        self.train_index, self.test_index = y_train.index, y_test.index
    
    def split_simulation_data(self, dict_output, train_num=0):
        '''
            シミュレーションデータを訓練データとテストデータに分割

        Parameters
        ----------
        dict_output : dict
            シミュレーションデータ.
        train_num : TYPE, optional
            訓練データとテストデータを分割するインデックスの数値. The default is 0.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割

        Returns
        -------
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
        '''
        y = dict_output['return']
        X = dict_output['factor']
        
        # train_numのチェック
        assert isinstance(train_num, int)
        assert train_num >= 0 and train_num <= y.shape[0]        
        if train_num == 0:
            train_num = int(y.shape[0]/2)
        
        # データの分割
        y_train = y.iloc[:train_num,:]
        y_test = y.iloc[train_num:,:]
        self.set_index(y_train, y_test)        

        # データのreshape
        y_train = y_train.values.reshape(-1)
        y_test = y_test.values.reshape(-1)
        
        X_train = []
        X_test = []        
        for key, val in X.items():
            temp = X[key]
            X_train.append(pd.Series(temp.iloc[:train_num,:].values.reshape(-1)))
            X_test.append(pd.Series(temp.iloc[train_num:,:].values.reshape(-1)))

        X_train = pd.concat(X_train, axis=1)        
        X_test = pd.concat(X_test, axis=1)
        X_train.columns = X_test.columns = list(X.keys())
        
        return X_train, X_test, y_train, y_test
