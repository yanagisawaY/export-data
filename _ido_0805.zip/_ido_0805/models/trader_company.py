# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    
"""
import numpy as np
import pandas as pd
import time
from models.company import Company

class TraderCompany(Company):
    def __init__(self, hyperparms_company_common):
        self.hyperparms_company_common = hyperparms_company_common
        self.method_measure = hyperparms_company_common['method_measure']
        self.fit_times = hyperparms_company_common['fit_times']
        self.method_sampling = hyperparms_company_common['method_sampling']
        self.aggregate_method = hyperparms_company_common['Aggregate']
        self.factor_list = hyperparms_company_common['factor_list']
        self.stock_list = hyperparms_company_common['stock_list']
        self.random_seed = hyperparms_company_common['random_seed']
        
    def check_df_columns(self, X_train, y_train=pd.DataFrame()):
        '''
            データの列名をstock_listに一致させる
        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : pandas.DataFrame
            被説明変数データ.
            
        Returns
        -------
        X_train, y_train --> 列名をstock_listと同一にする
        '''        
        assert isinstance(X_train, dict), f'X_trainはdict型として入力 : {type(X_train)}として入力されています'
        assert isinstance(y_train, pd.DataFrame), f'y_trainはpd.DataFrame型として入力 : {type(y_train)}として入力されています'
        assert len(self.stock_list)>0, 'stock_listが空です'
        
        X_train = {key : val[self.stock_list] for key, val in X_train.items()}
        
        if len(y_train) > 0:
            y_train = y_train[self.stock_list]
        
        return X_train, y_train
    
    def normalize_factor(self, X):
        '''
            各ファクターの値を0-1ランク化

        Parameters
        ----------
        X : dict(pandas.DataFrameによる辞書)
            特徴量データ.

        Returns
        -------
        X : dict(np.arrayによる辞書)
            0-1ランク化後特徴量データ.
        '''
        X_norm = {key : np.argsort(np.argsort(df.values, axis=1), axis=1)/df.shape[1] for key, df in X.items()}
        
        return X_norm
        
    def learn_trader(self, X_train, y_train, ticker_info={}):
        '''
            トレーダーのパラメータを学習
        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : pandas.DataFrame
            被説明変数データ.
            
        Returns
        -------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト (トレーダー, 戦略, ファクター)
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト (トレーダー, 戦略)        
        universe_mask : np.array
            ユニバースマスク(トレーダー, 時点，銘柄)
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点            
        '''
        super().__init__(self.hyperparms_company_common)  
        start = time.time()
        
        # データの列名をstock_listに一致させる
        X_train, y_train = self.check_df_columns(X_train, y_train)
        
        # 各ファクターの値を0-1ランク化
        X_train = self.normalize_factor(X_train)       

        # ユニバースマスクの作成 (トレーダー, 時点，　銘柄)
        screaning_mask, self.traders_sector = self.make_screaning_mask(ticker_info, y_train.shape[0], y_train.shape[1])
        universe_mask = self.make_universe_mask(screaning_mask = screaning_mask,
                                                tradable_mask = self.make_tradable_mask(y_train))
                        
        # step1:パラメータの初期値取得
        hyperparms_traders = self.get_all_traders_init(self.factor_list)
        traders_return = self.calc_return(hyperparms_traders, universe_mask, X_train, y_train)
        print('step1 : '+str(round(time.time() - start))+'sec')
                
        # step2:教育，生成                    
        for f in range(self.fit_times):
            random_seed = f + self.hyperparms_company_common['random_seed']      
            # トレーダーウェイト更新            
            hyperparms_traders = self.educate(traders_return, hyperparms_traders,  X_train, y_train)            
            traders_return = self.calc_return(hyperparms_traders, universe_mask, X_train, y_train)            
            
            # トレーダー生成
            hyperparms_traders = self.generate_traders(traders_return, hyperparms_traders, random_seed)    
            traders_return = self.calc_return(hyperparms_traders, universe_mask, X_train, y_train)
            print(f'step2 {f+1}/{self.fit_times} : {str(round(time.time() - start))}sec')
        
        self.traders_return = traders_return

        # step3 : アンサンブルウェイトの決定
        if self.aggregate_method == 'average':
            self.company_traders_weight = np.ones((traders_return.shape[1]))/traders_return.shape[1]
        elif self.aggregate_method == 'quantile':
            self.company_traders_weight = self.aggregate_traders_weight_quantile()
        elif self.aggregate_method =='cluster':
            traders_weight_train = self.calc_traders_weight_all(*self.make_scores(hyperparms_traders, X_train))
            self.company_traders_weight = self.aggregate_traders_weight_cluster(traders_return, traders_weight_train, y_train)
        else:
            raise ValueError(f'aggregate_methodは，{self.aggregate_method}には対応していません')
            
        print('step3 : '+str(round(time.time() - start))+'sec')
        
        return hyperparms_traders, universe_mask
            
    def aggregate(self, traders_weight_all):
        '''
            各トレーダの予測値を集約し，ポートフォリオのウェイト出力
            step3 : 集約で決定したself.company_traders_weightにより，トレーダーのウェイトを集約
            
        Parameters
        ----------
        traders_weight_all : numpy.array
            トレーダーの全戦略の投資ウェイト. : (トレーダー, 時点, 銘柄)
        Returns
        -------
        weight : numpy.array
            集約したポートフォリオのウェイト.
        '''
        weight = np.einsum("mts, m->ts", traders_weight_all, self.company_traders_weight)

        return weight
    
    def fit(self, X_train, y_train, ticker_info):
        '''
            パラメータの学習を実施

        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : np.array or pandas.DataFrame
            被説明変数データ.
        ticker_info : dict
            各銘柄の属性データ（セクター情報など）
        '''
        assert isinstance(ticker_info, dict), 'ticker_infoはdict形式として入力してください'
        assert isinstance(X_train, dict), 'X_trainはdict形式として入力してください'

        self.hyperparms_traders, self.universe_mask = self.learn_trader(X_train, y_train, ticker_info)
    
    def predict(self, X, ticker_info, y_test=pd.DataFrame()):
        '''
            トレーダーの全戦略の投資ウェイトを算出

        Parameters
        ----------
        X : dict
            特徴量データ.
        ticker_info : dict
            各銘柄の属性データ（セクター情報など）            
        y_test : np.array or pandas.DataFrame
            テストデータにおける被説明変数データ.
            
        Returns
        -------
        traders_weight : np.array
            トレーダーの全戦略の投資ウェイト. : (時点, 銘柄)
            y_testをインプットした場合，traders_performance(テスト期間中の各トレーダーのパフォーマンス)も出力        
        '''
        X, y_test  = self.check_df_columns(X, y_test)
        
        for key in X.keys():pass
        time_num = X[key].shape[0]
        stock_num = X[key].shape[1]
                
        # ユニバースマスクの作成 (トレーダー, 時点，　銘柄)
        screaning_mask, _ = self.make_screaning_mask(ticker_info, time_num, stock_num, self.traders_sector)
        universe_mask = self.make_universe_mask(screaning_mask = screaning_mask,
                                                tradable_mask = self.make_tradable_mask(X_test=X))
                
        traders_weight_all = self.calc_traders_weight(*self.make_scores(self.hyperparms_traders, universe_mask, X))
        traders_weight = self.aggregate(traders_weight_all)
        
        if len(y_test) > 0:
            traders_return = self.calc_return_traders(traders_weight_all, y_test)
            traders_performance = self.measure_trader_return(traders_return, method_measure=self.method_measure)
            return traders_weight, traders_performance
        else:
            return traders_weight
        
    def predict_traders(self, X, ticker_info):
        '''
            トレーダーの全戦略の投資ウェイトを算出（統合しない）

        Parameters
        ----------
        X : dict
            特徴量データ.
        ticker_info : dict
            各銘柄の属性データ（セクター情報など）            
            
        Returns
        -------
        traders_weight_all : np.array
            トレーダーの全戦略の投資ウェイト. : (トレーダー, 時点, 銘柄)
        '''
        X = np.array([df.values for df in X.values()])
        time_num = X.shape[1]
        stock_num = X.shape[2]
                
        # ユニバースマスクの作成 (トレーダー, 時点，　銘柄)
        screaning_mask, _ = self.make_screaning_mask(ticker_info, time_num, stock_num, self.traders_sector)
        universe_mask = self.make_universe_mask(screaning_mask = screaning_mask,
                                                tradable_mask = self.make_tradable_mask(X_test=X))
                
        traders_weight_all = self.calc_traders_weight_all(self.calc_traders_weight(\
             *self.make_scores(self.factor_weight, universe_mask, X)), self.strategy_weight)
            
        return traders_weight_all
    
    def get_params_info(self, hyperparms_traders):
        '''
            各トレーダの戦略パラメータの情報を抽出

        Parameters
        ----------
        hyperparms_traders : dict
            トレーダーの学習済みパラメータ
            
        Returns
        -------
            df_params : pd.DataFrame
                各トレーダーの戦略パラメータ.        
        '''   
        df_params = pd.DataFrame(self.make_parameters_list(hyperparms_traders), 
                                 columns=['trader_ID', 'formula_ID', 'weight', 'P_factor_id', 'Q_factor_id', 'A_activation_func', 'O_binary_operator'])        
        performance = self.measure_trader_return(self.traders_return, self.hyperparms_company_common['method_measure'])        
        df_performance = pd.DataFrame([list(range(self.hyperparms_company_common['N_trader'])), self.company_traders_weight, performance],
                                      index=['trader_ID', 'ensemble_weight', 'performance(train)']).T

        df_performance['trader_ID'] = df_performance['trader_ID'].astype(int)
        df_params['trader_ID'] = df_params['trader_ID'].astype(int)
        df_params = pd.merge(df_params, df_performance, on='trader_ID', how='left')
        
        return df_params
