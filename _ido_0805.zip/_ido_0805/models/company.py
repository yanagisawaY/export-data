# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文をコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Note : 
    Traderの機能はCompanyクラスのテンソル計算に包含されている
"""
import numpy as np
import pandas as pd
import random
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
import scipy.optimize as sco
from utils.cluster import cluster_KMeans_base
from models.trader import Trader, TraderGenarator, activation_functions, binary_operators

class Company:
    def __init__(self, hyperparms_company_common):   
        '''
        Parameters
        ----------
        hyperparms_company_common : dict
            トレーダに関する共通のハイパーパラメータ.
        '''
        self.hyperparms_company_common = hyperparms_company_common
        self.factor_list = self.hyperparms_company_common['factor_list']
        self.factor_num = len(self.factor_list)
        self.trader_type = hyperparms_company_common['trader_type']
        self.long_ratio = hyperparms_company_common['trader_long']
        self.short_ratio = hyperparms_company_common['trader_short']
        self.cost = hyperparms_company_common['cost']
        self.log_quantile = hyperparms_company_common['log_quantile']
        assert isinstance(self.log_quantile, list)
        # 記録用のインスタンス変数
        self.traders_performance_log = []
        self.factor_counts_log = pd.DataFrame(np.zeros(self.factor_num), 
                                              index=self.factor_list, columns=['drop'])
        
        # 離散値のパラメータ
        self.discrete_dict = {
            'P_factor_id'       : 3,
            'Q_factor_id'       : 4,
            'A_activation_func' : 5,
            'O_binary_operator' : 6,            
            }        
        
    @staticmethod
    def make_onehot_factor(x, max_num, random_seed):
        random.seed(random_seed)
        string = list('1'*x+'0'*(max_num-x))
        random.shuffle(string)
        return [int(x) for x in string]

    @staticmethod
    def make_onehot_NA(x, max_num):
        string = '1'*x+'0'*(max_num-x)
        return [int(x) if int(x) == 1 else np.nan for x in string]

    @staticmethod    
    def softmax_weight(x):
        '''NA値を除き，ソフトマックス関数により変換
        '''        
        x_dropna = [i for i in x if np.isnan(i) == False]        
        weight = np.exp(x_dropna)/np.sum(np.exp(x_dropna))
        weight = [weight[i] if np.isnan(num) == False else 0 for i, num in enumerate(x)]
        
        return weight

    @staticmethod    
    def weight_norm(x):
        '''ウェイトがマイナスになったものは0.01に置き換え，合計が1になるように正規化
            ⇒戦略ウェイトを0とすると，以降戦略数が減ってしまうため，0.01に置き換える
            ⇒xの要素が0より大きい前提で合計1となるような正規化を実施
        '''
        x_max = [max(i, 0.01) if i!=0 else 0 for i in x]
        weight = [max(i, 0.01)/sum(x_max) if i!=0 else 0 for i in x]
        
        return weight
    
    @staticmethod    
    def check_numpy_fillna(y_train):
        if not isinstance(y_train, np.ndarray):
            y_train = np.array(y_train)
            
        # 欠損値を0に置き換え
        y_train = np.nan_to_num(y_train)
        
        return y_train

    def check_ticker_info(self, ticker_info):
        '''
            ticker_infoとstock_listにある銘柄情報が互いに包含できているかを確認

        Parameters
        ----------
        ticker_info : dict
            ティッカー情報の辞書.

        Returns
        -------
        ticker_info_list : list
            ティッカー情報に格納された銘柄リスト.
        '''
        # stock_listと対応させる
        ticker_info_list = [key for key, val in ticker_info.items() if key in self.stock_list]
        assert len(ticker_info_list)==len(self.stock_list) , 'ticker_infoがstock_listにある銘柄情報を包含できていません'
        assert len(ticker_info)==len(self.stock_list) , 'stock_listがticker_infoにある銘柄情報を包含できていません'
            
    def get_all_traders_init(self, factor_list):
        '''
            全てのトレーダーの戦略の初期値を得る

        Parameters
        ----------
        factor_list : list
            ファクター名が格納されたlist.
            
        Returns
        -------
        hyperparms_traders : dict
            全てのトレーダーの戦略が格納された辞書.
        '''
        hyperparms_traders = {}
        cpg = TraderGenarator(factor_list, self.hyperparms_company_common['M_formula'])        
        for j in range(self.hyperparms_company_common['N_trader']):
            random_seed = self.hyperparms_company_common['random_seed'] + j    
            hyperparms_traders[j] = cpg.get_params_trader_init(random_seed)
        
        return hyperparms_traders
    
    def make_screaning_mask(self, ticker_info, time_num, stock_num, traders_sector=[]):
        '''
            スクリーニングマスクの作成 (トレーダー,　時点, 銘柄)
            各トレーダーの担当セクターをランダムに設定
            ⇒事前に指定することも可能ではあるが現状その機能はいれていない
        Parameters
        ----------
        ticker_info : dict
            各銘柄のセクター情報.
        time_num : int
            時点数（マスクのサイズ指定に使用）
        stock_num : int
            銘柄数（マスクのサイズ指定に使用）
        traders_sector : 
            トレーダーの担当セクターを事前に与える
            ※ 現状，スクリーニングにはセクター情報しか使っていないが，機能変更も可能            
        Returns
        -------
        screaning_mask : np.array
            スクリーニングマスク. (トレーダー,　時点, 銘柄)
        '''
        if len(ticker_info) > 0:
            # ticker_infoとstock_listにある銘柄情報の包含関係を確認
            self.check_ticker_info(ticker_info)
            
            ticker_info = {key : val for key, val in ticker_info.items() if key in self.stock_list}
            info_unique = sorted(set(ticker_info.values()))
            info_dict = dict(zip(info_unique, [[] for _ in info_unique]))
            for key, val in ticker_info.items():
                info_dict[val] += [key]            
                
            # 訓練データの場合，トレーダーの担当セクターをランダムに生成
            # テストデータの場合，訓練データ使用時のものを使用
            if len(traders_sector) == 0:
                # 各トレーダーの担当セクターをランダムに設定
                np.random.seed(self.hyperparms_company_common['random_seed'])        
                info_dict_count = [len(val)/stock_num for key, val in info_dict.items()]
                traders_sector = list(np.random.choice(info_unique, p=info_dict_count, size=self.hyperparms_company_common['N_trader']))
    
           # マスクされたテンソルの作成
            screaning_mask = np.zeros((self.hyperparms_company_common['N_trader'], time_num, stock_num))        
            for i, key in enumerate(traders_sector):
                index_ = [np.where(np.array(self.stock_list)==x)[0][0] for x in info_dict[key]]
                screaning_mask[i:i+1, :, index_] = np.ones((time_num, len(index_)))
        else:
            print('スクリーニングの設定なし')
            screaning_mask = np.ones((self.hyperparms_company_common['N_trader'], time_num, stock_num))        
            if len(traders_sector) == 0:            
                # 各トレーダーは全ユニバースを対象
                traders_sector = ['All' for _ in range(self.hyperparms_company_common['N_trader'])]
                
        return screaning_mask, traders_sector

    def make_tradable_mask(self, y_train={}, X_test={}):
        '''
            トレーダブルマスクの作成 (時点，銘柄)

        Parameters
        ----------
        y_train : pd.DataFrame
            各アセットのリターン情報.
        X_test : dict
            テストデータ時の特徴量データ⇒特徴量データからマスクを作成
            
        Returns
        -------
        tradable_mask : np.array
            トレーダブルマスク
        '''
        if len(X_test) == 0:
            tradable_mask = (y_train!=np.nan).values*1
        else:
            for key in X_test.keys():pass
            tradable_mask = np.ones((X_test[key].shape[0], X_test[key].shape[1]))
        
        return tradable_mask
    
    def make_universe_mask(self, screaning_mask, tradable_mask):
        '''
            ユニバースマスクの作成 (トレーダー, 時点，銘柄)

        Parameters
        ----------
        screaning_mask : np.array
            スクリーニングマスク. (トレーダー,　時点, 銘柄)
        tradable_mask : np.array
            トレーダブルマスク

        Returns
        -------
        universe_mask : np.array
            ユニバースマスク(トレーダー, 時点，銘柄)
        '''
        universe_mask = np.einsum("mts, ts->mts", screaning_mask, tradable_mask)
        
        return universe_mask

    def get_traders_score(self, hyperparms_traders, factor_tables):
        '''
            すべてのトレーダーの予測銘柄魅力度スコアを算出

        Parameters
        ----------
        hyperparms_traders : dict
            全てのトレーダーの戦略が格納された辞書.
        factor_tables : dict
            各銘柄のファクタースコア（≒ X_train）  key(ファクター数) : val(時点， 銘柄)

        Returns
        -------
        scores : numpy.array
            各時点，銘柄ごとの相対的魅力度スコア.  (トレーダー, 時点， 銘柄)
        '''
        scores = []
        tr = Trader(factor_tables)
        for key, dict_ in hyperparms_traders.items():
            hyperparms_all_formula, weight = dict_.values()
            scores.append(tr.make_stategy(weight, hyperparms_all_formula))
        
        scores = np.array(scores)
        
        return scores

    def make_scores(self, hyperparms_traders, universe_mask, factor_tables):
        '''
            各時点，銘柄ごとのスクリーニング後の相対的魅力度スコアを算出
            (0以上の値が取引対象（0より小さい値は取引対象外）となるようにスコアを調整)
        Parameters
        ----------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト　(トレーダー, 戦略, ファクター数)
        universe_mask : np.array
            ユニバースマスク (トレーダー, 時点，　銘柄)            
        factor_tables : dict
            各銘柄のファクタースコア（≒ X_train）  key(ファクター数) : val(時点， 銘柄)
            
        Returns
        -------
        scores : numpy.array
            各時点，銘柄ごとの相対的魅力度スコア.  (トレーダー, 時点， 銘柄)
        universe_mask_weight : numpy.array
            各トレーダーがマスクしない銘柄に関するウェイト(トレーダー,)            
        '''        
        scores = self.get_traders_score(hyperparms_traders, factor_tables)

        # 各トレーダーにおけるマスク銘柄数 + 1 (トレーダー,)
        stock_num = universe_mask.shape[2]
        universe_mask_num = stock_num - universe_mask.sum(2)[:,0]
        
        # 各トレーダーがマスクしない銘柄が1以上となるようなウェイトを計算        
        universe_mask_weight = 1/(universe_mask_num + 1)

        # スコアの単調性を維持しつつ，0より大きい数値に変換        
        scores = (scores - np.min(scores))+0.1
        
        # マスク値の設定⇒マスク値は0，それ以外は0より大きい数とする
        scores = universe_mask*scores
        
        # 0以上の値が取引対象となるようにスコアを調整
        scores = np.einsum("nts, n->nts", np.argsort(np.argsort(scores, axis=2), axis=2) + 1, universe_mask_weight) - 1
                
        return scores, universe_mask_weight
    
    def calc_traders_weight(self, scores, universe_mask_weight):
        '''
            各時点，銘柄ごとの投資ウェイト（LS戦略）を算出

        Parameters
        ----------
        scores : np.array (トレーダー, 時点， 銘柄)
            各時点，銘柄ごとの相対的魅力度スコア.
        universe_mask_weight : numpy.array
            各トレーダーがマスクしない銘柄に関するウェイト(トレーダー,)            
            
        Returns
        -------
        traders_weight : np.array (トレーダー, 時点， 銘柄)
            各時点，銘柄ごとの投資ウェイト.
        '''               
        def repeat_axis(x):
            x = x[:,np.newaxis,np.newaxis]
            for i in range(1, 3):
                x = np.repeat(x, scores.shape[i], axis=i)
            return x
        
        def calc_weight(scores, ratio, flag):
            # 閾値を超えた銘柄に対し，等ウェイトポートフォリオを構築
            if flag=='Long':
                target = 1*(scores>=ratio)
            elif flag=='Short':
                target = 1*(scores<=ratio)*(scores>=0)
                
            target_num = target.sum(2)[:,:,np.newaxis]
            target_num = np.repeat(target_num, scores.shape[2], axis=2)
            target = target/target_num                
            
            return target

        stock_num = scores.shape[2]
        long_ratio = self.long_ratio*(stock_num*universe_mask_weight - 1)
        long_ratio = repeat_axis(long_ratio)
        
        if self.trader_type == 'LongShort':
            short_ratio = self.short_ratio*(stock_num*universe_mask_weight - 1)
            short_ratio = repeat_axis(short_ratio)
            traders_weight = calc_weight(scores, long_ratio, flag='Long') - calc_weight(scores, short_ratio, flag='Short')
        elif self.trader_type == 'Long':
            traders_weight = calc_weight(scores, long_ratio, flag='Long')
        else:
            raise ValueError('trader_typeに予想外のインプットが入力されています')
        
        if np.isnan(traders_weight).sum() > 0:
            raise ValueError('ウェイトにnanが含まれています．特定のトレーダーの投資対象数が少なく，LSポートフォリオが構築できていない可能性があるため，特定トレーダーのユニバース数を増やしてください，')
        
        return traders_weight
    
    def calc_return_traders(self, traders_weight_all, y_train):
        '''
            戦略ウェイト統合後のトレーダーのリターンを算出

        Parameters
        ----------
        traders_weight : np.array
            各時点，銘柄ごとの投資ウェイト. : (トレーダー, 時点， 銘柄)
        y_train : np.array or pd.DataFrame
            各アセットのリターン. : (時点， 銘柄)

        Returns
        -------
        traders_return : np.array
            トレーダーごとの取引コスト控除後リターン. : (時点, トレーダー)
        '''
        y_train = self.check_numpy_fillna(y_train)
        zeros = np.zeros((traders_weight_all.shape[0], 1))
        cost = np.concatenate([zeros, (np.abs(np.diff(traders_weight_all, n=1, axis=1))*self.cost).sum(axis=2)], axis=1)
        traders_return = np.einsum("nts, ts->nts", traders_weight_all, y_train).sum(2) - cost
        # 行方向に時点がくるように転置する
        traders_return = traders_return.T
                
        return traders_return
    
    def calc_return_company(self, company_weight, y_train):
        '''
            カンパニーの投資ウェイトからリターンを算出する

        Parameters
        ----------
        traders_weight : np.array
            各時点，銘柄ごとの投資ウェイト. : (時点， 銘柄)
        y_train : np.array or pd.DataFrame
            各アセットのリターン. : (時点， 銘柄)

        Returns
        -------
        traders_return_all : np.array
            取引コスト控除後リターン. : (時点)
        '''
        y_train = self.check_numpy_fillna(y_train)                
        zeros = np.zeros((1))
        cost = np.concatenate([zeros, (np.abs(np.diff(company_weight, n=1, axis=0))*self.cost).sum(axis=1)], axis=0)
        traders_return_all = np.einsum("ts, ts->ts", company_weight, y_train).sum(1) - cost
        
        return traders_return_all
        
    def calc_return(self, hyperparms_traders, universe_mask, X_train, y_train):
        '''
            トレーダーの全戦略を統合したリターンを算出        

        Parameters
        ----------
        hyperparms_traders : dict
            全てのトレーダーの戦略が格納された辞書.
        universe_mask : np.array
            ユニバースマスク(トレーダー, 時点，銘柄)            
        X_train : dict(np.arrayによる辞書)
            0-1ランク化後特徴量データ. key(ファクター数) : val(時点， 銘柄)
        y_train : np.array or pd.DataFrame
            各アセットのリターン.

        Returns
        -------
        traders_return : np.array
            トレーダーの全戦略を統合したリターン.
        '''        
        traders_return = self.calc_return_traders(\
                        self.calc_traders_weight(*self.make_scores(hyperparms_traders, universe_mask, X_train)),
                        y_train)
        
        return traders_return
    
    def measure_trader_return(self, traders_return, method_measure):        
        '''
            トレーダーのパフォーマンスを測定

        Parameters
        ----------
        traders_return : np.array (トレーダー, 時点)
            トレーダーの全戦略を統合したリターン.
        method_measure : str
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ

        Returns
        -------
        traders_performance : np.array
            各トレーダーのパフォーマンス
        '''                        
        if method_measure == 'CR':
            # 累積リターン
            traders_return_cumsum = traders_return.cumsum(0)
            traders_performance = traders_return_cumsum[-1,:]
        elif method_measure == 'SR':
            # シャープレシオ
            traders_return_mean = traders_return.mean(0)
            traders_return_sd = traders_return.std(0)            
            traders_performance = traders_return_mean/traders_return_sd
        elif method_measure == 'DDR':
            # DDレシオ            
            traders_return_mean = traders_return.mean(0)
            traders_return_DD = np.sqrt(np.sum((traders_return[traders_return<0] ** 2))/len(traders_return))
            traders_performance = traders_return_mean/traders_return_DD            
        else:
            raise ValueError(f'"method_measure"は，{method_measure}には対応していません')            
        
        return traders_performance
    
    def collect_bad_traders(self, traders_return, method_measure):
        '''
            パフォーマンスの悪いトレーダーのフラグを作成
            
        Parameters
        ----------
        traders_return : np.array (トレーダー, 時点)
            トレーダーの予測した銘柄魅力度スコアに基づくリターン.
        method_measure : TYPE, optional
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ

        Returns
        -------
        is_bad_traders : list
            パフォーマンスの悪いトレーダーのフラグ.
        traders_performance : np.array
            各トレーダーのパフォーマンス            
        '''       
        traders_performance = self.measure_trader_return(traders_return, method_measure=method_measure)
        bottom_quantile = np.quantile(traders_performance, self.hyperparms_company_common['Q_quantile_educate'])
        print(f'bottom quantile: {method_measure} - {bottom_quantile}')
        is_bad_traders = list(traders_performance <= bottom_quantile)
                
        return is_bad_traders, traders_performance

    def educate(self, traders_return, hyperparms_traders, X_train, y_train):
        '''
            パフォーマンスの悪いトレーダーの各formulaにかかるウェイトを更新

        Parameters
        ----------
        traders_return : np.array (トレーダー, 時点)
            トレーダーの予測した銘柄魅力度スコアに基づくリターン.
        hyperparms_trader : dict
            各トレーダーのパラメータ.
            'weight'                 : formulaの重みづけ
            'hyperparms_all_formula' : 各formulaのパラメータ
        X_train : dict(np.arrayによる辞書)
            0-1ランク化後特徴量データ. key(ファクター数) : val(時点， 銘柄)
        y_train : np.array or pd.DataFrame
            各アセットのリターン.

        Returns
        -------
        hyperparms_traders : dict
            パフォーマンスの悪いトレーダーを更新したトレーダーのパラメータ.
        '''
        # パフォーマンスの悪いトレーダーIDを抽出
        is_bad_traders, traders_performance = self.collect_bad_traders(traders_return, self.method_measure)
        self.add_traders_performance_log(traders_performance_log = np.percentile(traders_performance, q=self.log_quantile))
        
        tr = Trader(X_train)
        for i, trader_i in hyperparms_traders.items():
            if is_bad_traders[i]:
                hyperparms_all_formula, _ = trader_i.values()
                trader_i['weight'] = tr.update_weight(hyperparms_all_formula, y_train, random_seed=self.hyperparms_company_common['random_seed']+i)
                hyperparms_traders[i] = trader_i 
                       
        return hyperparms_traders

    def generate_traders(self, traders_return, hyperparms_traders, random_seed):
        '''
            Good Tradersのパラメータ分布をもとにBad Tradersのパラメータを更新

        Parameters
        ----------
        traders_return : np.array (トレーダー, 時点)
            トレーダーの予測した銘柄魅力度スコアに基づくリターン.
        hyperparms_trader : dict
            各トレーダーのパラメータ.
            'weight'                 : formulaの重みづけ
            'hyperparms_all_formula' : 各formulaのパラメータ
        random_seed : int
            乱数シード.

        Returns
        -------
        hyperparms_traders : dict
            パフォーマンスの悪いトレーダーを更新したトレーダーのパラメータ.
        '''
        # fit_timesのカウント
        fit_times = random_seed - self.hyperparms_company_common['random_seed'] + 1
        
        # パフォーマンスの悪いトレーダーIDを抽出
        is_bad_traders, traders_performance = self.collect_bad_traders(traders_return, self.method_measure)
                
        # パフォーマンスの良い・悪いトレーダーのパラメータを抽出
        df_params = self.make_parameters_list(hyperparms_traders)
        bad_traders_ID = np.where(is_bad_traders)[0]
        bad_traders = self.extract_traders(df_params, bad_traders_ID)
        good_traders_ID = np.where([not x for x in is_bad_traders])[0] 
        good_traders = self.extract_traders(df_params, good_traders_ID)            
              
        # パフォーマンスのよいトレーダーのパラメータをもとに混合正規分布にフィットさせ，悪いトレーダーのパラメータをサンプリングにより更新
        bad_traders_new = self.sample_gaussian_mix(good_traders, bad_traders, random_seed)        
        df_params_new = np.concatenate([good_traders, bad_traders_new])                
        hyperparms_traders = self.make_dict_from_params(df_params_new)
        
        # 使用ファクター頻度とパフォーマンス分位点のログ
        self.add_traders_performance_log(traders_performance_log = np.percentile(traders_performance, q=self.log_quantile))
        self.add_factor_counts_log(factor_counts_log = self.count_factor(df_params_new, fit_times))
                
        return hyperparms_traders

    def make_parameters_list(self, hyperparms_traders):
        '''
            各トレーダーのパラメータをデータフレーム形式で出力        

        Parameters
        ----------
        hyperparms_traders : dict
            全てのトレーダーの戦略が格納された辞書.

        Returns
        -------
        df : np.array
            各トレーダーのパラメータ
        '''
        df = []
        for trader_id, val in hyperparms_traders.items():
            hyperparms_all_formula = val['hyperparms_all_formula']
            weight = val['weight']
            for formula_id, params in hyperparms_all_formula.items():
                one_formula = [trader_id, formula_id, weight[formula_id]] + list(params.values())
                one_formula[-2] = list(one_formula[-2].keys())[0]  # A_activation_func
                one_formula[-1] = list(one_formula[-1].keys())[0]  # O_binary_operator                
                df.append(one_formula)
        
        df = np.array(df)
        
        return df

    def make_dict_from_params(self, df_params):
        '''
            パラメータが格納された行列ををもとにhyperparms_tradersを更新

        Parameters
        ----------
        df_params : np.array
            各トレーダーのパラメータ

        Returns
        -------
        hyperparms_traders : dict
            全てのトレーダーの戦略が格納された辞書.
        '''
        TRADER_COL = 0
        WEIGHT_COL = 2        
        hyperparms_traders = {}
        
        for trader_id in np.unique(df_params[:,TRADER_COL]):
            hyperparms_trader = {}            
            df_params_trader = df_params[df_params[:,TRADER_COL]==trader_id,:]           
            hyperparms_all_formula = {}
            for formula_id in range(df_params_trader.shape[0]):
                hyperparms_j = {}
                factor_id = ['P_factor_id', 'Q_factor_id'] 
                hyperparms_j.update({str(key) : str(df_params_trader[formula_id, self.discrete_dict[key]]) for key in factor_id})
                key_activation = df_params_trader[formula_id, self.discrete_dict['A_activation_func']]
                hyperparms_j.update({'A_activation_func' : {str(key_activation) : activation_functions[key_activation]}})
                key_operator = df_params_trader[formula_id, self.discrete_dict['O_binary_operator']]
                hyperparms_j.update({'O_binary_operator' : {str(key_operator) : binary_operators[key_operator]}})
                hyperparms_all_formula[formula_id] = hyperparms_j

            hyperparms_trader['hyperparms_all_formula'] = hyperparms_all_formula            
            hyperparms_trader['weight'] = list(df_params_trader[:,WEIGHT_COL].astype(float))
            hyperparms_traders[int(trader_id)] = hyperparms_trader
                
        return hyperparms_traders

    def extract_traders(self, df_params, traders_ID):
        '''
            該当するトレーダーIDのパラメータ情報を抽出

        Parameters
        ----------
        df_params : np.array
            各トレーダーのパラメータ
        traders_ID : np.array
            トレーダーのID.

        Returns
        -------
        traders : np.array
            トレーダーの情報行列.
        '''
        traders = []
        for id_ in traders_ID:
            traders.append(df_params[df_params[:,0]==str(id_)])
        
        traders = np.concatenate(traders)                
        
        return traders
            
    def sample_gaussian_mix(self, good_traders, bad_traders, random_seed, conditional=True):
        '''
            パフォーマンスのよいパラメータ値を混合正規分布にあてはめ，サンプリング
            ※ 離散値を標準化⇒混合正規分布にフィット⇒逆変換後の値からもっとも近い離散値を新たらパラメータとして採用
            　　したがって，銘柄インデックスの最小値（最大値）は，フィットさせた確率分布でその値を下（上）回る累積確率分多く採用される傾向にあることに注意
              ⇒理想は混合切断正規分布のようなものからサンプリング．

        Parameters
        ----------
        good_traders : 
            フィッテイング対象となるトレーダー（パフォーマンスのよいトレーダー情報）
        bad_traders : 
            サンプリング対象のトレーダーID（パフォーマンスのわるいトレーダーのID）
        random_seed : int
            乱数シード.
        conditional : bool
            True⇒フィッテイング時にセクター情報は考慮するものの，生成時にはセクター情報は更新しない
            False⇒フィッテイング時にセクター情報は考慮し，さらに生成時にはセクター情報を更新する            
        Returns
        -------
        bad_traders : pandas.DataFrame
            サンプリングされたbad tradersのパラメータ.
        '''        
        # factor_idは順序性のない離散値であるため，数値を意図的にシャッフルする
        # ⇒もとのファクターの並び順に対し，ランダムに混合正規分布をフィットさせる
        unique_dict = {}
        list_temp = {}
                
        good_traders_copy = good_traders.copy()
        for name, id_num in self.discrete_dict.items():
            random.seed(random_seed + id_num)
            unique_names = np.unique(good_traders_copy[:,id_num])
            len_unique_names = len(unique_names)
            unique_names = random.sample(list(unique_names), len_unique_names)
            list_temp[name] = list(range(len(unique_names)))
            convert_dict = dict(zip(unique_names, list(range(len_unique_names))))
            unique_dict[name] = convert_dict       
            good_traders_copy[:,id_num] = np.array([convert_dict[x] for x in good_traders_copy[:,id_num]])

        random.seed(random_seed)                   
        id_num_start = 2
        gmm = GaussianMixture(n_components=self.hyperparms_company_common['GMM_n_components'], covariance_type='spherical', random_state=random_seed)
        sc = StandardScaler()
        sc.fit(good_traders_copy[:,id_num_start:])
        good_traders_scaled = sc.transform(good_traders_copy[:,id_num_start:])
        fitted = gmm.fit(good_traders_scaled)
        samples = sc.inverse_transform(fitted.sample(len(bad_traders))[0])
        samples[:,1:] = np.round(samples[:,1:]) # discrete_dictにあるものは整数化
        bad_traders_new = np.concatenate([bad_traders[:,0:id_num_start], samples], axis=1)

        def get_swap_dict(d):
            return {v: k for k, v in d.items()}
        
        def find_nearest(array, value):
            array = np.asarray(array)
            idx = (np.abs(array - value)).argmin()
            return array[idx]            
                
        # factor_idのindexで近い数のものを取り出し，それに対応するIDをconvert_dictから取り出す
        for name, id_num in self.discrete_dict.items():
            bad_traders_new[:,id_num] = [get_swap_dict(unique_dict[name])[find_nearest(list_temp[name], int(float(x)))] \
                                         for x in bad_traders_new[:,id_num]]
            
        return bad_traders_new
    
    def opt_SR(self, mean, cov):
        '''
            シャープレシオ最大化によるポートフォリオ最適化を実施（下限制約あり）

        Parameters
        ----------
        mean : np.array
            投資対象の平均.
        cov : np.array
            投資対象の分散共分散行列.

        Returns
        -------
        weight : np.array
            ポートフォリオのウェイト.
        '''
        x0 = [1. / len(mean)] * len(mean)
        def min_func_var(weights):
            return np.dot(weights.T, np.dot(cov, weights))
        
        cons = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1}, 
                {'type': 'eq', 'fun': lambda x: np.sum(mean * x) - 1}]
        
        bnds = [(0, None)] * len(mean)
        opts = sco.minimize(fun=min_func_var, x0=x0, method='SLSQP', bounds=bnds, constraints=cons)
        
        w_ = opts['x']
        weight = w_/sum(w_)
        
        return weight
       
    def aggregate_traders_weight_cluster(self, traders_return_train, traders_weight_train, y_train):
        '''
            トレーダーの投資ウェイトにさらにカンパニーが加重するウェイトを計算
            各トレーダーのリターンをクラスタリング⇒クラスターごとの等ウェイトポートフォリオを構築し，
            各クラスターに対し，シャープレシオが最大化となるウェイトを算出する

        Parameters
        ----------
        traders_return_train : np.array (時点, トレーダー)
            トレーダーの全戦略を統合したリターン.（訓練時のデータ）
        traders_weight_train : np.array(トレーダー, 時点, 銘柄)
            トレーダーの全戦略の投資ウェイト. （訓練時のデータ）
        y_train : np.array(時点, 銘柄)
            予測対象の各銘柄リターン.（訓練時のデータ）

        Returns
        -------
        company_traders_weight : np.array(トレーダー,）
            トレーダーの投資ウェイトにさらにカンパニーが加重するウェイト.
        '''
        corr = np.corrcoef(traders_return_train.T)
        corr1, clusters, silh = cluster_KMeans_base(corr, 
                                                    self.hyperparms_company_common['max_num_clusters'],
                                                    self.hyperparms_company_common['n_init_clusters'], 
                                                    self.hyperparms_company_common['random_seed'])
                    
        # print('相関係数行列の可視化')
        # import seaborn as sns
        # sns.heatmap(corr1, vmax=1, vmin=-1, center=0)
        weight_summary = []
        cluster_return = np.zeros((y_train.shape[0], len(clusters)))
        for i, val in clusters.items():
            weight_mean = np.mean(traders_weight_train[val,:,:], 0)
            cluster_return[:, i] = self.calc_return_company(weight_mean, y_train)
            weight_summary.append(weight_mean)
        
        cluster_cov = np.cov(cluster_return.T)
        cluster_mean = cluster_return.mean(0)
       
        cluster_weight = self.opt_SR(cluster_mean, cluster_cov)                
        
        company_traders_weight = np.zeros((self.traders_return.shape[1]))
        for i, val in clusters.items():            
            company_traders_weight[val] += cluster_weight[i]*(1/len(val))
        
        return company_traders_weight

    def aggregate_traders_weight_quantile(self):
        '''
            aggregate_methodをquantileとした場合の処理
            パフォーマンスが上位Aggregate_quantile以上のトレーダーのウェイトの平均値を返す

        Returns
        -------
        company_traders_weight : np.array(トレーダー,）
            トレーダーの投資ウェイトにさらにカンパニーが加重するウェイト.
        '''
        performance = self.measure_trader_return(self.traders_return, self.hyperparms_company_common['method_measure'])
        quan_threshold = np.quantile(performance, self.hyperparms_company_common['Aggregate_quantile'])
        trader_ID = np.where(performance>=quan_threshold)
        company_traders_weight = np.zeros((self.traders_return.shape[1]))
        company_traders_weight[trader_ID] += (performance[trader_ID]>=quan_threshold)/sum(performance[trader_ID]>=quan_threshold)
        
        return company_traders_weight

    def count_factor(self, df_params, fit_times):
        '''
            ファクターの使用頻度をカウント

        Parameters
        ----------
        df_params : np.array
            モデルのパラメータ.
        fit_times : int
            トレーダー生成の繰り返し回数
        Returns
        -------
        factor_counts_log : pd.Series
            トレーダーのfit_timesごとの使用ファクター頻度                    
        '''
        FACTOR_COL_NUM1 = self.discrete_dict['P_factor_id']
        FACTOR_COL_NUM2 = self.discrete_dict['Q_factor_id']
        factor_ID, factor_counts = np.unique(df_params[:,[FACTOR_COL_NUM1, FACTOR_COL_NUM2]].reshape(-1), return_counts=True)
        factor_counts_log = pd.DataFrame(factor_counts, index=factor_ID, columns=[str(fit_times)])
        
        return factor_counts_log        
    
    def add_traders_performance_log(self, traders_performance_log):
        '''トレーダーのfit_timesごとのパフォーマンス分位点をインスタンス変数に追加
        Parameters
        ----------        
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点                    
        '''
        self.traders_performance_log.append(traders_performance_log)

    def add_factor_counts_log(self, factor_counts_log):
        '''トレーダーのfit_timesごとの使用ファクター頻度をインスタンス変数に追加
        Parameters
        ----------        
        factor_counts_log : pd.Series
            トレーダーのfit_timesごとの使用ファクター頻度                    
        '''
        if 'drop' in self.factor_counts_log.columns:
            self.factor_counts_log = pd.merge(self.factor_counts_log, factor_counts_log, left_index=True, right_index=True).drop(['drop'], axis=1)
        else:
            self.factor_counts_log = pd.merge(self.factor_counts_log, factor_counts_log, left_index=True, right_index=True)        
        