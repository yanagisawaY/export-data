# -*- coding: utf-8 -*-
"""
バックテストを実施する最も階層の高いクラス
"""
import time
import pickle
import pandas as pd
import datetime as dt

from models.trader_company import TraderCompany
from models.comparative_model import ComparativeModel
from utils.loader import DataLoader
from utils.portfolio_evaluator import PortfolioEvaluator

class ResultMaker(DataLoader):
    def __init__(self, df_dict, hyperparms_company_common, ticker_info):
        '''
            モデルの学習を期間をスライドさせて実行させるクラス
        
        Parameters
        ----------        
            df_dict                   : 株価データ（dict形式 : OHLCVデータや企業特性データ）
            hyperparms_company_common : モデルのパラメータ        
            ticker_info               : ティッカー情報に関する辞書
        '''
        self.df_dict = df_dict
        self.ticker_info = ticker_info
        self.hyperparms_company_common = hyperparms_company_common
        self.business_days = hyperparms_company_common['rebalance_term']

    def set_data(self, stock_list, date_dict):
        '''
            データセットの作成を行い，訓練データとテストデータを出力

        Parameters
        ----------
        stock_list : list
            対象銘柄.（df_pctの列名に存在するものを指定）
        date_dict : dict
            訓練期間とテスト期間の日付が格納された辞書.

        Returns
        -------
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
        '''
        self.stock_list = stock_list
        # 期間の設定
        self.train_start_date, self.train_end_date, self.test_start_date, self.test_end_date = date_dict.values()        
        
        # データ作成    
        X_train, y_train, y_train_port = self.make_dataset(self.train_start_date, self.train_end_date)
        X_test, y_test, self.y_test_port = self.make_dataset(self.test_start_date, self.test_end_date)
        
        # factor_listとstock_listの情報を追加
        self.factor_list = list(X_train.keys())
        self.hyperparms_company_common['factor_list'] = self.factor_list
        self.hyperparms_company_common['stock_list'] = stock_list
               
        return X_train, y_train, X_test, y_test

    def learn(self, X_train, y_train, X_test, y_test):
        '''
            訓練データでの学習，テストデータにおけるウェイトを算出
    
        Parameters
        ----------
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
    
        Returns
        -------
        weight_test : pd.DataFrame
            テストデータにおける投資ウェイト.
        df_params : pd.DataFrame
            使用したパラメータ情報など
        df_info : pd.Series
            データの分割期間などの情報            
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点
        '''
        print('開始...')        
        start_time = time.time()
        # 学習
        self.tc = TraderCompany(self.hyperparms_company_common)                                
        self.tc.fit(X_train, y_train, self.ticker_info)
        weight_test, traders_performance_test = self.tc.predict(X_test, self.ticker_info, y_test)
        
        # テスト期間のウェイト算出
        weight_test = pd.DataFrame(weight_test, columns=self.stock_list, index=y_test.index)        
        
        # 累和リターンのプロット
        (weight_test*y_test).sum(1).cumsum().plot()
        
        # 学習モデル等の集約結果
        df_params = self.tc.get_params_info(self.tc.hyperparms_traders)        
        df_params = self.add_params_info(df_params, traders_performance_test)
                
        # トレーダー生成のログ
        traders_performance_log = pd.DataFrame(self.tc.traders_performance_log, columns=self.tc.log_quantile)
        factor_counts_log = self.tc.factor_counts_log.copy()
        
        # 情報の集約
        calc_time = round(time.time() - start_time)        
        col_names = ['訓練開始', '訓練終了', 'テスト開始', 'テスト終了', '計算時間(sec)'] + list(self.hyperparms_company_common.keys())
        df_info = pd.DataFrame([[self.train_start_date, self.train_end_date, self.test_start_date, self.test_end_date,
                                 calc_time]+list(self.hyperparms_company_common.values())], columns=col_names)
        
        print(f'End - {calc_time}sec')
        
        return weight_test, df_params, df_info, traders_performance_log, factor_counts_log
        
    def make_model_pred(self, stock_list, date_dict):
        '''
            訓練データでの学習，テストデータにおけるウェイトを算出
    
        Parameters
        ----------
        stock_list : list
            対象銘柄.（df_pctの列名に存在するものを指定）
        date_dict : dict
            訓練期間とテスト期間の日付が格納された辞書.
            
        Returns
        -------
        weight_test : pd.DataFrame
            テストデータにおける投資ウェイト.
        df_params : pd.DataFrame
            使用したパラメータ情報など
        df_info : pd.Series
            データの分割期間などの情報            
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点
        factor_counts_log : pd.Series
            トレーダーのfit_timesごとの使用ファクター頻度                    
        '''
        X_train, y_train, X_test, y_test = self.set_data(stock_list, date_dict)
        weight_test, df_params, df_info, traders_performance_log, factor_counts_log = self.learn(X_train, y_train, X_test, y_test)
        
        return weight_test, df_params, df_info, traders_performance_log, factor_counts_log
    
    def add_params_info(self, df_params, traders_performance_test):
        '''
            df_paramsに以下の情報を追加
            1.テストデータにおける各トレーダーのパフォーマンス
            2.訓練データにおけるトレーダーのリターン平均
            3.訓練データにおけるトレーダーのリターン標準偏差

        Parameters
        ----------
        traders_performance_test : pd.DataFrame
            テストデータにおける各トレーダーのパフォーマンス
        '''
        # トレーダーの訓練データにおける平均と標準偏差
        traders_train_mean = self.tc.traders_return.mean(0)
        traders_train_sd = self.tc.traders_return.std(0)
        
        # 各トレーダーのテスト期間中のパフォーマンス結果を結合
        df_performance = pd.DataFrame([list(range(self.hyperparms_company_common['N_trader'])), 
                                       traders_performance_test, traders_train_mean, traders_train_sd],
                                      index=['trader_ID', 'performance(test)', 'mean(train)', 'sd(train)']).T
        df_performance['trader_ID'] = df_performance['trader_ID'].astype(int)
        df_params['trader_ID'] = df_params['trader_ID'].astype(int)
        df_params = pd.merge(df_params, df_performance, on='trader_ID', how='left')

        return df_params
    
    @staticmethod
    def get_dateset_dict(era, year_term_train, year_term_test):
        '''
            訓練期間とテスト期間の日付設定
    
        Parameters
        ----------
        era : int
            訓練開始時の年
        year_term_train : int
            訓練期間の年数
        year_term_test : int
            テスト期間の年数
    
        Returns
        -------
        date_dict : dict
            訓練期間とテスト期間の日付が格納された辞書.
        '''
        date_dict = {
        'train_start_date' : dt.datetime(era, 1, 1),
        'train_end_date'   : dt.datetime(era+year_term_train, 12, 31),
        'test_start_date'  : dt.datetime(era+year_term_train+1, 1, 1),
        'test_end_date'    : dt.datetime(era+year_term_train+year_term_test, 12, 31),
        }
        
        return date_dict
    
    def get_all_result(self, all_setting):
        '''モデル学習とバックテストの実施
        Parameters
        ----------    
        all_setting : dict
            start_year                : 訓練開始年
            end_year                  : 訓練終了年
            year_term_train           : 訓練データ年数
            year_term_test            : テストデータ年数
            is_get_dict               : テストデータ分割方法の指定
                                        True  : year_term_trainごとのスライド方式
                                        False : 論文と同じ訓練/テスト期間(2000-2010が訓練) 
            hyperparms_portfolio      : ポートフォリオ構築のパラメータ
            stock_list                : 分析対象銘柄のTicker
            pattern_name              : 出力するファイルに付与する名前 
            hyperparms_comparative    : 比較モデルに関するパラメータ            
        Returns
        -------
        all_result : dict
            学習・バックテストの結果        
        '''            
        # DataLoaderの継承
        super().__init__(self.df_dict, self.hyperparms_company_common)
        
        model_name = 'ECSP'
        is_get_dict = all_setting['is_get_dict']
        year_term_train = all_setting['year_term_train']
        year_term_test = all_setting['year_term_test']
        stock_list = all_setting['stock_list']
        hyperparms_portfolio = all_setting['hyperparms_portfolio']
        hyperparms_comparative = all_setting['hyperparms_comparative']
        
        if is_get_dict:
            start_year_in = all_setting['start_year']
            start_year_lower = self.index_date.min().year            
            end_year_in = all_setting['end_year']
            end_year_upper = self.index_date.max().year            
            start_year = max(start_year_in, start_year_lower)
            end_year = max(start_year_in, min(end_year_in, end_year_upper-1) - year_term_train)
            
            era_list = list(range(start_year, end_year, year_term_test))
        else:
            era_list = ['one_pattern']
        
        all_result = {}
        df_info = pd.DataFrame()
        weight_test_all = pd.DataFrame()        
        y_test_port_all = pd.DataFrame()
        weight_dict_others = {x : pd.DataFrame() for x in hyperparms_comparative['model_list']} 
                
        # 時点をスライドさせてバックテストを実施
        for era in era_list:
            print(era)
            result = {}
            
            if is_get_dict:
                output_name_era = str(era) + '_' + str(era+year_term_train-1)
                date_dict = self.get_dateset_dict(era, year_term_train, year_term_test)
            else:
                output_name_era = str(era)
                date_dict = {
                    'train_start_date' : dt.datetime(2001, 1, 1),
                    'train_end_date'   : dt.datetime(2015, 12, 31),
                    'test_start_date'  : dt.datetime(2016, 1, 1),
                    'test_end_date'    : dt.datetime(2021, 5, 30),
                    }
            
            result['weight'], result['df_params'], df_info_, \
                result['traders_performance_log'], result['factor_counts_log'] = self.make_model_pred(stock_list, date_dict)
            result['index'], result['performance'] = \
                self.get_portfolio_result(result['weight'], self.y_test_port, hyperparms_portfolio, model_name)
            result['return'] = self.y_test_port
            
            # 比較モデルの学習/結果の出力
            if hyperparms_comparative['is_comparison']:
                X_train, y_train, X_test, y_test = self.set_data(stock_list, date_dict)
                weight_dict_other = self.get_result_other(hyperparms_comparative, X_train, y_train, X_test, y_test)
                other_name_list = []
                for other_name, weight_test_other in weight_dict_other.items():
                    temp = weight_dict_others[other_name].copy()
                    weight_dict_others[other_name] = pd.concat([temp, weight_test_other])
                    other_name_list += [other_name]
                    index_, performance_ = self.get_portfolio_result(weight_test_other, y_test, hyperparms_portfolio, other_name)
                    result['index'] = pd.concat([result['index'], index_], axis=1)
                    result['performance'] = pd.concat([result['performance'], performance_], axis=1)
                result['index'].columns = [model_name] + other_name_list
                
            df_info = pd.concat([df_info, df_info_])
            weight_test_all = pd.concat([weight_test_all, result['weight']])
            y_test_port_all = pd.concat([y_test_port_all, self.y_test_port])
            all_result[output_name_era] = result
            
        # 全期間の結果を統合
        result_all = {}
        result_all['weight'] = weight_test_all
        result_all['return'] = y_test_port_all
        result_all['df_info'] = df_info
        result_all['index'], result_all['performance']  = self.get_portfolio_result(weight_test_all, y_test_port_all, hyperparms_portfolio, 'all')
        
        # 全期間での比較モデルの学習/結果の出力        
        if hyperparms_comparative['is_comparison']:
            other_name_list = []            
            for other_name, weight_test_other in weight_dict_others.items():
                other_name_list += [other_name]
                index_, performance_ = self.get_portfolio_result(weight_test_other, y_test, hyperparms_portfolio, other_name)
                result_all['index'] = pd.concat([result_all['index'], index_], axis=1)
                result_all['performance'] = pd.concat([result_all['performance'], performance_], axis=1)            
            result_all['index'].columns = [model_name] + other_name_list
            
        all_result['all'] = result_all
        
        return all_result

    def get_portfolio_result(self, weight, y_port, hyperparms_portfolio, output_name = 'result'):
        '''
            ポートフォリオのパフォーマンス結果を出力
    
        Parameters
        ----------
        weight : pd.DataFrame
            投資ウェイト.
        y_port : 
            各資産のリターン
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        output_name : str
            resultの列名.(任意な列名を設定可能)
    
        Returns
        -------
        index_portfolio : pd.DataFrame
            ポートフォリオのインデックス推移.
        performance : pd.DataFrame
            ポートフォリオのパフォーマンス結果.
        '''
        pe = PortfolioEvaluator(y_port, self.business_days, hyperparms_portfolio)
        return_portfolio = pe.calc_portfolio_return(weight)
        index_portfolio = pe.calc_wealth(return_portfolio)
        performance = pe.make_peformance_result(weight, output_name)
        print(performance)    
        
        return index_portfolio, performance

    def get_result_other(self, hyperparms_comparative, X_train, y_train, X_test, y_test):
        '''
            比較モデルによるポートフォリオウェイトを算出

        Parameters
        ----------
        hyperparms_comparative : dict
            比較対象のモデルのハイパーパラメータ
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
            
        Returns
        -------
        weight_dict : dict
            比較モデルごとのポートフォリオウェイト.
        '''
        hyperparms_comparative['stock_list'] = self.stock_list
        cm = ComparativeModel(hyperparms_comparative)
        stock_num = len(self.stock_list)        
        cm.set_index(y_train, y_test)
        
        # データの列名をstock_listに一致させる
        X_train, y_train = cm.check_df_columns(X_train, y_train)
        X_test, y_test = cm.check_df_columns(X_test, y_test) 
        
        # 各ファクターの値を0-1ランク化
        X_train = cm.normalize_factor(X_train)
        X_test = cm.normalize_factor(X_test)        

        # データのreshape
        X_train, y_train = cm.reshape_data(X_train, y_train)
        X_test, y_test = cm.reshape_data(X_test, y_test)

        # 欠損値処理
        X_train, y_train = cm.drop_na(X_train, y_train)            
        # X_test, y_test = cm.drop_na(X_test, y_test) 
        
        # ウェイトの算出
        weight_dict = cm.calc_weight_all_model(X_train, X_test, y_train, y_test, stock_num)
        
        return weight_dict
    
    def output_result(self, all_result, path_output):
        '''学習済みのハイパーパラメータをフォルダに出力(pickleファイル)
        Parameters
        ----------
        all_result : dict
            学習・バックテストの結果   
        path_output : str
            ファイルの出力フォルダ.
        '''    
        def pickle_dump(obj, path):
            with open(path, mode='wb') as f:
                pickle.dump(obj, f)    
                
        pickle_dump(all_result, path_output+'\\all_result.pickle')
