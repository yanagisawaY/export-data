# -*- coding: utf-8 -*-
"""
TraderCompanyクラスより学習したトレーダーのパラメータをもとに使用されたファクターに関する情報を抽出
"""
import pandas as pd

class Interpreter:
    def __init__(self):
        '''TraderCompanyクラスより学習したトレーダーのパラメータをもとに使用されたファクターに関する情報を抽出するクラス
        '''
        pass

    def get_factor_count(self, df_params, ensemble_weight=True):
        '''
            TraderCompanyクラスより学習した結果をもとに，トレーダーが使用したファクターの頻度を算出

        Parameters
        ----------
        df_params : pd.DataFrame
            トレーダーが学習したパラメータ.

        Returns
        -------
        factor_counts : pd.Series
            ファクターの頻度．
        '''
        if ensemble_weight:
            df_adopted = df_params[df_params['ensemble_weight']>0]
        else:
            df_adopted = df_params.copy()
        
        factor_counts = df_adopted['factor'].value_counts()
        factor_counts = pd.Series(factor_counts, index = factor_counts.index).sort_values(ascending=False)
    
        return factor_counts
    
    def get_factor_weighted(self, df_params, ensemble_weight=True):
        '''
            TraderCompanyクラスより学習した結果をもとに，トレーダーが使用したファクターの頻度をstarategy_weightにより重みづけした値を算出

        Parameters
        ----------
        df_params : pd.DataFrame
            トレーダーが学習したパラメータ.

        Returns
        -------
        factor_weighted : pd.Series
            starategy_weightにより重みづけされたファクターの頻度．
        '''
        if ensemble_weight:        
            df_adopted = df_params[df_params['ensemble_weight']>0]
        else:
            df_adopted = df_params.copy()            
        
        factor_counts = df_adopted['factor'].value_counts()
        factor_weighted = []
        for x in list(factor_counts.index):
            factor_weighted += [df_adopted.loc[df_adopted['factor']==x, 'strategy_weight'].astype(float).sum()]

        factor_weighted = pd.Series(factor_weighted, index = factor_counts.index).sort_values(ascending=False)
    
        return factor_weighted
    
    def get_factor_weighted_all(self, output):
        '''
            outputに格納された全設定に対し，starategy_weightにより重みづけされたファクターの頻度を算出
            ある試行において使用されなかったファクターは0で置き換える
            
        Parameters
        ----------
        output : dict
            全ての試行パターンの結果が格納された辞書.

        Returns
        -------
        factor_weighted_all : pd.DataFrame
            全ての試行パターンにおける各ファクターの重みづけ頻度. 
        '''
        factor_weighted_all = pd.DataFrame()
        for key, val in output.items():
            factor_weighted = self.get_factor_weighted(val['df_params'])
            factor_weighted.name = key
            factor_weighted_all = pd.concat([factor_weighted_all, factor_weighted], axis=1)
    
        factor_weighted_all = factor_weighted_all.fillna(0)
        
        return factor_weighted_all
    
    def get_factor_weighted_score(self, factor_weighted_all):
        '''
            使用したファクターの頻度の全試行における合計値を算出

        Parameters
        ----------
        factor_weighted_all : pd.DataFrame
            全ての試行パターンにおける各ファクターの重みづけ頻度. 

        Returns
        -------
        factor_weighted_score : pd.Series
                全ての試行パターンにおける各ファクターの重みづけ頻度の合計値. 
        '''
        factor_weighted_score = factor_weighted_all.sum(1).sort_values(ascending=False)    
        
        return factor_weighted_score
    
    def get_factor_weighted_stat(self, factor_weighted_all, factor_list_sorted=[]):
        '''
            

        Parameters
        ----------
        factor_weighted_all : pd.DataFrame
            全ての試行パターンにおける各ファクターの重みづけ頻度. 
        factor_list_sorted : list, optional
            データフレームの並び順を指定する場合に使用するリスト. The default is [].

        Returns
        -------
        factor_weighted_stat : pd.DataFrame
            各ファクターの使用頻度に関する統計量.
        '''
        if len(factor_list_sorted)==0:
            factor_weighted_stat = factor_weighted_all.T.describe()        
        else:
            factor_weighted_stat = factor_weighted_all.T[factor_list_sorted].describe()
        
        return factor_weighted_stat