# -*- coding: utf-8 -*-
"""
クラスタリングを実施
@author: Yanagisawa
"""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples
    
def cluster_KMeans_base(corr_distance, min_num_clusters, max_num_clusters, n_init, random_state=0):
    '''
        ONCベースクラスタリングを実施
        アセットマネージャーのためのファイナンス機械学習 P.78

    Parameters
    ----------
    corr : np.array or pd.DataFrame
        相関係数行列
    max_num_clusters : int
        クラスター数の最小値.        
    max_num_clusters : int
        クラスター数の最大値.
    n_init : int
        初期化計算の繰り返し回数. (k_means++におけるn_initではない)
    random_state : init
        ランダムシード

    Returns
    -------
    corr1 : pd.DataFrame
        クラスターごとに並び変えた相関係数行列.
    clusters : dict
        各クラスターに属するID番号.
    silh : pd.Series
        シルエットスコア.
    '''
    # corrの行方向に対し，相関係数行列を作成する
    if not isinstance(corr_distance, pd.DataFrame):
        corr_distance = pd.DataFrame(corr_distance)
    
    index_corr = corr_distance.copy().index
    silh = pd.DataFrame()
        
    for init in range(n_init):
        for i in range(min_num_clusters, max_num_clusters+1):
            kmeans_ = KMeans(n_clusters=i, n_init=10, random_state=random_state+init)
            kmeans_ = kmeans_.fit(corr_distance)
            silh_ = silhouette_samples(corr_distance, kmeans_.labels_)
            stat = (silh_.mean()/silh_.std(), silh.mean()/silh.std())

            if isinstance(stat[1], pd.Series) or (stat[0] > stat[1]):
                print(f'####### cluster{i} #######')
                silh, kmeans = silh_, kmeans_
            
    clusters = {i : corr_distance.columns[np.where(kmeans.labels_==i)[0]].tolist() for i in np.unique(kmeans.labels_)}
            
    corr_distance.index = corr_distance.columns = kmeans.labels_ #  [str(x)+'-'+str(index_corr[i]) for i, x in enumerate(kmeans.labels_)]
    idx_new = np.argsort(kmeans.labels_)
    corr_distance = corr_distance.iloc[idx_new,:]
    corr_distance = corr_distance.iloc[:,idx_new]
    silh = pd.Series(silh, index=index_corr)
    
    return corr_distance, clusters, silh    