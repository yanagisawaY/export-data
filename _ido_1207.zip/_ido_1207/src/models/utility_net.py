from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd
import numpy as np
import math
from utils.optimizer_weight import solve_opt

class ONINorm(nn.Module):
    """
    
    Notes
    -----
    `Controllable Orthogonalization in Training DNNs <https://openaccess.thecvf.com/content_CVPR_2020/html/Huang_Controllable_Orthogonalization_in_Training_DNNs_CVPR_2020_paper.html>`_
        
    `コード参照元 <https://github.com/huangleiBuaa/ONI/blob/387c4eeecf9adfcaa00ff5e73017c75e87790ec0/ONI_PyTorch/extension/normalization/NormedConv.py>`_    
    """
    def __init__(self, T=10, norm_groups=1, *args, **kwargs):
        super(ONINorm, self).__init__()
        self.T = T
        self.norm_groups = norm_groups
        self.eps = 1e-5
 
    def matrix_power3(self, Input):
        B=torch.bmm(Input, Input)
        return torch.bmm(B, Input)

    def forward(self, port_rt: torch.Tensor):
        """
            ウェイトを変換させる行列Bを出力

        Parameters
        ----------
        port_rt : torch.Tensor
            直交変換前の特性ポートフォリオのリターン.

        Returns
        -------
        convert_ht : torch.Tensor
            ウェイトに掛け合わせる直交変換用の行列.
        
        convert_ht@(直交返還前の隠れ層の合成ポートフォリオのウェイト)をかけることで，
        各々のポートフォリオを直交させる(ニュートン法を用いた直交変換)
        """
        assert port_rt.shape[0] % self.norm_groups == 0        
        Z = port_rt.view(self.norm_groups, port_rt.shape[0] // self.norm_groups, -1)  # type: torch.Tensor
        Zc = Z - Z.mean(dim=-1, keepdim=True)
        S = torch.matmul(Zc, Zc.transpose(1, 2))
        eye = torch.eye(S.shape[-1]).to(S).expand(S.shape)
        S = S + self.eps*eye
        norm_S = S.norm(p='fro', dim=(1, 2), keepdim=True)
        S = S.div(norm_S)
        B = [torch.Tensor([]) for _ in range(self.T + 1)]
        B[0] = torch.eye(S.shape[-1]).to(S).expand(S.shape)
        for t in range(self.T):
            B[t + 1] = torch.baddbmm(1.5, B[t], -0.5, self.matrix_power3(B[t]), S)
        
        # W = B[self.T].matmul(Zc).div_(norm_S.sqrt())
        # W.view_as(port_rt)
        convert_ht = B[self.T].div_(norm_S.sqrt()).squeeze(0)
        
        return convert_ht

    def extra_repr(self):
        fmt_str = ['T={}'.format(self.T)]
        if self.norm_groups > 1:
            fmt_str.append('groups={}'.format(self.norm_groups))
        return ', '.join(fmt_str)


class MultiPortNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''

    def __init__(self, hyperparms, input_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(MultiPortNet, self).__init__()
        layer_units = hyperparms['layer_list']
        layer_num = len(layer_units)
        if layer_num > 0:
            layer = []
            
            for i in range(layer_num):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))
                
                if i>=1:
                    input_num_layer = layer_units[i-1]
                elif layer_num==1 or i==0:
                    input_num_layer = input_num
                    
                if i < layer_num - 1:
                    layer.append(nn.Linear(input_num_layer, layer_units[i]))
                else:
                    layer.append(nn.Linear(input_num_layer, layer_units[i], bias=False))
                    
                layer.append(nn.BatchNorm1d(layer_units[i]))
                layer.append(nn.ReLU())
                
            self.full = nn.Sequential(*layer)
            self.is_linear = False
            self.last_unit = layer_units[-1]            
        else:
            self.is_linear = True
            self.last_unit = input_num            
            
    def forward(self, X):
        """順伝搬

        Parameters
        ----------
        X : torch.tensor
            (バッチ(時点), 銘柄, 特長量)

        Returns
        -------
        hidden : torch.tensor
            (バッチ(時点), 合成ポートフォリオの数, 銘柄)
        
        Notes
        -----
        L-1層はクロスセクション方向に平均ゼロ，標準偏差1に標準化
        ->　ポートフォリオフォリオの総ウェイトが1となることが保証
        """
        if self.is_linear:
            hidden = torch.transpose(X, 1, 2)
        else:
            hidden = torch.zeros(X.size(0), self.last_unit, X.size(1))            
            for stock_i in range(X.size(1)):
                hidden[:,:,stock_i] = self.full(X[:,stock_i,:]).squeeze()
        
        hidden = (hidden - torch.mean(hidden, 2).unsqueeze(2).tile(hidden.shape[2]))/(torch.std(hidden, 2).unsqueeze(2).tile(hidden.shape[2]))
        
        return hidden


class UtilityNet(nn.Module):
    def __init__(self, hyperparms, input_num):
        super(UtilityNet, self).__init__()
        self.layer_units = hyperparms['layer_list']        
        if len(self.layer_units) > 0:
            last_unit = self.layer_units[-1]
        else:
            last_unit = input_num            
        self.last = nn.Linear(last_unit, 1, bias=False)
        self.oln = ONINorm(T=5, norm_groups=1)
        self.mpn = MultiPortNet(hyperparms, input_num)
        self.network_type = hyperparms["network_type"]
        
    def forward(self, X, rt=None, mode="train"):
        weight_ht = self.call_hidden_weight(X, rt, mode)
            
        # calculate last layer        
        weight_t = torch.zeros((weight_ht.shape[0], weight_ht.shape[2]))
        for stock_i in range(X.size(1)):
            weight_t[:,stock_i] = self.last(weight_ht[:,:,stock_i]).squeeze()
        
        self.stock_nums = torch.ones(weight_t.size())/weight_t.shape[1]
        weight_t = weight_t*self.stock_nums
    
        return weight_t
    
    def call_hidden_weight(self, X, rt=None, mode="train"):
        # calculate L-1 layer
        weight_ht = self.mpn.forward(X)

        if self.network_type=="onc":
            if mode=="train":
                hidden_rt = torch.einsum('tkn,tn->tk', weight_ht, rt)
                convert_ht = self.oln(hidden_rt.T)
                self.convert_ht = convert_ht.detach()
            else:
                convert_ht = self.convert_ht
    
            weight_ht = torch.einsum('tkn, km->tmn', weight_ht, convert_ht)
            # 直交変換させた際にウェイトが小さくスケーリングされるため，
            # クロスセクション方向に標準偏差が1となるようリスケーリングする
            weight_ht = weight_ht/weight_ht.std(dim=2, keepdim=True)
            
        return weight_ht
    
    def preserve_corr(self, weight_ht, rt):
        convert_rt_ = torch.einsum('tkn,tn->tk', weight_ht, rt).detach().numpy().copy()
        convert_rt = pd.DataFrame(convert_rt_)
        import pdb
        pdb.set_trace()
        

def base_port_return(rt):
    """ベンチマークポートフォリオのリターンを算出（ベンチマークは等ウェイトポートフォリオ）
    """    
    weight_bench = torch.ones(rt.size())/rt.shape[1]    
    rt_bench = torch.einsum('nm,nm->n', rt, weight_bench)    
    
    return rt_bench

class UtilityLoss(nn.Module):
    def __init__(self, utility_type, gamma):
        super().__init__()
        self.utility_type = utility_type
        self.gamma = gamma        
    
    def forward(self, port_rt):
        if self.utility_type == "CRRA":
            utility = ((1 + port_rt)**(1 - self.gamma))/(1 - self.gamma)
            utility = utility.mean()
        elif self.utility_type == "MV":
            utility = torch.mean(port_rt) - self.gamma*torch.var(port_rt)/2            
        elif self.utility_type == "SR":
            utility = torch.mean(port_rt)/torch.std(port_rt)
        else:
            raise ValueError("this version only supports CRRA")
        
        return utility
    
    
class XSDataLoader:
    """torch型のデータセットを作成するクラス
    """
    def __init__(self, X, y, batch_size, stock_list, factor_list, is_t_1):
        """

        Parameters
        ----------
        X : pd.DataFrame
            各銘柄の特長量データセット
        y : pd.DataFrame
            各銘柄のリターンデータ      
        batch_size : int
            バッチサイズ
        stock_list : list
            銘柄のリスト
        factor_list : list
            特長量のリスト
        is_t_1 : bool, optional
            翌期の特長量データを使用する場合はTrue, by default True

        Raises
        ------
        ValueError
            pd.DataFrame出ない場合はエラー            
        """
        self.is_t_1 = is_t_1
        if not isinstance(X, pd.DataFrame) or not isinstance(y, pd.DataFrame):
            raise ValueError("X and y must be pd.DataFrame")
        self.X, self.y = X, y
        self.date_index = y.index
        self.batch_size = batch_size 
        self.factor_list = factor_list
        self.stock_list = stock_list

    def _iter_t_1(self, index_start, index_end):
        array_t = np.zeros((
            index_end - index_start,            
            len(self.stock_list), 
            len(self.factor_list))
            )
        array_t_1 = np.zeros((
            index_end - index_start,            
            len(self.stock_list), 
            len(self.factor_list))
            )
            
        for i, index_ in enumerate(range(index_start, index_end)):
            df_t = self.X.loc[self.X["Date"] == self.date_index[index_], :].drop(
                ["Date"], axis=1)
            df_t_1 = self.X.loc[self.X["Date"] == self.date_index[index_+1],
                                :].drop(["Date"], axis=1)
            df_combined = pd.merge(df_t, df_t_1, how="left", on="stock")
            df_combined = df_combined.set_index("stock")

            array_t[i,:,:] = df_combined.iloc[:, :int(
                len(self.factor_list))].values
            array_t_1[i,:,:] = df_combined.iloc[:, int(
                len(self.factor_list)):].values
        X_t_torch = torch.tensor(array_t).float()
        X_t_1_torch = torch.tensor(array_t_1).float()
        y_torch = torch.tensor(
            self.y.loc[self.date_index[index_start:index_end], :].values).float()
        
        return X_t_torch, X_t_1_torch, y_torch        

    def _iter_t(self, index_start, index_end):
        array_t = np.zeros((
            index_end - index_start,            
            len(self.stock_list), 
            len(self.factor_list))
            )
        for i, index_ in enumerate(range(index_start, index_end)):
            array_t[i,:,:] = self.X.loc[self.X["Date"] == self.date_index[index_], :].drop(
                ["Date"], axis=1).set_index("stock").values

        X_t_torch = torch.tensor(array_t).float()
        y_torch = torch.tensor(
            self.y.loc[self.date_index[index_start:index_end], :].values).float()

        return X_t_torch, y_torch
        
    def __iter__(self):
        """torch変換されたデータを作成するクラス

        Yields
        -------
        X_t_torch : torch.tensor
            t時点における各銘柄の特長量データセット
            (銘柄, 時点, バッチサイズ)
        X_t_1_torch : torch.tensor
            t+1時点における各銘柄の特長量データセット

            * is_t_1がTrueの場合，翌期の特長量データセット(X_t_1_torch)が作成

            * is_t_1がFalseの場合，t時点における各銘柄の特長量データセットのみ出力  
        y_torch : torch.tensor
            各時点における各銘柄のリターンデータ
        """            
        if self.is_t_1:        
            batch_set = math.floor((len(self.date_index)-1)/self.batch_size)
        else:
            batch_set = math.floor(len(self.date_index)/self.batch_size)           

        for t in range(batch_set):
            index_start = int(self.batch_size * t)                
            if self.is_t_1:
                if t+1 == batch_set:
                    index_end = len(self.date_index) - 1              
                else:
                    index_end = int(self.batch_size * (t+1))                
                yield self._iter_t_1(index_start, index_end)
            else:
                if t+1 == batch_set:
                    index_end = len(self.date_index)          
                else:
                    index_end = int(self.batch_size * (t+1))                
                yield self._iter_t(index_start, index_end)
                
                

class UtilityTrader:
    '''DNNの学習を行うクラス
    '''

    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        self.hyperparms = hyperparms
        self.stock_list = self.hyperparms["stock_list"]
        self.factor_list = self.hyperparms["factor_list"]
        self.is_opt = self.hyperparms["is_opt"]
        self.model = []
    
    def scale(self, X):
        """データの基準化

        * クロスセクション方向にランク化 → 平均0，標準偏差1に基準化

        Parameters
        ----------
        X : pd.DataFrame
            基準化前のデータ.

        Returns
        -------
        X_scale : pd.DataFrame
            基準化後のデータ.
        """
        date_indices = sorted(X["Date"].unique())
        X_scale = []        
        for date_index in date_indices:
            X_ = X.loc[X["Date"] == date_index,:].copy()
            # temp = np.argsort(np.argsort(X_[self.factor_list], 0), 0)
            # temp = temp.apply(lambda x: (x-x.mean())/ x.std(), axis=0)
            # df_ = pd.concat([X_[["Date", "stock"]], temp], axis=1)
            # X_scale.append(df_)            
            for factor in self.factor_list:
                temp_isna_ = -1*(1*X_[factor].isna()-1)
                temp = X_[factor].dropna()
                temp = np.argsort(np.argsort(temp))
                temp = (temp - temp.mean())/temp.std()
                X_.loc[temp.index, factor] = temp.values
                
            X_scale.append(X_)
        
        X_scale = pd.concat(X_scale).fillna(0)
        
        return X_scale
    
    def fit(self, X, y, X_val=None, y_val=None):
        '''
        X : pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pandas.DataFrame
            被説明変数(時点,銘柄)
        '''
        X = self.scale(X)
        torch.manual_seed(self.hyperparms['random_state'])
        batch_size = min(self.hyperparms["batch_size"], y.shape[0])
        loader = XSDataLoader(X, y, batch_size, self.stock_list,
                              self.factor_list, is_t_1=self.hyperparms["is_cost"])
        
        if X_val is not None:
            assert self.hyperparms["is_cost"] == False, "current version is only supported False"
            loader_val = XSDataLoader(X_val, y_val, y_val.shape[0], self.stock_list,
                                  self.factor_list, is_t_1=self.hyperparms["is_cost"])
            is_val = True
        else:
            is_val = False

        # 早期停止条件用の設定
        loss_val_min = 10000**100              
        patience_count = 0
        upper_patience_count = self.hyperparms["upper_patience_count"]
        min_epoch = self.hyperparms["min_epoch"]
        
        input_num = len(self.factor_list)
        model = UtilityNet(self.hyperparms, input_num)
        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.hyperparms['lr'])
        criterion = UtilityLoss(
            self.hyperparms["utility_type"], 
            self.hyperparms["gamma"])
        
        self.loss_save = []
        for epoch in range(self.hyperparms['epoch']):
            for X_t, y_t in loader:                
                weight_t = model.forward(X_t, rt=y_t, mode="train")
                rt_active = torch.einsum('tn,tn->tn', weight_t, y_t).sum(1)
                rt_bench = base_port_return(y_t)
                port_rt = rt_bench + rt_active
                loss = - criterion(port_rt)         
                
                # L2-normの正則化項を追加
                l2 = torch.tensor(0., requires_grad=True)
                for w in model.parameters():
                    l2 = l2 + self.hyperparms["l2_norm"]*torch.norm(w)**2
                loss = loss + l2
                
                optimizer.zero_grad()                    
                loss.backward()
                optimizer.step()                 
                            
            if is_val:
                with torch.no_grad():
                    for X_val, y_val in loader_val:
                        weight_val = model.forward(X_val, rt=y_val, mode="predict")
                        rt_active = torch.einsum('tn,tn->tn', weight_val, y_val).sum(1)
                        rt_bench = base_port_return(y_val)       
                        port_rt = rt_bench + rt_active                       
                        loss_val = - criterion(port_rt).item()
                    if loss_val_min > loss_val:
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1
                    self.loss_save += [[loss.item(), loss_val]]               
                    
                    if patience_count > upper_patience_count and epoch > min_epoch:
                        print(f"[BREAK] {epoch+1}/{self.hyperparms['epoch']} train {- round(loss.item(), 4)} val {- round(loss_val, 4)}")
                        break

                print(f"{epoch+1}/{self.hyperparms['epoch']} train {- round(loss.item(), 4)} val {- round(loss_val, 4)}")
            else:                
                self.loss_save += [-loss.item()]
                print(f"{epoch+1}/{self.hyperparms['epoch']} train {- round(loss.item(), 4)}")                
                
        self.model = model
    
    def get_hidden_return(self, X, rt):     
        hidden_weight = self.model.call_hidden_weight(X, rt=None, mode="predict")
        hidden_weight = hidden_weight/torch.abs(hidden_weight).sum(2, keepdim=True)
        hidden_rt = torch.einsum('tkn,tn->tk', hidden_weight, rt).detach().numpy().copy()
        hidden_rt = pd.DataFrame(hidden_rt)
        
        return hidden_rt

    def get_port_info(self, X, rt):
        feature_importance = self.get_feature_importance(X, rt)
        port_past = self.get_port_return(X, rt)
        
        return port_past, feature_importance
    
    def get_port_return(self, X, rt):
        X = self._convert(X)
        
        if isinstance(rt, pd.DataFrame):
            rt = rt.values            
        rt = torch.tensor(rt).float()

        rt_bench = base_port_return(rt)
        weight_active = [i[0] for i in self.model.last.parameters()][0]
                
        hidden_rt = self.get_hidden_return(X, rt)        
        rt_active = hidden_rt@weight_active.detach().numpy().copy()
        port_rt = rt_bench + rt_active        
        port_all = pd.concat([port_rt, pd.Series(rt_bench), rt_active, hidden_rt], axis=1)
        port_all.columns = ["all", "bench", "active"] + ["hidden_"+str(k_) for k_ in range(hidden_rt.shape[1])]
        
        return port_all
            
    def get_feature_importance(self, X, rt):
        X = self._convert(X)
        if isinstance(rt, pd.DataFrame):
            rt = rt.values            
        rt = torch.tensor(rt).float()
        
        rt_bench = base_port_return(rt)
        weight_active = [i[0] for i in self.model.last.parameters()][0]
        
        criterion = UtilityLoss(
            self.hyperparms["utility_type"], 
            self.hyperparms["gamma"])
        def _get_utlity(X):
            hidden_weight = self.model.call_hidden_weight(X, rt=None, mode="predict")
            hidden_rt = torch.einsum('tkn,tn->tk', hidden_weight, rt)
            ce_hidden = []
            for k in range(hidden_rt.shape[1]):
                ce_hidden.append(criterion(hidden_rt[:,k]).item())
            
            rt_active = hidden_rt@weight_active
            port_rt = rt_bench + rt_active          
            ce = criterion(port_rt).item()
            
            return ce, ce_hidden
       
        ce_all, ce_hidden_all = _get_utlity(X)
        layer_units = self.hyperparms['layer_list']
        layer_num = len(layer_units)
        if layer_num==0:
            feature_importance = pd.Series(ce_hidden_all, index=self.factor_list)
        else:            
            feature_importance = []
            for k in range(X.shape[2]):
                X_ = X.clone().detach()
                X_[:,:,k] = torch.zeros((X.shape[0], X.shape[1]))
                ce, ce_hidden = _get_utlity(X_)
                ce_hidden_ = [ce_hidden_all[k_] - ce_hidden[k_] for k_ in range(len(ce_hidden))]
                feature_importance.append([ce_all - ce] + ce_hidden_)
    
            feature_importance = pd.DataFrame(
                feature_importance, 
                index=self.factor_list, 
                columns=["all"]+["hidden_"+str(k_) for k_ in range(len(ce_hidden_all))]
                )
                    
        return feature_importance
                
    def _convert(self, X):
        X = self.scale(X)
        time_ = int(X.shape[0]/len(self.stock_list))
        array_t = np.zeros((
            time_,            
            len(self.stock_list), 
            len(self.factor_list))
            )
        date_index = sorted(X["Date"].unique())
        for i, index_ in enumerate(range(time_)):
            array_t[i,:,:] = X.loc[X["Date"] == date_index[index_], :].drop(
                ["Date"], axis=1).set_index("stock").values

        X = torch.tensor(array_t).float()   

        return X

    def predict(self, X, X_past=[], rt_train=[], rt_test=[], turnover=None, target_risk=None):
        '''
        X : np.array or pandas.DataFrame
            テスト(予測)期間における特徴量データ(銘柄×時点, 特徴量)        
        X_past: np.array
            訓練期間における特長特長量データ
        rt_train: np.array
            訓練期間における銘柄リターン            
        rt_test: np.array
            テスト期間における銘柄リターン
        weight : np.dnarray
            テスト期間におけるポートフォリオのウェイト
        turnover : float, default: None
            売買回転率の上限制約．Noneの場合，self.hyperparamsに与えられたturnoverを参照
        target_risk : float, default: None
            リスク制約の上限値            
        '''
        def convert_numpy(rt_):
            if isinstance(rt_, pd.DataFrame):
                rt_ = rt_.values
            assert isinstance(rt_, np.ndarray)
            
            return rt_

        X = self._convert(X)   
        if len(X_past)>0:
            is_opt = True
            X_past = self._convert(X_past)            
            rt_train = convert_numpy(rt_train)
            rt_test = convert_numpy(rt_test)
        else:
            is_opt = False            
                
        if is_opt:
            hidden_weight_current = self.model.call_hidden_weight(X, rt=None, mode="predict").detach().numpy().copy()
            hidden_weight_past = self.model.call_hidden_weight(X_past, rt=None, mode="predict").detach().numpy().copy()            
            if turnover is None:
                turnover = self.hyperparms["turnover"]
            if target_risk is None:
                target_risk = self.hyperparms["target_risk"]
            test_time = X.shape[0]
                        
            theta = []
            weight = []
            weight_ = None
            status_all = []
            for t_roll in range(test_time):
                hidden_weight = np.concatenate([hidden_weight_past, hidden_weight_current[:(t_roll+1),:,:]], axis=0)
                rit_ = np.concatenate([rt_train, rt_test[:(t_roll),:]], axis=0)
                T = hidden_weight.shape[0]
                K = hidden_weight.shape[1]
                # （要改善）ユニバースに含めない銘柄かどうかはリターンがゼロか否かで判断しているため不正確
                
                weights_char = [hidden_weight[t,:,rit_[t,:]!=0].reshape(K, -1) for t in range(T-1)]
                weights_char.append(hidden_weight[T-1,:,rt_test[t_roll,:]!=0].reshape(K, -1))
                rit = [rit_[t,rit_[t,:]!=0] for t in range(T-1)]
                stock_list = self.stock_list[rt_test[t_roll,:]!=0]
                weight_bench = np.ones(len(stock_list))/len(stock_list)
                
                # if t_roll == 0:
                #     # 初期時点は保有ポートフォリオが等ウェイトポートフォリオであるとする
                #     weight_hold = np.ones(len(stock_list))/len(stock_list)
                # else:
                #     # 前の時点での保有ポートフォリオ
                #     weight_hold = weight_.values*(1+rt_test[(t_roll),:])/sum(weight_.values*(1+rt_test[(t_roll),:]))
                
                weight_hold = np.ones(len(stock_list))/len(stock_list)
                weight_, theta_, is_status = solve_opt(
                    weight_bench,
                    weights_char,
                    weight_hold,
                    rit,
                    target_risk,
                    turnover,
                    stock_list,
                    is_print=True,    
                )

                turnover_ = np.sum(np.abs(weight_-weight_hold))
                if not is_status or turnover_ < self.hyperparms["turnover_min"]:
                    # 最適化に失敗した場合，リバランスを実施しない
                    # 取引コストの抑制のため，ターンオーバーが閾値を超えない場合はリバランスを実施しない
                    weight_ = pd.Series(weight_hold, index=stock_list)
                    
                status_all.append(is_status)
                weight_t_roll = pd.Series(np.zeros(len(self.stock_list)), index=self.stock_list)
                weight_t_roll[stock_list] = weight_
                weight.append(weight_t_roll)
                theta.append(pd.Series(theta_, index=["port"+str(k) for k in range(len(theta_))]))
            
            weight = pd.concat(weight, axis=1).T
            theta = pd.concat(theta, axis=1).T
        
            return weight.values, theta, status_all
        else:
            weight_add = self.model.forward(X, rt=None, mode="predict").detach().numpy().copy()
            weight_bench = np.ones(weight_add.shape)/weight_add.shape[1]
            weight = weight_bench + weight_add
            
            return weight
