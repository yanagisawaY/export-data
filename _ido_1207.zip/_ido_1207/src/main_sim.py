"""
シミュレーションデータによる検証
"""
import os
import datetime as dt
import matplotlib.pyplot as plt
import seaborn as sns
import time
import pickle
# パスの設定
PATH_HEAD = r"C:\Users\yana\Desktop\github\parametric_portfolio_boosting\ppboost\src"
os.chdir(PATH_HEAD)

from simulator.experimenter import Experimenter

# %%
# =============================================================================
# # モデルのハイパーパラメータ設定
# =============================================================================
hyperparms = {
    "random_state": 1,
    "batch_size": 60,
    "layer_list": [3],
    "lr": 1e-3,
    "epoch": 30,
    "is_cost": False,  # 取引コストを目的関数に入れ込むかどうか
    "utility_type" : "SR",
    "model": "UtilityTrader",        
    "network_type": "onc",
    "val_ratio": 0.25,
    "target_risk": 0.1,
    "turnover": 0.1,
    "turnover_min": 0.05,
    "is_opt": False,
    "gamma": 10,
    "layer_dropout": 0.05,
    "l2_norm": 0,# 1e-3,
    "min_epoch": 50, # 早期停止を適用しない学習回数
    "upper_patience_count": 10, # バリデーションデータが向上しないことが続いた場合，早期停止を実施
}

# =============================================================================
# hyperparms = {
#     "random_state": 1,
#     "batch_size": 60,
#     "layer_w": [16, 8],
#     "layer_g": [8],
#     "lr": 1e-3,
#     "gan_iter": 1, #6
#     "epoch_init": 10, #256,
#     "epoch_w": 10, #1024,    
#     "epoch_g": 10, #64,
#     "model": "UtilityGanTrader",    
#     "val_ratio": 0.25,
#     "dropout_w": 0.95,
#     "dropout_g": 0.95,    
#     "lambda": 10,
#     "leverage": 1000,
#     "is_cost": False,
# }
# 
# =============================================================================

# =============================================================================
# # バックテスト時の設定
# =============================================================================
hyperparms_portfolio = {
    "cost_buy": 0,
    "cost_sell": 0,
    "calc_type": "cumulative",
    "wealth_init": 100,
}

"""
hyperparms_portfolio : dict
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
"""
# =============================================================================
# # シミュレーションデータの設定
# =============================================================================
simulation_setting = {
    # 乱数シード
    "random_seed": 1,

    # 訓練データとテストデータを分割するインデックスの数値. The default is 0.
    # 0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
    "train_num": 0,

    # データセットサイズ関連(銘柄, 時点)
    "stock_num": 500,
    "time_num": 400,
    
    # シミュレーションデータの生成モード
    # [1] 非線形 + 依存関係
    # [2] 非線形+ 依存関係 + 3ファクタ
    # [3] 非線形 + 依存関係 + 3ファクター + 自己相関    
    "mode": 2,
    
    # ファクターリターンの平均と標準偏差
    "factor_mean": 0.005,
    "factor_std": 0.01,
    
    # 非システマティックリスクの誤差項
    "epsilon_std": 0.1,#0.1,
    
    # 企業特性間の相関係数
    "rho": 0.4,
    # 企業特性のAR(1)における係数    
    "phi": 0.8,

    # 冗長な企業特性データの生成
    "redundant_num": 0,
    "redundant_noise": 1,
    # 有効な企業特性にかける係数の最大値 ➡1より小さくすることでSDFに含まれるファクターよりはシグナルが弱いという設定
    # 係数は0~redundant_coefの一様乱数より生成
    "redundant_coef": 0.2,

    # ノイズな企業特性データの生成
    # "factor_noise_num": 5,
    "factor_noise_num": 0,    
    "factor_noise": 1,
}

# 比較モデルのハイパーパラメータ
hyperparms_comparative = {
    # 比較モデルの学習等を実施する場合はTrue
    "is_comparison": False,

    # 検証する比較モデルの名前
    "model_list": [
        "lasso",
        #        "randomforest",
        "lightgbm",
        "dnn",        
    ],

    # Lasso回帰のハイパーパラメータ
    "params_lasso":
        {
        "random_state": 1,
        "cv": 5,
    },

    # ランダムフォレスト回帰のハイパーパラメータ
    "params_randomforest":
        {
        "random_state": 1,
        "n_estimators": 100,
    },

    # LightGBM回帰のハイパーパラメータ
    "params_lightgbm":
        {
        "random_state": 1,
        "boosting_type": "gbdt",
        "silent": False,
        "n_estimators": 100,
    },

    # 深層学習のハイパーパラメータ
    "params_dnn" : 
        {
        "random_state"  : 1,            
        "layer_dropout" : 0.2,
        "layer_list"    : [5],
        "lr"            : 1e-5,
        "batch_size"    : 502,
        "epoch"         : 25,
        },
        
    # スコアに対してLS戦略を組む際のパーセンタイル
    "long_ratio": 0.90,
    "short_ratio": 0.1,

    # LongShort or Long / スコアに基づくポートフォリオ構築方法
    "portfolio_type": "LongShort",
}

# %%
if __name__ == "__main__":
    time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
    start = time.time()
    output = {}
    seed_pattern = 6

    sim_states = {}
    sim_coef = {}
    for seed in range(6, seed_pattern+1):
        output_name = "sim" + str(seed)
        print(f"実行中 / {output_name}")
        simulation_setting["random_seed"] = seed
        hyperparms["random_seed"] = int(seed*2+1)
        ex = Experimenter(hyperparms)
        output.update(ex.get_simulation_result(simulation_setting,
                      hyperparms_portfolio, hyperparms_comparative, output_name))

        fig = plt.figure()        
        output[output_name]['port_train'].iloc[:,:2].cumsum().plot(title=output_name+"_train")
        plt.show()
        output[output_name]['port_train'].iloc[:,2:].cumsum().plot(title=output_name+"_train")
        plt.show()        
        sns.heatmap(output[output_name]['port_train'].iloc[:,3:].corr(), annot=True)
        plt.show()        
        output[output_name]['feature_importance_train'].plot.bar(title=output_name+"_train")
        plt.show()        

        fig = plt.figure()   
        output[output_name]['port_test'].iloc[:,:2].cumsum().plot(title=output_name+"_test")
        plt.show()
        output[output_name]['port_test'].iloc[:,2:].cumsum().plot(title=output_name+"_test")
        plt.show()        
        sns.heatmap(output[output_name]['port_test'].iloc[:,3:].corr(), annot=True)
        plt.show()        
        output[output_name]['feature_importance_test'].plot.bar(title=output_name+"_test")
        plt.show()        
        
        # シミュレーションデータに関する情報\
        # sim_coef[output_name] = ex.sim.redundant_chosen

    # 結果の出力
    output_all = {
        "output": output,
        "hyperparms": hyperparms,
        "hyperparms_portfolio": hyperparms_portfolio,
        "hyperparms_comparative": hyperparms_comparative,

        # シミュレーションデータに関するデータ
        "simulation_setting": simulation_setting,
        "sim_states": sim_states,
        "sim_coef": sim_coef,
    }

    path_output = PATH_HEAD + "\\Result\\simulation\\" + time_now
    os.makedirs(path_output, exist_ok=True)
    ex.output_result(output_all, path_output)
    end = round(time.time() - start)
    print(f"time - {end}sec")    