"""
Standard Deep model
"""
from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import OneHotEncoder
import pandas as pd

class DeepNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''
    def __init__(self, hyperparms, input_num, output_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(DeepNet, self).__init__()
        layer_units = hyperparms['layer_list']        
        layer_num = len(layer_units)
        layer = []
        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(input_num, layer_units[0]))
        layer.append(nn.BatchNorm1d(layer_units[0]))
        layer.append(nn.ReLU())
        if layer_num > 1:
            for i in range(layer_num-1):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))
                layer.append(nn.Linear(layer_units[i], layer_units[i+1]))
                layer.append(nn.BatchNorm1d(layer_units[i+1]))
                layer.append(nn.ReLU())

        layer.append(nn.Dropout(hyperparms['layer_dropout']))                    
        layer.append(nn.Linear(layer_units[-1], output_num))
        if output_num == 3:
            layer.append(nn.Softmax(dim=1))
        self.full = nn.Sequential(*layer)
                            
    def forward(self, X):        
        output = self.full(X)
        
        return output.squeeze()


class DeepLearner:
    '''DNNの学習を行うクラス
    '''    
    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout  : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        self.hyperparms = hyperparms
        
    def fit(self, X, y):
        """モデル学習を実行

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : np.array or pandas.DataFrame
            被説明変数(銘柄×時点,)
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(y, pd.DataFrame):
            y = y.values
            
        torch.manual_seed(self.hyperparms['random_state'])            
        X = torch.Tensor(X)
        if self.hyperparms['loss'] == 'MSELoss':            
            y = torch.Tensor(y)
        elif self.hyperparms['loss'] == '3class':            
            y = torch.Tensor(y).squeeze().long()            
            
        df = TensorDataset(X, y)
        loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=True)
        input_num = X.size(1)
        
        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
            model = DeepNet(self.hyperparms, input_num, output_num=1)  
        elif self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()
            model = DeepNet(self.hyperparms, input_num, output_num=3) 

        optimizer = torch.optim.Adam(model.parameters(), lr = self.hyperparms['lr'])               
        for epoch in range(self.hyperparms['epoch']):
            for X_, y_ in loader:
                y_pred = model.forward(X_)
                loss = criterion(y_pred, y_)
                loss.backward()
                optimizer.step()
            
            if (epoch+1)%100==0:
                print(f'{epoch+1}/{self.hyperparms["epoch"]} : {round(loss.item(), 4)}')

        self.model = model
        
    def predict(self, X):
        """学習したパラメータをもとに予測値を出力

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量)

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        X = torch.Tensor(X)        
        y_pred = self.model.forward(X)
        y_pred = y_pred.detach().numpy().copy()

        return y_pred
    