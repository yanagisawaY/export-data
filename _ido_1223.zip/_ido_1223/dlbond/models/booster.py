

import lightgbm as lgb
import xgboost as xgb
import numpy as np
import pandas as pd
import optuna


class BoostLearner:
    """ブースティング系モデルの学習を行うクラス
    """
    def __init__(self, hyperparms):
        """
        hyperparms : dict
        """
        self.hyperparms = hyperparms        
        self.model_name = self.hyperparms["model"]
         # lightgbm, xgboostのclassに読み込ませるハイパーパラメータの辞書
         # →classの引数に関係のないハイパーパラメータは除外
        self.hyperparms_model = self._delete_key(
            hyperparms.copy(), 
            ["val_ratio", "model", "is_val", "early_stopping_rounds", "loss", "is_best_ntree"]
            )
        self.hyperparms_fit = {
            "early_stopping_rounds": hyperparms["early_stopping_rounds"],            
            }
        self.study = None
        self.is_fit_cv = False

    def _delete_key(self, hyperparms_model, delete_list):
        """指定したキーとその要素を辞書から削除

        Parameters
        ----------
        hyperparms_model : dict
            キー除外前の辞書データ.
        delete_list : list
            削除したいキーのリスト.

        Returns
        -------
        hyperparms_model : dict
            キーを削除した辞書.
        """
        assert sum([x not in list(hyperparms_model.keys()) for x in delete_list])==0,(
            "学習時に必要なパラメータが設定されていません"
            )
        for key in delete_list:
            del hyperparms_model[key]        
        
        return hyperparms_model

    def _call_categorical_features(self):
        self.categorical_features = ""

    def _call_criterion_lgb(self):
        """回帰問題や多クラス分類などにあわせ，目的関数・評価関数を設定(lightgbmの設定)
        """
        if self.hyperparms["loss"] == "MSELoss":
            self.hyperparms_model["objective"] = "regression"
            self.hyperparms_fit["eval_metric"] = "l2"
        elif self.hyperparms["loss"] == "2class":
            self.hyperparms_model["objective"] = "binary"
            self.hyperparms_fit["eval_metric"] = "logloss"
        elif self.hyperparms["loss"] == "3class":
            self.hyperparms_model["objective"] = "multiclass"
            self.hyperparms_fit["eval_metric"] = "logloss"

    def _call_criterion_xgb(self):
        """回帰問題や多クラス分類などにあわせ，目的関数・評価関数を設定(xgboostの設定)
        """        
        if self.hyperparms["loss"] == "MSELoss":
            self.hyperparms_model["objective"] = "reg:squarederror"
            self.hyperparms_fit["eval_metric"] = "rmse"
        elif self.hyperparms["loss"] == "2class":
            self.hyperparms_model["objective"] = "binary:logistic"
            self.hyperparms_fit["eval_metric"] = "logloss"
            self.hyperparms_model["use_label_encoder"] = False # エラーメッセージの回避
        elif self.hyperparms["loss"] == "3class":
            self.hyperparms_model["objective"] = "multi:softmax"
            self.hyperparms_fit["eval_metric"] = "logloss"
            self.hyperparms_model["num_class"] = 3

    def _call_model(self):
        """モデルの呼び出し(目的関数などの設定も更新)

        Returns
        -------
        model : class
            モデルクラス
        
        Notes
        -----
        * Scikit-Learn Wrapper interfaceを使用
        """
        if self.model_name == "lightgbm":
            self._call_criterion_lgb()
        elif self.model_name == "xgboost":
            self._call_criterion_xgb()

        self._call_categorical_features()
        
        if self.model_name == "lightgbm":
            if self.hyperparms["loss"] == "MSELoss":
                model = lgb.LGBMRegressor
            elif "class" in self.hyperparms["loss"]:
                model = lgb.LGBMClassifier
        elif self.model_name == "xgboost":
            if self.hyperparms["loss"] == "MSELoss":
                model = xgb.XGBRegressor
            elif "class" in self.hyperparms["loss"]:        
                model = xgb.XGBClassifier

        return model

    def _fit(self, X, y, X_val=[], y_val=[], hyperparms_model=[]):        
        if len(hyperparms_model)==0:
            hyperparms_model = self.hyperparms_model
        model = self._call_model()
        if len(X_val) > 0 and len(y_val) > 0:
            model_fit_params = {
                "X": X,
                "y": y,
                "eval_set": [(X, y), (X_val, y_val)],
                "eval_metric": self.hyperparms_fit["eval_metric"],
                "early_stopping_rounds": self.hyperparms_fit["early_stopping_rounds"],
                "verbose": False,  # 学習の経過の非表示
            }
        else:     
            model_fit_params = {
                "X": X,
                "y": y,
                "eval_set": [(X, y),],
                "eval_metric": self.hyperparms_fit["eval_metric"],
                "verbose": False,  # 学習の経過の非表示                    
            }
                
        model = model(**hyperparms_model).fit(**model_fit_params)        
        evals_result = model.evals_result_

        return model, evals_result
    
    def _to_pandas_frame(self, evals_result : dict):
        if len(evals_result) == 2:
            evals_result = pd.concat([
                pd.DataFrame.from_records(evals_result["train"]),
                pd.DataFrame.from_records(evals_result["ation_1"])
                ], axis=1)
            evals_result.columns = ["train", "ation_1"]
        else:
            evals_result = pd.DataFrame.from_records(evals_result["train"])
            evals_result.columns = ["train"]          
        
        return evals_result

    def fit(self, X, y, is_val=False, hyperparms_model=[]):
        """モデル学習を実行

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ(時点, 特徴量)
        y : pd.Series
            被説明変数(時点,)            
        is_val : bool, optional
            バリデーションデータを用いた早期停止条件を課す場合はTrue, by default False
        hyperparms_model : dict
            モデルのハイパーパラメータが格納された辞書．何も入力がされていない場合，self.hyperparams_modelで実行される．

        Attributes
        ----------
        model : 
            学習済みモデル
        evals_result : pd.DataFrame
            学習回数ごとの目的関数値
        """
        if is_val:
            val_num = int(X.shape[0]*(1-self.hyperparms["val_ratio"]))
            X_, y_ = X, y
            X = X_.iloc[:val_num, :]
            y = y_.iloc[:val_num]
            X_val = X_.iloc[val_num:, :]
            y_val = y_.iloc[val_num:]
            if len(hyperparms_model)>0:            
                self.model, self.evals_result = self._fit(X, y, X_val, y_val, hyperparms_model)
            else:
                self.model, self.evals_result = self._fit(X, y, X_val, y_val)                
        else:
            if len(hyperparms_model)>0:
                self.model, self.evals_result = self._fit(X, y, hyperparms_model)
            else:
                self.model, self.evals_result = self._fit(X, y)                
                
    def fit_cv(self, dict_val, hyperparms_model=[]):
        """モデル学習を実行

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        models : 
            各ホールドのデータセットで学習したモデル
        evals_result_save : pd.DataFrame
            各ホールドのデータセットにおける学習回数ごとの目的関数値
        """
        models = {}
        evals_result_save = {}
        loss_sum = 0
        for i, dict_ in dict_val.items():
            (X_train, y_train, X_val, y_val) = dict_.values()
            if len(hyperparms_model)>0:
                model, evals_result = self._fit(X_train, y_train, X_val, y_val, hyperparms_model)
            else:
                model, evals_result = self._fit(X_train, y_train, X_val, y_val)
            models.update({i: model})
            evals_result_save.update({i: evals_result})

        self.models = models
        self.evals_result_save = evals_result_save
        self.is_fit_cv = True
        self.loss_sum = loss_sum
        
    def predict_cv(self, X, ensemble_weight=[]):
        """CVを用いて学習したモデルの予測値をアンサンブルした予測値を出力

        Parameters
        ----------
        X : pd.DataFrame
            特長量データ．
        ensemble_weight : list, optional
            各モデルの出力値の重みづけ．特に設定しない場合，等ウェイトの予測値を出力．

        Returns
        -------
        y_pred_ensembled : np.array
            アンサンブルした予測値
        """
        if len(ensemble_weight) == 0:
            ensemble_weight = [1/len(self.models)
                               for _ in range(len(self.models))]
        
        if self.hyperparms["loss"] == "3class":
            y_pred_ensembled = np.zeros((X.shape[0], 3)) 
        elif self.hyperparms["loss"] == "2class":
            y_pred_ensembled = np.zeros((X.shape[0], 2)) 
        elif self.hyperparms["loss"] == "MSELoss":
            y_pred_ensembled = np.zeros(X.shape[0])
                    
        for i, model in enumerate(self.models.values()):
            if self.hyperparms["is_best_ntree"]:
                if self.model_name == "xgboost":
                    if "class" in self.hyperparms["loss"]:
                        y_pred = model.predict_proba(X, iteration_range=(0, model.best_ntree_limit))
                    else:
                        y_pred = model.predict(X, iteration_range=(0, model.best_ntree_limit))
                elif self.model_name == "lightgbm":
                    if "class" in self.hyperparms["loss"]:
                        y_pred = model.predict_proba(X, num_iteration=model.best_iteration_)
                    else:
                        y_pred = model.predict(X, num_iteration=model.best_iteration_)
            else:
                y_pred = model.predict(X)
            y_pred_ensembled += ensemble_weight[i]*y_pred
        
        return y_pred_ensembled

    def predict(self, X):
        """学習したパラメータをもとに予測値を出力
        
        Parameters
        ----------
        X : pandas.DataFrame
            特徴量データ(時点, 特徴量) 

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        assert isinstance(X, pd.DataFrame)

        if self.is_fit_cv:
            y_pred = self.predict_cv(X)
        else:
            if self.hyperparms["is_best_ntree"]:
                if self.model_name == "xgboost":                
                    if "class" in self.hyperparms["loss"]:
                        y_pred = self.model.predict_proba(X, iteration_range=(0, self.model.best_ntree_limit))
                    else:
                        y_pred = self.model.predict(X, iteration_range=(0, self.model.best_ntree_limit))                
                elif self.model_name == "lightgbm":
                    if "class" in self.hyperparms["loss"]:                    
                        y_pred = self.model.predict_proba(X, num_iteration=self.model.best_iteration_)
                    else:                        
                        y_pred = self.model.predict(X, num_iteration=self.model.best_iteration_)
            else:
                if "class" in self.hyperparms["loss"]:                                    
                    y_pred = self.model.predict_proba(X)
                else:
                    y_pred = self.model.predict(X)                    
        
        return y_pred

    def tune(self, X, y, X_val, y_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : pandas.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : pandas.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : pandas.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        study : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
            [1] https://optuna.org/
        """
        hyperparms_model = self.hyperparms_model

        def objective(trial):
            if self.model_name=="xgboost":
                hyperparms_model["eta"] = 0.1          
                hyperparms_model["max_depth"] = trial.suggest_int("max_depth", 3, 9)
                hyperparms_model["min_child_weight"] = trial.suggest_loguniform("min_child_weight", 0.1, 10)
                hyperparms_model["gamma"] = trial.suggest_loguniform("gamma", 1e-8, 1)
                hyperparms_model["colsample_bytree"] = trial.suggest_uniform("colsample_bytree", 0.6, 0.95)
                hyperparms_model["subsample"] = trial.suggest_uniform("colsample_bytree", 0.6, 0.95)                                
            elif self.model_name=="lightgbm":
                hyperparms_model["feature_fraction"] = trial.suggest_uniform("feature_fraction", 0.4, 1.0)
                hyperparms_model["lambda_l1"] = trial.suggest_loguniform("lambda_l1", 1e-8, 10.0),     
                hyperparms_model["lambda_l2"] = trial.suggest_loguniform("lambda_l2", 1e-8, 10.0),
                hyperparms_model["num_leaves"] = trial.suggest_int("num_leaves", 2, 256),
                hyperparms_model["bagging_fraction"] = trial.suggest_uniform("bagging_fraction", 0.4, 1.0)
                hyperparms_model["bagging_freq"] = trial.suggest_int("bagging_freq", 1, 7)
                hyperparms_model["min_child_samples"] = trial.suggest_int("min_child_samples", 5, 100)
                # if extra_trees set to true, when evaluating node splits LightGBM will check only one randomly-chosen threshold for each feature
                hyperparms_model["extra_trees"] = trial.suggest_categorical("extra_trees", [True, False])
                                
            _, evals_result = self._fit(X, y, X_val, y_val, hyperparms_model=hyperparms_model)
            
            if self.hyperparms["is_best_ntree"]:
                loss = np.array(list(evals_result[list(evals_result.keys())[1]].values())[0]).min()
            else:
                loss = list(evals_result[list(evals_result.keys())[1]].values())[0][-1]
                    
            return loss

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms["random_state"])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler)
        study.optimize(
            objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"])
        self.study = study

    def tune_Kfold_nonprune(self, dict_val, is_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化をPurgedKfoldにより実施

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        study : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
            [1] https://optuna.org/
        
        Notes
        -----
        現状の設定では，lightgbmもxgboostもどちらも早期停止した場合，
        最もバリデーションデータの評価値のよいパラメータをとっているわけではなく，早期停止した段階での結果を参照している．\n
        →最もバリデーションデータの評価値のよいパラメータをとる方法も場合によっては検討してもよい
        `xgboost docs<https://xgboost.readthedocs.io/en/stable/python/python_intro.html>`_ \n
        If early stopping occurs, the model will have two additional fields:   \n
        bst.best_score, bst.best_iteration. Note that xgboost.train() will return a model  \n
        from the last iteration, not the best one.
        
        * xgboostのハイパーパラメータの設定参照元 : `Kaggleで勝つデータ分析の技術<https://gihyo.jp/book/2019/978-4-297-10843-4>`_
        
        * lightgbmのハイパーパラメータの設定参照元 : `Optuna の拡張機能 LightGBM Tuner によるハイパーパラメータ自動最適化<https://tech.preferred.jp/ja/blog/hyperparameter-tuning-with-optuna-integration-lightgbm-tuner/>`_        
        
        -> 本来であれば．optunaの拡張機能が使えることが望ましいが，本件はバリデーションデータの分割が特殊であるため，これらを使用しなかった．
        
        -> lightgbmのオプションであるextra_treesをTrueにすることがパフォーマンス向上に(経験則的に)
        つながることが書かれた記事があったことを参考にし，ハイパーパラメータとして追加
        `(参照元)<https://note.com/j26/n/n64d9c37167a6>`_
        """
        hyperparms_model = self.hyperparms_model

        def objective(trial):
            if self.model_name=="xgboost":
                hyperparms_model["eta"] = 0.1          
                hyperparms_model["max_depth"] = trial.suggest_int("max_depth", 3, 9)
                hyperparms_model["min_child_weight"] = trial.suggest_loguniform("min_child_weight", 0.1, 10)
                hyperparms_model["gamma"] = trial.suggest_loguniform("gamma", 1e-8, 1)
                hyperparms_model["colsample_bytree"] = trial.suggest_uniform("colsample_bytree", 0.6, 0.95)
                hyperparms_model["subsample"] = trial.suggest_uniform("colsample_bytree", 0.6, 0.95)                                
            elif self.model_name=="lightgbm":
                hyperparms_model["feature_fraction"] = trial.suggest_uniform("feature_fraction", 0.4, 1.0)
                hyperparms_model["lambda_l1"] = trial.suggest_loguniform("lambda_l1", 1e-8, 10.0),     
                hyperparms_model["lambda_l2"] = trial.suggest_loguniform("lambda_l2", 1e-8, 10.0),
                hyperparms_model["num_leaves"] = trial.suggest_int("num_leaves", 2, 256),
                hyperparms_model["bagging_fraction"] = trial.suggest_uniform("bagging_fraction", 0.4, 1.0)
                hyperparms_model["bagging_freq"] = trial.suggest_int("bagging_freq", 1, 7)
                hyperparms_model["min_child_samples"] = trial.suggest_int("min_child_samples", 5, 100)
                # if extra_trees set to true, when evaluating node splits LightGBM will check only one randomly-chosen threshold for each feature
                hyperparms_model["extra_trees"] = trial.suggest_categorical("extra_trees", [True, False])

            loss_all = 0
            for i, dict_ in enumerate(dict_val.values()):
                print(f"{i}/{len(dict_val)} fold")
                (X, y, X_val, y_val) = dict_.values()
                _, evals_result = self._fit(X, y, X_val, y_val, hyperparms_model=hyperparms_model)

                if self.hyperparms["is_best_ntree"]:
                    loss_all += np.array(list(evals_result[list(evals_result.keys())[1]].values())[0]).min()
                else:                
                    loss_all += list(evals_result[list(evals_result.keys())[1]].values())[0][-1] 

            loss_all = loss_all/len(dict_val)

            return loss_all

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms["random_state"])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler)
        study.optimize(objective, n_trials=n_trials, timeout=timeout)
        self.study = study

    def update_hyperparams(self, hyperparms_best_updated={}):
        """optunaにより調整したハイパーパラメータの辞書の更新

        Parameters
        ----------
        hyperparms_best_updated : dict
            更新されたハイパーパラメータ (チューニングされたパラメータのみ)

            指定しない場合，tuneにより調整されたstudyのbest_trialが参照される．

        Raises
        ----------
        optunaのハイパーパラメータ最適化( tune )を先に実行する

        Returns
        -------
        hyperparms_best : dict
            更新したハイパーパラメータの辞書
        """
        if len(hyperparms_best_updated) == 0:            
            if self.study is None:
                raise ValueError("tuneを実行してください")                    
            hyperparms_best = self.hyperparms
            hyperparms_best_updated = self.study.best_trial.params            
        else:
            assert isinstance(hyperparms_best_updated, dict)
            hyperparms_best = self.hyperparms
            
        for key, val in hyperparms_best_updated.items():
            hyperparms_best[key] = val
                        
        self.hyperparms = hyperparms_best

        return hyperparms_best