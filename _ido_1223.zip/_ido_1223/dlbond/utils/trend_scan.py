import pandas as pd
import numpy as np
import statsmodels.api as sm1

def tval_linear(close):
    """線形トレンドからt値を算出

    Parameters
    ----------
    close : pd.Series
        予測対象の原形列値

    Returns
    -------
    tvalues
        線形トレンドから算出したt値

    Note
    -------        
    本関数はアセットマネージャーのためのファイナンス機械学習のスニペット5.2に記載されたコードである．
    命名もこちらの本に従い設定．
    """
    x = np.ones((close.shape[0],2))
    x[:,1] = np.arange(close.shape[0])
    ols = sm1.OLS(close, x).fit()
    tvalues = ols.tvalues[1]

    return tvalues

def trend_scan(molecule, close, span):
    """線形トレンドのt値の符合からラベルを作成

    Parameters
    ----------
    molecule : pd.core.indexes.datetimes.DatetimeIndex
        ラベルづけしたい観測値のインデックス
    close : pd.Series
        X_tの時系列
    span : list
        絶対値が最大のt値を探索する際にアルゴリズムが評価するLの値(ウィンドウ)の集合
        組み込み関数であるrange関数の引数として渡すリスト

    Returns
    -------
    output : pd.DataFrame
        t1   : 発見されたトレンドの終了時点
        tVal : 推定トレンド回帰係数のt値
        bin  : トレンドの符合 

    Note
    -------        
    本関数はアセットマネージャーのためのファイナンス機械学習のスニペット5.2に記載されたコードである．
    命名もこちらの本に従い設定．
    ※ 元コードからリーケージの期間を1つスライドしていることに注意．
    """
    out = pd.DataFrame(index=molecule, columns=['t1', 'tVal', 'bin'])
    hrzns = range(*span)

    for dt0 in molecule:
        df0 = pd.Series()
        iloc0 = close.index.get_loc(dt0) + 1
        if iloc0+max(hrzns)>=close.shape[0]:
            continue
        for hrzn in hrzns:
            dt1 = close.index[iloc0+hrzn]
            df1 = close.loc[dt0:dt1]
            df0.loc[dt1] = tval_linear(df1.values)

        dt1 = df0.replace([-np.inf, np.inf, np.nan], 0).abs().idxmax()
        out.loc[dt0, ['t1', 'tVal', 'bin']] = df0.index[-1], df0[dt1], np.sign(df0[dt1])
    out['t1'] = pd.to_datetime(out['t1'])
    out['bin'] = pd.to_numeric(out['bin'], downcast='signed')
    output = out.dropna(subset=['bin'])
    return output 