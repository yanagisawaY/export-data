# -*- coding: utf-8 -*-
"""
損失関数
@author: Yanagisawa
"""
from torch.distributions.multivariate_normal import MultivariateNormal
import torch.distributions as tdist
import numpy as np
import torch

def gaussian_likelihood_loss(z, mu, sigma):
    '''
    Gaussian Liklihood Loss
    Args:
    z (tensor): true observations, shape (num_ts, num_periods)
    mu (tensor): mean, shape (num_ts, num_periods)
    sigma (tensor): standard deviation, shape (num_ts, num_periods)
    '''
    negative_likelihood = 2*torch.log(sigma) + (z - mu)**2 / (2*sigma**2)
    return negative_likelihood.mean()