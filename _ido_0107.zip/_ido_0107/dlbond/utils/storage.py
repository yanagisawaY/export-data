import os

import pandas as pd


class Storage:
    def __init__(self, now="", path=None, dir_="\\experiment\\result\\", add_path=""):
        self.now = now
        self.path = path
        self.dir_ = dir_
        self.add_path = add_path
    
    def save(self, model, result, file_name, now="", path=None, dir_=None):
        if now == "":
            now = self.now
        if path is None:
            path = self.path
        if dir_ is None:
            dir_ = self.dir_
        
        if len(self.add_path) == 0:
            folder_ = file_name.split("/")[0] + "\\" + now + "\\" + file_name.split("/")[1]
        else:
            folder_ = file_name.split("/")[0] + "\\feature_select\\" + now + "\\" + self.add_path + "\\" + file_name.split("/")[1]
            
        output_path = path + dir_ + folder_
        os.makedirs(output_path, exist_ok=True)
        os.makedirs(output_path + "\\params", exist_ok=True)       
                
        pd.to_pickle(model, output_path + "\\params\\model.pkl")
        pd.to_pickle(result, output_path + "\\result.pkl")
        term_info = result["term"]
        pd.to_pickle(term_info, output_path + "\\term_info.pkl")
        
    def save_result_all(self, result_all, file_name, now="", path=None, dir_=None):
        if now == "":
            now = self.now
        if path is None:
            path = self.path
        if dir_ is None:
            dir_ = self.dir_

        if len(self.add_path) == 0:        
            self.output_path = path + dir_ + file_name + "\\" + now
        else:
            self.output_path = path + dir_ + file_name + "\\feature_select\\" + now + "\\" + self.add_path
        os.makedirs(self.output_path, exist_ok=True)
        pd.to_pickle(result_all, self.output_path + "\\result_all.pkl")
    
    def save_config(self, config, now="", path=None, dir_=None):
        pd.to_pickle(config, self.output_path + "\\config.pkl")
        
    def save_result_feature_select(self, result_trial):
        assert len(self.add_path) > 0
        temp = self.output_path.split("\\"+self.add_path)[0]
        pd.to_pickle(result_trial, temp + "\\result_trial.pkl")
        
        
        