import copy
import pandas as pd
import numpy as np
import os
import glob
import datetime as dt
from .split import Splitter

def get_models_result(path=None):
    """experiment直下のresultフォルダーに格納されたモデル，configを全パターン抽出

    Parameters
    ----------
    path : str
        experiment/resultのフォルダパス

    Returns
    -------
    models_result : dict
        以下の構造で辞書形式にモデル, config情報を保存
        
        Notes
        -----
        |- model1
            |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
                |- termX : model.pkl, term_info.pklをタームごとにtupleで保存
                |- config.pkl : 設定ファイル 
    """
    if path is None:
        path = os.getcwd()+"\\experiment\\result"
        
    model_files = [x.split("\\")[-1] for x in glob.glob(path + "/**")]
    models_result = {model_:{} for model_ in model_files}
    for model_ in model_files:
        path_model = path + "\\" + model_
        timestamp_files = [x.split("\\")[-1] for x in glob.glob(path_model + "/**")]
        models_result[model_] = {timestamp:{} for timestamp in timestamp_files}
        for timestamp in timestamp_files:
            path_stamp = path_model + "\\" + timestamp        
            dir_all = os.walk(path_stamp) 
            for dirs, _, files in dir_all:
                key_ = dirs.split("\\params")[0].split("\\")[-1]           
                if len(files)>0 and "result.pkl" == files[0]:
                    result = dirs.split("\\params")[0] + "\\result.pkl"
                    models_result[model_][timestamp].update({
                        key_: (
                            pd.read_pickle(result)
                            )})
                elif len(files)>0 and "config.pkl" == files[0]:
                    models_result[model_][timestamp].update({
                        "result_all": pd.read_pickle(dirs + "/" + files[1])
                    })
                    
    return models_result

def get_models_info(path=None):
    """experiment直下のresultフォルダーに格納されたモデル，configを全パターン抽出

    Parameters
    ----------
    path : str
        experiment/resultのフォルダパス

    Returns
    -------
    models_info : dict
        以下の構造で辞書形式にモデル, config情報を保存
        
        Notes
        -----
        |- model1
            |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
                |- termX : model.pkl, term_info.pklをタームごとにtupleで保存
                |- config.pkl : 設定ファイル 
    """
    if path is None:
        path = os.getcwd()+"\\experiment\\result"
        
    model_files = [x.split("\\")[-1] for x in glob.glob(path + "/**")]
    models_info = {model_:{} for model_ in model_files}
    for model_ in model_files:
        path_model = path + "\\" + model_
        timestamp_files = [x.split("\\")[-1] for x in glob.glob(path_model + "/**")]
        models_info[model_] = {timestamp:{} for timestamp in timestamp_files}
        for timestamp in timestamp_files:
            path_stamp = path_model + "\\" + timestamp        
            dir_all = os.walk(path_stamp)    
            for dirs, _, files in dir_all:
                key_ = dirs.split("\\params")[0].split("\\")[-1]           
                if len(files)>0 and "model.pkl" == files[0]:
                    term = dirs.split("\\params")[0] + "\\term_info.pkl"
                    models_info[model_][timestamp].update({
                        key_: (
                            pd.read_pickle(dirs + "/" + files[0]), 
                            pd.read_pickle(term)
                            )})
                elif len(files)>0 and "config.pkl" == files[0]:
                    models_info[model_][timestamp].update({
                        "config": pd.read_pickle(dirs + "/" + files[0])            
                    })
                    
    return models_info


class ModelEnsembler(Splitter):
    def __init__(self, dfs_input, models_info):
        self.super_max_features(dfs_input, models_info)
        self.models_info_init = models_info
    
    def super_max_features(self, dfs_input, models_info):
        """モデルが使用するデータの和集合を抽出し，Splitterクラスへ継承する

        Parameters
        ----------
        dfs_input : dict
            入力データ
        config : dict
            設定ファイル
        models_info : dict
            モデル情報
        
        Notes
        -----
        テクニカル指標の作成をモデルごとに行わないために，必要となるテクニカル指標をすべて初期段階でまとめて作成する
        
        ただし，PCAの変換とCODEに基づく変換はモデルごとの設定に基づくため，モデルごとに処理を行う
        """
        features = 1
        features_ohlcv = 1
        
        for model_ in models_info.values():
            for i, models_timestamp in enumerate(model_.values()):
                if i == 0:
                    config = models_timestamp["config"]
                features_ = models_timestamp["config"]["features"]
                features = (features_==0)*features
                features_ohlcv_ = models_timestamp["config"]["features_ohlcv"]            
                features_ohlcv = (features_ohlcv_==0)*features_ohlcv
        
        config["features"] = config["features"]*(features == 0)
        config["features_ohlcv"] = config["features_ohlcv"]*(features_ohlcv == 0)
                
        return super().__init__(dfs_input, config)
    
    def process_code(self, X, features):
        """CODEに基づいて特長量を変換

        Parameters
        ----------
        X : pd.DataFrame
            特長量データ
        features : pd.DataFrame
            特長量データの設定に関するデータフレーム

        Returns
        -------
        X : pd.DataFrame
            CODEに基づいて変換した特長量データ
        """
        explained_names = list(features.loc[features['CODE']>0,:].index)        
        code_list = features.loc[explained_names, 'CODE']
        
        df_explained = []        
        for explained_name in explained_names:
            df_explained.append(self.convert_raws(X[explained_name], code=code_list[explained_name]))

        df_explained = pd.concat(df_explained, axis=1) 
        X.loc[:,df_explained.columns] = df_explained
        X = self.fill_na(X)
        
        return X
    
    def process(self, X, model, pca_features):
        """標準化やPCAにより前処理を実施する

        Parameters
        ----------
        X : pd.DataFrame
            CODEに基づいて変換した特長量データ
        model : model
            学習済みモデルデータ
        pca_features : list
            PCA変換を実施する変数名

        Returns
        -------
        X : pd.DataFrame
            前処理済みの特長量データ
        """
        for process in model.processor_save:
            if "PCA" in str(type(process)):
                col_pca = ['PCA'+str(i+1) for i in range(process.n_components)]
                temp = pd.DataFrame(
                    process.transform(X[pca_features]), 
                    columns=col_pca, 
                    index=X.index)                                
                X = pd.concat([temp, X.drop(pca_features, axis=1)], axis=1)                                
            elif "StandardScaler" in str(type(process)):
                X = pd.DataFrame(
                    process.transform(X), 
                    columns=X.columns, 
                    index=X.index)
        
        return X
    
    def generate(self, X):
        """学習済みモデルを用いて予測値を出力

        Parameters
        ----------
        X : pd.DataFrame
            前処理済みの特長量データ

        Yields
        -------
        y_pred : np.ndarray
            予測値
        """
        start_date_test = X.index[0]
        for model_ in self.models_info.values():
            for models_timestamp in model_.values():      
                X_code = X.copy()                
                config = models_timestamp["config"]
                features = config["features"]
                # X_code = self.process_code(X_, features).dropna()
                pca_features = list(features.loc[features['PCA']==1,:].index)
                for key, tuple_ in models_timestamp.items():
                    if key != "config":
                        model, term_info, is_model = tuple_
                        
                        if is_model:                       
                            end_date_train = term_info["end_date_train"].values[0]
                            
                            if end_date_train > start_date_test:
                                break
                            
                            X_processed = self.process(X_code, model, pca_features)                        
                            y_pred = model.predict(X_processed)
                            position = pd.Series(model.trader.make_signal(
                                                 y_pred), index=X_code.index)                            
                            
                            yield position
    
    def set_ensemble_pattern(self, mode, start_date_test=None):
        """予測に使用する学習済みモデルの選択

        Parameters
        ----------
        mode : str
            使用する学習済みモデルの選択
            
            * all : 全termの学習モデルを使用
            
            * term_last : 最終期間の学習モデルを使用(リークのない範囲でモデルを選択)
                        
        start_date_test : datetime
            テストデータの開始時点
        """
        assert mode == "all" or mode == "term_last"
        
        self.ensemble_cols = []
        self.models_info = copy.deepcopy(self.models_info_init)
        for model_, models in self.models_info.items():
            for timestamp, models_timestamp in models.items():
                end_date_trains = {}
                for term, tuple_ in models_timestamp.items():                        
                    if term != "config":
                        _, term_info = tuple_
                        end_date_train = term_info["end_date_train"].values[0]
                                                   
                        end_date_trains.update({
                            term: end_date_train
                            })
                        
                        if mode == "all" and end_date_train <= start_date_test:
                            self.models_info[model_][timestamp][term] += (True,)
                            self.ensemble_cols.append(model_+"_"+timestamp+"_"+term)                            
                        else:
                            self.models_info[model_][timestamp][term] += (False,)

                if mode == "term_last":                
                    last_term = [key for key, val in end_date_trains.items() if val<=start_date_test][-1]
                    temp = self.models_info[model_][timestamp][last_term]
                    temp = list(temp)
                    temp[2] = True
                    self.models_info[model_][timestamp][last_term] = tuple(temp)
                    self.ensemble_cols.append(model_+"_"+timestamp+"_"+last_term)
                                                                    
    def predict_all(self, X, mode):
        """各学習モデルの予測値を出力

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
            
        Returns
        -------
        position : np.ndarray
            各学習モデルの予測値
        """
        start_date_test = X.index[0]
        self.set_ensemble_pattern(mode, start_date_test)        
        positions = []
        positions = [position for position in self.generate(X)]
        positions = pd.concat(positions, axis=1)
        positions.columns=self.ensemble_cols
                
        return positions
    
    def ensemble(self, X, mode):
        """アンサンブルしたモデルの予測値

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)

        Returns
        -------
        y_pred
            予測値
        """
        positions = self.predict_all(X, mode)
        position = positions.mode(1)
        if position.shape[1]>1:
            position = position.iloc[:,0]
        
        return position