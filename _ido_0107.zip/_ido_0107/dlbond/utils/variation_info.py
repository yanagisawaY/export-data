"""Variation on Informationを算出

References
----------
* アセットマネージャーのためのファイナンス機械学習の3章を参考
"""
import numpy as np
from sklearn.metrics import mutual_info_score
import scipy.stats as ss
import pandas as pd


def _set_bins(n_obs, corr=None):
    """離散化の最適ビン数を算出(P.61参照)

    Parameters
    ----------
    n_obs : int
        観測値の数
    corr : float, optional
        相関係数. The default is None.

    Returns
    -------
    bins : int
        離散化の最適ビン数.
    """

    if corr is None:
        # 単変量の場合
        z = (8 + 324 * n_obs + 12 * (36 * n_obs + 729 * n_obs ** 2) ** 0.5) ** (
            1 / 3
        )
        b = round(z / 6 + 2 / (3 * z) + 1 / 3)
    else:
        # 二変量の場合
        b = round(
            2 ** (-0.5) * ((1 + (1 + 24 * n_obs / (1 - corr ** 2)) ** 0.5) ** 0.5)
        )

    bins = int(b)
    return bins

def _calc_vi(x, y, norm=True):
    """離散化された連続確率変数のVariation of Informationを算出

    Parameters
    ----------
    x : np.array
        系列1.
    y : np.array
        系列2.
    norm : bool, optional
        正規化したVIを算出する場合はTrue. The default is False.

    Returns
    -------
    vi : float
        Variation of Information.
    """
    bins = _set_bins(x.shape[0], corr=np.corrcoef(x, y)[0, 1])
    contingency = np.histogram2d(x, y, bins)[0]
    multi_info = mutual_info_score(None, None, contingency=contingency)
    peripheral_entropy_x = ss.entropy(np.histogram(x, bins)[0])
    peripheral_entropy_y = ss.entropy(np.histogram(y, bins)[0])

    vi = peripheral_entropy_x + peripheral_entropy_y - 2 * multi_info

    if norm:
        vi_denominator = peripheral_entropy_x + peripheral_entropy_y - multi_info
        vi = vi / vi_denominator

    return vi

def VarInfo(X, norm=True):
    """データフレームのVariation on Informationを算出する

    Parameters
    ----------
    X : pd.DataFrame
        データフレーム.
    norm : bool, optional
        正規化したVIを算出する場合はTrue. The default is False.
    
    Returns
    -------
    vi_matrix : np.array
        Variation of Informationが格納された行列.
    """
    assert isinstance(X, pd.DataFrame)
    mat_size = X.shape[1]
    vi_matrix = np.zeros((mat_size, mat_size))

    for i in range(mat_size):
        for j in range(i + 1, mat_size):
            vi_matrix[i, j] = _calc_vi(
                X.iloc[:, i].values, X.iloc[:, j].values, norm
            )
            vi_matrix[j, i] = vi_matrix[i, j]

    vi_matrix = pd.DataFrame(vi_matrix)
    vi_matrix.columns = vi_matrix.index = X.columns

    return vi_matrix

