import pandas as pd
print("loading data...")
sheet_names = pd.ExcelFile('data/input_data.xlsx').sheet_names
data_names = ['daily', 'week', 'ohlcv', 'month', 'irregular']
dfs_input = pd.read_excel('data/input_data.xlsx',
                          sheet_name=data_names, index_col=0)

for key, df in dfs_input.items():
    dfs_input[key].index = pd.to_datetime(df.index)

print("complete!")
