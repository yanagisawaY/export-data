# -*- coding: utf-8 -*-
"""
@author: Yanagisawa
"""
import os
import numpy as np
import sys
import pandas as pd
import torch
import random
import matplotlib.pyplot as plt
import time
os.chdir(r'C:\Users\猛\Desktop\yoshiki_study\timeseries forecasting')
from data import data_generator
from model.trainer import Trainer 

df_org = pd.read_csv('data/index_data.csv', encoding = 'utf-8').set_index('Date')
df = df_org.copy()

def convert(x):
    if x[0] == 1:
        x = x[1:]
    elif x[0] == 2:
        x = x[1:].diff()
    elif x[0] == 3:
        x = x[1:].pct_change()
    else:
        sys.exit('Codeは1~3の値を選択')
    return x

#target_names = ['GJGB10 index', 'USGG10YR Index']
target_names = ['USGG10YR Index']
df_org.loc['Code', target_names] = 2
df = df_org.apply(convert).replace([np.inf, -np.inf], np.nan).dropna()
df = df.iloc[:,20:23]
df = df[target_names]
df.index = pd.to_datetime(df.index)

config = {
    'model_name'  : 'deep_factors',
    'random_seed' : 777,
    'time_steps'  : 5,        
    'len_train'   : 100,
    'len_val'     : 30,
    'len_test'    : 30,
    'batch_size'  : 32,
    'device'      : torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    }

train_start_index = 10
dg = data_generator.DataGenerator(config['random_seed'], config['time_steps'], train_start_index,
                                  config['len_train'], config['len_test'], df.index, config['len_val'], is_val = False)
loader_train, loader_train_fit, loader_test, loader_test_fit = dg.make_dataloader(dg, df, config['batch_size'], target_names)

#%%
# clustering
# =============================================================================
# from tslearn.clustering import KShape
# from tslearn.preprocessing import TimeSeriesScalerMeanVariance
# start = time.time()
# random_seed = 777
# n_clusters = 7
# df_temp, _ = dg.scale(df, df)
# stack_data = TimeSeriesScalerMeanVariance(mu=0.0, std=1.0).fit_transform(df_temp)
# ks = KShape(n_clusters = n_clusters, n_init= df_temp.shape[1],
#             verbose = True, random_state = random_seed)
# y_pred = ks.fit_predict(stack_data)
# elapse_time = round((time.time() - start)/60, 1)
# print(f'KShape:計算時間 {elapse_time}min')
# =============================================================================

#%%
hyperparms = {
    'lr' : 1e-4,
    'noise_nlayers'      : 1,
    'noise_hidden_size'  : 20,
    'global_nlayers'     : 1,
    'global_hidden_size' : 20,
    'n_global_factors'   : 1,
    }

epoch = 100
tr = Trainer(hyperparms, epoch, loader_train, config)
model, hist_loss = tr.train(True)