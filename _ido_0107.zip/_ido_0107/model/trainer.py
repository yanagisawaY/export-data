# -*- coding: utf-8 -*-
"""
@author: Yangisawa
"""
import numpy as np
import torch
import time
import random
import matplotlib.pyplot as plt
from model import deep_factors
from utils.loss import gaussian_likelihood_loss
import sys

class Trainer:
    def __init__(self, hyperparms, epoch, loader_train, config):
        '''
            学習を行うクラス            
        '''            
        self.hyperparms = hyperparms            
        self.epoch = epoch
        self.loader_train = loader_train
        self.config = config
        for temp, _ in loader_train:pass
        input_size = temp.shape[2]
        self.model_name = self.config['model_name']
        self.random_seed = config['random_seed']

        if config['model_name'] == 'deep_factors':
            self.model = deep_factors.DFRNN(input_size, hyperparms, config['device'])
        else:
            sys.exit('config内のmodel_nameに想定外のインプットが入っています')
         
    def train(self, is_plot_hist = False):            
        '''
            損失関数を最小化するようモデルの学習を行う

        hist_loss : TYPE
            各エポック処理後の損失関数.
        '''
        # 乱数の設定
        np.random.seed(self.random_seed)
        random.seed(self.random_seed)
        torch.manual_seed(self.random_seed)
        torch.cuda.manual_seed(self.random_seed)

        optimizer = torch.optim.Adam(self.model.parameters(), lr = self.hyperparms['lr'])
            
        start = time.time()
        hist_loss = []
        print('訓練開始… ', self.model_name)
        for epoch_i in range(self.epoch):
            for t, [_X_train, _Y_train] in enumerate(self.loader_train):
                mu, sigma = self.model(_X_train)
                loss = gaussian_likelihood_loss(_Y_train.squeeze(), mu, sigma)
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                
            hist_loss.append(loss.item())
            elapsed_time = time.time() - start
            print(f'Epoch {epoch_i+1} {round(elapsed_time/60,1)}min loss: {loss.item()}')
            
        print(f'{self.model_name} 実行終了：{round(elapsed_time/60,1)}min')                 
        if is_plot_hist:
            plt.plot(hist_loss)
            if self.epoch > 10:
                plt.xlim(10, len(hist_loss))
            plt.ylabel('loss')  
            plt.xlabel('epoch')              
            plt.show()
            
        return self.model, hist_loss