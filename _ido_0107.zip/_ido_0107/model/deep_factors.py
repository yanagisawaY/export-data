'''
Pytorch Implementation of Deep Factors For Forecasting
Paper Link: https://arxiv.org/pdf/1905.12417.pdf
AppendixのA.1. DF-RNN: Gaussian noise process as the local modelの実装
'''
import torch
from torch import nn
import torch.nn.functional as F 

import numpy as np
import utils

class DeepFactor(nn.Module):
    def __init__(self, input_size, global_nlayers, global_hidden_size, n_global_factors):
        super(DeepFactor, self).__init__()
        self.lstm = nn.LSTM(input_size, global_hidden_size, global_nlayers, \
                            bias=True, batch_first=True)
        self.factor = nn.Linear(global_hidden_size, n_global_factors)

    def forward(self, X):
        num_ts, num_features = X.shape
        X = X.unsqueeze(1)
        _, (h, c) = self.lstm(X)
        ht = h[-1, :, :] # num_ts, global factors
        ht = F.relu(ht)
        gt = ht
        return gt.view(num_ts, -1)

class Noise(nn.Module):
    def __init__(self, input_size, noise_nlayers, noise_hidden_size):
        super(Noise, self).__init__()
        self.lstm = nn.LSTM(input_size, noise_hidden_size, 
                            noise_nlayers, bias=True, batch_first=True)
        self.affine = nn.Linear(noise_hidden_size, 1)

    def forward(self, X):
        num_ts, num_features = X.shape
        X = X.unsqueeze(1)
        _, (h, c) = self.lstm(X)
        ht = h[-1, :, :] # num_ts, global factors
        ht = F.relu(ht)
        sigma_t = self.affine(ht)
        sigma_t = torch.log(1 + torch.exp(sigma_t))
        return sigma_t.view(-1, 1)

class DFRNN(nn.Module):
    def __init__(self, input_size, hyperparms, device):
        '''DF-RNN: Gaussian noise process as the local model
        https://arxiv.org/pdf/1905.12417.pdfのP12参照

        Parameters
        ----------
        input_size         : 特徴量の数        
        hyperparms : ハイパーパラメータ
            noise_nlayers      : ランダム効果のRNNの層数
            noise_hidden_size  : ランダム効果のRNNのユニット数
            global_nlayers     : グローバル効果のRNNの層数
            global_hidden_size : グローバル効果のRNNのユニット数
            n_global_factors   : グローバル効果の出力次元（固定効果の項の数）
        device : TYPE
            CPU or GPU.
        '''        
        super(DFRNN, self).__init__()
        self.noise = Noise(input_size, hyperparms['noise_hidden_size'], hyperparms['noise_nlayers'])
        self.global_factor = DeepFactor(input_size, hyperparms['global_nlayers'], 
                                        hyperparms['global_hidden_size'], hyperparms['n_global_factors'])
        self.embed = nn.Linear(hyperparms['global_hidden_size'], hyperparms['n_global_factors'])
        self.device = device
    
    def forward(self, X,):
        if isinstance(X, type(np.empty(2))):
            X = torch.from_numpy(X).float()
        num_ts, num_periods, num_features = X.size()
        mu = []
        sigma = []
        for t in range(num_periods):
            gt = self.global_factor(X[:, t, :])
            ft = self.embed(gt)
            ft = ft.sum(dim=1).view(-1, 1)
            sigma_t = self.noise(X[:, t, :])
            mu.append(ft)
            sigma.append(sigma_t)
            
        mu = torch.cat(mu, dim=1).view(num_ts, num_periods)
        sigma = torch.cat(sigma, dim=1).view(num_ts, num_periods) + 1e-6
        return mu, sigma
    
    def sample(self, X, num_samples=100):
        if isinstance(X, type(np.empty(2))):
            X = torch.from_numpy(X).float()
        mu, var = self.forward(X)
        num_ts, num_periods = mu.size()
        z = torch.zeros(num_ts, num_periods)
        
        for _ in range(num_samples):
            dist = torch.distributions.normal.Normal(loc=mu, scale=var)
            zs = dist.sample().view(num_ts, num_periods)
            z += zs
        z = z / num_samples
        return z
    