# -*- coding: utf-8 -*-
"""
評価を行うクラス
"""
import pandas as pd
import numpy as np

class Evaluator:
    def __init__(self, df_return, df_return_true):
        '''
        df_return : TYPE
            各銘柄リターンの予測値.
        df_return_true : TYPE
            各銘柄リターンの実績値(正解の値).
        '''
        self.df_return = df_return
        self.df_return_true = df_return_true
           
    def calc_mse(self):
        '''
            各銘柄の予測値と実績値の(平均の)mse(最小2乗誤差)を算出する関数

        Returns
        -------
            各銘柄の予測値と実績値の(平均の)mse(最小2乗誤差)

        '''        
        return np.mean((self.df_return - self.df_return_true).values**2)
    
    def calc_hit_rate(self):
        '''
            予測値と実績値が正負の方向が一致している割合を算出する関数

        Returns
        -------
            各時点の的中率のリスト.
        '''
        result_hit_rate = []
        for i, row in (self.df_return*self.df_return_true > 0).iterrows():
            result_hit_rate.append(sum(row) / len(row))

        output_result = pd.Series(result_hit_rate, index=self.df_return.index)        
        
        return output_result, np.mean(result_hit_rate)
        
    def calc_mdd(self, wealth):
        '''
           MDD(Maximum Drawdown)を計算 

        Parameters
        ----------
        mdd : TYPE
            累積（あるいは類和）リターン.

        '''
        mdd = np.max((np.maximum.accumulate(wealth) - wealth)/np.maximum.accumulate(wealth), 0)
        return mdd
    
    def calc_performance(self, return_portfolio, output_name ='result'):
        '''
            ポートフォリオのパフォーマンスを測定する関数

        Parameters
        ----------
        return_portfolio : TYPE
            ポートフォリオのリターン.        
        output_name : TYPE, optional
            出力するデータフレームの名前ラベル. The default is 'result'.

        Returns
        -------
        Output : pd.Series
            ポートフォリオの測定結果.
        '''
        BUSINESS_DAYS = 250
        mean_year = return_portfolio.mean()*BUSINESS_DAYS            
        sd_year = ((np.sqrt(BUSINESS_DAYS) * pd.DataFrame.std(return_portfolio, ddof=1)))
        SR_year = mean_year / sd_year
        lpm2_year = np.sqrt(BUSINESS_DAYS) * np.sqrt(np.sum((return_portfolio[return_portfolio<0] ** 2))/len(return_portfolio))
        DDR_year = mean_year / lpm2_year
        
        output = pd.Series([mean_year,sd_year,SR_year, lpm2_year, DDR_year],
                           index=['平均(年率換算)','標準偏差(年率換算)',
                                  'R/R(年率換算)','半分散(年率換算)','DDRatio(年率換算)'],
                           name=output_name)
        
        return output   