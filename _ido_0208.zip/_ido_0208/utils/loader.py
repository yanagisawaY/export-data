# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import numpy as np
import datetime as dt

class DataLoader:
    def __init__(self, df_pct, stock_i, hyperparms_company_common):
        self.hyperparms_company_common = hyperparms_company_common
        try:
            self.use_col = self.hyperparms_company_common['use_col']
            if self.use_col == None:
                self.use_col = df_pct.columns
        except KeyError:
            self.use_col = df_pct.columns
        
        self.df_pct, self.stock_i = df_pct, stock_i
        self.index_date = df_pct.index

    def get_index(self, start_date, end_date):
        '''
            データ分割における日付を取得

        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.

        Returns
        -------
        target_start_date : datetime
            予測データの開始日.(入力した日付がない場合，該当日以降のうち，最も近い日付)
        target_end_date : datetime
            予測データの終了日.(入力した日付がない場合，該当日以降のうち，最も近い日付)
        explained_start_date : datetime
            説明変数データの開始日.
        explained_end_date : datetime
            説明変数データの終了日.
        '''
        
        if (not isinstance(start_date, dt.datetime)) or (not isinstance(end_date, dt.datetime)):
            raise ValueError('start_date, end_dateはdatetime型にしてください')            
                    
        try:
            target_start_index = np.abs(self.index_date-start_date).argmin()
            target_start_date = self.index_date[target_start_index]
            
            if target_start_date < start_date:
                target_start_index = np.abs(self.index_date-start_date).argmin() + 1
                target_start_date = self.index_date[target_start_index]
                
            explained_start_index = target_start_index - (self.hyperparms_company_common['lookback_window_max'] + self.hyperparms_company_common['lag'])                    
            explained_start_date = self.index_date[explained_start_index]
        except:
            raise ValueError('データ期間の開始日が範囲外です.lookback_window_maxとlagを考慮して日付を設定してください')
        
        if explained_start_index < 0:
            raise ValueError('データ期間の開始日が範囲外です.lookback_window_maxとlagを考慮して日付を設定してください')
        
        try:
            target_end_index = np.abs(self.index_date-end_date).argmin()
            target_end_date = self.index_date[target_end_index]            
            explained_end_index = target_end_index - self.hyperparms_company_common['lag']
            explained_end_date = self.index_date[explained_end_index]
        except:
            raise ValueError('データ期間の終了日が範囲外です.lookback_window_maxとlagを考慮して日付を設定してください')
                   
        return target_start_date, target_end_date, explained_start_date, explained_end_date

    def make_dataset(self, start_date, end_date):
        '''
            説明変数データ，被説明変数データを作成

        Parameters
        ----------
        use_col: list
            説明変数を任意に設定可能
        （ハイパーパラメータ内で引数の省略可）

        Returns
        -------
        X : dict
            説明変数データ.
        y : pandas.DataFrame
            予測データ.
        '''
        target_start_date, target_end_date, explained_start_date, explained_end_date = self.get_index(start_date, end_date)
                
        X_explain = self.df_pct[explained_start_date:explained_end_date]
        y = self.df_pct[target_start_date:target_end_date].loc[:,self.stock_i]
        window_max = X_explain.shape[0] + 1 - self.hyperparms_company_common['lookback_window_max']        
        X = {}
        for t in range(self.hyperparms_company_common['lag'], window_max):
            X[t] = X_explain.iloc[(t-self.hyperparms_company_common['lag']):(t+self.hyperparms_company_common['lookback_window_max']-self.hyperparms_company_common['lag']),:]
           
        return X, y
  