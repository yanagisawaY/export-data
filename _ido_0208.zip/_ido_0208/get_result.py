# -*- coding: utf-8 -*-
"""
Created on Mon Feb  8 00:13:24 2021

@author: 猛
"""
import time
import pickle
import pandas as pd
import datetime as dt
import os

from models.trader_company import TraderCompany
from utils.loader import DataLoader
from utils.portfolio_builder import PortfolioBuilder

def get_trader_company_result(df_pct, stock_i, dataset_dict, hyperparms_company_common):
    '''
        1銘柄を対象にTrader-Companyを実行

    Parameters
    ----------
    df_pct : pd.DataFrame
        リターン行列. 次元数=(時点,銘柄)
    stock_i : str
        銘柄のTicker.
    dataset_dict : dict
        訓練期間，テスト期間の設定値.
    hyperparms_company_common : dict
        Trader-Companyモデルのハイパーパラメータ.

    Returns
    -------
    y_test : TYPE
        リターンの正解値.
    y_test_pred : TYPE
        予測リターン.
    df_info : TYPE
        モデル関連の情報.
    hyperparms_company_learned : dict
        学習済みパラメータ.
    '''
    start_time = time.time()    
    print(f'予測対象...{stock_i}')

    # データ作成    
    train_start_date, train_end_date, test_start_date, test_end_date = dataset_dict.values()    
    dl = DataLoader(df_pct, stock_i, hyperparms_company_common)
    X_train, y_train = dl.make_dataset(train_start_date, train_end_date)
    X_test, y_test = dl.make_dataset(test_start_date, test_end_date)
    
    # 学習
    tc = TraderCompany(hyperparms_company_common)
    tc.fit(X_train, y_train)
    y_test_pred = tc.predict(X_test)

    calc_time = round(time.time() - start_time)
    print(f'{stock_i} - {calc_time}sec')
    
    col_names = ['予測対象', '訓練開始', '訓練終了', 'テスト開始', 'テスト終了', '計算時間(sec)'] + list(hyperparms_company_common.keys())
    df_info = pd.DataFrame([[stock_i, train_start_date, train_end_date, test_start_date, test_end_date, calc_time]+list(hyperparms_company_common.values())], 
                           columns=col_names)
    
    hyperparms_company_learned = tc.hyperparms_company_learned
    
    return y_test, y_test_pred, df_info, hyperparms_company_learned


def make_model_pred(df_pct, stock_list, dataset_dict, hyperparms_company_common, time_now):
    '''
        全銘柄の予測値を算出
        各銘柄のpickleファイルを出力

    Parameters
    ----------
    df_pct : pd.DataFrame
        リターン行列. 次元数=(時点,銘柄)
    stock_list : list
        予測を実施する銘柄.（df_pctの列名に存在するものを指定）
    dataset_dict : dict
        訓練期間，テスト期間の設定値.
    hyperparms_company_common : dict
        Trader-Companyモデルのハイパーパラメータ.
    time_now : str
        出力フォルダ用のタイムスタンプ.

    Returns
    -------
    df_y_pred : pd.DataFrame
        予測リターンの行列.
    df_y_true : pd.DataFrame
        リターンの正解値の行列.
    df_info_all : pd.DataFrame
        モデル関連の情報を格納したデータフレーム.
    '''
    # 出力フォルダの作成
    file_name = dataset_dict['train_start_date'].strftime("%y%m%d") + '_' + dataset_dict['train_end_date'].strftime("%y%m%d")
    path_output = '.\\Result\\train\\' + file_name + '\\' + time_now
    os.makedirs(path_output, exist_ok=True)
    
    # 全銘柄の予測値算出
    df_info_all = pd.DataFrame()
    df_y_true = pd.DataFrame()
    df_y_pred = pd.DataFrame()
    hyperparms_company_learned_all = {}
    for stock_i in stock_list:
        # 予測値の算出    
        y_test, y_test_pred, df_info, hyperparms_company_learned_all[stock_i] = get_trader_company_result(df_pct, stock_i, dataset_dict, hyperparms_company_common)
        
        # 結果の統合
        df_y_true = pd.concat([df_y_true, y_test], axis=1)
        df_y_pred = pd.concat([df_y_pred, pd.DataFrame(y_test_pred, index=df_y_true.index, columns=[stock_i])], axis=1)
        df_info_all = pd.concat([df_info_all, df_info], axis=0)
    
    # 予測結果の書き出し
    df_info_all = df_info_all.reset_index(drop=True)
    df_info_all.to_csv(path_output+'\\info_'+file_name+'.csv', encoding='cp932')
    df_y_pred.to_csv(path_output+'\\rt_predict_'+file_name+'.csv', encoding='cp932')
    df_y_true.to_csv(path_output+'\\rt_true_'+file_name+'.csv', encoding='cp932')
    
    # 学習パラメータの書き出し
    file_name_output = path_output + '\\hyperparms_company_' + file_name + '.pickle'
    def pickle_dump(obj, path):
        with open(path, mode='wb') as f:
            pickle.dump(obj,f)
    
    pickle_dump(hyperparms_company_learned_all, file_name_output)
    
    return df_y_pred, df_y_true, df_info_all


def get_dateset_dict(era, year_term_train, year_term_test):
    '''
        訓練期間とテスト期間の日付設定

    Parameters
    ----------
    era : int
        訓練開始時の年
    year_term_train : int
        訓練期間の年数
    year_term_test : int
        テスト期間の年数

    Returns
    -------
    dataset_dict : dict
        訓練期間とテスト期間の日付が格納された辞書.
    '''
    dataset_dict = {
    'train_start_date' : dt.datetime(era, 1, 1),
    'train_end_date'   : dt.datetime(era+year_term_train, 12, 31),
    'test_start_date'  : dt.datetime(era+year_term_train+1, 1, 1),
    'test_end_date'    : dt.datetime(era+year_term_train+year_term_test, 12, 31),
    }
    
    return dataset_dict


def get_portfolio_result(df_y_pred, df_y_true, hyperparms_portfolio, output_name):
    '''
        ポートフォリオ構築結果を出力

    Parameters
    ----------
    df_y_pred : pd.DataFrame
        リターンの予測値.
    df_y_true : pd.DataFrame
        リターンの正解値.
    hyperparms_portfolio : dict
        ポートフォリオのパラメータ.
    output_name : str
        resultの列名.

    Returns
    -------
    index_portfolio : pd.DataFrame
        ポートフォリオのインデックス推移.
    index_quantile_port : pd.DataFrame
        クオンタイルポートフォリオのインデックス推移.
    result : pd.DataFrame
        ポートフォリオのパフォーマンス結果.
    '''
    # ポートフォリオ構築
    print('ポートフォリオの構築')
    pb = PortfolioBuilder(df_y_pred, hyperparms_portfolio)
    weight = pb.calc_weight()
    return_portfolio = pb.calc_portfolio_return(weight, df_y_true)
    index_portfolio = pb.calc_wealth(return_portfolio)
    
    index_quantile_port = pb.make_quantile_portfolio(df_y_true)
    result = pb.make_peformance_result(df_y_true, output_name)
    print(result)    
    
    return index_portfolio, index_quantile_port, result