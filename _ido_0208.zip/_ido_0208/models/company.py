# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import numpy as np
import pandas as pd
import random
from sklearn import linear_model
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler

from models.trader import Trader
from config.config import *

class Company:
    def __init__(self, X_train, y_train, hyperparms_company_common):        
        self.hyperparms_company_common = hyperparms_company_common
        self.X_train, self.y_train = X_train, y_train
        self.stock_list = self.get_stock_list()
        
    def get_stock_list(self):
        '''銘柄の探索範囲リストを取得
        '''       
        try:
            stock_num = self.X_train[1].shape[1]
        except:
            raise ValueError('X_train内の各データフレームは2次元に設定してください')
            
        if stock_num < 2:
            raise ValueError('X_train内の各データフレームは2列以上に設定してください')   
            
        stock_list = list(range(stock_num))
        
        return stock_list
            
    def collect_trader_staregy(self, hyperparms_company, X_inputs={}):
        '''
            パラメータ（hyperparms_company）と入力値（X_inputs）をもとに，全トレーダーの予測値を算出

        Parameters
        ----------
        hyperparms_company : dict
            全トレーダーのハイパーパラメータ.
        X_inputs : dict
            入力値（説明変数データ）
            指定しない場合は訓練データ(X_train)を選択
            
        Returns
        -------
        trader_strategy_all : TYPE
            全トレーダーの予測値.（次元数） = (時点,トレーダー数)
        '''
        if len(X_inputs) == 0:
            X_inputs = self.X_train
        
        if isinstance(X_inputs, dict):
            pass
        else:
            raise ValueError('X_trainはdictである必要があります')
            
        trader_strategy_all = []
        for t, X_input in X_inputs.items():
            cp = CompanyPrediction(hyperparms_company, X_input)
            # 全トレーダーの戦略を集約
            trader_prediction = cp.predict()
            trader_strategy_all.append(trader_prediction)
        
        trader_strategy_all = np.array(trader_strategy_all)
        
        return trader_strategy_all

    def convert_strategy(self, trader_strategy_all):
        '''
            予測結果を変形　：3.1節(6)式
    
        Parameters
        ----------
        trader_strategy_all : TYPE
            トレーダーの予測結果　：3.1節(5)式
    
        Returns
        -------
        strategy : TYPE
            予測結果を変形：3.1節(6)式
    
        '''
        strategy = np.sign(trader_strategy_all)
        
        return strategy
     
    def measure_trader_return(self, trader_strategy_all, method_measure):        
        '''
            トレーダーのパフォーマンスを測定

        Parameters
        ----------
        trader_strategy_all : TYPE
            全時点，全トレーダーのハイパーパラメータ.
        method_measure : TYPE
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ

        Returns
        -------
        traders_performance : np.array
            各トレーダーのパフォーマンス
        '''
        traders_return = np.array([self.y_train*trader_strategy_all[:, i] for i in range(trader_strategy_all.shape[1])]).T
        if method_measure == 'CR':
            # 累積リターン
            traders_return_cumsum = traders_return.cumsum(0)
            traders_performance = traders_return_cumsum[-1,:]
        elif method_measure == 'SR':
            # シャープレシオ            
            traders_return_mean = traders_return.mean(0)
            traders_return_sd = traders_return.std(0)            
            traders_performance = traders_return_mean/traders_return_sd
        else:
            raise ValueError(f'"method_measure"は，{method_measure}には対応していません')            
        
        return traders_performance
    
    def collect_bad_traders(self, trader_strategy_all, method_measure='CR'):
        '''
            パフォーマンスの悪いトレーダーのフラグを作成
            
        Parameters
        ----------
        trader_strategy_all : TYPE
            全時点，全トレーダーのハイパーパラメータ.
        method_measure : TYPE, optional
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ

        Returns
        -------
        is_bad_traders : list
            パフォーマンスの悪いトレーダーのフラグ.
        '''
        traders_performance = self.measure_trader_return(trader_strategy_all, method_measure=method_measure)
        bottom_quantile = np.quantile(traders_performance, self.hyperparms_company_common['Q_quantile_educate'])
        is_bad_traders = list(traders_performance <= bottom_quantile)
        
        return is_bad_traders

    def update_weight(self, hyperparms_company, is_bad_traders):
        '''
            パフォーマンスの悪いトレーダーの，各戦略ウェイトを更新

        Parameters
        ----------
        hyperparms_company : dict
            全てのトレーダーの戦略が格納された辞書.
        is_bad_traders : list
            パフォーマンスの悪いトレーダーのフラグ.

        Returns
        -------
        hyperparms_company_updated : dict
            パフォーマンスの悪いトレーダーの各戦略ウェイトが更新された辞書.
        '''
        lr = linear_model.LinearRegression()
        hyperparms_traders_updated = hyperparms_company['hyperparms_traders'].copy()
        for i, trader_i in hyperparms_company['hyperparms_traders'].items():
            if is_bad_traders[i]:
                trader_strategy = []
                for X_input in self.X_train.values():
                    tr = Trader(trader_i['hyperparms_all_formula'], X_input)
                    trader_strategy_t = tr.make_strategy()
                    trader_strategy.append(trader_strategy_t)
                trader_strategy = np.array(trader_strategy)
                try:
                    fit_result = lr.fit(trader_strategy, self.y_train.values)   
                except:
                    # 要改善：エラーが発生した場合，もう一度実行するとなぜか実行できる                    
                    fit_result = lr.fit(trader_strategy, self.y_train.values)   
                    
                trader_i['weight'] = fit_result.coef_
                hyperparms_traders_updated[i] = trader_i
        
        hyperparms_company_updated = hyperparms_company.copy()
        hyperparms_company_updated['hyperparms_traders'] = hyperparms_traders_updated
        
        return hyperparms_company_updated

    def educate(self, trader_strategy_all, hyperparms_company, method_measure='CR'):
        '''
            Algorithm 2　Educate algorithm of Company
            パフォーマンスの悪いトレーダーの各戦略ウェイトを更新          

        Parameters
        ----------
        trader_strategy_all : dict
            全時点，全トレーダーのハイパーパラメータ.
        hyperparms_company : dict
            全てのトレーダーの戦略が格納された辞書.            
        method_measure : TYPE, optional
            パフォーマンスの測定手法
            CR:累積リターン
            SR:シャープレシオ
            
        Returns
        -------
        hyperparms_company_updated : dict
            パフォーマンスの悪いトレーダーの各戦略ウェイト更新後のパラメータ.

        '''                   
        is_bad_traders = self.collect_bad_traders(trader_strategy_all, method_measure)
        hyperparms_company_updated = self.update_weight(hyperparms_company, is_bad_traders)
        
        return hyperparms_company_updated


class CompanyPrediction:
    def __init__(self, hyperparms_company, X_input):
        '''
            Algorithm 1　Prediction algorithm of Company
            t+1時点における銘柄iの予測リターンを算出するクラス

        Parameters
        ----------
        hyperparms_company : dict
            companyのハイパーパラメータ.
                hyperparms_company_common : 共通のハイパーパラメータ
                hyperparms_all_formula    : M個の戦略のハイパーパラメータ情報が階層的に格納された辞書
                weight                    : 各戦略のウェイト.次元数 ：　(M_formula_num)          
        X_input : pandas.DataFrame or numpy.ndarray
            投資対象のリターン行列.(説明変数群)      
        '''
        self.hyperparms_traders = hyperparms_company['hyperparms_traders']
        self.X_input = X_input        

    def predict_all(self):
        trader_prediction_all = []
        for dict_ in self.hyperparms_traders.values():
            hyperparms_all_formula, weight = dict_.values()
            tr = Trader(hyperparms_all_formula, self.X_input)
            trader_prediction_all.append(tr.make_strategy())
        
        return trader_prediction_all
        
    def predict(self):
        trader_prediction = []
        for dict_ in self.hyperparms_traders.values():
            hyperparms_all_formula, weight = dict_.values()
            tr = Trader(hyperparms_all_formula, self.X_input)
            trader_prediction.append(tr.predict(weight))
        
        return trader_prediction


class CompanyPruneGenerate:
    def __init__(self, hyperparms_company, is_bad_traders):
        self.is_bad_traders = is_bad_traders
        self.hyperparms_company = hyperparms_company
        self.good_traders, self.bad_traders_id = self.make_good_traders()
        
    def make_good_traders(self):
        '''
            パフォーマンスのよいトレーダーのハイパーパラメータとパフォーマンスの悪いトレーダーのIDを抽出，

        Returns
        -------
        good_traders : pandas.DataFrame
            パフォーマンスのよいトレーダーのパラメータ.
        bad_traders_id : list
            パフォーマンスの悪いトレーダーのフラグ.
        '''
        good_traders = []
        good_traders_func = []
        bad_traders_id = []
        for i, trader_i in self.hyperparms_company['hyperparms_traders'].items():            
            if self.is_bad_traders[i]:
                bad_traders_id += [i for _ in range(len(trader_i['hyperparms_all_formula']))]                        
            else:
                for j, item in trader_i['hyperparms_all_formula'].items():
                    good_traders_func.append(list(item['A_activation_func'].keys()) + list(item['O_binary_operator'].keys()))
                    good_traders.append([i]+list(item.values()))
        
        good_traders = np.hstack([np.array(good_traders)[:, :-2], np.array(good_traders_func)])
        col_names = ['id'] + list(item.keys())
        good_traders = pd.DataFrame(good_traders, columns=col_names)
        
        return good_traders, bad_traders_id
    
    def sample_categorical(self, random_seed, use_col):
        '''
            パフォーマンスのよいパラメータ値を各パラメータで独立なカテゴリカル分布にあてはめ，サンプリング        

        Parameters
        ----------
        random_seed : int
            乱数シード.
        use_col : list
            サンプリングする列名.

        Returns
        -------
        bad_traders : pandas.DataFrame
            サンプリングされたbad tradersのパラメータ.
        '''
        bad_traders = np.array(self.bad_traders_id)        
        np.random.seed(seed=self.hyperparms_company['random_seed']+random_seed)            
        # カテゴリカル分布
        for name in use_col:
            count_unique = self.good_traders[name].value_counts()
            count_unique = count_unique/sum(count_unique)
            new_sampled = list(np.random.choice(list(count_unique.index), p=list(count_unique.values), size=len(self.bad_traders_id)))
            bad_traders = np.vstack([bad_traders, np.array(new_sampled)])
        
        bad_traders = pd.DataFrame(bad_traders.T, columns=self.good_traders.columns)
        
        return bad_traders

    def sample_gaussian_mix(self, random_seed, use_col):
        '''
            パフォーマンスのよいパラメータ値を混合正規分布にあてはめ，サンプリング
            ※ 離散値を標準化⇒混合正規分布にフィット⇒逆変換後の値からもっとも近い離散値を新たらパラメータとして採用
            　　したがって，銘柄インデックスの最小値（最大値）は，フィットさせた確率分布でその値を下（上）回る累積確率分多く採用される傾向にあることに注意
              ⇒理想は混合切断正規分布のようなものからのサンプリング．

        Parameters
        ----------
        random_seed : int
            乱数シード.
        use_col : list
            サンプリングする列名.

        Returns
        -------
        bad_traders : pandas.DataFrame
            サンプリングされたbad tradersのパラメータ.
        '''
        random.seed(random_seed)
        bad_traders = np.array(self.bad_traders_id)            
        unique_dict = {}
        df_good_traders = self.good_traders.copy().astype(str)
        list_temp = {}
        for name in use_col:
            unique_names =  df_good_traders[name].unique().astype(str)
            len_unique_names = len(unique_names)
            unique_names = random.sample(list(unique_names), len_unique_names)
            list_temp[name] = list(range(len(unique_names)))
            convert_dict = dict(zip(unique_names, list(range(len_unique_names))))                
            unique_dict[name] = convert_dict
            df_good_traders[name] = df_good_traders[name].map(convert_dict)
            
        gmm = GaussianMixture(n_components=self.hyperparms_company['GMM_n_components'], covariance_type='spherical', random_state=random_seed)
        sc = StandardScaler()
        sc.fit(df_good_traders[use_col].values)
        df_scaled = sc.transform(df_good_traders[use_col].values)
        fitted = gmm.fit(df_scaled)
        samples = np.round(sc.inverse_transform(fitted.sample(len(bad_traders))[0]))
        bad_traders = pd.DataFrame(np.hstack([bad_traders[:,np.newaxis], samples]), columns=self.good_traders.columns)

        def get_swap_dict(d):
            return {v: k for k, v in d.items()}
        
        def find_nearest(array, value):
            array = np.asarray(array)
            idx = (np.abs(array - value)).argmin()
            return array[idx]            
        
        for name, convert_dict in unique_dict.items():
            bad_traders[name] = list(map(lambda x: find_nearest(list_temp[name], x), bad_traders[name]))
            bad_traders[name] = bad_traders[name].map(get_swap_dict(convert_dict))
            
        return bad_traders

    def make_bad_traders(self, random_seed, method_sampling):
        '''
            パフォーマンスのいいトレーダーから生成したパラメータでパフォーマンスの悪いトレーダーの戦略を更新し，更新結果のデータフレームを出力

        Parameters
        ----------
        random_seed : int
            ランダムシード.
        method_sampling : str
            サンプリング手法.（categorical）

        Returns
        -------
        bad_traders : pandas.DataFrame
            パフォーマンスの悪いトレーダーのパラメータ.
        '''
        use_col = self.good_traders.columns.drop('id')        
        if method_sampling == 'categorical':
            # カテゴリカル分布からサンプリング
            bad_traders = self.sample_categorical(random_seed, use_col)
            
        elif method_sampling == 'GMM':
            # 混合正規分布からサンプリング
            bad_traders = self.sample_gaussian_mix(random_seed, use_col)

        else:
            raise ValueError(r'"method_sampling"は，{method_sampling}には対応していません')

        bad_traders['A_activation_func'] = [{x : activation_functions[x]} for x in bad_traders['A_activation_func']]
        bad_traders['O_binary_operator'] = [{x : binary_operators[x]} for x in bad_traders['O_binary_operator']]
                        
        return bad_traders
    
    def update_bad_traders(self, bad_traders):
        '''
            パフォーマンスの悪いトレーダーのハイパーパラメータの辞書を更新

        Parameters
        ----------
        bad_traders : pandas.DataFrame
            パフォーマンスの悪いトレーダーのパラメータ.

        Returns
        -------
        hyperparms_company_updated : dict
            パラメータを更新したトレーダーのハイパーパラメータ
        '''
        id_count = 0
        hyperparms_company_updated = self.hyperparms_company.copy()
        for i, trader_i in self.hyperparms_company['hyperparms_traders'].items():
            if self.is_bad_traders[i]:
                for j, item in trader_i['hyperparms_all_formula'].items():
                    trader_i['hyperparms_all_formula'][j] = dict(bad_traders.iloc[id_count, 1:])
                    id_count += 1
                    
                hyperparms_company_updated['hyperparms_traders'][i] = trader_i
                
        return hyperparms_company_updated                
    