# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import numpy as np
import pandas as pd
from sklearn import linear_model
from sklearn.ensemble import RandomForestRegressor as RFR
import matplotlib.pyplot as plt

from models.company import Company, CompanyPruneGenerate
from models.trader import get_all_traders_init, TraderGenarator

class TraderCompany(Company):
    def __init__(self, hyperparms_company_common):
        self.hyperparms_company_common = hyperparms_company_common
        self.method_measure = hyperparms_company_common['method_measure']
        self.fit_times = hyperparms_company_common['fit_times']
        self.method_sampling = hyperparms_company_common['method_sampling']
        self.aggregate_method = hyperparms_company_common['Aggregate']
        
    def learn_trader(self, X_train, y_train):
        '''
            トレーダーのパラメータを学習

        Returns
        -------
        hyperparms_company_updated : dict
            学習済みパラメータ.
        '''
        super().__init__(X_train, y_train, self.hyperparms_company_common)
        
        # step1:パラメータの初期値取得
        hyperparms_company = get_all_traders_init(self.hyperparms_company_common, self.stock_list)
        trader_strategy_all = self.collect_trader_staregy(hyperparms_company)
        trader_flag_all = self.convert_strategy(trader_strategy_all)
        
        # step2:教育        
        hyperparms_company_updated = self.educate(trader_flag_all, hyperparms_company, self.method_measure)
        trader_strategy_updated = self.collect_trader_staregy(hyperparms_company_updated)
        trader_flag_updated = self.convert_strategy(trader_strategy_updated)
        
        def generate_traders(trader_flag_updated, hyperparms_company_updated, random_seed):
            '''Good Tradersのパラメータ分布をもとにBad Tradersのパラメータを更新
            '''
            is_bad_traders = self.collect_bad_traders(trader_flag_updated, self.method_measure)
            cpg = CompanyPruneGenerate(hyperparms_company_updated, is_bad_traders)
            bad_traders = cpg.make_bad_traders(random_seed=random_seed, method_sampling=self.method_sampling)
            hyperparms_company_new = cpg.update_bad_traders(bad_traders)
            trader_strategy_new = self.collect_trader_staregy(hyperparms_company_new)        
            trader_flag_new = self.convert_strategy(trader_strategy_new)            
            
            return trader_flag_new, hyperparms_company_new
 
        # step3:剪定，生成        
        for f in range(self.fit_times):
            print(f'トレーダー生成:{f+1}/{self.fit_times}')
            random_seed = f
            trader_flag_updated, hyperparms_company_updated = generate_traders(trader_flag_updated, hyperparms_company_updated, random_seed)
            
            trader_strategy_train = self.collect_trader_staregy(hyperparms_company_updated)            
            
            if self.hyperparms_company_common['is_hist_plot']:
                # トレーダー生成の度に予測リターンのヒストグラムを出力
                plt.figure()
                plt.hist([np.mean(trader_strategy_train, 1), self.y_train, np.mean(trader_strategy_train, 1)-self.y_train],
                         20, color=['r', 'b', 'g'], alpha=0.3, label=['prediction', 'true', 'residual'])
                plt.legend()
                plt.title('Train_'+str(f))
                plt.show()

        return hyperparms_company_updated

    def fit_for_aggregation(self, trader_strategy_train):
        '''
            各トレーダの予測値をもとにその集約方法に応じて，パラメータの学習を実施

        Parameters
        ----------
        trader_strategy_train : TYPE
            訓練データにおける各トレーダの予測値.
        '''
        if self.aggregate_method == 'average':
            pass            
        
        elif self.aggregate_method == 'linear':
            self.lr = linear_model.LinearRegression()
            try:
                self.lr.fit(trader_strategy_train, self.y_train)
            except:
                # 一度失敗しても，再実行するとうまくいく
                self.lr.fit(trader_strategy_train, self.y_train)                
                
        elif self.aggregate_method == 'random_forest':
            self.rg = RFR(**self.hyperparms_company_common['Aggregate_parms']) 
            self.rg.fit(trader_strategy_train, self.y_train)
            
    def aggregate(self, trader_strategy_test):
        '''
            各トレーダの予測値を集約

        Parameters
        ----------
        trader_strategy_test : numpy.array
            テストデータにおけるトレーダの予測値.

        Returns
        -------
        y_pred : numpy.array
            最終的な予測値.
        '''
        if self.aggregate_method == 'average':
            y_pred = np.mean(trader_strategy_test, 1)
            
        elif self.aggregate_method == 'linear':
            try:
                y_pred = self.lr.predict(trader_strategy_test)            
            except:
                raise ValueError(f'{self.aggregate_method}:事前にfit_for_aggregationを実行してください')
        elif self.aggregate_method == 'random_forest':
            try:
                y_pred = self.rg.predict(trader_strategy_test)            
            except:
                raise ValueError(f'{self.aggregate_method}:事前にfit_for_aggregationを実行してください')                        
        else:
            raise ValueError(f'aggregate_methodは，{self.aggregate_method}には対応していません')
            
        return y_pred
    
    def fit(self, X_train, y_train):
        '''
            パラメータの学習を実施

        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : np.array or pandas.DataFrame
            被説明変数データ.
        '''
        self.hyperparms_company_learned = self.learn_trader(X_train, y_train)
        trader_prediction_fitted = self.collect_trader_staregy(self.hyperparms_company_learned)
        self.fit_for_aggregation(trader_prediction_fitted)
        self.prediction = self.aggregate(trader_prediction_fitted)
    
    def predict(self, X):
        '''
            予測値を出力

        Parameters
        ----------
        X : dict
            特徴量データ.

        Returns
        -------
        y_pred : numpy.array
            予測値.
        '''
        trader_prediction = self.collect_trader_staregy(self.hyperparms_company_learned, X)        
        y_pred = self.aggregate(trader_prediction)
        
        return y_pred

    def calc_parms_frequency(self, feature_names, hyperparms_company_learned={}):
        '''
            各トレーダの戦略パラメータの頻度を算出

        Parameters
        ----------
        feature_names : list
            特徴量の列名.
        hyperparms_company_learned : 
            トレーダーの学習済みパラメータ
            
        Returns
        -------
        ticker_counts : pandas.DataFrame
            各特徴量の使用頻度.
        activation_counts : pandas.DataFrame
            各活性化関数の使用頻度.
        operator_counts : pandas.DataFrame
            各二項演算子の使用頻度.
        '''
        col_name = 'frequency'
        ticker_counts = pd.DataFrame(0, index=feature_names, columns=[col_name])
        
        tg = TraderGenarator(list([0]), self.hyperparms_company_common)
        activation_counts = pd.DataFrame(0, index=list(tg.activation_functions.keys()), columns=[col_name])
        operator_counts = pd.DataFrame(0, index=list(tg.binary_operators.keys()), columns=[col_name])
        
        if len(hyperparms_company_learned):
            hyperparms_company_learned = self.hyperparms_company_learned.copy()
            
        for i, trader_i in hyperparms_company_learned['hyperparms_traders'].items():
            for j, trader_i_j in trader_i['hyperparms_all_formula'].items():
                ticker_counts[col_name][int(trader_i_j['P_stock_id'])-1] += 1
                ticker_counts[col_name][int(trader_i_j['Q_stock_id'])-1] += 1
                activation_name = list(trader_i_j['A_activation_func'].keys())[0]
                activation_counts.loc[[activation_name,]] += 1        
                operator_name = list(trader_i_j['O_binary_operator'].keys())[0]
                operator_counts.loc[[operator_name,]] += 1
              
        ticker_counts = ticker_counts.sort_values(col_name, ascending=False)

        return ticker_counts, activation_counts, operator_counts