# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
    3.pickleで保存するため，lambda式で記述せず，関数を定義
"""
import numpy as np

def func_x(x):
    return x

def func_relu(x):
    return x*(x>0)

def func_sum(x, y):
    return x+y

def func_diff(x, y):
    return x-y

def func_prod(x, y):
    return x*y

def func_select_x(x, y):
    return x

def func_select_y(x, y):
    return y

def func_max(x, y):
    return max(x, y)

def func_min(x, y):
    return min(x, y)

def func_x_larger(x, y):
    return 1*(x>y)

def func_y_larger(x, y):
    return 1*(x<y)

activation_functions = {
    'x'    : func_x, 
    'tanh' : np.tanh,
    'exp'  : np.exp,
    'sign' : np.sign, 
    'ReLU' : func_relu,
    }

binary_operators = {
    'x+y'    : func_sum, 
    'x-y'    : func_diff,
    'x*y'    : func_prod,
    'x'      : func_select_x,
    'y'      : func_select_y,                    
    'max_xy' : func_max,
    'min_xy' : func_min,
    'x>y'    : func_x_larger,
    'x<y'    : func_y_larger,                    
    }
