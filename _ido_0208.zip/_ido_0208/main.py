# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import openpyxl
import pandas as pd
import datetime as dt
import os

# パスの設定
PATH_HEAD = r''
os.chdir(PATH_HEAD)
from get_result import make_model_pred, get_dateset_dict, get_portfolio_result

#%%
# 事前に設定する項目    
hyperparms_company_common = {
    'N_trader_num'        : 100,
    'Aggregate'           : 'linear', # 'average', 'linear', 'random_forest'
    'Q_quantile_educate'  : 0.5,
    'formula_num_max'     : 10,
    'lookback_window_max' : 10,    
    'lag'                 : 1,        
    'random_seed'         : 7777,  
    'method_measure'      : 'CR',
    'method_sampling'     : 'GMM',
    'fit_times'           : 3,
    'GMM_n_components'    : 3,
    'Aggregate_parms'     : {'random_state' : 777, 'n_estimators' : 100,},
    'is_hist_plot'        : False,
    'use_col'             : None,
    }   
'''
hyperparms_company_common : ハイパーパラメータ
    'N_trader_num'        : トレーダー数
    'Aggregate'           : 集約方法の指定
            'average'         : トレーダーの予測値平均 
            'linear'          : トレーダーの予測値をインプットとした線形回帰による予測
            'random_forest'   : トレーダーの予測値をインプットとしたランダムフォレストによる予測 
    'Q_quantile_educate'  : パフォーマンスの悪いトレーダーを教育する割合
    'formula_num_max'     : 各トレーダーの戦略（公式）の候補数の最大値
    'lookback_window_max' : 各銘柄のリターンの参照期間候補の最大値
    'lag'                 : 説明変数の時点と被説明変数の時点のラグ
    'random_seed'         : ランダムシード
    'method_measure'      : トレーダーのパフォーマンス測定基準
            'CR'              : 累積リターン
            'SR'　　　　　　　　　　　: シャープレシオ
    'method_sampling'     : トレーダー生成時のサンプリング方法
            'GMM'             : 混合正規分布によるサンプリング
            'categorical'     : カテゴリカル分布によるサンプリング
    'fit_times'           : レーダー生成の繰り返し回数
    'GMM_n_components'    : 混合正規分布のフィット時におけるクラスター数
    'Aggregate_parms'     : 集約方法で用いるモデルのハイパーパラメータ
            'random_state'    : 乱数シード
            'n_estimators'    : ランダムフォレストで用いる木の数
    'is_hist_plot'        : トレーダー生成時に，トレーダーの予測値と実際の値のヒストグラムを表示する場合はTrueを指定
    'use_col'             : 説明変数に使用するの列の指定（Noneの場合は全てのデータを使用）
'''
hyperparms_portfolio = {
    'split_num'              : 10,
    'portfolio_type'         : 'Simple',
    'turnover_stock_uplimit' : 4,
    'cost_buy'               : 0,
    'cost_sell'              : 0,
    'calc_type'              : 'cumulative',    
    'wealth_init'            : 100,    
    }

'''
hyperparms_portfolio : dict
    split_num              : 分位数.
    portfolio_type         : ポートフォリオの構築方法の選択
        LongShort              : 最上位の分位群をロング，最下位の分位群をショート
        Long                   : 最上位の分位群のロング
        Long_const             : 組み入れ銘柄数制限付き，最上位の分位群のロング
        Simple                 : 予測リターンが正のものをロング，負のものをショート
    turnover_stock_uplimit : 組み入れ変更銘柄数の上限
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
'''

#%%
# データセットの入力
df_org_ = pd.read_csv(PATH_HEAD+'\\data\\SP500_2010_2020_adj_close.csv', engine = 'python').set_index('Date')
df_org_.index = pd.to_datetime(df_org_.index)
df_org = df_org_.iloc[[i!=0 for i in df_org_.count(1)],:]
df = df_org.dropna(axis=1)
df_pct = df.pct_change().dropna(axis=0)

# 訓練，テスト期間の設定
stock_list = df_pct.columns
start_year = 2016
end_year = 2018
year_term_train = 2
year_term_test = 1
era_list = list(range(start_year, end_year, year_term_test))

# 実行
df_y_pred_all, df_y_true_all, df_info_all = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
index_portfolio_dict, index_quantile_port_dict, result_dict = {}, {}, {}
time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
for era in era_list:
    print(era)
    output_name = str(era) + '_' + str(era+year_term_train-1)
    dataset_dict = get_dateset_dict(era, year_term_train, year_term_test)
    df_y_pred, df_y_true, df_info = make_model_pred(df_pct, stock_list, dataset_dict, hyperparms_company_common, time_now)
    df_y_pred_all = pd.concat([df_y_pred_all, df_y_pred], axis=0)
    df_y_true_all = pd.concat([df_y_true_all, df_y_true], axis=0)
    df_info_all = pd.concat([df_info_all, df_info], axis=0)

    index_portfolio_dict[output_name], index_quantile_port_dict[output_name], result_dict[output_name] = \
        get_portfolio_result(df_y_pred, df_y_true, hyperparms_portfolio, output_name)

index_portfolio, index_quantile_port, result_all = \
    get_portfolio_result(df_y_pred_all, df_y_true_all, hyperparms_portfolio, output_name=str(start_year)+'_'+str(end_year))

# 結果の出力
all_term = str(start_year) + '_' + str(end_year+year_term_train+year_term_test-1)
path_output = PATH_HEAD + '\\Result\\' + all_term + '\\' + time_now
os.makedirs(path_output, exist_ok=True)
wb = openpyxl.Workbook()
wb.save(path_output+'\\All_info.xlsx')
with pd.ExcelWriter(path_output+'\\All_info.xlsx') as writer:
    result_all.to_excel(writer, sheet_name='result')
    index_portfolio.to_excel(writer, sheet_name='index_portfolio')
    index_quantile_port.to_excel(writer, sheet_name='index_quantile')
    df_info_all.to_excel(writer, sheet_name='info')
    df_y_pred_all.to_excel(writer, sheet_name='予測リターン')
    df_y_true_all.to_excel(writer, sheet_name='リターン_実績値')
    
    for name_, result_ in result_dict.items():
        result_.to_excel(writer, sheet_name='result_'+name_)
            
#%%
# パラメータの使用頻度を算出
# =============================================================================
# hyperparms_company_learned = tc.hyperparms_company_learned
# ticker_counts, activation_counts, operator_counts = tc.calc_parms_frequency(df_pct.columns, hyperparms_company_learned)
# ticker_counts.iloc[:30,:].plot.bar()
# activation_counts.plot.bar()
# operator_counts.plot.bar()
# =============================================================================