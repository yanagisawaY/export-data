# -*- coding: utf-8 -*-
"""
ポートフォリオのパフォーマンス測定を実施
"""
import pandas as pd
import numpy as np
from datetime import timedelta

class Evaluator:
    def __init__(self):
        pass
        
    def calc_mdd(self, wealth):
        '''
           MDD(Maximum Drawdown)を計算 

        Parameters
        ----------
        mdd : TYPE
            累積（あるいは類和）リターン.

        '''
        mdd = np.max((np.maximum.accumulate(wealth) - wealth)/np.maximum.accumulate(wealth), 0)
        return mdd
    
    def calc_performance(self, return_portfolio, business_days, output_name ='result'):
        '''
            ポートフォリオのパフォーマンスを測定する関数

        Parameters
        ----------
        return_portfolio : TYPE
            ポートフォリオのリターン.        
        business_days : int
            年率換算時に使用する営業日日数換算値
        output_name : TYPE, optional
            出力するデータフレームの名前ラベル. The default is 'result'.

        Returns
        -------
        Output : pd.Series
            ポートフォリオの測定結果.
        '''
        mean_year = return_portfolio.mean()*business_days            
        sd_year = ((np.sqrt(business_days) * pd.DataFrame.std(return_portfolio, ddof=1)))
        SR_year = mean_year / sd_year
        lpm2_year = np.sqrt(business_days) * np.sqrt(np.sum((return_portfolio[return_portfolio<0] ** 2))/len(return_portfolio))
        DDR_year = mean_year / lpm2_year
        
        output = pd.Series([mean_year,sd_year,SR_year, lpm2_year, DDR_year],
                           index=['平均(年率換算)','標準偏差(年率換算)',
                                  'R/R(年率換算)','半分散(年率換算)','DDRatio(年率換算)'],
                           name=output_name)
        
        return output  
    
    
class PortfolioEvaluator(Evaluator):
    def __init__(self, df_return, business_days, hyperparms_portfolio):
        '''
        df_return : pandas.DataFrame
            各投資対象銘柄の実績リターン.
        business_days : int
            年率換算時に使用する使用営業日日数      
        hyperparms_portfolio : dict
            wealth_init            : 初期富
            cost_buy               : 銘柄購入時のコスト
            cost_sell              : 銘柄売却時のコスト
            calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
        '''
        self.df_return = df_return
        self.cost_buy = hyperparms_portfolio['cost_buy']
        self.cost_sell = hyperparms_portfolio['cost_sell']             
        self.calc_type = hyperparms_portfolio['calc_type']
        self.wealth_init = hyperparms_portfolio['wealth_init']
        self.business_days = 250/business_days
    
    def check_index(self, df1, df2):
        assert all(df1.index == df2.index), 'データフレームのindexを統一してくださし'

    def calc_portfolio_return(self, weight, is_no_cost=False):
        '''
            ポートフォリオのリターンを計算する

        Parameters
        ----------
        weight : pd.DataFrame
            ポートフォリオのウェイト行列.(時点,銘柄)
        is_no_cost : 取引コストを考慮しない場合はTrue
        
        Returns
        -------
        return_portfolio
            ポートフォリオのリターン.
        '''
        if is_no_cost:
            cost_buy, cost_sell = 0, 0
        else:
            cost_buy, cost_sell = self.cost_buy, self.cost_sell

        weight_diff = self.calc_weight_diff(weight)
            
        cost_matrix = np.abs(weight_diff[weight_diff>0].fillna(0)) * cost_buy + np.abs(weight_diff[weight_diff<0].fillna(0)) * cost_sell
        cost_index  = cost_matrix.sum(axis=1)

        self.check_index(weight, self.df_return)
        if self.calc_type == 'accumulation':
            return_portfolio = (1 + (weight * self.df_return).sum(axis=1))*(1 - cost_index) - 1
        elif self.calc_type == 'cumulative':            
            return_portfolio = (weight * self.df_return).sum(axis=1) - cost_index
                    
        return return_portfolio

    def calc_weight_diff(self, weight, weight_init=[]):
        '''
            ポートフォリオのウェイト変化を算出
        
        Notes
        ----------        
        self.calc_type == accumulation : 
            ポートフォリオの組替え時のウェイト変化を，リターンの実現時点を加味して算出
            (期末時点の各資産の富を計算し，リバランスの際の差分コストを計算)
        self.calc_type == cumulative : 
            投資量を常に固定した場合のウェイト変化を算出
            
        Returns
        -------            
        weight_diff
            ポートフォリオのウェイト変化
        '''               
        port = pd.concat([(1+self.df_return*weight).mean(1)]*weight.shape[1], axis=1)
        port.columns = weight.columns
        
        if len(weight_init) == 0:
            weight_t_1 = weight.shift(1).fillna(1/weight.shape[1])
        else:
            assert isinstance(weight_init, pd.Series)
            weight_t_1 = weight.shift(1).dropna()
            weight_t_1 = pd.concat([weight_init, weight_t_1])
            
        weight_t = weight_t_1*(1+self.df_return)/port
        weight_diff = weight - weight_t
        
        return weight_diff
            
    def calc_turnover(self, weight):
        '''
            ポートフォリオのターンオーバーを計算する(初期時点は除く)

        Parameters
        ----------
        weight : pandas.DataFrame
            ポートフォリオのウェイト推移.（時点×銘柄）            
        Returns
        -------
        turnover : 
            ターンオーバー
        '''
        weight_diff = self.calc_weight_diff(weight)
        turnover = 0.5*np.sum(np.sum(np.abs(weight_diff), 1))/weight.shape[0]
        
        return turnover
        
    def calc_wealth(self, return_portfolio, wealth=0):        
        '''
            ポートフォリオの累積(累和)リターンを計算する関数

        Parameters
        ----------
        return_portfolio : TYPE
            ポートフォリオのリターン.
        wealth : 
            初期富

        Returns
        -------
        index_portfolio : pandas.DataFrame
            ポートフォリオの累積(累和)リターン
        '''
        index_portfolio = []
        if wealth == 0:
            wealth0 = self.wealth_init
            wealth = self.wealth_init
        else:
            wealth0 = wealth
            
        if self.calc_type == 'accumulation':
            for i in return_portfolio:    
                wealth = wealth * (1+i)
                index_portfolio.append(wealth)
        elif self.calc_type == 'cumulative':
            for i in return_portfolio:
                wealth += wealth0 * i
                index_portfolio.append(wealth)
            
        index_portfolio = pd.Series(index_portfolio, index=return_portfolio.index)      
        index_portfolio = pd.concat([pd.Series([wealth0]), index_portfolio])
        index_portfolio = index_portfolio.rename(index = {0:pd.to_datetime(index_portfolio.index[1]) - timedelta(days=1)})
        
        return index_portfolio
    
    def make_peformance_result(self, weight, output_name='result'):
        '''
            パフォーマンス結果を出力

        Parameters
        ----------
        weight : pandas.DataFrame
            ポートフォリオのウェイト推移.（時点×銘柄）            
        output_name : str
            出力するデータフレームの名前ラベル.

        Returns
        -------
        output_result : pd.DataFrame
            集約結果
        '''
        super().__init__()        
        return_portfolio = self.calc_portfolio_return(weight)
        turnover = self.calc_turnover(weight)
        output_result = self.calc_performance(return_portfolio, self.business_days, output_name)
        output_result['turnover'] = turnover
        index_portfolio = self.calc_wealth(return_portfolio, wealth=1)        
        index_portfolio.name = output_name
        output_result['MDD'] = self.calc_mdd(index_portfolio)        
        
        return output_result
        
        