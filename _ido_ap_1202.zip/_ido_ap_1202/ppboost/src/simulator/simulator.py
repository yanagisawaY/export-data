# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    本コードで使用しているクラス
    StockSimulator
        株式リターンのシミュレーションデータ生成を実施するクラス
    Simulator　-> StockSimulatorを継承
        シミュレーションデータの生成を実施するクラス
"""
import numpy as np
import pandas as pd

class StockSimulator:
    def __init__(self, simulation_setting):
        '''
            株式リターンのシミュレーションデータ生成を実施するクラス

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''
        self.random_seed = simulation_setting['random_seed']
        self.stock_num = simulation_setting['stock_num']        
        self.time_span = simulation_setting['time_span']
        self.year_term = simulation_setting['year_term']
        self.sigma_epsilon = simulation_setting['sigma_epsilon']
        self.market_u = simulation_setting['market_u']
        self.market_sigma = simulation_setting['market_sigma']
        self.beta_u = simulation_setting['beta_u']
        self.beta_sigma = simulation_setting['beta_sigma']
        self.alpha_sigma = simulation_setting['alpha_sigma']
        
        self.regime0_mean = simulation_setting['regime0_mean']
        self.regime0_sigma =simulation_setting['regime0_sigma']
        self.regime1_mean = simulation_setting['regime1_mean']
        self.regime1_sigma =simulation_setting['regime1_sigma']        
        assert len(self.regime0_mean) == len(self.regime1_mean)
        self.regime_0_init = simulation_setting['regime_0_init']
        self.regime_1_init = simulation_setting['regime_1_init']             
        self.regime_0_stay = simulation_setting['regime_0_stay']
        self.regime_1_stay = simulation_setting['regime_1_stay']
        
        self.factor_num = len(self.regime0_mean)
        np.random.seed(self.random_seed)                
        
    def generate_marcket_return(self, seed):
        '''
        Returns
        -------
        market_r : np.array
            マーケットリターン (銘柄，年代)
        '''
        np.random.seed(self.random_seed + seed)
        market_r = self.market_u + np.random.randn(self.time_span, self.year_term)*self.market_sigma
        
        return market_r

    def generate_marcket_beta(self, seed):
        '''
        Returns
        -------
        beta : np.array
            マーケットリターンへの感応度 (銘柄，年代)
        '''
        np.random.seed(self.random_seed + seed)        
        beta = self.beta_u + np.random.randn(self.stock_num, self.year_term)*self.beta_sigma
        
        return beta

    def generate_epsilon(self, seed):
        '''
        Returns
        -------
        epsilon : np.array
            非システマティックリスクの誤差項(銘柄, 時点， 年代)
        '''
        np.random.seed(self.random_seed + seed)                
        epsilon = np.random.randn(self.stock_num, self.time_span, self.year_term)*self.sigma_epsilon
        
        return epsilon

    def generate_alpha_noise(self, seed):
        '''
        Returns
        -------
        alpha_noise : np.array
            アルファリターンの誤差項(銘柄，年代)
        '''
        np.random.seed(self.random_seed + seed)                        
        alpha_noise = np.random.randn(self.stock_num, self.year_term)*self.alpha_sigma
        
        return alpha_noise

    def generate_characteristic(self, seed):
        '''
        Returns
        -------
        characteristic : np.array
            企業特性(銘柄，年代, 企業特性数)
        '''
        np.random.seed(self.random_seed + seed)                                
        characteristic = np.random.randn(self.stock_num, self.year_term, self.factor_num)
        self.characteristic = characteristic
        
        return characteristic

    def set_transition(self):
        '''
        Returns
        -------
        transition : np.array
            2×2の推移確率行列.
        '''                
        transition = np.array([[self.regime_0_stay, 1-self.regime_0_stay],
                               [1-self.regime_1_stay, self.regime_1_stay]])
        
        return transition

    def calc_transition_mat(self, state_prob, transition):
        '''
            次の時点の状態確率を算出

        Parameters
        ----------
        state_prob : np.array
            1×2の状態確率.
        transition : np.array
            2×2の推移確率行列.

        Returns
        -------
        next_state_prob : np.array
            次の時点の1×2の推移確率行列.
        '''
        next_state_prob = state_prob@transition
        
        return next_state_prob

    def sample_state(self, state_prob, count : int):
        '''
            次の時点の状態確率を算出

        Parameters
        ----------
        state_prob : np.array
            1×2の状態確率.

        Returns
        -------
        state : int -> 0 or 1
            乱数によるサンプリングされた状態
        '''
        np.random.seed(self.random_seed + count)
        state = 1*(state_prob[1] >= np.random.rand())
        
        return state

    def sample_states(self):
        '''
            全ファクターの全期間における状態をサンプリング

        Returns
        -------
        states : np.array
            サンプリングされた状態 (年代, 企業特性)
        '''
        states = np.zeros((self.year_term, self.factor_num))        
        
        # 推移確率行列
        transition = self.set_transition()
        
        for k in range(self.factor_num):
            # 初期状態
            state_prob = np.array([self.regime_0_init, self.regime_1_init])                            
            for y in range(1, self.year_term):                
                count = k*self.factor_num + y
                states[y, k] = self.sample_state(state_prob, count)
            
                # サンプリングした状態の情報をもとに次年度の状態確率を算出
                state_prob = transition[int(states[y, k]),:]
        
        return states
    
    def generate_delta(self, seed):
        '''
        Returns
        -------
        delta : np.array
            期間yごとにレジームスイッチングする企業特性感応度(年代, 企業特性)
        '''
        np.random.seed(self.random_seed + seed)
        delta_regime0_sigma = np.random.randn(self.year_term, self.factor_num)*self.regime0_sigma
        np.random.seed(self.random_seed + seed + 100)
        delta_regime1_sigma = np.random.randn(self.year_term, self.factor_num)*self.regime1_sigma        
        
        delta_regime0 = np.tile(np.array(self.regime0_mean), (self.year_term, 1)) + delta_regime0_sigma
        delta_regime1 = np.tile(np.array(self.regime1_mean), (self.year_term, 1)) + delta_regime1_sigma        

        # シミュレーションによりサンプリングされた状態に応じ，感応度を設定
        self.states = self.sample_states() # 後に参照できるようにselfで値を保持
        delta = (self.states==0)*1*delta_regime0 + (self.states==1)*1*delta_regime1
        
        return delta
            
    def calc_alpha_term(self, X, delta, alpha_noise):
        '''
        Returns
        -------
        alpha : np.array
            アルファリターン(銘柄, 時点， 年代)
        '''
        alpha = np.einsum("mts, ts->mts", X, delta).sum(2) + alpha_noise
        alpha = np.repeat(alpha[:,np.newaxis,:], self.time_span, axis=1)
        
        return alpha

    def calc_market_term(self, market_r, beta):
        '''
        Returns
        -------
        market_term  : np.array
            マーケットリターン(銘柄, 時点， 年代)
        '''
        # サンプルリターンの計算
        market_term = np.einsum("mts, mts->mts", 
                                np.repeat(beta[:,np.newaxis,:], self.time_span, axis=1), 
                                np.repeat(market_r[np.newaxis,:,:], self.stock_num, axis=0))
        
        return market_term

    def sum_terms(self):
        '''
        Returns
        -------
        market_term  : np.array
            マーケットリターン(銘柄, 時点， 年代)
        '''
        # マーケットリターンの生成        
        self.market_r = self.generate_marcket_return(seed=1)
        beta = self.generate_marcket_beta(seed=2)
        market_term = self.calc_market_term(self.market_r, beta)
        
        # アルファリターンの生成
        X = self.generate_characteristic(seed=3)
        delta = self.generate_delta(seed=4)
        alpha_noise = self.generate_alpha_noise(seed=5)
        alpha = self.calc_alpha_term(X, delta, alpha_noise)
        
        noise = self.generate_epsilon(seed=6)
        
        rt = alpha + market_term + noise
                    
        return rt
    
    def sample_return(self):
        '''
            サンプリングを実施．
        Returns
        -------
        samples  : pd.DataFrame
            マーケットリターン(銘柄, 時点×年代)
        '''        
        rt = self.sum_terms()
        samples = np.zeros([self.time_span*self.year_term, self.stock_num])
        for i in range(rt.shape[2]):
            samples[i*rt.shape[1]:(i*rt.shape[1]+rt.shape[1]),:] = rt[:,:,i].T

        self.stock_names = ['stock_'+str(i) for i in range(self.stock_num)]
        samples = pd.DataFrame(samples, columns=self.stock_names) 
            
        return samples


class Simulator(StockSimulator):
    def __init__(self, simulation_setting):
        '''
            シミュレーションデータ生成を実施するクラス

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''        
        super().__init__(simulation_setting)
        self.redundant_num = simulation_setting['redundant_num']
        self.redundant_noise = simulation_setting['redundant_noise']
        self.redundant_coef = simulation_setting['redundant_coef']        
        self.factor_noise_num = simulation_setting['factor_noise_num']
        self.factor_noise = simulation_setting['factor_noise']
        
    def orgnanize_characteristic(self):
        '''
            企業特性データをリターンと同じサイズで出力

        Returns
        -------
        X_output : np.array
            企業特性データ.(銘柄，時点×年代, 企業特性数)
        '''
        X = self.characteristic        
        X_output = np.zeros([self.time_span*self.year_term, self.stock_num, self.factor_num])
        for i in range(self.year_term):
            X_output[i*self.time_span:(i*self.time_span+self.time_span),:,:] = np.repeat(X[:,i,:][np.newaxis,:,:], self.time_span, axis=0)
            
        return X_output

    def make_factor_dict(self, X_output):
        '''
            企業特性データを辞書形式で保存

        Parameters
        ----------
        X_output : np.array
            企業特性データ.(銘柄，時点×年代, 企業特性数)

        Returns
        -------
        factor_dict : dict
            企業特性データが格納された辞書.
        factor_I : list
            企業特性データの名前（I_1，などの名前を設定）.
        '''
        factor_dict = {}
        factor_I = []
        for i in range(X_output.shape[2]):
            name = 'I_'+str(i)
            factor_I.append(name)
            factor_dict[name] = pd.DataFrame(X_output[:,:,i], columns=self.stock_names)

        return factor_dict, factor_I

    def generate_redundancy(self, factor_dict, factor_I):
        '''
            冗長な企業特性を生成
            (To Test作業者):乱数シードごとに異なる乱数が生成されているか？            

        Parameters
        ----------
        factor_dict : dict
            企業特性データの辞書.
        factor_I : list
            企業特性データの名前（I_1，などの名前を設定）.

        Returns
        -------
        factor_dict : dict
            冗長な特徴量が追加された企業特性データの辞書.
        
        Notes : 
            coef(有効な企業特性にかける係数)は0~0.8の一様乱数より設定    
            ➡アノマリーのあるファクターよりはシグナルが弱いという設定
        '''
        prob = [1/self.factor_num for _ in range(self.factor_num)]
        
        coef_redundant = []
        redundant_chosen = {}
        for j in range(self.redundant_num):
            np.random.seed(self.random_seed + j)
            name_I = np.random.choice(factor_I, p=prob)
            name = 'R_' + str(j)
            coef = np.random.rand()*self.redundant_coef
            temp = factor_dict[name_I]*coef + np.random.randn(self.year_term*self.time_span, self.stock_num)*self.redundant_noise
            factor_dict[name] = pd.DataFrame(temp, columns=self.stock_names)        

            coef_redundant += [coef]
            redundant_chosen[name] = name_I
                    
        coef_redundant = pd.Series(coef_redundant)
        coef_redundant.index = list(redundant_chosen.keys())
        redundant_chosen = pd.DataFrame(redundant_chosen.values(), index=redundant_chosen.keys())
        self.redundant_chosen = pd.concat([redundant_chosen, coef_redundant], axis=1)
        self.redundant_chosen.columns = ['factor', 'coef']
        
        return factor_dict
    
    def generate_noise(self, factor_dict):
        '''
            無関係な企業特性を生成
            (To Test作業者):乱数シードごとに異なる乱数が生成されているか？

        Parameters
        ----------
        factor_dict : dict
            企業特性データの辞書.

        Returns
        -------
        factor_dict : dict
            企業特性とは無関係なデータが追加された企業特性データの辞書.
        '''
        for j in range(self.factor_noise_num):
            np.random.seed(self.random_seed + j)                    
            name = 'N_' + str(j)
            temp = np.random.randn(self.year_term*self.time_span, self.stock_num)*self.factor_noise
            factor_dict[name] = pd.DataFrame(temp, columns=self.stock_names)
            
        return factor_dict
    
    def make_simulation_data(self):
        '''
            シミュレーションデータを生成

        Returns
        -------
        df_all : pd.DataFrame
            シミュレーションデータ.
        '''
        return_samples = self.sample_return()
        X_output = self.orgnanize_characteristic()
        factor_dict_, self.factor_I = self.make_factor_dict(X_output)
        factor_dict_ = self.generate_redundancy(factor_dict_, self.factor_I)
        factor_dict = self.generate_noise(factor_dict_)
        
        index_ = list(return_samples.index)
        return_samples["index"] = index_
        df_all = return_samples.melt(id_vars="index")
        df_all.columns = ["Date", "stock", "return"]        
        for key, df_factor in factor_dict.items():
            df_factor["index"] = index_
            temp = df_factor.melt(id_vars="index")
            temp.columns = ["Date", "stock", key]
            df_all = pd.merge(df_all, temp, how="left", on=["Date", "stock"])       

        return df_all
    