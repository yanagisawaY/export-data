"""
シミュレーションデータによる検証
"""
import os
import datetime as dt
# パスの設定
PATH_HEAD = r"C:\Users\yana\Desktop\github\parametric_portfolio_boosting\ppboost\src"
os.chdir(PATH_HEAD)

from simulator.experimenter import Experimenter

# %%
# =============================================================================
# # モデルのハイパーパラメータ設定
# =============================================================================
hyperparms = {
    "random_state": 1,
    "batch_size": 60,
    "layer_list"    : [],
    "lr"            : 1e-4,
    "epoch"         : 100,        
    "is_cost": False,  # 取引コストを目的関数に入れ込むかどうか
    "utility_type" : "CRRA",
    "model": "UtilityTrader",        
    "gamma": 0.5,
    "val_ratio": 0.25,
    "layer_dropout": 0.95,    
    "leverage": 0,#10,
#    "l2_norm": 0,#1e-4,    
}


# =============================================================================
# hyperparms = {
#     "random_state": 1,
#     "batch_size": 60,
#     "layer_w": [16, 8],
#     "layer_g": [8],
#     "lr": 1e-3,
#     "gan_iter": 1, #6
#     "epoch_init": 10, #256,
#     "epoch_w": 10, #1024,    
#     "epoch_g": 10, #64,
#     "model": "UtilityGanTrader",    
#     "val_ratio": 0.25,
#     "dropout_w": 0.95,
#     "dropout_g": 0.95,    
#     "lambda": 10,
#     "leverage": 1000,
#     "is_cost": False,
# }
# 
# =============================================================================

# =============================================================================
# # バックテスト時の設定
# =============================================================================
hyperparms_portfolio = {
    "cost_buy": 0,
    "cost_sell": 0,
    "calc_type": "cumulative",
    "wealth_init": 100,
}

"""
hyperparms_portfolio : dict
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
"""
# =============================================================================
# # シミュレーションデータの設定
# =============================================================================
simulation_setting = {
    # 乱数シード
    "random_seed": 1,

    # 訓練データとテストデータを分割するインデックスの数値. The default is 0.
    # 0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
    "train_num": 0,

    # データセットサイズ関連(銘柄, 時点， 年代)
    "stock_num": 500,
    "time_span": 12,
    "year_term": 10,

    # 非システマティックリスクの誤差項(銘柄, 時点， 年代)
    "sigma_epsilon": 0.05,

    # マーケットリターンの平均と標準偏差(銘柄，年代)
    "market_u": 0.02,
    "market_sigma": 0.05,

    # マーケットリターンへの感応度(銘柄，年代)
    "beta_u": 1,
    "beta_sigma": 0.1,

    # アルファリターンの誤差項(銘柄，年代)
    "alpha_sigma": 0,

    # 期間yごとに変動する企業特性への感応度(年代, 企業特性)
    "regime0_mean": [0.01*(-1)**i for i in range(10)],
    "regime0_sigma": 0.02,
    "regime1_mean": [0*(-1)**(i+1) for i in range(10)],
    "regime1_sigma": 0.02,

    # レジームスイッチングの初期状態の所属確率
    "regime_0_init": 0.99,
    "regime_1_init": 0.01,
    # レジームスイッチングの推移確率行列の対角成分(同じ状態にとどまる確率)
    "regime_0_stay": 0.97,  # 0.9,
    "regime_1_stay": 0.99,

    # 冗長な企業特性データの生成
    "redundant_num": 5,
    "redundant_noise": 1,
    # 有効な企業特性にかける係数の最大値 ➡1より小さくすることでアノマリーのあるファクターよりはシグナルが弱いという設定
    # 係数は0~redundant_coefの一様乱数より生成
    "redundant_coef": 0.5,

    # ノイズな企業特性データの生成
    "factor_noise_num": 30,
    "factor_noise": 1,
}

# 比較モデルのハイパーパラメータ
hyperparms_comparative = {
    # 比較モデルの学習等を実施する場合はTrue
    "is_comparison": True,

    # 検証する比較モデルの名前
    "model_list": [
        "lasso",
        #        "randomforest",
        "lightgbm",
        "dnn",        
    ],

    # Lasso回帰のハイパーパラメータ
    "params_lasso":
        {
        "random_state": 1,
        "cv": 5,
    },

    # ランダムフォレスト回帰のハイパーパラメータ
    "params_randomforest":
        {
        "random_state": 1,
        "n_estimators": 100,
    },

    # LightGBM回帰のハイパーパラメータ
    "params_lightgbm":
        {
        "random_state": 1,
        "boosting_type": "gbdt",
        "silent": False,
        "n_estimators": 100,
    },

    # 深層学習のハイパーパラメータ
    "params_dnn" : 
        {
        "random_state"  : 1,            
        "layer_dropout" : 0.2,
        "layer_list"    : [50, 50, 25, 25, 10],
        "lr"            : 1e-5,
        "batch_size"    : 502,
        "epoch"         : 25,
        },
        
    # スコアに対してLS戦略を組む際のパーセンタイル
    "long_ratio": 0.90,
    "short_ratio": 0.1,

    # LongShort or Long / スコアに基づくポートフォリオ構築方法
    "portfolio_type": "LongShort",
}

# %%
if __name__ == "__main__":
    time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
    output = {}
    seed_pattern = 6

    sim_states = {}
    sim_coef = {}
    for seed in range(6, seed_pattern+1):
        output_name = "sim" + str(seed)
        print(f"実行中 / {output_name}")
        simulation_setting["random_seed"] = seed
        hyperparms["random_seed"] = int(seed*2+1)
        ex = Experimenter(hyperparms)
        output.update(ex.get_simulation_result(simulation_setting,
                      hyperparms_portfolio, hyperparms_comparative, output_name))

        # シミュレーションデータに関する情報
        sim_states[output_name] = ex.get_simulation_states()
        sim_coef[output_name] = ex.sim.redundant_chosen

    # 結果の出力
    output_all = {
        "output": output,
        "hyperparms": hyperparms,
        "hyperparms_portfolio": hyperparms_portfolio,
        "hyperparms_comparative": hyperparms_comparative,

        # シミュレーションデータに関するデータ
        "simulation_setting": simulation_setting,
        "sim_states": sim_states,
        "sim_coef": sim_coef,
    }

    path_output = PATH_HEAD + "\\Result\\simulation\\" + time_now
    #os.makedirs(path_output, exist_ok=True)
    #ex.output_result(output_all, path_output)
