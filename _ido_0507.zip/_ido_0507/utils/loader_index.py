# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.データ作成のコード
    2.テクニカル指標作成に関わるものはconfig（別コード）にて設定

"""
import numpy as np
import pandas as pd
import datetime as dt
import time
import itertools
import talib as ta
from config.config_index import *

func_close = {
    # talib以外のテクニカル指標
    'sma_gap'  : {'timeperiod' : [20, 40, 60]}, 
    'vol' : {'timeperiod' : [20, 40, 60]},
    'MACD' : {'fastperiod' : [12], 'slowperiod' : [26, 52], 'signalperiod' : [9]}, # https://www.moneypartners.co.jp/support/tech/macd.html
    }

# talib以外のテクニカル指標作成関数
def sma_gap(close, timeperiod):
    '''調整後終値ベースの移動平均乖離率
    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    timeperiod : int
        スライド期間.
    '''
    output = close/(close.rolling(timeperiod).mean())
    
    return output

def vol(close, timeperiod):
    '''調整後終値ベースのボラティリティ
    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    timeperiod : int
        スライド期間.
    '''    
    output = np.log(close).diff().rolling(timeperiod).std()
    
    return output

def MACD(close, fastperiod, slowperiod, signalperiod):
    '''調整後終値ベースのMACD https://www.moneypartners.co.jp/support/tech/macd.html
    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    fastperiod, slowperiod, signalperiod : int
        パラメータはリンク参照    
    output : macdhist = macd - macdsignal
    '''    
    
    macd, macdsignal, macdhist = ta.MACD(close, fastperiod, slowperiod, signalperiod)
    
    return macdhist

    
# =============================================================================
# # データ成形のクラス    
# =============================================================================
class DataLoader:
    def __init__(self, df_org, hyperparms_model):        
        self.hyperparms_model = hyperparms_model
        self.df, df_nontech = self.make_feature_data(df_org)
        
        #　対数リターン(説明変数に使用)
        self.df_pct = self.get_pct_change_log(self.hyperparms_model['rebalance_term'])

        # 非説明変数に使用するリターン
        self.df_pct_target = self.get_pct_change_log(self.hyperparms_model['rebalance_term'])        
        
        # ポートフォリオのリバランス時点で観測するリターン
        self.df_pct_port = self.get_pct_change_port(self.hyperparms_model['rebalance_term'])
        
        self.index_date = self.df_pct.index
        # テクニカル指標データの作成
        print('テクニカル指標データ作成...')
        start = time.time()
        dict_talib_all = self.make_technical_data()
        print(f'テクニカル指標作成完了: {round(time.time()-start)}sec')  
        dict_talib = self.change_technical_dict(dict_talib_all)
        print(f'テクニカル指標変換完了: {round(time.time()-start)}sec')
        self.dict_talib = self.combine_data(dict_talib, df_nontech)
                
        self.check_index()
    
    def combine_data(self, dict_talib, df_nontech):
        '''
            テクニカル指標とほかのデータを結合

        Parameters
        ----------
        dict_talib : dict
            テクニカル指標が格納されたデータ.
        df_nontech : pd.DataFrame
            テクニカル指標を作成しないデータ.

        Returns
        -------
        dict_talib : dict
            結合後データ.
        '''
        for name, df in dict_talib.items():
            col_names = [name+'_'+i for i in df.columns]           
            dict_talib[name] = dict_talib[name].rename(columns=dict(zip(df.columns, col_names)))
                        
        dict_talib_temp = dict_talib.copy()
        
        df_temp = []
        for name, df in dict_talib_temp.items():                
            df_temp.append(df)
        df_temp = pd.concat(df_temp, axis=1)
        
        for name, df in dict_talib_temp.items():
            dict_talib[name] = pd.concat([df_temp, df_nontech], axis=1)
            
        return dict_talib
    
    def check_index(self):
        assert self.hyperparms_model['rebalance_term'] >= 1

    def get_index(self, start_date, end_date):
        '''
            データ分割における日付を取得(lagとrebalance_termを考慮して説明変数データのindexを作成)

        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.

        Returns
        -------
        target_start_date : datetime
            予測データの開始日.(入力した日付がない場合，該当日以降のうち，最も近い日付)
        target_end_date : datetime
            予測データの終了日.(入力した日付がない場合，該当日以降のうち，最も近い日付)
        explained_start_date : datetime
            説明変数データの開始日.
        explained_end_date : datetime
            説明変数データの終了日.
        '''
        
        if (not isinstance(start_date, dt.datetime)) or (not isinstance(end_date, dt.datetime)):
            raise ValueError('start_date, end_dateはdatetime型にしてください')            

        try:
            target_start_index = np.abs(self.index_date-start_date).argmin()
            target_start_date = self.index_date[target_start_index]
            
            if target_start_date < start_date:
                target_start_index = np.abs(self.index_date-start_date).argmin() + 1
                target_start_date = self.index_date[target_start_index]
                
            explained_start_index = target_start_index - self.hyperparms_model['lag'] - self.hyperparms_model['rebalance_term']
            explained_start_date = self.index_date[explained_start_index]
        except:
            raise ValueError('データ期間の開始日が範囲外です.rebalance_termとlagを考慮して日付を設定してください')
        
        assert explained_start_index >= 0,{
            'データ期間の開始日が範囲外です.rebalance_termとlagを考慮して日付を設定してください'            
            }
        
        try:
            target_end_index = np.abs(self.index_date-end_date).argmin()
            target_end_date = self.index_date[target_end_index]            
            explained_end_index = target_end_index - self.hyperparms_model['lag'] - self.hyperparms_model['rebalance_term']
            explained_end_date = self.index_date[explained_end_index]
        except:
            raise ValueError('データ期間の終了日が範囲外です.rebalance_termとlagを考慮して日付を設定してください')
                   
        return target_start_date, target_end_date, explained_start_date, explained_end_date

    def make_dataset(self, start_date, end_date, stock_i, is_test=False):
        '''
            説明変数データ，被説明変数データを作成

        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.
        stock_i : str
            銘柄のティッカー（説明変数）
        is_test : 
            テストデータセットを作成する場合はTrue（X, y, y_portをリストで出力）
        Returns
        -------
        X : pd.DataFrame
            説明変数データ.
        y : pandas.DataFrame
            予測データ.
        y_port : pandas.DataFrame
            バックテストにおける観測リターンデータ.
            （リバランスのずれを考慮している場合，yとは一致しない）
        '''
        target_start_date, target_end_date, explained_start_date, explained_end_date = self.get_index(start_date, end_date)

        if self.hyperparms_model['data_type'] == 'Tech':
            dict_talib_ = self.extract_technical_dict(self.dict_talib, explained_start_date, explained_end_date)
            X = dict_talib_[stock_i]
        elif self.hyperparms_model['data_type'] == 'RtTech':
            dict_talib_ = self.extract_technical_dict(self.dict_talib, explained_start_date, explained_end_date)
            X = dict_talib_[stock_i].drop('return', axis=1)
            X = pd.concat([self.df_pct[explained_start_date:explained_end_date], X], axis=1)
        elif self.hyperparms_model['data_type'] == 'Rt':
            X = self.df_pct[explained_start_date:explained_end_date]
        else:
            raise ValueError(r'hyperparms_modelのdata_typeに想定外のインプットが入力されています')            

        y = self.df_pct_port[target_start_date:target_end_date].loc[:, stock_i]
        y_port = self.df_pct_port[target_start_date:target_end_date].loc[:, stock_i]
        
        # バックテストパターンの設定
        X_output, y_output, y_port_output = [], [], []
        for split_id in range(self.hyperparms_model['rebalance_term']):
            X_output.append(X[split_id::self.hyperparms_model['rebalance_term']])
            y_output.append(y[split_id::self.hyperparms_model['rebalance_term']])            
            y_port_output.append(y_port[split_id::self.hyperparms_model['rebalance_term']])
        
        if not is_test:
            X_output = pd.concat(X_output)
            y_output = pd.concat(y_output)
            y_port_output = pd.concat(y_port_output)
                
        return X_output, y_output, y_port_output

    def get_pct_change(self, rebalance_term):
        '''価格リターンの算出
        '''        
        output = self.df.pct_change(rebalance_term).dropna(axis=0)
        return output

    def get_pct_change_log(self, rebalance_term):
        '''対数リターンの算出
        '''                
        output = self.df.applymap(np.log).diff(rebalance_term).dropna(axis=0)
        
        return output
    
    def get_pct_change_port(self, rebalance_term):
        '''ポートフォリオのリバランス時点で観測するリターン
            1日ラグをあけて終値を観察．
        '''        
        output = self.df.shift(-1).pct_change(rebalance_term).dropna(axis=0)
                
        return output

    def convert(self, x):
        if x[0] == 1:
            # x = np.log(x[1:]).diff()
            x = x[1:].pct_change()
        elif x[0] == 2:
            x = x[1:].diff()
        elif x[0] == 3:
            x = x[1:]
        else:
            raise ValueError('Codeは1~3の値を選択')
        return x

    def make_feature_data(self, df_org):        
        df_org.loc['Code', self.hyperparms_model['tech_list']] = 3
        df = df_org.apply(self.convert).replace([np.inf, -np.inf], np.nan).dropna()
        df.index = pd.to_datetime(df.index)
        df_tech = df[self.hyperparms_model['tech_list']]
        df_nontech = df.drop(self.hyperparms_model['tech_list'], axis=1)               
        
        return df_tech, df_nontech
    
    def make_technical_data(self):
        '''
            テクニカル指標データの作成
            (dict_talibはconfig.pyにて設定)
        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.        

        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''
        dict_talib = {}
        dict_talib['return'] = self.get_pct_change(self.hyperparms_model['rebalance_term'])
        dict_talib.update(self.make_technical_return())
        dict_talib.update(self.make_technical_close())
        dict_talib.update(self.make_technical_org())
        
        return dict_talib

    def extract_technical_dict(self, dict_talib, explained_start_date, explained_end_date):
        '''テクニカル指標の日付を統一
        Returns
        -------
        dict_talib_output : dict
            日付統一後のテクニカル指標データ.
        '''
        dict_talib_output = dict_talib.copy()
        for key, df in dict_talib.items():
            try:
                dict_talib_output[key] = df[explained_start_date:explained_end_date]
            except:
                raise ValueError(f'{key} : {explained_start_date.strftime("%Y-%m-%d")}以前の日付が存在しません．\nデータの最初の日付は{min(df.index).strftime("%Y-%m-%d")}です')

        return dict_talib_output

    def change_technical_dict(self, dict_talib):
        '''テクニカル指標の辞書を銘柄ごとに集約
        Returns
        -------
        dict_talib_stocks : dict [銘柄数] : {pd.DataFrame=(時点,テクニカル指標数)}
        '''
        dict_talib_stocks = {}
        for stock_i in self.df.columns:
            df_temp = [args[stock_i].rename(key) for key, args in dict_talib.items()]
            dict_talib_stocks[stock_i] = pd.concat(df_temp, axis=1)

        return dict_talib_stocks
        
    def make_technical_return(self):
        '''
            リターン系列のテクニカル指標データの作成
            (talib_returnはconfig.pyにて設定)
        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''                
        dict_talib = {}

        for name_i, args in talib_return.items():
            for key_i, args_i in args.items():
                for j in args_i:
                    if len(args) == 1:
                        key = 'r_' + name_i + str(j)
                    else:
                        key = 'r_' + name_i + '_' + str(key_i) + str(j)
                        
                    dict_talib[key] = self.get_pct_change_log(1).apply(eval('ta.' + name_i), **{key_i:j}).dropna()      
                   
        return dict_talib
    
    def make_technical_close(self):
        '''
            リターン系列のテクニカル指標データの作成
            (talib_closeはconfig.pyにて設定)
        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''                
        dict_talib_close = {}
        
        for name_i, args in talib_close.items():
            for key_i, args_i in args.items():
                for j in args_i:
                    if len(args) == 1:
                        key = 'p_' + name_i + str(j)
                    else:
                        key = 'p_' + name_i + '_' + str(key_i) + str(j)
                        
                    dict_talib_close[key] = self.df.apply(eval('ta.' + name_i), **{key_i:j}).dropna()      
                   
        return dict_talib_close

    @staticmethod    
    def _product(args):
        if 'None' in args:
            result = args.copy()
        else:   
            product = [x for x in itertools.product(*args.values())]
            result = [dict(zip(args.keys(), r)) for r in product]
        
        return result
        
    def make_technical_org(self):
        '''
            talib以外のテクニカル指標
        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''                
        dict_talib_close = {}
                
        for name_i, args in func_close.items():
            procuct_list = self._product(args)          
            dict_temp = {}
            for dict_i in procuct_list:
                if 'None' in dict_i:
                    key = 'p_' + name_i                                    
                else:
                    key = 'p_' + name_i + '_' + '_'.join(map(str, list(dict_i.values())))  

                if 'None' not in dict_i:
                    dict_temp.update(dict_i)
            
            dict_talib_close[key] = self.df.apply(eval(name_i), **dict_temp).dropna()                          
                  
        return dict_talib_close
    