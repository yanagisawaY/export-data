# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.テクニカル指標は本コードにて設定
"""

# =============================================================================
# # テクニカル指標関連の設定
# # talib:https://mrjbq7.github.io/ta-lib/index.html
# 引数の指定がない場合は{'None' : None}として設定
# =============================================================================

# 期間数の引数(timeperiod)の引数はリストで指定
talib_return = {
    # Overlap Studies Functions
    'SMA' : {'timeperiod' : [5, 10, 20, 30]},
    'EMA' : {'timeperiod' : [10, 30, 75]},
     # Momentum Indicator Functions       
    'MOM' : {'timeperiod' : [10, 25]},
    'RSI' : {'timeperiod' : [5, 7, 14, 21]},
    }

talib_close = {
    # Overlap Studies Functions
    'SMA'          : {'timeperiod' : [5, 10, 20, 30]},
    'TRIMA'        : {'timeperiod' : [5, 14, 21]},    
    'EMA'          : {'timeperiod' : [10, 30, 75]},
    
     # Momentum Indicator Functions   
    'RSI'  : {'timeperiod' : [5, 14, 21]},
    'MOM'  : {'timeperiod' : [10, 25]},    
    'ROCP' : {'timeperiod' : [10, 25]}, # (price-prevPrice)/prevPrice
    }

# (参考)ろうそく足：https://non-dimension.com/candle-chart-summary/
talib_OHLCV = {    
    # Momentum Indicator Functions
    'AROONOSC' : {'timeperiod' : [7, 14]}, # Aroon Oscillator
    'ADX'      : {'timeperiod' : [7, 14]}, # Average Directional Movement Index
    'MFI'      : {'timeperiod' : [7, 14]}, # Money Flow Index
    
    # Volatility Indicator Functions 
    'NATR'     : {'timeperiod' : [7, 14]}, # Normalized Average True Range /(ATR) https://hirose-fx.co.jp/category/market/tec/content_tec/30.html
    
    # Pattern Recognition Functions(ローソク足系統)
    'CDLBELTHOLD'  : {'None' : None}, # 寄付坊主(Bullish Belt Hold) or 大引坊主(Bearish Belt Hold) (ローソク足1本パターン)
    'CDLENGULFING' : {'None' : None}, # 強気 or 弱気の抱き線(包み線) (ローソク足2本パターン)
    'CDL3OUTSIDE'  : {'None' : None}, # 包み上げ or 包み下げ(ローソク足3本パターン)
    # 'CDLBREAKAWAY' : {'None' : None}, # CDLBREAKAWAY – Breakaway(ローソク足4本以上パターン)⇒値がすべて0だった(原因不明)ためいったんコメントアウト

    # Volume Indicator Functions
    'ADOSC' : {'fastperiod' : [3], 'slowperiod' : [10, 15]}, # Chaikin A/D Oscillator
    }

# open, high, low, close, volumeの使用データタイプの指定
# 2:high, low
# 3:high, low, close
# 4:high, low, close, volume
# 5:open, high, low, close
OHLCV_type = {
    'AROONOSC'     : 2,
    'ADX'          : 3,
    'MFI'          : 4,
    'NATR'         : 3,        
    'CDLBELTHOLD'  : 5,
    'CDLENGULFING' : 5,
    'CDL3OUTSIDE'  : 5,
    # 'CDLBREAKAWAY' : 5,
    'ADOSC'        : 4,        
    }

