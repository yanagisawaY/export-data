# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.予測タスクの実行⇒結果出力に関わるコード
"""
import time
import pickle
import pandas as pd
import datetime as dt
import openpyxl
import os

from models.double_ensemble import DoubleEnsemble
from utils.loader import DataLoader
from utils.portfolio_builder import PortfolioBuilder


class ResultMaker(DataLoader):
    def __init__(self, df_dict, hyperparms_model, dataset_dict):
        '''
        Parameters
        ----------
        df_dict : dict
            銘柄情報(OHLCV). 高値安値等の銘柄情報 : 次元数=(時点,銘柄)
        hyperparms_model : dict
            モデルのハイパーパラメータ.
        dataset_dict : dict
            訓練期間，テスト期間の設定値.
        '''
        super().__init__(df_dict, hyperparms_model)
        self.df_dict = df_dict
        self.hyperparms_model = hyperparms_model
        self.dataset_dict = dataset_dict
        self.train_start_date, self.train_end_date, self.test_start_date, self.test_end_date = self.dataset_dict.values()
                
    def get_result_one(self, stock_i):
        '''
            1銘柄を対象に予測タスクを実行
    
        Parameters
        ----------
        stock_i : str
            銘柄のTicker.
    
        Returns
        -------
        y_test : list
            リターンの正解値.
        y_test_pred : list
            予測リターン.
        y_port_test : list
            実際の観測リターン
        df_info : list
            モデル関連の情報.
        '''
        start_time = time.time()    
        print(f'予測対象...{stock_i}')
    
        # データ作成    
        X_train, y_train, y_port_train = self.make_dataset(self.train_start_date, self.train_end_date, stock_i, is_test=False)
        X_test, y_test, y_port_test = self.make_dataset(self.test_start_date, self.test_end_date, stock_i, is_test=True)
                
        # 学習       
        tc = DoubleEnsemble(self.hyperparms_model)        
        tc.fit(X_train, y_train)
        y_test_pred = []
        for X_test_ in X_test:
            y_test_pred.append(tc.predict(X_test_))
        
        calc_time = round(time.time() - start_time)
        print(f'{stock_i} - {calc_time}sec')
        
        col_names = ['予測対象', '訓練開始', '訓練終了', 'テスト開始', 'テスト終了', '計算時間(sec)'] + list(self.hyperparms_model.keys())
        df_info = pd.DataFrame([[stock_i, self.train_start_date, self.train_end_date, self.test_start_date, self.test_end_date,
                                 calc_time]+list(self.hyperparms_model.values())], columns=col_names)
        
        return y_test, y_test_pred, y_port_test, df_info

    def make_model_pred(self, stock_list):
        '''
            全銘柄の予測値を算出
    
        Parameters
        ----------
        stock_list : list
            予測を実施する銘柄.（df_pctの列名に存在するものを指定）
    
        Returns
        -------
        df_y_pred : pd.DataFrame
            予測リターンの行列.
        df_y_true : pd.DataFrame
            リターンの正解値の行列.
        df_y_port_test : pd.DataFrame
            バックテストにおける観測リターンデータ.            
        df_info_all : pd.DataFrame
            モデル関連の情報を格納したデータフレーム.
        '''
        # 全銘柄の予測値算出
        df_info_all = pd.DataFrame()
        df_y_true = [pd.DataFrame() for _ in range(self.hyperparms_model['rebalance_term'])]
        df_y_pred = [pd.DataFrame() for _ in range(self.hyperparms_model['rebalance_term'])]
        df_y_port_test = [pd.DataFrame() for _ in range(self.hyperparms_model['rebalance_term'])]
        
        for stock_i in stock_list:
            # 予測値の算出    
            y_test, y_test_pred, y_port_test, df_info = self.get_result_one(stock_i)
            
            # 結果の統合
            for i, df_y_true_ in enumerate(df_y_true):
                df_y_true[i] = pd.concat([df_y_true_, y_test[i]], axis=1)                
            for i, df_y_pred_ in enumerate(df_y_pred):
                df_y_pred[i] = pd.concat([df_y_pred_, pd.DataFrame(y_test_pred[i], index=y_test[i].index, columns=[stock_i])], axis=1)
            for i, df_y_port_test_ in enumerate(df_y_port_test):
                df_y_port_test[i] = pd.concat([df_y_port_test_, y_port_test[i]], axis=1)
            df_info_all = pd.concat([df_info_all, df_info], axis=0)
        
        # 予測結果の書き出し
        df_info_all = df_info_all.reset_index(drop=True)
       
        return df_y_pred, df_y_true, df_y_port_test, df_info_all
    

def get_dateset_dict(era, year_term_train, year_term_test):
    '''
        訓練期間とテスト期間の日付設定

    Parameters
    ----------
    era : int
        訓練開始時の年
    year_term_train : int
        訓練期間の年数
    year_term_test : int
        テスト期間の年数

    Returns
    -------
    dataset_dict : dict
        訓練期間とテスト期間の日付が格納された辞書.
    '''
    dataset_dict = {
    'train_start_date' : dt.datetime(era, 1, 1),
    'train_end_date'   : dt.datetime(era+year_term_train, 12, 31),
    'test_start_date'  : dt.datetime(era+year_term_train+1, 1, 1),
    'test_end_date'    : dt.datetime(era+year_term_train+year_term_test, 12, 31),
    }
    
    return dataset_dict


def get_portfolio_result(df_y_pred, df_y_true, hyperparms_portfolio, output_name, rebalance_term):
    '''
        ポートフォリオ構築結果を出力

    Parameters
    ----------
    df_y_pred : pd.DataFrame
        リターンの予測値.
    df_y_true : pd.DataFrame
        リターンの正解値.
    hyperparms_portfolio : dict
        ポートフォリオのパラメータ.
    output_name : str
        resultの列名.
    rebalance_term : int
        リバランスの頻度

    Returns
    -------
    index_portfolio : pd.DataFrame
        ポートフォリオのインデックス推移.
    index_quantile_port : pd.DataFrame
        クオンタイルポートフォリオのインデックス推移.
    result : pd.DataFrame
        ポートフォリオのパフォーマンス結果.
    '''
    # ポートフォリオ構築
    index_portfolio, index_quantile_port, result = {}, {}, pd.DataFrame()

    for i, [df_y_pred_, df_y_true_] in enumerate(zip(df_y_pred, df_y_true)):
        pb = PortfolioBuilder(df_y_pred_, hyperparms_portfolio)
        weight = pb.calc_weight()
        return_portfolio = pb.calc_portfolio_return(weight, df_y_true_)
        index_portfolio[output_name+'_'+str(i)] = pb.calc_wealth(return_portfolio)        
        index_quantile_port[output_name+'_'+str(i)] = pb.make_quantile_portfolio(df_y_true_)
        result = pd.concat([result, pb.make_peformance_result(df_y_true_, output_name+'_'+str(i), rebalance_term)], axis=1)
        
    print(result)    
        
    return index_portfolio, index_quantile_port, result


def output_result(output_all, path_output, file_name):
    '''バックテストパターンごとに結果をフォルダに出力
    Parameters
    ----------
    outtput_all : dict
        訓練・テスト等の結果を集約した辞書.
    path_output : str
        ファイルの出力フォルダ.
    file_name : str
        出力するエクセルファイルの名前
    '''               
    # フォルダ作成
    os.makedirs(path_output, exist_ok=True)
    os.makedirs(path_output+'\\return', exist_ok=True)
    
    def pickle_dump(obj, path):
        with open(path, mode='wb') as f:
            pickle.dump(obj, f)    
            
    pattern_names = []
    result_all = []    
    df_info_all = []        
    result_all_era = []    
    idx_port = {}
    
    for pattern, output_pattern in output_all.items():pass
    for i in range(len(output_pattern['idx_port'])):
        idx_port['pattern_'+str(i)] = pd.DataFrame()
        
    for pattern, output_pattern in output_all.items():
        pattern_names += pattern
        result_all.append(output_pattern['result_all'])
        df_info_all.append(output_pattern['df_info_all'])
        for i, [name, idx_port_] in enumerate(output_pattern['idx_port'].items()):
            idx_port['pattern_'+str(i)] = pd.concat([idx_port['pattern_'+str(i)], pd.DataFrame(idx_port_, columns=[name])], axis=1)
        
        try:
            # eraがないパターン
            for name_, output_all_era in output_pattern['era'].items():                       
                for era, output_era in output_all_era.items():
                    if name_ == 'result_dict':
                        output_era['pattern'] = pattern
                        result_all_era.append(output_era)                       
        except:
            pass

    df_info_all = pd.concat(df_info_all, axis=0)
    result_all = pd.concat(result_all, axis=1)        
    
    # 学習結果の書き出し
    wb = openpyxl.Workbook()
    wb.save(path_output+'\\All_info_'+file_name+'.xlsx')
    with pd.ExcelWriter(path_output+'\\All_info_'+file_name+'.xlsx') as writer:    
        result_all.to_excel(writer, sheet_name='result_all')
        for name, idx_port_ in idx_port.items():
            idx_port_.to_excel(writer, sheet_name=name)
        
        try:
            # eraがないパターン            
            result_all_era = pd.concat(result_all_era, axis=1)                
            result_all_era.to_excel(writer, sheet_name='result_all_era')            
        except:
            pass        

        if df_info_all.shape[0] < 20000:
            # データ容量の都合で保存方法を場合分け
            df_info_all.to_excel(writer, sheet_name='info_all')
        else:
            file_name_output = path_output + '\\df_info_'+file_name+'.pickle'    
            pickle_dump(df_info_all, file_name_output)

        for pattern, output_pattern in output_all.items():
            for sheet_name, output in output_pattern.items():
               if sheet_name == 'df_info_all' or sheet_name == 'era' \
                   or sheet_name == 'result_all' or sheet_name == 'idx_port':
                   continue # 書き出し済み
               elif sheet_name == 'df_y_pred_all':
                   for i, output_ in enumerate(output):
                       file_name_output = path_output + '\\return\\r_'+file_name+'_'+pattern+'_'+str(i)+'.pickle'
                       pickle_dump(output_, file_name_output)
               elif sheet_name == 'idx_quantile_port':
                   for name, output_ in output.items():
                       output_.to_excel(writer, sheet_name=name)                
               else:
                   # エクセルシート名の制限文字数を考慮
                   output.to_excel(writer, sheet_name=(sheet_name+'_'+pattern)[:31])

    
def get_result(start_year, end_year, year_term_train, year_term_test, is_get_dict, 
               df_dict, hyperparms_model, hyperparms_portfolio, stock_list, pattern_name):
    '''モデル学習・バックテストの実施
    Parameters
    ----------    
    all_setting : dict
        start_year                : 訓練開始年
        end_year                  : 訓練終了年
        year_term_train           : 訓練データ年数
        year_term_test            : テストデータ年数
        is_get_dict               : テストデータ分割方法の指定
                                    True  : year_term_trainごとのスライド方式
                                    False : 論文と同じ訓練/テスト期間(2000-2010が訓練) 
        df_dict                   : 株価データ（dict形式 : OHLCVデータ）
        hyperparms_model          : モデル構築のパラメータ
        hyperparms_portfolio      : ポートフォリオ構築のパラメータ
        stock_list                : 分析対象銘柄のTicker
    Returns
    -------
        output_pattern : dict ⇒ 学習・バックテストの結果        
    '''    
    df_y_pred_dict, df_y_true_dict = {}, {}    
    index_portfolio_split, index_quantile_port_split, result_all_split = {}, {}, {}
    
    for split_id in range(hyperparms_model['rebalance_term']):
        df_y_pred_dict[split_id], df_y_true_dict[split_id]= pd.DataFrame(), pd.DataFrame()
        index_portfolio_split[split_id], index_quantile_port_split[split_id], result_all_split[split_id] = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
            
    df_info_all = pd.DataFrame()
    index_portfolio_dict, index_quantile_port_dict, result_dict = {}, {}, {}

    # 訓練・テスト期間の設定
    if is_get_dict:    
        era_list = list(range(start_year, end_year, year_term_test))
    else:
        era_list = ['2001-2010']
        
    df_y_pred_all = [pd.DataFrame() for _ in range(hyperparms_model['rebalance_term'])]
    df_y_port_all = [pd.DataFrame() for _ in range(hyperparms_model['rebalance_term'])]
    for era in era_list:
        print(era)
        
        if is_get_dict:
            output_name_era = str(era) + '_' + str(era+year_term_train-1)
            dataset_dict = get_dateset_dict(era, year_term_train, year_term_test)
        else:
            output_name_era = str(era)
            dataset_dict = {
                'train_start_date' : dt.datetime(2011, 1, 1),
                'train_end_date'   : dt.datetime(2016, 12, 31),
                'test_start_date'  : dt.datetime(2017, 1, 1),
                'test_end_date'    : dt.datetime(2020, 2, 8),
                }
        
        rm = ResultMaker(df_dict, hyperparms_model, dataset_dict)
          
        df_y_pred, df_y_true, df_y_port, df_info = rm.make_model_pred(stock_list)
        
        for i, df_y_pred_all_ in enumerate(df_y_pred_all):
            df_y_pred_all[i] = pd.concat([df_y_pred_all_, df_y_pred[i]], axis=0)
        for i, df_y_port_all_ in enumerate(df_y_port_all):
            df_y_port_all[i] = pd.concat([df_y_port_all_, df_y_port[i]], axis=0)

        df_info_all   = pd.concat([df_info_all, df_info], axis=0)
        
        if len(era_list) > 1:
            index_portfolio_dict[output_name_era], index_quantile_port_dict[output_name_era], result_dict[output_name_era] = \
                get_portfolio_result(df_y_pred, df_y_port, hyperparms_portfolio, output_name_era, hyperparms_model['rebalance_term'])

    index_portfolio, index_quantile_port, result_all = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    
    index_portfolio, index_quantile_port, result_all = \
        get_portfolio_result(df_y_pred_all, df_y_port_all, hyperparms_portfolio, pattern_name, hyperparms_model['rebalance_term'])
        
    output_pattern = {
        'idx_port'          : index_portfolio,
        'idx_quantile_port' : index_quantile_port,
        'result_all'        : result_all,
        'df_y_pred_all'     : df_y_pred_all,
        'df_info_all'       : df_info_all,
        }
    
    if len(era_list) > 1:
        dict_temp = {
            'era' : {
                'index_ports'    : index_portfolio_dict,
                'quantile_ports' : index_quantile_port_dict,
                'result_all'     : result_all,
                }
            }
        output_pattern.update(dict_temp)    
            
    return output_pattern