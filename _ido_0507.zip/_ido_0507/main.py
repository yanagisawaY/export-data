# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.None

"""
import openpyxl
import pandas as pd
import datetime as dt
import os
import pickle

# パスの設定
PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\double_ensemble'
os.chdir(PATH_HEAD)
from get_result import get_result, output_result
import matplotlib.pyplot as plt

#%%
# 事前に設定する項目    
hyperparms_model = {
    'lookback_window_max'  : 10,
     # データセットに関わるパラメータ
    'rebalance_term'       : 5,
    'lag'                  : 1,               
    
    'random_seed'          : 7777,  
    'data_type'            : 'Rt', # 'Tech', 'RtTech'
    'model_type'           : 'SR_FS',
    'num_submodels'        : 6,
    'submodel'             : 'lightgbm',
    'hyperparms_submodels' : 
        {'n_estimators'   : 200,
         'num_leaves'     : 32,
         'verbose'        : -1,},
    'SR_params' : 
        {'alpha1'      : 1,
         'alpha2'      : 1,
         'bins_B'      : 10,
         'decay_gamma' : 0.99,
         'C_ratio'     : 0.1,},        
    'FS_params' : 
        {'sample_ratio' : [0.8, 0.7, 0.6, 0.5, 0.4]} # D=5bins
    }

    
'''
hyperparms_model : ハイパーパラメータ
    'data_type'               : 説明変数データのパターン
        'Rt'                      : 銘柄リターン 
        'Tech'                    : テクニカル指標のみ
        'RtTech'                  : 銘柄リターン + テクニカル指標                        
    'model_type'              : 実行するモデルのタイプ(論文参照)
        'SR_FS'                   : サンプル重みづけ + 説明変数選択
        'single'                  : アンサンブルのないシンプルなモデル
        'simple'                  : 乱数シードのみを変更したアンサンブル
        'random'                  : 0.75~1.25の一様乱数によりサンプルの重みづけを実施したアンサンブル
        'SR'                      : SR（サンプル重みづけ）のみ．FS（説明変数シャッフル）を実施しない
        'SR_only1'                : SR（サンプル重みづけ）のみ，かつ第1項目のみ考慮．FS（説明変数シャッフル）を実施しない
        'SR_only2'                : SR（サンプル重みづけ）のみ，かつ第2項目のみ考慮．FS（説明変数シャッフル）を実施しない        
        'FS'                      : FS（説明変数シャッフル）のみ．SR（サンプル重みづけ）を実施しない．        
    'num_submodels'           : アンサンブルするサブモデルの数
    'submodel'                : 使用するサブモデル
    'hyperparms_submodels'    :　サブモデルのハイパーパラメータ（各サブモデルのハイパラは固定） 
        'n_estimators'            : 決定木の数
        'num_leaves'              : 木にある分岐の個数(大きくすると精度は上がるが過学習が進む)
    'SR_params' 　　　　　　　　　　　: Algorithm 2 SRのパラメータ　Learning trajectory based sample reweighting
        'alpha1'                  : boosts the weights of hard samples (but also those of noisy samples)
        'alpha2'                  : suppresses the weights of noisy  samples 
        'bins_B'                  : divide  all  the  samplesintoBbins  according  to  the h-value
        'decay_gamma'             : γ∈[0,1] to encourage the weight distribution to be more uniform in the latter sub-models of the ensemble
        'C_ratio'                 : h2項のCstart,Cendに使用するサンプルの割合
    'FS_params'               : Algorithm3 FSのパラメータ: shuffling based feature selection
        'sample_ratio'            : sampling ratio for each bin
'''

hyperparms_portfolio = {
    'split_num'              : 10,
    'portfolio_type'         : 'Simple',
    'turnover_stock_uplimit' : 4,
    'cost_buy'               : 0,
    'cost_sell'              : 0,
    'calc_type'              : 'cumulative',    
    'wealth_init'            : 100,    
    }

'''
hyperparms_portfolio : dict
    split_num              : 分位数.
    portfolio_type         : ポートフォリオの構築方法の選択
        LongShort              : 最上位の分位群をロング，最下位の分位群をショート
        Long                   : 最上位の分位群のロング
        Long_const             : 組み入れ銘柄数制限付き，最上位の分位群のロング
        Simple                 : 予測リターンが正のものをロング，負のものをショート
    turnover_stock_uplimit : 組み入れ変更銘柄数の上限
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
'''

#%%
# データセットの入力
with open(PATH_HEAD+'\\data\\sp500.pickle', 'rb') as f:
    df_dict_org = pickle.load(f) 

# yahooファイナンスデータゆえの特殊対応
df_dict = {}
for name, df_ in df_dict_org.items():
    df_.index = pd.to_datetime(df_.index)
    df_dict[name] = df_.iloc[[i!=0 for i in df_.count(1)],:].dropna(axis=1)
    del df_

del df_dict_org
    
# 訓練，テスト期間の設定
all_setting = {
    'start_year'                : 2015, # is_get_dictでTrueとした場合の訓練データの開始期間（）
    'end_year'                  : 2018,
    'year_term_train'           : 2,
    'year_term_test'            : 1,
    'is_get_dict'               : True,
    'df_dict'                   : df_dict,
    'hyperparms_model'          : hyperparms_model,
    'hyperparms_portfolio'      : hyperparms_portfolio,
    'stock_list'                : df_dict['Adj Close'].columns,
    }

'''
all_setting : dict
    start_year                : 訓練開始年
    end_year                  : 訓練終了年
    year_term_train           : 訓練データ年数
    year_term_test            : テストデータ年数
    is_get_dict               : テストデータ分割方法の指定
                                True  : year_term_trainごとのスライド方式
                                False : 論文と同じ訓練/テスト期間(2000-2010が訓練期間) 
    df_dict                   : 株価データ（dict形式 : OHLCVデータ）
    hyperparms_model          : Trader-Company法のパラメータ
    hyperparms_portfolio      : ポートフォリオ構築のパラメータ
    stock_list                : 分析対象銘柄のTicker
'''

#%%
model_types = [
    'SR_FS',
    'single',
#    'simple',
#    'random',
#    'SR',
#    'SR_only1',
#    'SR_only2',
#    'FS',
    ]

data_types = ['Tech'] # , 'Tech'
seeds = [1]
# 実行
output_all = {}
time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
    
# パターン数大きくしすぎるとメモリが限界に達する可能性があるため，適度にoutput_resultで出力
for seed_ in seeds:
    for data_type_ in data_types:
        for model_type_ in model_types:
            hyperparms_model['random_seed'] = seed_
            hyperparms_model['data_type'] = data_type_
            hyperparms_model['model_type'] = model_type_
            pattern_name = data_type_ + str(seed_) + '_' + model_type_
            print(f'pattern_name = {pattern_name}')
            all_setting['pattern_name'] = pattern_name
            all_setting['hyperparms_model'] = hyperparms_model
            output_all[pattern_name] = get_result(**all_setting)
    
        # 結果の出力
        path_output = PATH_HEAD + '\\Result\\' + time_now
        output_result(output_all, path_output, file_name=data_type_+str(seed_))

path_output = PATH_HEAD + '\\Result\\' + time_now
output_result(output_all, path_output, file_name='all')
