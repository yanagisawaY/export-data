# -*- coding: utf-8 -*-
"""
予測リターンをもとにポートフォリオの構築を実施
"""
import pandas as pd
import numpy as np
import pulp
from datetime import timedelta
from utils.evaluator import Evaluator

class PortfolioBuilder(Evaluator):
    def __init__(self, df_return, hyperparms_portfolio):
        '''
        df_return : pandas.DataFrame
            各投資対象銘柄の予測リターン.
        hyperparms_portfolio : dict
            split_num              : 分位数.
            portfolio_type         : ポートフォリオの構築方法の選択(LongShort or Long, Long_const)
            turnover_stock_uplimit : 組み入れ変更銘柄数の上限
            wealth_init            : 初期富
            cost_buy               : 銘柄購入時のコスト
            cost_sell              : 銘柄売却時のコスト
            calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
        '''
        self.df_return = df_return
        self.split_num = hyperparms_portfolio['split_num']
        if df_return.shape[1] < self.split_num:
            self.split_num = df_return.shape[1]
        self.portfolio_type = hyperparms_portfolio['portfolio_type']        
        self.turnover_stock_uplimit = hyperparms_portfolio['turnover_stock_uplimit']   
        self.cost_buy = hyperparms_portfolio['cost_buy']
        self.cost_sell = hyperparms_portfolio['cost_sell']             
        self.calc_type = hyperparms_portfolio['calc_type']        
        self.wealth_init = hyperparms_portfolio['wealth_init']        
        
    def make_rankdataset(self):
        '''
            リターンをsplit_num分位で分割し，ランク付けしたデータフレームを返す関数
    
        Parameters
        ----------
        split_num : TYPE
            分位数.
        Returns
        -------
        df_return_rank : TYPE
            リターンをsplit_num分位で分割してランク付けしたデータフレーム(重複がある場合はsplit_num分位とならず，自動調整される)
        '''
        df_return_rank = pd.DataFrame(index=self.df_return.index, columns=self.df_return.columns)        
        for x in self.df_return.index:
            df_return_rank.loc[x,:] = pd.qcut(-self.df_return.loc[x,:], self.split_num, labels=False, duplicates='drop')+1
    
        return df_return_rank
            
    def calc_weight(self, weight_0=[]):
        '''
            ポートフォリオのウェイトを作成する

        Parameters
        ----------
        weight_0 : 
            初期時点のポートフォリオのウェイト

        Returns
        -------
        weight : TYPE
            ポートフォリオのウェイト.
        '''
        df_return_rank = self.make_rankdataset()        
        
        if self.portfolio_type == 'LongShort':
            weight = (df_return_rank == 1)*(1/(df_return_rank == 1).sum(axis=1).mean()) +\
        (df_return_rank == self.split_num)*(-1/(df_return_rank == self.split_num).sum(axis=1).mean())
        elif self.portfolio_type == 'Long':
            weight = (df_return_rank == 1)*(1/(df_return_rank == 1).sum(axis=1).mean())
        elif self.portfolio_type == 'Simple':
            weight = ((self.df_return>=0)*1).apply(lambda x: x/sum(x), axis=1).fillna(0) + ((self.df_return<0)*-1).apply(lambda x: -x/sum(x), axis=1).fillna(0)
        elif self.portfolio_type == 'Long_const':
            weight = pd.DataFrame(columns=df_return_rank.columns, index=df_return_rank.index)
            if len(weight_0) == 0:
                weight = (df_return_rank == 1)*(1/(df_return_rank == 1).sum(axis=1).mean())                
            else:
                weight.iloc[0,:] = weight_0
            
            for i in range(1, weight.shape[0]):
                weight_0 = weight.iloc[i-1,:].copy()
                weight.iloc[i,:], status, stock_change_num = self.opt_weight_turnoverconst(weight_0.values, self.df_return.iloc[i,:].values)
                if status != 'Optimal':
                    print(f'{i} Status {status} : 組み入れ変更銘柄数 {stock_change_num}')
                if i % 50 == 0:
                    print(f'{i} Status {status} : 組み入れ変更銘柄数 {stock_change_num}')
                    
            weight.iloc[0,:] = weight.iloc[0,:] / sum(weight.iloc[0,:])
            
        return weight
        
    def opt_weight_turnoverconst(self, weight_0, rt):
        '''
            組み入れ変更銘柄数の制約の下でリターンが最大となる等ウェイトポートフォリオを計算
            （ただしweight_0は等ウェイトポートフォリオのインプットであると想定，かつその投資銘柄の合計は変更しない）
    
        Parameters
        ----------
        weight_0 : numpy.array
            初期時点のウェイト.
        rt : numpy.array
            各銘柄の予測リターン.
    
        Returns
        -------
        weight : numpy.array
            組み入れ変更銘柄数の制約の下でリターンが最大となる等ウェイトポートフォリオ.
        '''
        weight_0[weight_0>0] = 1
        stock_num = sum(weight_0)
    
        stock_universe_num = len(rt)
        problem = pulp.LpProblem('PortfolioOpt', pulp.LpMaximize)
        xb = [pulp.LpVariable(name='xb_{}'.format(i), cat='Binary') for i in range(stock_universe_num)]
        xs = [pulp.LpVariable(name='xs_{}'.format(i), cat='Binary') for i in range(stock_universe_num)]
            
        # 目的関数
        problem += pulp.lpSum([rt[i] * (xb[i] - xs[i]) for i in range(stock_universe_num)]), "Objective"
        # 組み入れ変更銘柄数の制約
        problem += pulp.lpSum([xb[i] + xs[i] for i in range(stock_universe_num)]) <=  self.turnover_stock_uplimit
        
        # 銘柄数の等式制約
        problem += pulp.lpSum([weight_0[i] + xb[i] - xs[i] for i in range(stock_universe_num)]) == stock_num
        
        for i in range(stock_universe_num):
            # 空売り禁止制約
            problem += weight_0[i] + xb[i] - xs[i] >= 0
            problem += weight_0[i] + xb[i] - xs[i] <= 1    
        
        status = problem.solve()
        weight = [weight_0[i] + pulp.value(xb[i]) - pulp.value(xs[i]) for i in range(stock_universe_num)]
        dif_weight = [pulp.value(xb[i]) - pulp.value(xs[i]) for i in range(stock_universe_num)]

        status = pulp.LpStatus[status]
        stock_change_num = sum(abs(np.array(dif_weight)))    
        weight = weight / sum(weight)
        
        return weight, status, stock_change_num

    def make_quantile_portfolio(self, df_return_true, is_no_cost=True):
        '''
            分位ポートフォリオのインデックスを作成する

        Parameters
        ----------
        df_return_true : TYPE
            各銘柄のリターン行列.(時点,銘柄)            
        is_no_cost : 取引コストを考慮しない場合はTrue
        Returns
        -------
        index_quantile_port : TYPE
            分位ポートフォリオのインデックス.
        '''            
        df_return_rank = self.make_rankdataset()  
        index_quantile_port = pd.DataFrame(index=df_return_rank.index, columns=['Top'+str(i) for i in range(1, self.split_num+1)])        
        
        for i in range(1, self.split_num+1):
            weight = (df_return_rank == i)*(1/(df_return_rank == i).sum(axis=1).mean())
            return_portfolio = self.calc_portfolio_return(weight, df_return_true, is_no_cost)
            index_quantile_port.iloc[:,(i-1)] = self.calc_wealth(return_portfolio)[1:]

        index_quantile_port = pd.concat([pd.DataFrame([self.wealth_init for _ in range(self.split_num)],
                                                      index=['Top'+str(i) for i in range(1, self.split_num+1)]),
                                                      index_quantile_port.T], axis=1).T
        index_quantile_port = index_quantile_port.rename(index = {0:pd.to_datetime(index_quantile_port.index[1]) - timedelta(days=1)})
        index_quantile_port.index = pd.to_datetime(index_quantile_port.index, format='%Y/%m/%d')
                                                   
        return index_quantile_port
                
    def calc_portfolio_return(self, weight, df_return_true, is_no_cost=False):
        '''
            ポートフォリオのリターンを計算する

        Parameters
        ----------
        weight : pd.DataFrame
            ポートフォリオのウェイト行列.(時点,銘柄)
        df_return_true : pd.DataFrame
            各銘柄のリターン行列.(時点,銘柄)
        is_no_cost : 取引コストを考慮しない場合はTrue
        
        Returns
        -------
        return_portfolio
            ポートフォリオのリターン.
        '''
        if is_no_cost:
            cost_buy, cost_sell = 0, 0            
        else:
            cost_buy, cost_sell = self.cost_buy, self.cost_sell

        weight_diff = self.calc_weight_diff(weight, df_return_true)
            
        cost_matrix = np.abs(weight_diff[weight_diff>0].fillna(0)) * cost_buy + np.abs(weight_diff[weight_diff<0].fillna(0)) * cost_sell
        cost_index  = cost_matrix.sum(axis=1)
        if self.calc_type == 'accumulation':        
            return_portfolio = (1 + (weight * df_return_true).sum(axis=1))*(1 - cost_index) - 1
        elif self.calc_type == 'cumulative':            
            return_portfolio = (weight * df_return_true).sum(axis=1) - cost_index
                    
        return return_portfolio

    def calc_weight_diff(self, weight, df_return_true):
        '''ポートフォリオの組替え時のウェイト変化を，リターンの実現時点を加味して算出
        '''               
        wealth = 1
        weight_diff = weight.diff().fillna(0).copy()
        for t in range(1, weight.shape[0]):
            weight_t_1 = weight.iloc[t-1,:].copy()
            return_t = df_return_true.iloc[t-1,:].copy()
            wealth_t_1_end = wealth*weight_t_1*(1+weight_t_1*return_t)
            plus_weight_sum = sum(wealth_t_1_end[wealth_t_1_end>=0])
            minus_weight_sum = abs(sum(wealth_t_1_end[wealth_t_1_end<0]))
            weight_t_1_end = wealth_t_1_end.apply(lambda x: x/plus_weight_sum if x >= 0 else x/minus_weight_sum)
            weight_t = weight.iloc[t,:].copy()
            weight_diff.iloc[t,:] = weight_t - weight_t_1_end
            
        return weight_diff
            
    def calc_turnover(self, weight, df_return_true):
        '''
            ポートフォリオのターンオーバーを計算する(初期時点は除く)

        Parameters
        ----------
        weight : pandas.DataFrame
            ポートフォリオのウェイト推移.（時点×銘柄）
        df_return_true : pd.DataFrame
            各銘柄のリターン行列.(時点,銘柄)
            
        Returns
        -------
        turnover : 
            ターンオーバー
        '''
        weight_diff = self.calc_weight_diff(weight, df_return_true)
        turnover = np.sum(np.sum(np.abs(weight_diff), 1))/(weight.shape[0] - 1)
        
        return turnover
        
    def calc_wealth(self, return_portfolio, wealth=0):        
        '''
            ポートフォリオの累積(累和)リターンを計算する関数

        Parameters
        ----------
        return_portfolio : TYPE
            ポートフォリオのリターン.
        wealth : 
            初期富

        Returns
        -------
        index_portfolio : pandas.DataFrame
            ポートフォリオの累積(累和)リターン
        '''
        index_portfolio = []
        if wealth == 0:
            wealth0 = self.wealth_init
            wealth = self.wealth_init
        else:
            wealth0 = wealth
            
        if self.calc_type == 'accumulation':
            for i in return_portfolio:    
                wealth = wealth * (1+i)
                index_portfolio.append(wealth)
        elif self.calc_type == 'cumulative':
            for i in return_portfolio:
                wealth += wealth0 * i
                index_portfolio.append(wealth)
            
        index_portfolio = pd.Series(index_portfolio, index=return_portfolio.index)      
        index_portfolio = pd.concat([pd.Series([wealth0]), index_portfolio])
        index_portfolio = index_portfolio.rename(index = {0:pd.to_datetime(index_portfolio.index[1]) - timedelta(days=1)})
        
        return index_portfolio
    
    def make_peformance_result(self, df_return_true, output_name='result'):
        '''
            パフォーマンス結果を出力

        Parameters
        ----------
        df_return_true : pd.DataFrame
            リターンの正解値.
        output_name : str
            出力するデータフレームの名前ラベル.

        Returns
        -------
        None.

        '''
        super().__init__(self.df_return, df_return_true)
        weight = self.calc_weight()
        return_portfolio = self.calc_portfolio_return(weight, df_return_true)
        index_portfolio = self.calc_wealth(return_portfolio, wealth=1)
        turnover = self.calc_turnover(weight, df_return_true)        
        output_result = self.calc_performance(return_portfolio, output_name)
        output_result['turnover'] = turnover
        output_result['MDD'] = self.calc_mdd(index_portfolio)
        _, output_result['的中率'] = self.calc_hit_rate()
        output_result['MSE'] = self.calc_mse()        
        
        return output_result
        
        