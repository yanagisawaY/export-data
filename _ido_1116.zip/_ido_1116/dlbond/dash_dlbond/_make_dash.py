import pandas as pd
import os

PATH_HEAD = r'C:\Users\yana\Desktop\yoshiki_study\double_ensemble'
os.chdir(PATH_HEAD)
from utils.portfolio_builder import PortfolioBuilder

# データインプット

# 実績ベース株価等データ
df_input = pd.read_pickle(PATH_HEAD+'\\data\\sp500.pickle')
df_dict = {}
for name, df_ in df_input.items():
    df_.index = pd.to_datetime(df_.index)
    df_dict[name] = df_.iloc[[i!=0 for i in df_.count(1)],:].dropna(axis=1)
    del df_

del df_input

rebalance_term = 5


# 正解リターン
adj_index = df_dict['Adj Close']/df_dict['Close']
df_true_all = (adj_index*df_dict['Open']).shift(-1).pct_change(rebalance_term).dropna(axis=0)


PATH_DATA = PATH_HEAD+'/Result/210423_230251/return'
files = os.listdir(PATH_DATA)
colnames = ['single', 'SR_FS']

# 設定
hyperparms_portfolio = {
    'split_num'              : 10,
    'portfolio_type'         : 'Long',
    'calc_type'              : 'cumulative',        
    'turnover_stock_uplimit' : 4,
    'cost_buy'               : 0,
    'cost_sell'              : 0,
    'wealth_init'            : 100,    
    }

hyperparms_portfolio_name = {
    'split_num'              : '分位数',
    'portfolio_type'         : 'ポートフォリオの構築方法の選択',
    'calc_type'              : 'リターン集計方法',        
    'turnover_stock_uplimit' : '組み入れ銘柄数制限',
    'cost_buy'               : '購入時のコスト',
    'cost_sell'              : '売却時のコスト',
    'wealth_init'            : '初期富',    
    }
    
def get_backtest_result(file, hyperparms_portfolio):
    # 予測リターン
    df_pred = pd.read_pickle(PATH_DATA+'/'+file)    
    df_true = df_true_all.loc[df_pred.index]
    output_name = file

    # バックテストの実施
    pb = PortfolioBuilder(df_pred, hyperparms_portfolio)
    weight = pb.calc_weight()
    return_portfolio = pb.calc_portfolio_return(weight, df_true)
    index_portfolio = pb.calc_wealth(return_portfolio)
    result = pb.make_peformance_result(df_true, output_name, rebalance_term)
    
    return result, index_portfolio

def get_quantile_result(file, hyperparms_portfolio):
    # 予測リターン
    df_pred = pd.read_pickle(PATH_DATA+'/'+file)    
    df_true = df_true_all.loc[df_pred.index]

    # バックテストの実施
    pb = PortfolioBuilder(df_pred, hyperparms_portfolio)
    index_quantile_port = pb.make_quantile_portfolio(df_true)
    
    return index_quantile_port

#%%
import dash
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_table
# import plotly.express as px
import plotly
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# app.py
external_stylesheets = ["https://codepen.io/chriddyp/pen/bWLwgP.css"]
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.config.suppress_callback_exceptions = True

tab_selected_style = {
    "backgroundColor": "limegreen",
    "color": "white",
    "fontWeight": "bold",
}


# layout.py
app.layout = html.Div(
    [
    # コールバックの返り値を表示する
    html.H1('Backtest Tool ver1.0'),     
    dcc.Tabs(
        id='tabs',
        value='one',
        children=[
            
            # パフォーマンス指標を表示するタブ
            dcc.Tab(
                label='パフォーマンス指標',
                value='one',
                selected_style=tab_selected_style,
                children=[
                    html.Div([
                        
                        # バックテストの設定
                        html.Div([
                            html.Label([ 
                            '予測リターンの選択',
                            dcc.Dropdown(
                                id='data_selected',
                                options=[{'label' : i, 'value' : i} for i in files],  # 選択肢の設定
                                value=files,
                                multi=True,
                                clearable=True,  # 選択を削除できるように設定
                                style={"textAlign": "left"},  # 文字を左に寄せる
                                )
                            ]),
                    
                            # ハイパーパラメータのテーブル
                            dash_table.DataTable(
                                id='parameters',
                                style_cell={'textAlign': 'center'},                        
                                editable=True,
                                columns=[{'name' : hyperparms_portfolio_name[key], 'id' : key, 'presentation': 'dropdown'} if i<=2 
                                         else {'name' : hyperparms_portfolio_name[key], 'id' : key} 
                                         for i, key in enumerate(hyperparms_portfolio.keys())],
                                data=pd.DataFrame.from_dict(hyperparms_portfolio, orient='index').T.to_dict('records'), # dashに対応させる形式に変換
                                
                                dropdown={
                                        'split_num': {
                                            'options': [
                                                {'label': i, 'value': i}
                                                for i in ['2', '3', '4', '5', '10']
                                            ]
                                        },
                                        'portfolio_type': {
                                             'options': [
                                                {'label': i, 'value': i}
                                                for i in ['Long', 'LongShort', 'Long_const', 'Simple']
                                            ]
                                        },
                                        'calc_type' : {
                                             'options': [
                                                {'label': i, 'value': i}
                                                for i in ['cumulative', 'accumulation']
                                            ]
                                        },
                                    },
                                ),                    
                            ],
                        style={'columnCount': 1},
                        ), 

                    html.Button(id='my-botton_1', n_clicks=0, children='バックテスト実行'),

                    # 読み込み
                    dcc.Loading(
                        id='loading_1',
                        type='dot',
                        children=[
                            
                            # インデックスの推移を出力
                            html.Div(
                                [dcc.Graph(id='index_port_output')],
                                style={
                                    'display' : 'inline-block', 
                                    'width' : '100%', 
                                    },
                                ),
                            
                            # 精度指標の表を出力
                            html.Div(id='result_table'),                                                           
                                ],
                            ) 
                       
                        ]
                    ),
                ],
            ),
            
            # グラフを表示するタブ
            dcc.Tab(
                label='分位ポートフォリオインデックスの推移',
                value='two',
                selected_style=tab_selected_style,
                children=[
                    html.Div([
                        html.Label(['予測リターンの選択']),                  
                        # ドロップダウンの作成
                        dcc.Dropdown(
                            id='data_selected_quantile',
                            options=[{'label' : i, 'value' : i} for i in files],  # 選択肢の設定
                            value=files[0],
                            multi=False,
                            clearable=True,  # 選択を削除できるように設定
                            style={"textAlign": "left"},  # 文字を左に寄せる
                            ), 
                                                   
                        html.Label(['分位数の選択']),                
                        # 分位数のドロップダウン
                        dcc.Dropdown(
                            id='quantile_selected',
                            options=[{'label' : i, 'value' : i} for i in [2, 3, 4, 5, 10]],  # 選択肢の設定
                            value=10,
                            clearable=True,  # 選択を削除できるように設定
                            style={"textAlign": "center"},  # 文字を左に寄せる
                            ),
                    ], style={'columnCount': 1}),
                    
                    # 読み込み
                    dcc.Loading(
                        id='loading_2',
                        type='dot',
                        children=[
                                                    
                        # 分位ポートフォリオの推移
                        html.Div(
                            [dcc.Graph(id='index_quantile_output')],
                            style={
                                'display' : 'inline-block', 
                                'width' : '100%', 
                                },
                            ),
    
                        # 最上位ポートフォリオ-最下位ポートフォリオの差分推移 
                        html.Div(
                            [dcc.Graph(id='index_quantile_diff_output')],
                            style={
                                'display' : 'inline-block', 
                                'width' : '100%', 
                                },
                            ),
                    
                        ],
                    )                        
                ],
            ),
        ],
    ),
     ],
)

# callback_result.py
# コールバック関数(パフォーマンス指標)
@app.callback(
    Output('result_table', 'children'),
    Output('index_port_output', 'figure'),    
    Input('my-botton_1', 'n_clicks'),
    State("data_selected", 'value'),
    State('parameters', 'data'),
    )
        
def update_result(n_clicks, files, hyperparms_portfolio_list): 
    hyperparms_portfolio = hyperparms_portfolio_list[0]
    hyperparms_portfolio['split_num'] = int(hyperparms_portfolio['split_num'])
    # バックテストの実施
    result = []
    index_portfolio = []
    for file in files:
        result_, index_portfolio_ = get_backtest_result(file, hyperparms_portfolio)
        index_portfolio.append(index_portfolio_)
        result.append(result_) 
    
    # 列名の設定
    colnames = files
    
    # バックテスト結果の結合 
    try:
        result = pd.concat(result, axis=1).applymap(lambda x : round(x, 4))
        index_portfolio = pd.concat(index_portfolio, axis=1)
    except:
        result = pd.DataFrame(result).applymap(lambda x : round(x, 4))
        index_portfolio = pd.DataFrame(index_portfolio)

    result.columns = colnames
    index_portfolio.columns = colnames        
    result = result.reset_index().rename(columns={'index':'metrics'})            
    
    # 精度指標結果
    dash_output = dash_table.DataTable(
        id='result',
        data=result.to_dict('records'), # keyが列ラベル，valueが値となる辞書を要素とするリストに変換
        columns=[{'id' : i, 'name' : i} for i in result.columns],

        # セルのスタイル設定
        style_cell = {
                'font_family': 'arial',
                'font_size': '15px',
                'text_align': 'center'
            },        

        # 値の大きい数値に色付け(?)
# =============================================================================
#         style_cell_conditional=[
#             {
#                 'if': {
#                     'filter_query' : '{{{row}}} > 0',
#                     'row_index': row
#                     },
#             'backgroundColor': '#FF4136',
#             'color': 'white',                
#             } for row in result.columns[1:]
#         ],
# =============================================================================
        
        # 1行ごとに色づけ        
        style_data_conditional=[
            {
                'if': {'row_index': 'odd'},
                'backgroundColor': 'rgb(248, 248, 248)'
            }
        ],
        
        # header色付け
        style_header={
            'backgroundColor': 'rgb(230, 230, 230)',
            'fontWeight': 'bold'
        },        
        )
    
    # インデックスの推移
    fig = go.Figure(data=[go.Scatter(
                 x=index_portfolio.index,
                 y=index_portfolio[name_i],
                 opacity=.5,
                 name=name_i,
                 ) for i, name_i in enumerate(index_portfolio.columns)
             ],
        )
    # fig.update_xaxes(tickformat="%b\n%Y")
        
    return dash_output, fig

# コールバック関数( 分位ポートフォリオインデックスの推移)     
@app.callback(
    Output('index_quantile_output', 'figure'),      
    Output('index_quantile_diff_output', 'figure'),      
    Input("data_selected_quantile", 'value'),    
    Input('quantile_selected', 'value'),    
    )

def update_index_plot(file, split_num):
    hyperparms_portfolio['split_num'] = split_num
    index_quantile_port = get_quantile_result(file, hyperparms_portfolio)
    
    # カラーの指定
    color_list = plotly.colors.DEFAULT_PLOTLY_COLORS[:index_quantile_port.shape[1]]
    color_dict = dict(zip(index_quantile_port.columns, color_list))        
    
    # 1.分位ポートフォリオインデックスの推移
    fig_quantile = go.Figure(data=[go.Scatter(
        x=index_quantile_port.index,
        y=index_quantile_port[name_i],
        line=dict(color=color_dict[name_i], dash="solid"),
        opacity=.5,
        name=name_i,
        ) for i, name_i in enumerate(index_quantile_port.columns)
        ],
    )
    # fig_quantile.update_xaxes(tickformat="%b\n%Y")
    
    # 2.最上位・最下位の分位ポートフォリオインデックスの推移
    fig_quantile_diff = make_subplots(specs=[[{"secondary_y": True}]])

    # 最上位ポートフォリオのインデックス推移
    fig_quantile_diff.add_trace(
            go.Scatter(
            x=index_quantile_port.index,
            y=index_quantile_port[index_quantile_port.columns[0]],
            line=dict(color=color_dict[index_quantile_port.columns[0]], width=3, dash="solid"),
            opacity=.5,
            name=index_quantile_port.columns[0],
            ),
            secondary_y=False,            
        )

    # 最下位ポートフォリオのインデックス推移            
    fig_quantile_diff.add_trace(
            go.Scatter(
            x=index_quantile_port.index,
            y=index_quantile_port[index_quantile_port.columns[-1]],
            line=dict(color=color_dict[index_quantile_port.columns[-1]], width=3, dash="solid"),
            opacity=.5,
            name=index_quantile_port.columns[-1],
            ),        
            secondary_y=False,            
        )

    # 最上位 - 最下位の差分ポートフォリオのインデックス推移            
    fig_quantile_diff.add_trace(
        go.Scatter(
        x=index_quantile_port.index,
        y=index_quantile_port[index_quantile_port.columns[0]] - index_quantile_port[index_quantile_port.columns[-1]],
        fill='tozeroy',            
        mode='none',
        name=f'{index_quantile_port.columns[0]} - {index_quantile_port.columns[-1]}',
        ), 
        secondary_y=True,                
        )
    
    # fig_quantile_diff.update_xaxes(tickformat="%b\n%Y")
    
    return fig_quantile, fig_quantile_diff

if __name__ == "__main__":
    app.run_server(debug=True)



