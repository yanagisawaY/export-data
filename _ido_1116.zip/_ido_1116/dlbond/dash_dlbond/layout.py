from os import access
import dash_core_components as dcc
import dash_html_components as html
import dash_table
import pandas as pd

# import from self-made modules
from .utils.generate_table import generate_table
from .utils.select_result import select_result
from .utils.set_path import set_path
from .pages.access_results import get_model_select
from .markdown.title import title_markdown
from .markdown.app_description import description_markdown

# common setting
df = pd.read_csv('https://gist.githubusercontent.com/chriddyp/c78bf172206ce24f77d6363a2d754b59/raw/c353e8ef842413cae56ae3920b8fd78468aa4cb2/usa-agricultural-exports-2011.csv')
path = "C:/Users/yana/Desktop/github/trade_index/experiment/result"

tab_selected_style = {
    "backgroundColor": "rgb(0, 0, 118)",
    "color": "white",
    "fontWeight": "bold",
}

this_layout = html.Div(
    children=[
        
        # Top tile
        dcc.Markdown(children=title_markdown),
        
        # tab        
        dcc.Tabs([
            # 1st Tab
            dcc.Tab(
                label="README",
                value='readme',
                selected_style=tab_selected_style,                        
                children=[
                    dcc.Markdown(children=description_markdown),
                ]
            ),
                        
            # 2nd Tab
            dcc.Tab(
                label="backtest",
                value='reference',
                selected_style=tab_selected_style,                                        
                children=[
                    html.H4(children='set the folder path'),
                    set_path(path),
                ]
            ),

            # 3rd Tab                        
            dcc.Tab(
                label="experiments",
                value='data table',
                selected_style=tab_selected_style,                                        
                children=[
                    html.H4(children='Example'),                    
                ]
            ),

            # 4th Tab            
            dcc.Tab(
                label="tbd",
                value='tbd',
                selected_style=tab_selected_style,                                        
                children=[
                    html.H4(children='モデルの選択'),
                    html.Button("PUSH ME", id="add_drop", n_clicks=0),
                    html.Div(id="model_dropdown", children=[]),                    
                ],
            ),            
        ],),
    ],
)
