import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix

class Evaluator:
    def __init__(self):
        pass

    def calc_mdd(self, wealth):
        """MDD(Maximum Drawdown)を計算 

        Parameters
        ----------
        wealth : pd.Series
            トレードによる累積リターン

        Returns
        -------
        mdd_ratio : float
            MDD(Maximum Drawdown)レシオ.
        mdd : float
            MDD
        """
        mdd_ratio = np.max((np.maximum.accumulate(wealth) - wealth) /
                     np.maximum.accumulate(wealth), 0)
        mdd = np.max((np.maximum.accumulate(wealth) - wealth), 0)
        
        return mdd_ratio, mdd
    
    def calc_confusion_mat(self, position, trade_return):
        def make_cm(cm):
            if len(cm.flatten()) > 0:
                tn, fp, fn, tp = cm.flatten()
                cm_t = pd.DataFrame([[tp, fn], [fp, tn]])
            else:
                cm_t = pd.DataFrame([[0, 0], [0, 0]])                
            cm_t.columns = ["T", "N"]
            cm_t.index = ["T", "N"]
                
            return cm_t

        cm_long = confusion_matrix((position[position>0]>0), (trade_return[position>0]>0))
        cm_short = confusion_matrix((position[position<0]<0), (trade_return[position<0]>0))        
        cm_long = make_cm(cm_long)
        cm_short = make_cm(cm_short) 
        cm_all = pd.DataFrame([[cm_long.values[0, 0], cm_short.values[0, 1]],
                               [cm_long.values[0, 1], cm_short.values[0, 0]]])
        cm_all.index = ["long(tr)", "short(tr)"]
        cm_all.columns = ["long(model)", "short(model)"]        
        
        return cm_all
    
    def calc_trader_result(self, futures_return, trade_return, position, wealth_init=100*30):        
        def _calc_return(trade_return, position, name):
            total_return = trade_return.sum()*wealth_init        
            total_return_win = trade_return[trade_return>0].sum()*wealth_init
            total_return_lose = trade_return[trade_return<0].sum()*wealth_init
            total_trade_num = (position!=0).sum()
            win_num = (trade_return>0).sum()
            lose_num = (trade_return<0).sum()
            if total_trade_num == 0:
                win_ratio = np.nan                        
            else:            
                win_ratio = win_num/total_trade_num        
            mean_return = trade_return.mean()*wealth_init
            max_return = trade_return.max()*wealth_init
            min_return = trade_return.min()*wealth_init             
            mean_win_return = trade_return[trade_return>0].mean()*wealth_init
            mean_lose_return = trade_return[trade_return<0].mean()*wealth_init        
            
            output = pd.Series([
                total_return, 
                total_return_win, 
                total_return_lose, 
                total_trade_num, 
                win_num, 
                lose_num, 
                win_ratio, 
                mean_return, 
                max_return, 
                min_return, 
                mean_win_return, 
                mean_lose_return],
                index=[
                    "総損益",
                    "総利益",
                    "総損失",
                    "総トレード数",
                    "利益トレード数",
                    "損失トレード数",
                    "勝率",
                    "損益平均",
                    "最大利益",                    
                    "最大損失",
                    "利益の平均値",
                    "損失の平均値",                    
                    ], name=name)
            
            return output
        
        output = _calc_return(trade_return, position, name="トータル")
        output = pd.concat([output, _calc_return(trade_return[position>0], position[position>0], name="買い")], axis=1)
        output = pd.concat([output, _calc_return(trade_return[position<0], position[position<0], name="売り")], axis=1)        
        
        return output

    def calc_performance(self, trade_return, output_name='result', business_days=250):
        '''トレーディング戦略のパフォーマンスを測定する関数

        Parameters
        ----------
        wealth : pd.Series
            トレードによる累積リターン        
        trade_return : pd.Series
            トレーディング戦略のリターン.        
        output_name : str
            出力するデータフレームの名前ラベル. The default is 'result'.
        business_days : int
            年率換算時に使用する営業日日数換算値

        Returns
        -------
        output : pd.Series
            トレーディング戦略のパフォーマンス結果.
        '''
        mean_year = trade_return.mean()*business_days
        sd_year = ((np.sqrt(business_days) *
                   pd.DataFrame.std(trade_return, ddof=1)))
        SR_year = mean_year / sd_year
        lpm2_year = np.sqrt(
            business_days) * np.sqrt(np.sum((trade_return[trade_return < 0] ** 2))/len(trade_return))
        DDR_year = mean_year / lpm2_year

        output = pd.Series([mean_year, sd_year, SR_year, lpm2_year, DDR_year],
                           index=['平均(年率換算)', '標準偏差(年率換算)',
                                  'R/R(年率換算)', '半分散(年率換算)', 'DDRatio(年率換算)'],
                           name=output_name)

        return output

    def calc_performance_all(
            self, 
            trade_return, 
            wealth, 
            futures_return,            
            position,                        
            output_name='result', 
            business_days=250):
        '''トレーディング戦略のパフォーマンスを測定する関数

        Parameters
        ----------
        trade_return : pd.Series
            トレーディング戦略のリターン.        
        wealth : pd.Series
            トレードによる累積リターン            
        futures_return : pd.Series
            トレーディング対象のリターン.
        position : pd.Series
            売買ポジション            
        output_name : str
            出力するデータフレームの名前ラベル. The default is 'result'.
        business_days : int
            年率換算時に使用する営業日日数換算値

        Returns
        -------
        output : pd.Series
            トレーディング戦略のパフォーマンス結果.
        '''
        output = self.calc_performance(
            trade_return, output_name, business_days)
        mdd_ratio, mdd = self.calc_mdd(wealth)
        output["MDD_ratio"] = mdd
        output_trade = self.calc_trader_result(futures_return, trade_return, position)
        cm_all = self.calc_confusion_mat(position, trade_return)

        return output, output_trade, cm_all