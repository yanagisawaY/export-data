import os

import pandas as pd


class Storage:
    def __init__(self, now="", path=None, dir_="\\experiment\\result\\"):
        self.now = now
        self.path = path
        self.dir_ = dir_
    
    def save(self, model, trader, result, file_name, now="", path=None, dir_=None):
        if now == "":
            now = self.now
        if path is None:
            path = self.path
        if dir_ is None:
            dir_ = self.dir_
        
        folder_ = file_name.split("/")[0] + "\\" + now + "\\" + file_name.split("/")[1]
        
        output_path = path + dir_ + folder_
        os.makedirs(output_path, exist_ok=True)
        os.makedirs(output_path + "\\params", exist_ok=True)       
        
        threshold_info = {
            trader: trader
        }
        
        pd.to_pickle(model, output_path + "\\params\\model.pkl")
        pd.to_pickle(result, output_path + "\\result.pkl")
        term_info = result["term"]
        pd.to_pickle(term_info, output_path + "\\term_info.pkl")
        
    def save_result_all(self, result_all, file_name, now="", path=None, dir_=None):
        if now == "":
            now = self.now
        if path is None:
            path = self.path
        if dir_ is None:
            dir_ = self.dir_
        
        self.output_path = path + dir_ + file_name + "\\" + now
        os.makedirs(self.output_path, exist_ok=True)
        pd.to_pickle(result_all, self.output_path + "\\result_all.pkl")
    
    def save_config(self, config, now="", path=None, dir_=None):
        pd.to_pickle(config, self.output_path + "\\config.pkl")