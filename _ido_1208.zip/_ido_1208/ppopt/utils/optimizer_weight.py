import pulp
import numpy as np
import pandas as pd



def solve_opt(
    weight_bench: np.array,
    weights_char: np.array,
    weight_hold: np.array,
    rit: np.array,
    target_risk: float,
    turnover: float,
    stock_name: list,
    is_print: bool = True,
):
    """リスク制約,売買回転率制約,空売り禁止制約のもとでアクティブリターンが最大となるポートフォリオのウェイトを算出

    Parameters
    ----------
    weight_bench : np.array
        リバランス時点におけるベンチマークポートフォリオのウェイト (銘柄数)
    weights_char : list
        企業特性合成ポートフォリオのウェイト [(合成ポートフォリオの数, t時点の銘柄数) for t in range(時点)]
    weight_hold : np.array
        リバランス時点における保有ポートフォリオのウェイト(銘柄数)
    rit : list
        各銘柄のリターン [(t時点の銘柄数) for t in range(時点)]
    target_risk : float
        リスク制約の上限値
    turnover : float
        売買回転率の上限
    stock_name: list
        銘柄名のリスト
    is_print : bool
        最適化結果のプリント(任意設定)
    
    Return
    ------
    weight : pd.DataFrame
        各資産へのウェイト    
    theta : list
        企業特性合成ポートフォリオへのウェイト
    is_status : bool
        最適解が求まった場合はTrueを返す
    Notes
    -----
    * 線形計画法により定式化

    * オメガレシオは，アクティブリターンのアップサイド/アクティブリターンのダウンサイドとして定義

    * 時点ごとにユニバースに含まれる銘柄数が異なる場合にも対応

    * 変数z_tは最適化に不要であるが，これを入れることで解が安定する様子が確認された（原因は不明...)
    """
    stock_num = len(weight_bench)
    T = len(rit)
    K = weights_char[0].shape[0]
    stock_num_list = [rit[t].shape[0] for t in range(T)]
    stock_num_list.append(stock_num)
    problem = pulp.LpProblem('ActiveOpt', pulp.LpMaximize)

    # 決定変数
    theta = [pulp.LpVariable(name='theta_{}'.format(
        k), cat="Continuous") for k in range(K)]
    # 補助変数
    yt = [pulp.LpVariable(name='yt_{}'.format(t), lowBound=0,
                          cat="Continuous") for t in range(T)]
    dti = [pulp.LpVariable(name='dti_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]
    alpha = pulp.LpVariable(name='alpha', cat="Continuous")

    # 目的関数
    problem += alpha, "Objective"
    
    # リスク制約
    problem += pulp.lpSum([yt[t] for t in range(T)])/T <= target_risk

    # アクティブリターンからの不足分
    for t in range(T):
        problem += pulp.lpSum([(theta[k]*weights_char[t][k, i])*rit[t][i]
                               for k in range(K) for i in range(stock_num_list[t])]) + yt[t] >= 0

    # 期待アクティブリターン
    sum_at = []
    for t in range(T):
        sum_at += [(theta[k]*weights_char[t][k, i])*rit[t][i]
                   for k in range(K) for i in range(stock_num_list[t])]
    problem += pulp.lpSum(sum_at)/T == alpha

    # 投資制約
    # リバランス時点の売買回転率上限制約
    problem += pulp.lpSum([dti[i]
                          for i in range(stock_num_list[T])]) <= turnover
    for i in range(stock_num):
        # # リバランス時点の空売り禁止制約
        problem += weight_bench[i] + pulp.lpSum(
            [theta[k]*weights_char[T][k, i] for k in range(K)]) >= 0
        # # リバランス時点の購入ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) - weight_hold[i] - dti[i] <= 0
        # リバランス時点の売却ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) - weight_hold[i] + dti[i] >= 0
    
    status = problem.solve()
    weight_add = [sum([pulp.value(theta[k])*weights_char[T][k, i]
                       for k in range(K)]) for i in range(stock_num)]
    
    weight = pd.Series(
        [weight_bench[i] + weight_add[i] for i in range(stock_num)],
        index=stock_name)

    status = pulp.LpStatus[status]
    theta = [pulp.value(theta[k]) for k in range(K)]

    if is_print:
        turnover_ = np.sum(np.abs(weight-weight_hold))
        print(
            f'Status {status} 目的関数値 = {pulp.value(problem.objective)} turnover {round(turnover_, 3)}')
    
    is_status = status == "Optimal"

    return weight, theta, is_status


def _solve_opt_(
    weight_bench: np.array,
    weights_char: np.array,
    weight_hold: np.array,
    rit: np.array,
    target_risk: float,
    turnover: float,
    stock_name: list,
    is_print: bool = True,
):
    """リスク制約,売買回転率制約,空売り禁止制約のもとでアクティブリターンが最大となるポートフォリオのウェイトを算出

    Parameters
    ----------
    weight_bench : np.array
        リバランス時点におけるベンチマークポートフォリオのウェイト (銘柄数)
    weights_char : list
        企業特性合成ポートフォリオのウェイト [(合成ポートフォリオの数, t時点の銘柄数) for t in range(時点)]
    weight_hold : np.array
        リバランス時点における保有ポートフォリオのウェイト(銘柄数)
    rit : list
        各銘柄のリターン [(t時点の銘柄数) for t in range(時点)]
    target_risk : float
        リスク制約の上限値
    turnover : float
        売買回転率の上限
    stock_name: list
        銘柄名のリスト
    is_print : bool
        最適化結果のプリント(任意設定)
    
    Return
    ------
    weight : pd.DataFrame
        各資産へのウェイト    
    theta : list
        企業特性合成ポートフォリオへのウェイト
    is_status : bool
        最適解が求まった場合はTrueを返す
    Notes
    -----
    * 線形計画法により定式化

    * オメガレシオは，アクティブリターンのアップサイド/アクティブリターンのダウンサイドとして定義

    * 時点ごとにユニバースに含まれる銘柄数が異なる場合にも対応

    * 変数z_tは最適化に不要であるが，これを入れることで解が安定する様子が確認された（原因は不明...)
    """
    stock_num = len(weight_bench)
    T = len(rit)
    K = weights_char[0].shape[0]
    stock_num_list = [rit[t].shape[0] for t in range(T)]
    stock_num_list.append(stock_num)
    problem = pulp.LpProblem('ActiveOpt', pulp.LpMaximize)

    # 決定変数
    theta = [pulp.LpVariable(name='theta_{}'.format(
        k), cat="Continuous") for k in range(K)]
    # 補助変数
    yt = [pulp.LpVariable(name='yt_{}'.format(t), lowBound=0,
                          cat="Continuous") for t in range(T)]
    dti = [pulp.LpVariable(name='dti_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]
    zi = [pulp.LpVariable(name='zi_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]
    alpha = pulp.LpVariable(name='alpha', cat="Continuous")

    # 目的関数
    problem += alpha, "Objective"
    
    # リスク制約
    problem += pulp.lpSum([yt[t] for t in range(T)])/T <= target_risk

    # アクティブリターンからの不足分
    for t in range(T):
        problem += pulp.lpSum([(theta[k]*weights_char[t][k, i])*rit[t][i]
                               for k in range(K) for i in range(stock_num_list[t])]) + yt[t] >= 0

    # 期待アクティブリターン
    sum_at = []
    for t in range(T):
        sum_at += [(theta[k]*weights_char[t][k, i])*rit[t][i]
                   for k in range(K) for i in range(stock_num_list[t])]
    problem += pulp.lpSum(sum_at)/T == alpha

    # 投資制約
    # リバランス時点の売買回転率上限制約
    problem += pulp.lpSum([dti[i]
                          for i in range(stock_num_list[T])]) <= turnover
    for i in range(stock_num):
        # # リバランス時点の空売り禁止制約
        problem += weight_bench[i] + pulp.lpSum(
            [theta[k]*weights_char[T][k, i] for k in range(K)]) + zi[i] >= 0
        # # リバランス時点の購入ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) + zi[i] - weight_hold[i] - dti[i] <= 0
        # リバランス時点の売却ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) + zi[i] - weight_hold[i] + dti[i] >= 0

    # 投資量固定
    problem += pulp.lpSum([weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                          for k in range(K)]) + zi[i] for i in range(stock_num)]) == 1
    
    status = problem.solve()
    weight_add = [sum([pulp.value(theta[k])*weights_char[T][k, i]
                       for k in range(K)]) + pulp.value(zi[i]) for i in range(stock_num)]
    
    weight = pd.Series(
        [weight_bench[i] + weight_add[i] for i in range(stock_num)],
        index=stock_name)

    status = pulp.LpStatus[status]
    theta = [pulp.value(theta[k]) for k in range(K)]

    if is_print:
        turnover_ = np.sum(np.abs(weight-weight_hold))
        print(
            f'Status {status} 目的関数値 = {pulp.value(problem.objective)} turnover {round(turnover_, 3)}')
        print(f'k_sum = {round(sum([pulp.value(zi[i]) for i in range(stock_num)]), 8)}')
    
    is_status = status == "Optimal"

    return weight, theta, is_status


def solve_opt_omega(
    weight_bench: np.array,
    weights_char: np.array,
    weight_hold: np.array,
    rit: np.array,
    alpha: float,
    turnover: float,
    stock_name: list,
    is_print: bool = True,
):
    """売買回転率制約と空売り禁止制約のもとでオメガレシオが最大となるポートフォリオのウェイトを算出

    Parameters
    ----------
    weight_bench : np.array
        リバランス時点におけるベンチマークポートフォリオのウェイト (銘柄数)
    weights_char : list
        企業特性合成ポートフォリオのウェイト [(t時点の銘柄数, 合成ポートフォリオの数) for t in range(時点)]
    weight_hold : np.array
        リバランス時点における保有ポートフォリオのウェイト(銘柄数)
    rit : list
        各銘柄のリターン [(t時点の銘柄数) for t in range(時点)]
    alpha : float
        アクティブリターンの要求水準
    turnover : float
        売買回転率の上限
    stock_name: list
        銘柄名のリスト
    is_print : bool
        最適化結果のプリント(任意設定)

    Notes
    -----
    * 線形計画法により定式化

    * オメガレシオは，アクティブリターンのアップサイド/アクティブリターンのダウンサイドとして定義

    * 時点ごとにユニバースに含まれる銘柄数が異なる場合にも対応

    * alphaは0より大きい値で設定
    """
    assert alpha > 0
    stock_num = len(weight_bench)
    T = len(rit)
    K = weights_char[0].shape[1]
    stock_num_list = [rit[t].shape[0] for t in range(T)]
    stock_num_list.append(stock_num)
    problem = pulp.LpProblem('ActiveOpt', pulp.LpMinimize)

    # 決定変数
    x_k = [pulp.LpVariable(name='x_k_{}'.format(
        k), cat="Continuous") for k in range(K)]
    # 補助変数
    yt = [pulp.LpVariable(name='yt_{}'.format(t), lowBound=0,
                          cat="Continuous") for t in range(T)]
    dti = [pulp.LpVariable(name='dti_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]
    zi = [pulp.LpVariable(name='zi_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]

    # 目的関数
    problem += pulp.lpSum([yt[t] for t in range(T)])/T, "Objective"

    # アクティブリターンからの不足分
    for t in range(T):
        problem += pulp.lpSum([(x_k[k]*weights_char[t][k, i])*rit[t][i]
                               for k in range(K) for i in range(stock_num_list[t])]) + yt[t] >= 0

    # 期待アクティブリターン項(変数変換後)
    sum_at = []
    for t in range(T):
        sum_at += [(x_k[k]*weights_char[t][k, i])*rit[t][i]
                   for k in range(K) for i in range(stock_num_list[t])]
    problem += pulp.lpSum(sum_at)/T == 1

    # 投資制約
    # リバランス時点の売買回転率上限制約
    problem += pulp.lpSum([dti[i]
                          for i in range(stock_num_list[T])]) <= turnover
    for i in range(stock_num):
        # # リバランス時点の空売り禁止制約
        problem += weight_bench[i] + pulp.lpSum(
            [alpha*x_k[k]*weights_char[T][k, i] for k in range(K)]) + zi[i] >= 0
        # # リバランス時点の購入ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([alpha*x_k[k]*weights_char[T][k, i]
                                                for k in range(K)]) + zi[i] - weight_hold[i] - dti[i] <= 0
        # リバランス時点の売却ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([alpha*x_k[k]*weights_char[T][k, i]
                                                for k in range(K)]) + zi[i] - weight_hold[i] + dti[i] >= 0

    # 投資量固定
    problem += pulp.lpSum([weight_bench[i] + pulp.lpSum([alpha*x_k[k]*weights_char[T][k, i]
                          for k in range(K)]) + zi[i] for i in range(stock_num)]) == 1

    status = problem.solve()
    theta = [alpha*pulp.value(x_k[k]) for k in range(K)]
    weight_add = [sum([theta[k]*weights_char[T][k, i]
                       for k in range(K)]) + pulp.value(zi[i]) for i in range(stock_num)]
    weight = pd.Series(
        [weight_bench[i] + weight_add[i] for i in range(stock_num)],
        index=stock_name)

    status = pulp.LpStatus[status]

    turnover_ = np.sum(np.abs(weight-weight_hold))
    if is_print:
        print(
            f'Status {status} 目的関数値 = {pulp.value(problem.objective)} turnover {round(turnover_, 3)}')

    return weight, theta


# =============================================================================
# def solve_opt_old(
#     weight_bench: np.array,
#     weights_char: np.array,
#     weight_hold: np.array,
#     rit: np.array,
#     turnover: float,
#     stock_name: list,
#     is_print: bool = True,
# ):
#     """売買回転率制約と空売り禁止制約のもとでオメガレシオが最大となるポートフォリオのウェイトを算出
# 
#     Parameters
#     ----------
#     weight_bench : np.array
#         リバランス時点におけるベンチマークポートフォリオのウェイト (銘柄数)
#     weights_char : list
#         企業特性合成ポートフォリオのウェイト [(t時点の銘柄数, 合成ポートフォリオの数) for t in range(時点)]
#     weight_hold : np.array
#         リバランス時点における保有ポートフォリオのウェイト(銘柄数)
#     rit : list
#         各銘柄のリターン [(t時点の銘柄数) for t in range(時点)]
#     turnover : float
#         売買回転率の上限
#     stock_name: list
#         銘柄名のリスト
#     is_print : bool
#         最適化結果のプリント(任意設定)
# 
#     Notes
#     -----
#     * 線形計画法により定式化
# 
#     * オメガレシオは，アクティブリターンのアップサイド/アクティブリターンのダウンサイドとして定義
# 
#     * 時点ごとにユニバースに含まれる銘柄数が異なる場合にも対応
# 
#     * 変数z_tは最適化に不要であるが，これを入れることで解が安定する様子が確認された（原因は不明...)
#     """
#     stock_num = len(weight_bench)
#     T = len(rit)
#     K = weights_char[0].shape[1]
#     stock_num_list = [rit[t].shape[0] for t in range(T)]
#     stock_num_list.append(stock_num)
#     problem = pulp.LpProblem('ActiveOpt', pulp.LpMinimize)
# 
#     # 決定変数
#     theta = [pulp.LpVariable(name='theta_{}'.format(
#         k), cat="Continuous") for k in range(K)]
#     # 補助変数
#     yt = [pulp.LpVariable(name='yt_{}'.format(t), lowBound=0,
#                           cat="Continuous") for t in range(T)]
#     dti = [pulp.LpVariable(name='dti_{}'.format(
#         i), lowBound=0, cat="Continuous") for i in range(stock_num)]
#     zi = [pulp.LpVariable(name='zi_{}'.format(
#         i), lowBound=0, cat="Continuous") for i in range(stock_num)]
#     alpha = pulp.LpVariable(name='alpha', cat="Continuous")
# 
#     # 目的関数
#     problem += pulp.lpSum([yt[t] for t in range(T)])/T - alpha, "Objective"
# 
#     # アクティブリターンからの不足分
#     for t in range(T):
#         problem += pulp.lpSum([(theta[k]*weights_char[t][k, i])*rit[t][i]
#                                for k in range(K) for i in range(stock_num_list[t])]) + yt[t] >= 0
# 
#     # 期待アクティブリターン
#     sum_at = []
#     for t in range(T):
#         sum_at += [(theta[k]*weights_char[t][k, i])*rit[t][i]
#                    for k in range(K) for i in range(stock_num_list[t])]
#     problem += pulp.lpSum(sum_at)/T == alpha
# 
#     # 投資制約
#     # リバランス時点の売買回転率上限制約
#     problem += pulp.lpSum([dti[i]
#                           for i in range(stock_num_list[T])]) <= turnover
#     for i in range(stock_num):
#         # # リバランス時点の空売り禁止制約
#         problem += weight_bench[i] + pulp.lpSum(
#             [theta[k]*weights_char[T][k, i] for k in range(K)]) + zi[i] >= 0
#         # # リバランス時点の購入ウェイトの上限制約
#         problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
#                                                 for k in range(K)]) + zi[i] - weight_hold[i] - dti[i] <= 0
#         # リバランス時点の売却ウェイトの上限制約
#         problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
#                                                 for k in range(K)]) + zi[i] - weight_hold[i] + dti[i] >= 0
# 
#     # 投資量固定
#     problem += pulp.lpSum([weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
#                           for k in range(K)]) + zi[i] for i in range(stock_num)]) == 1
# 
#     status = problem.solve()
#     weight_add = [sum([pulp.value(theta[k])*weights_char[T][k, i]
#                        for k in range(K)]) for i in range(stock_num)]
#     weight = pd.Series(
#         [weight_bench[i] + weight_add[i] for i in range(stock_num)],
#         index=stock_name)
# 
#     status = pulp.LpStatus[status]
# 
#     turnover_ = np.sum(np.abs(weight-weight_bench))
#     if is_print:
#         print(
#             f'Status {status} 目的関数値 = {pulp.value(problem.objective)} turnover {round(turnover_, 3)}')
# 
#     return weight
# =============================================================================
