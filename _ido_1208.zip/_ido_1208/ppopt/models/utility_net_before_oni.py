from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd
import numpy as np
import math


class UtilityNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''

    def __init__(self, hyperparms, input_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(UtilityNet, self).__init__()
        layer_units = hyperparms['layer_list']
        layer_num = len(layer_units)
        if layer_num > 0:
            layer = []
            layer.append(nn.Dropout(hyperparms['layer_dropout']))
            layer.append(nn.BatchNorm1d(layer_units[0]))
            layer.append(nn.ReLU())
            if layer_num > 1:
                for i in range(layer_num-1):
                    layer.append(nn.Linear(layer_units[i], layer_units[i+1]))
                    layer.append(nn.BatchNorm1d(layer_units[i+1]))
                    layer.append(nn.ReLU())
    
            self.full = nn.Sequential(*layer)
            self.last = nn.Linear(layer_units[-1], 1, bias=False)
            self.last_unit = layer_units[-1]
            self.is_linear = False
        else:
            self.is_linear = True
            self.last = nn.Linear(input_num, 1, bias=False)            
            self.last_unit = input_num
            
    def forward(self, X):
        """順伝搬

        Parameters
        ----------
        X : torch.tensor
            (バッチ(時点), 銘柄, 特長量)

        Returns
        -------
        weight : torch.tensor
            (バッチ(時点), 銘柄)
        
        Notes
        -----
        最終層はクロスセクション方向に平均ゼロ，標準偏差1に標準化
        ->　ポートフォリオフォリオのウェイトが1となることが保証
        
        ベンチマークのウェイトは等ウェイトとして設定
        """
        weight = torch.zeros(X.size()[:2])
        
        if self.is_linear:
            hidden = torch.transpose(X, 1, 2)
        else:
            hidden = torch.zeros(X.size(0), self.last_unit, X.size(1))            
            for stock_i in range(X.size(1)):
                hidden[:,:,stock_i] = self.full(X[:,stock_i,:]).squeeze()
        
        # hidden = (hidden - torch.mean(hidden, 2).unsqueeze(2).tile(hidden.shape[2]))/torch.std(hidden, 2).unsqueeze(2).tile(hidden.shape[2])
        for stock_i in range(X.size(1)):    
            weight[:,stock_i] = self.last(hidden[:,:,stock_i]).squeeze(1)

        weight = (weight - torch.mean(weight, 1).unsqueeze(1).tile(weight.shape[1]))/torch.std(weight, 1).unsqueeze(1).tile(weight.shape[1])
            
        return weight


class UtilityLoss(nn.Module):
    def __init__(self, utility_type, gamma, leverage=0):
        super().__init__()
        self.utility_type = utility_type
        self.gamma = gamma        
        self.leverage = leverage
    
    def forward(self, rt, weight):
        weight_add = weight/weight.shape[1]
        port_weight = torch.ones(weight.size())/weight.shape[1] + weight_add
        port_rt = torch.einsum('nm,nm->n', rt, port_weight)
        if self.utility_type == "CRRA":
            utility = ((1 + port_rt)**(1 - self.gamma))/(1 - self.gamma)
        else:
            raise ValueError("this version only supports CRRA")
        
        utility = (utility - self.leverage*torch.sum(weight_add**2, 1)/2).mean()
        
        return utility
    

class XSDataLoader:
    """torch型のデータセットを作成するクラス
    """
    def __init__(self, X, y, batch_size, stock_list, factor_list, is_t_1):
        """

        Parameters
        ----------
        X : pd.DataFrame
            各銘柄の特長量データセット
        y : pd.DataFrame
            各銘柄のリターンデータ      
        batch_size : int
            バッチサイズ
        stock_list : list
            銘柄のリスト
        factor_list : list
            特長量のリスト
        is_t_1 : bool, optional
            翌期の特長量データを使用する場合はTrue, by default True

        Raises
        ------
        ValueError
            pd.DataFrame出ない場合はエラー            
        """
        self.is_t_1 = is_t_1
        if not isinstance(X, pd.DataFrame) or not isinstance(y, pd.DataFrame):
            raise ValueError("X and y must be pd.DataFrame")
        self.X, self.y = X, y
        self.date_index = y.index
        self.batch_size = batch_size 
        self.factor_list = factor_list
        self.stock_list = stock_list

    def _iter_t_1(self, index_start, index_end):
        array_t = np.zeros((
            index_end - index_start,            
            len(self.stock_list), 
            len(self.factor_list))
            )
        array_t_1 = np.zeros((
            index_end - index_start,            
            len(self.stock_list), 
            len(self.factor_list))
            )
            
        for i, index_ in enumerate(range(index_start, index_end)):
            df_t = self.X.loc[self.X["Date"] == self.date_index[index_], :].drop(
                ["Date"], axis=1)
            df_t_1 = self.X.loc[self.X["Date"] == self.date_index[index_+1],
                                :].drop(["Date"], axis=1)
            df_combined = pd.merge(df_t, df_t_1, how="left", on="stock")
            df_combined = df_combined.set_index("stock")

            array_t[i,:,:] = df_combined.iloc[:, :int(
                len(self.factor_list))].values
            array_t_1[i,:,:] = df_combined.iloc[:, int(
                len(self.factor_list)):].values
        X_t_torch = torch.tensor(array_t).float()
        X_t_1_torch = torch.tensor(array_t_1).float()
        y_torch = torch.tensor(
            self.y.loc[self.date_index[index_start:index_end], :].values).float()
        
        return X_t_torch, X_t_1_torch, y_torch        

    def _iter_t(self, index_start, index_end):
        array_t = np.zeros((
            index_end - index_start,            
            len(self.stock_list), 
            len(self.factor_list))
            )
        for i, index_ in enumerate(range(index_start, index_end)):
            array_t[i,:,:] = self.X.loc[self.X["Date"] == self.date_index[index_], :].drop(
                ["Date"], axis=1).set_index("stock").values

        X_t_torch = torch.tensor(array_t).float()
        y_torch = torch.tensor(
            self.y.loc[self.date_index[index_start:index_end], :].values).float()

        return X_t_torch, y_torch
        
    def __iter__(self):
        """torch変換されたデータを作成するクラス

        Yields
        -------
        X_t_torch : torch.tensor
            t時点における各銘柄の特長量データセット
            (銘柄, 時点, バッチサイズ)
        X_t_1_torch : torch.tensor
            t+1時点における各銘柄の特長量データセット

            * is_t_1がTrueの場合，翌期の特長量データセット(X_t_1_torch)が作成

            * is_t_1がFalseの場合，t時点における各銘柄の特長量データセットのみ出力  
        y_torch : torch.tensor
            各時点における各銘柄のリターンデータ
        """            
        if self.is_t_1:        
            batch_set = math.floor((len(self.date_index)-1)/self.batch_size)
        else:
            batch_set = math.floor(len(self.date_index)/self.batch_size)           

        for t in range(batch_set):
            index_start = int(self.batch_size * t)                
            if self.is_t_1:
                if t+1 == batch_set:
                    index_end = len(self.date_index) - 1              
                else:
                    index_end = int(self.batch_size * (t+1))                
                yield self._iter_t_1(index_start, index_end)
            else:
                if t+1 == batch_set:
                    index_end = len(self.date_index)          
                else:
                    index_end = int(self.batch_size * (t+1))                
                yield self._iter_t(index_start, index_end)
                
                

class UtilityTrader:
    '''DNNの学習を行うクラス
    '''

    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        self.hyperparms = hyperparms
        self.stock_list = self.hyperparms["stock_list"]
        self.factor_list = self.hyperparms["factor_list"]
    
    def scale(self, X):
        """データの基準化

        * クロスセクション方向にランク化 → 平均0，標準偏差1に基準化

        Parameters
        ----------
        X : pd.DataFrame
            基準化前のデータ.

        Returns
        -------
        X_scale : pd.DataFrame
            基準化後のデータ.
        """
        date_indices = sorted(X["Date"].unique())
        X_scale = []
        for date_index in date_indices:
            X_ = X.loc[X["Date"] == date_index,:]
            temp = np.argsort(np.argsort(X_[self.factor_list], 0), 0)
            temp = temp.apply(lambda x: (x-x.mean())/ x.std(), axis=0)
            df_ = pd.concat([X_[["Date", "stock"]], temp], axis=1)
            X_scale.append(df_)
        
        X_scale = pd.concat(X_scale)
        
        return X_scale

    def fit(self, X, y, X_val=None, y_val=None):
        '''
        X : pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pandas.DataFrame
            被説明変数(時点,銘柄)
        '''
        X = self.scale(X)
        torch.manual_seed(self.hyperparms['random_state'])
        batch_size = min(self.hyperparms["batch_size"], y.shape[0])
        loader = XSDataLoader(X, y, batch_size, self.stock_list,
                              self.factor_list, is_t_1=self.hyperparms["is_cost"])
        
        if X_val is not None:
            loader_val = XSDataLoader(X_val, y_val, y_val.shape[0], self.stock_list,
                                  self.factor_list, is_t_1=self.hyperparms["is_cost"])
            is_val = True
        else:
            is_val = False

        loss_val_min = 10000**1000                    
        input_num = len(self.factor_list)
        model = UtilityNet(self.hyperparms, input_num)
        optimizer = torch.optim.Adam(
            model.parameters(), lr=self.hyperparms['lr'])
        criterion = UtilityLoss(
            self.hyperparms["utility_type"], 
            self.hyperparms["gamma"],
            self.hyperparms["leverage"])
        
        self.loss_save = []
        for epoch in range(self.hyperparms['epoch']):
            for X_t, y_t in loader:
                weight_t = model.forward(X_t)             
                loss = - criterion(y_t, weight_t)                
                
                # L2-normの正則化項を追加
                l2 = torch.tensor(0., requires_grad=True)
                for w in model.parameters():
                    l2 = l2 + self.hyperparms["l2_norm"]*torch.norm(w)**2
                loss = loss + l2
                
                optimizer.zero_grad()                    
                loss.backward()
                optimizer.step()                 
                            
            if is_val:
                with torch.no_grad():
                    for X_val, y_val in loader_val:
                        weight_val = model.forward(X_val)
                        loss_val = - criterion(y_val, weight_val).item()
                    if loss_val_min > loss_val:
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1
                    self.loss_save += [loss.item(), loss_val]                
                    
                print(f"{epoch+1}/{self.hyperparms['epoch']} train {round(loss.item(), 4)} val {round(loss_val, 4)}")
            else:                
                self.loss_save += [-loss.item()]
                print(f"{epoch+1}/{self.hyperparms['epoch']} train {round(loss.item(), 4)}")                
                
        self.model = model

    def predict(self, X):
        '''
        X : np.array or pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)        
        
        weight : np.dnarray
            テスト期間におけるポートフォリオのウェイト
        '''
        X = self.scale(X)
        time_ = int(X.shape[0]/len(self.stock_list))
        array_t = np.zeros((
            time_,            
            len(self.stock_list), 
            len(self.factor_list))
            )
        date_index = sorted(X["Date"].unique())
        for i, index_ in enumerate(range(time_)):
            array_t[i,:,:] = X.loc[X["Date"] == date_index[index_], :].drop(
                ["Date"], axis=1).set_index("stock").values

        X = torch.tensor(array_t).float()

        X = torch.Tensor(X)
        weight = self.model.forward(X)
        weight_add = weight/weight.shape[1]
        weight = torch.ones(weight.size())/weight.shape[1] + weight_add        

        return weight.detach().numpy().copy()
