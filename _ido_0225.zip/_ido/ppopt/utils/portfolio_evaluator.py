"""ポートフォリオのパフォーマンス測定を実施
"""
import pandas as pd
import numpy as np
from .util import calc_weight_diff, get_universe_slice_list


class Evaluator:
    """ポートフォリオのリターン情報をもとにポートフォリオのパフォーマンス指標を算出する

    Parameters
    ----------
    year_convert_num : int
        年率換算に使用する月数
        * 月次リターンから年率換算する場合, year_convert_num = 12
        * 日次リターンから年率換算する場合，year_convert_num = 250 (おおよその値) 
    """

    def __init__(self, year_convert_num):
        self.year_convert_num = year_convert_num
        self.bench_peformance = None
        self.rt_bench = None

    def calc_mdd(self, wealth):
        '''MDD (最大ドローダウン)を計算 

        Parameter
        ----------
        welath : pd.Series
            累積和リターンの推移

        Return
        -------
        mdd : float
            MDD (最大ドローダウン)
        '''
        mdd = np.max((np.maximum.accumulate(wealth) - wealth) /
                     np.maximum.accumulate(wealth), 0)
        return mdd

    def calc_performance_port(self, rt_port, result_name):
        """パフォーマンス指標(年率換算)を算出

        算出するパフォーマンス指標
        [1] 平均
        [2] 標準偏差
        [3] R/R (平均/標準偏差)
        [4] 下方半分散
        [5] DDRatio (平均/下方半分散)        
        [6] MDD (最大ドローダウン)

        Parameters
        ----------
        rt_port : pd.Series
            ポートフォリオのリターン
        result_name : str
            パフォーマンス結果のデータフレームに付与する名前

        Returns
        -------
        result : pd.Series
            年率換算したパフォーマンス指標
        """
        mean_year = rt_port.mean()*self.year_convert_num
        sd_year = np.sqrt(self.year_convert_num) * rt_port.std()
        SR_year = mean_year/sd_year
        lpm2_year = np.sqrt(self.year_convert_num)*np.sqrt(
            np.sum((rt_port[rt_port < 0]**2))/len(rt_port))
        DDR_year = mean_year/lpm2_year
        wealth = rt_port.cumsum()
        mdd = self.calc_mdd(wealth)

        result = pd.Series({
            "平均": mean_year,
            "標準偏差": sd_year,
            "R/R": SR_year,
            "半分散": lpm2_year,
            "DDRatio": DDR_year,
            "MDD": mdd,
        }, name=result_name)

        return result

    def _get_bench_performance(self, rt_bench):
        if self.bench_peformance is None and sum(self.rt_bench != rt_bench) > 0:
            self.bench_peformance = self.calc_performance_port(
                rt_bench, "bench")
            self.rt_bench = rt_bench

        return self.bench_peformance

    def calc_active_performance(self, rt_port, rt_bench, result_name):
        """アクティブリターンのパフォーマンス指標(年率換算)を算出

        算出するパフォーマンス指標
        [1] 平均アクティブリターン
        [2] TE (トラッキングエラー)
        [3] IR (インフォメーションレシオ)

        Parameters
        ----------
        rt_port : pd.Series
            ポートフォリオのリターン
        result_name : str
            パフォーマンス結果のデータフレームに付与する名前

        Returns
        -------
        result : pd.Series
            年率換算したアクティブリターンのパフォーマンス指標
        """
        acctive_mean_year = (rt_port - rt_bench).mean()*self.year_convert_num
        acctive_sd_year = np.sqrt(
            self.year_convert_num)*(rt_port-rt_bench).std()
        IR_year = acctive_mean_year/acctive_sd_year

        result = pd.Series({
            "平均アクティブリターン": acctive_mean_year,
            "TE": acctive_sd_year,
            "IR": IR_year,
        }, name=result_name)

        return result

    def calc_performance(self, rt_port, rt_bench, weight_diff, output_name):
        '''ポートフォリオのパフォーマンスを測定する関数

        Parameters
        ----------
        rt_port : pd.Series
            ポートフォリオのリターン
        rt_bench : pd.Series
            ベンチマークのポートフォリオのリターン
        weight_diff : pd.Series
            ポートフォリオのウェイト変化
        year_convert_num : int
            年率換算時に使用する営業日日数換算値
        output_name : str, optional
            出力するデータフレームの名前ラベル. The default is 'result'.

        Returns
        -------
        performance : pd.DataFrame
            ポートフォリオのパフォーマンス結果
        '''
        model_peformance = self.calc_performance_port(rt_port, output_name)
        bench_peformance = self._get_bench_performance(rt_bench)
        accrive_performance = self.calc_active_performance(
            rt_port, rt_bench, output_name)

        performance = pd.concat([model_peformance, accrive_performance])
        turnover = weight_diff.mean()
        performance["turnover"] = turnover
        performance = pd.concat([performance, bench_peformance], axis=1)

        return performance


class PortfolioEvaluator(Evaluator):
    '''ポートフォリオのパフォーマンスをもとめるクラス

    Parameters
    ----------
    y_port : pd.Series (MultiIndex("Date", "stock"))
        各投資対象銘柄の実績リターン.
    weight : pd.Series (MultiIndex("Date", "stock"))
        各投資対象銘柄への投資ウェイト
    hyperparms_portfolio : Dict[str: Any]
        以下4つのパラメータを設定
        wealth_init: float
            初期富
        cost: float
            取引コスト (定率の取引コスト)
        year_convert_num : int
            年率換算に使用する月数
            * 月次リターンから年率換算する場合, year_convert_num = 12
            * 日次リターンから年率換算する場合，year_convert_num = 250 (おおよその値) 

    Notes
    -----
    * 本機能では，累積和リターンを使用してポートフォリオのパフォーマンス指標を算出
    '''

    def __init__(self, y_port, weight, hyperparms_portfolio):
        super().__init__(hyperparms_portfolio["year_convert_num"])
        self.y_port = y_port
        self.weight = weight
        self.cost = hyperparms_portfolio['cost']
        self.wealth_init = hyperparms_portfolio['wealth_init']

    def _calc_bench_return(self, mode="equal_weight"):
        """ベンチマークポートフォリオのリターンを算出        

        Parameters
        ----------
        mode : str, optional
            ベンチマークポートフォリオのパターン名. The default is "equal_weight".

        Raises
        ------
        ValueError
            modeはequal_weight(等ウェイトポートフォリオ)のみに対応.

        Returns
        -------
        rt_bench : pd.Series(Index = 'Date')
            各時点におけるベンチマークポートフォリオのリターン.

        Notes
        -----
        * ベンチマークポートフォリオのリターン算出時においては，取引コストは控除していない
        """
        if mode == "equal_weight":
            weight_bench = np.zeros(self.weight.shape)
            date_indexes = sorted(self.weight.index.get_level_values("Date").unique())
            universe_index = get_universe_slice_list(self.weight.index, date_indexes)
            for universe in universe_index:
                stock_num = len(self.weight[universe])
                weight_bench[universe] = np.ones(stock_num)/stock_num
        else:
            raise ValueError(
                f"mode = {mode} : equal_weight以外には対応していません")

        rt_bench = (weight_bench*self.y_port).sum(level="Date")

        return rt_bench

    def calc_portfolio_return(self, cost=None):
        '''ポートフォリオの(取引コスト控除後)リターンを計算する

        Parameters
        ----------
        cost: float
            取引コスト(Noneの場合，hyperparamsで設定した値を参照)

        Returns
        -------
        rt_port : pd.DataFrame
            ポートフォリオの(取引コスト控除後)リターンと取引コスト

        Notes
        -----
        * 取引コストは両側取引コストとして定義
        * 初期時点のウェイト変化は0とする(初期時点は取引コストはかからないとしている)
        '''
        if cost is None:
            cost = self.cost

        weight_diff = calc_weight_diff(self.weight, self.y_port)
        data_index_first = self.weight.index.get_level_values("Date").unique().min()
        # 初期時点のウェイト変化は0とする
        self.weight_diff = pd.concat([
            pd.Series([0], index=[data_index_first]),
            weight_diff])
        cost_index = self.weight_diff * cost
        cost_index.name = "cost"
        rt_port = (self.weight*self.y_port).sum(level="Date") - cost_index
        rt_port.name = "port"
        rt_port = pd.concat([rt_port, cost_index], axis=1)

        return rt_port
    
    def calc_portfolio_performance(self, output_name):
        """ポートフォリオのウェイト

        Parameters
        ----------
        output_name : str
            辞書に付与する名前

        Returns
        -------
        result : Dict[str: Any]
            ポートフォリオのパフォーマンス指標を格納した辞書
            rt_port : pd.DataFrame
                ポートフォリオの(取引コスト控除後)リターンと取引コスト,
                ベンチマークポートフォリオのリターンを格納したデータフレーム       
            performance : pd.DtaFrame
                ポートフォリオのパフォーマンス結果                
        """
        rt_port = self.calc_portfolio_return()  # 取引コスト控除後リターンを算出
        rt_bench = self._calc_bench_return()
        performance = self.calc_performance(rt_port["port"], rt_bench, self.weight_diff, output_name)
        rt_port = pd.concat([rt_port, rt_bench], axis=1)
        result = {
            output_name: {
                "rt_port": rt_port,
                "performance": performance,
                }
            }
        
        print(performance)
        
        return result
