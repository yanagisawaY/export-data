from .lrp import LRP
from .portfolio_evaluator import PortfolioEvaluator
from .decorater import mystopwatch
from .util import get_universe_slice_list

import numpy as np


class Backtester:
    def __init__(self, hyperparms):
        self.hyperparms = hyperparms
        self.factor_list = hyperparms["factor_list"]        

    @mystopwatch
    def learn(self, estimator, X_train, y_train, X_val=None, y_val=None):
        """DNNのパラメータ学習

        Parameters
        ----------
        estimator : function(pytorch module)
            モデル.
        X_train : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(時点×銘柄, 特徴量)
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点×銘柄,)
        X_val : pd.DataFrame (MultiIndex("Date", "stock"))
            バリデーション期間における特徴量データ(時点, 特徴量)
            -> Noneの場合，バリデーションデータにおける評価値を計算しない            
        y_val : pd.Series (MultiIndex("Date", "stock"))
            バリデーション期間における被説明変数(時点×銘柄,)
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
            
        Returns
        -------
        estimator : function(pytorch module)
            学習済みモデル.
        
        Notes
        -----
        * is_tuneがTrueの場合，optunaを用いてハイパーパラメータを探索\n
        -> さらにis_pruneがTrueの場合，枝刈りアルゴリズムを使用してチューニングを実施
        -> 最終的に選ばれたハイパーパラメータを用いて再度学習を実施
        """                
        if self.hyperparms["is_tune"] and X_val is not None and y_val is not None:
            if self.hyperparms["is_prune"]:
                # 枝刈りアルゴリズムを使用
                estimator.tune_prune(
                        X_train,
                        y_train,
                        X_val,
                        y_val,
                    )
            else:
                # 枝刈りアルゴリズムを使用しない                
                estimator.tune(
                    X_train,
                    y_train,
                    X_val,
                    y_val,
                )
            self.hyperparms = estimator.update_hyperparams()
            
        estimator.fit(X_train, y_train, X_val, y_val)
        
        return estimator
    
    @mystopwatch
    def calc_weight(self, estimator, X_past, y_past, X_test, y_test):
        """ポートフォリオのウェイトをターンオーバー制約などの制限のもと算出

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        X_past : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_past : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点,)
        X_test : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト期間における特徴量データ(銘柄×時点, 特徴量)            
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)

        Returns
        -------
        weight_info : Dict[str: Dict[str: ...]]
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.
            weight_info[key] : dict
                weight : pd.DataFrame
                    ポートフォリオのウェイト
                theta : list
                    企業特性合成ポートフォリオへのウェイト
                status : list
                    最適化が成功したかどうかのリスト(中身はTrue or False)
                turnover : float
                    ターンオーバー制約の上限値
                target_risk : float
                    ターゲットリスクの上限値                
                weight_stockX : pd.DataFrame
                    リバランスする銘柄数をXと制約を課して調整したポートフォリオのウェイト
        """
        weight_train_i = estimator.predict(X_past, is_add_hidden_weight=True)                    
        weight_test_i = estimator.predict(X_test, is_add_hidden_weight=True)

        weight_info = {}        
        for turnover in self.hyperparms["turnover"]:
            for target_risk in self.hyperparms["target_risk"]:
                if turnover is None and target_risk is None:
                    theta_test_i = status_test_i = None
                elif turnover is None or target_risk is None:
                    continue
                else:
                    weight_test_i, theta_test_i, status_test_i = estimator.predict(
                        X_test, is_add_hidden_weight=True, rt_test=y_test, X_past=X_past, rt_past=y_past, turnover=turnover, target_risk=target_risk
                        )
                
                key_ = "to_" + str(turnover) + "_tr_" + str(target_risk)
                
                weight_info[key_] = {
                    "weight_train": weight_train_i,
                    "weight": weight_test_i,
                    "theta": theta_test_i,
                    "status": status_test_i,
                    "turnover": turnover,
                    "target_risk": target_risk,
                    }
                
                for stock_limit in self.hyperparms["stock_limit"]:
                    if stock_limit is None:
                        continue
                    weight_test_adjusted_i = estimator.adjust_weight(weight_test_i, y_test, stock_limit)
                    weight_info[key_].update({
                        "weight_stock" + str(stock_limit): weight_test_adjusted_i,
                        })
        
        assert len(weight_info) > 0,(
            "If the list of hyperparams['turnover'] contains None, " 
            + "then the list of hyperparams['target_risk'] must also contain None."
            )
        
        return weight_info
    
    @mystopwatch
    def calc_lrp(self, estimator, weight_info, X, y, mode):
        """LRPを用いて特徴量の貢献度を算出するメソッド

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        weight_info : Dict[str: Dict[str: ...]]
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト期間における特徴量データ(銘柄×時点, 特徴量)            
        y : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)

        Returns
        -------
        port_lrp : Dict[str: Dict[str: DataFrame]]
            各設定(turnoverやtarget_risk)ごとのLRPの結果．各辞書の値(val)は以下で構成
            port_lrp[key] : Dict[str: DataFrame]
                各時点のポートフォリオにおける特徴量の貢献度(企業特性合成ポートフォリオの特徴量の貢献度も結合させる)
                key : ["all", "hidden_0", ...,'hidden_X']
                val[key] : pd.DataFrame
                    hidden_Xポートフォリオにおける各時点の特徴量の貢献度
        """
        lrp = LRP(estimator, self.hyperparms)        
        date_list = sorted(y.index.get_level_values("Date").unique())        
        universe_index = get_universe_slice_list(y.index, date_list)
        hidden_lrp_dict = lrp.get_hidden_lrp(X, universe_index)
        hidden_port_lrp_dict = lrp.get_port_hidden_lrp(hidden_lrp_dict)               
        
        if mode=="train":
            port_lrp = lrp.calc_port_lrp(hidden_port_lrp_dict)
        elif mode=="test":
            port_lrp = {}
            for key, val in weight_info.items():
                theta = val["theta"]
                if theta is None:
                    port_lrp[key] = lrp.calc_port_lrp(hidden_port_lrp_dict)
                else:
                    port_lrp[key] = lrp.calc_port_lrp(hidden_lrp_dict, weight_active=theta)
        
        return port_lrp

    @mystopwatch
    def calc_port_return(self, weight_info, y_past, y_test):       
        """ポートフォリオ(+ 企業特性合成ポートフォリオ)のリターンを計算

        Parameters
        ----------
        weight_info : Dict[str: Dict[str: ...]]
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.
            see also calc_weight method
        y_past : pd.Series (MultiIndex("Date", "stock"))
            訓練期間におけるリターンデータ
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間におけるリターンデータ

        Returns
        -------
        port_past : Dict[pd.DataFrame]
            訓練期間中のポートフォリオ(+ 企業特性合成ポートフォリオ)のリターン
        port_test : Dict[pd.DataFrame]
            テストデータ期間中のポートフォリオ(+ 企業特性合成ポートフォリオ)のリターン
        """
        port_rt_past = {}
        port_rt_test = {}
        for pattern_name, weight_dict in weight_info.items():
            weight_past = weight_dict["weight_train"]
            port_rt_past[pattern_name] = (
                weight_past*np.repeat(y_past.values[:, np.newaxis],
                                      weight_past.shape[1], axis=1)).sum(level="Date")
            weight_test = weight_dict["weight"]
            port_rt_test[pattern_name] = (
                weight_test*np.repeat(y_test.values[:, np.newaxis],
                                      weight_test.shape[1], axis=1)).sum(level="Date")
        
        return port_rt_past, port_rt_test

    @mystopwatch    
    def get_port_performance(
            self, 
            weight_info, 
            y_past,
            y_test,
            hyperparms_portfolio, 
            output_name, 
            ):
        '''ポートフォリオのパフォーマンス結果を算出

        Parameters
        ----------
        weight_info : Dict[str: Dict[str: ...]]
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        y_past : pd.Series (MultiIndex("Date", "stock"))
            訓練期間におけるリターンデータ            
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間におけるリターンデータ
        hyperparms_portfolio : Dict[str: Any]
            ポートフォリオのパフォーマンス算出時に使用するパラメータ.
        output_name : str
            resultの列名.(任意な列名を設定可能)

        Returns
        -------
        result : Dict[str: Any]
            パフォーマンス結果とウェイトの情報を格納した辞書
            weight_infoの各valに格納されたweightに対し，以下の結果を格納
            index_portfolio : pd.DataFrame
                ポートフォリオのインデックス推移.
            performance : pd.DataFrame
                ポートフォリオのパフォーマンス結果.
        '''
        result = {}
        for pattern, weight_dict in weight_info.items():
            weight_list = [i for i in weight_dict.keys() if "weight" in i]            
            for key_ in weight_list:
                try:
                    weight = weight_dict[key_]["all"]
                except KeyError:
                    weight = weight_dict[key_]
                
                if "train" in key_:
                    pe = PortfolioEvaluator(y_past, weight, hyperparms_portfolio)
                else:
                    pe = PortfolioEvaluator(y_test, weight, hyperparms_portfolio)
                    
                result.update(pe.calc_portfolio_performance(
                    output_name="{}_{}".format(pattern, key_)))
        
        return result
            
            