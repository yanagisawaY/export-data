import os
import pandas as pd
import datetime as dt
print(os.getcwd())
PATH_HEAD = r'C:\Users\yana\Desktop\github\trade_index'
os.chdir(PATH_HEAD)
print('変更後'+os.getcwd())

sheet_names = pd.ExcelFile('data/input_data.xlsx').sheet_names
data_names = ['daily', 'week', 'ohlcv', 'month', 'irregular']
dfs_input = pd.read_excel('data/input_data.xlsx',
                          sheet_name=data_names, index_col=0)

for key, df in dfs_input.items():
    dfs_input[key].index = pd.to_datetime(df.index)

config = {
    'features': pd.read_excel('data/input_data.xlsx', sheet_name=['config_features'], index_col=0)['config_features'],
    'features_ohlcv': pd.read_excel('data/input_data.xlsx', sheet_name=['config_ohlcv_features'], index_col=0)['config_ohlcv_features'],
    'target_name': ['GJGB10 index'],  # 教師ラベル作成時に使用する指標(listとして入力)
    'trade_target': ['GJGB10 index'],  # リターン算出時に使用する指標(listとして入力)
    'config_target': {
        'type': 'trend_scan',  # trend_scan or 2018ver
        'scan_window': [7, 10, 1],   # ウェインドウ期間Lの探索範囲[Lの最小値, Lの最大値, 刻み幅]
        'flag_window_2018': 10,           # 2018年案件にて設定していた期間(int)
        'basis_bp_top': 10,           # 2018年案件にて設定していた閾値(bps)
        'basis_bp_sec': 3,            # 2018年案件にて設定していた閾値(bps)
    },
    'config_features': {
        'n_components': 16,  # PCA変換を実施する際の主成分数
    },
    'backtest_info': {
        # ハイパーパラメータ調整のためのバリデーションを実施する場合はTrue
        'validation_type': 'PurgedKFold',
        'is_expanding': True,                      # バックテストのウィンドウ期間を拡大する際に訓練期間を固定する場合True
        'start_date': dt.datetime(2010, 1, 1),   # データの使用開始時点
        'end_date': dt.datetime(2016, 12, 31),  # データの使用終了時点
        'train_month': 60,                        # 訓練期間
        'test_month': 6,  # テスト期間
        'relearn_month': 6,  # ウィンドウ期間
        'fast_valid': {
            'val_month': 12,  # バリデーション期間
        },
        'PurgedKFold': {
            'n_splits': 5,
            'pct_embargo': 0.01,
        }
    },
    'config_trade': {
        '2018ver': {
            'threshold': 0.2,  # TBD
        },
        'trend_scan': {
            'threshold': 1,  # 売買シグナルを出す閾値
        },
        'cost_buy': 0,  # 売買コスト(ロングサイド)
        'cost_sell': 0,  # 売買コスト(ショートサイド)
    },
    'model': 'dnn',
    'dnn': {
        'random_state': 1,            # 乱数シード
        'layer_dropout': 0.5,          # 中間層に適用するドロップアウト
        'layer_list': [24, 18, 16],  # 中間層のノード数(リストのサイズが中間層の数)
        'lr': 1e-3,         # 学習率
        'batch_size': 64,           # バッチサイズ
        'epoch': 500,          # エポック数
        'min_ephoch' : 100,
        'patience_max' : 30,  # 学習が改善しないepoch数の許容回数
        "is_val": True,  # 早期停止を行うかどうか        
        # 早期停止条件を課す際のバリデーションデータの割合(0~1を指定)．
        # validation_typeに'PurgedKFold'を指定しない場合のみに使用
        'val_early_stop': 0.1,  
    },
    'config_optuna': {
        'n_trials': 1,
        'timeout': 600,
    }
}
