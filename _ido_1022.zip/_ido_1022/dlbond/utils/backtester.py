"""
Notes:
    1.バックテストを実行するクラス
    2.データ加工からモデルの学習までを実施する最上位クラス
"""
import numpy as np
import pandas as pd
from dateutil.relativedelta import relativedelta

from dlbond.models.dnn import DeepLearner
from .split import Splitter


class Evaluator:
    def __init__(self):
        pass

    def calc_mdd(self, wealth):
        """MDD(Maximum Drawdown)を計算 

        Parameters
        ----------
        wealth : pd.Series
            トレードによる累積リターン

        Returns
        -------
        mdd : float
            MDD(Maximum Drawdown).
        """
        mdd = np.max((np.maximum.accumulate(wealth) - wealth) /
                     np.maximum.accumulate(wealth), 0)
        return mdd

    def calc_performance(self, trade_return, output_name='result', business_days=250):
        '''トレーディング戦略のパフォーマンスを測定する関数

        Parameters
        ----------
        wealth : pd.Series
            トレードによる累積リターン        
        trade_return : pd.Series
            トレーディング戦略のリターン.        
        output_name : str
            出力するデータフレームの名前ラベル. The default is 'result'.
        business_days : int
            年率換算時に使用する営業日日数換算値

        Returns
        -------
        output : pd.Series
            トレーディング戦略のパフォーマンス結果.
        '''
        mean_year = trade_return.mean()*business_days
        sd_year = ((np.sqrt(business_days) *
                   pd.DataFrame.std(trade_return, ddof=1)))
        SR_year = mean_year / sd_year
        lpm2_year = np.sqrt(
            business_days) * np.sqrt(np.sum((trade_return[trade_return < 0] ** 2))/len(trade_return))
        DDR_year = mean_year / lpm2_year

        output = pd.Series([mean_year, sd_year, SR_year, lpm2_year, DDR_year],
                           index=['平均(年率換算)', '標準偏差(年率換算)',
                                  'R/R(年率換算)', '半分散(年率換算)', 'DDRatio(年率換算)'],
                           name=output_name)

        return output

    def calc_performance_all(self, trade_return, wealth, output_name='result', business_days=250):
        '''トレーディング戦略のパフォーマンスを測定する関数

        Parameters
        ----------
        trade_return : pd.Series
            トレーディング戦略のリターン.        
        wealth : pd.Series
            トレードによる累積リターン            
        output_name : str
            出力するデータフレームの名前ラベル. The default is 'result'.
        business_days : int
            年率換算時に使用する営業日日数換算値

        Returns
        -------
        output : pd.Series
            トレーディング戦略のパフォーマンス結果.
        '''
        output = self.calc_performance(
            trade_return, output_name, business_days)
        output['MDD'] = self.calc_mdd(wealth)

        return output


class Trader:
    def __init__(self, config):
        self.config = config
        self.cost_buy = config['config_trade']['cost_buy']
        self.cost_sell = config['config_trade']['cost_sell']

    def make_signal(self, y_pred):
        """予測値をもとに売買シグナルを作成

        Parameters
        ----------
        y_pred : pd.Series
            予測値

        Returns
        -------
        signal : pd.Series
            売買シグナル
        """
        target_type = self.config['config_target']['type']
        if target_type == 'trend_scan':
            threshold = self.config['config_trade'][target_type]['threshold']
            signal = 1*(y_pred >= threshold) - 1*(y_pred <= -threshold)
        else:
            raise ValueError(
                'current version is only supported trend_scan. please wait for some updates coming soon...')

        return signal

    def calc_tradecost(self, signal):
        """投資量を固定した場合の取引コストを算出(取引コストは売り買いそれぞれで設定)

        Parameters
        ----------
        signal : pd.Series
            売買シグナル

        Returns
        -------
        cost_index : pd.Series
            売買コスト
        """
        signal = pd.Series(signal)
        weight_diff = signal.diff().fillna(0).copy()  # 投資量を常に固定した場合のウェイト変化を算出
        cost_index = np.abs(weight_diff.fillna(0)*(weight_diff > 0))*self.cost_buy + \
            np.abs(weight_diff.fillna(0)*(weight_diff < 0))*self.cost_sell

        return cost_index

    def calc_wealth(self, futures_return, signal):
        """トレードの結果の富の計算

        Parameters
        ----------
        futures_return : pd.Series
            トレーディング対象のリターン.
        signal : pd.Series
            売買シグナル

        Returns
        -------
        wealth : pd.Series
            トレードによる累積リターン

        Note
        -------
        富の計算式は以下を参照(参照先(1)式の無リスクリターンを0としたものを使用)
        http://papers.neurips.cc/paper/1551-reinforcement-learning-for-trading.pdf
        """
        cost_index = self.calc_tradecost(signal)
        trade_return = futures_return*signal
        cost_index.index = trade_return.index
        wealth = ((1 + trade_return)*(1 - cost_index)).cumprod()

        return trade_return, wealth


class BackTester:
    def __init__(self, dfs_input, config):
        self.sp = Splitter(dfs_input, config)
        self.tr = Trader(config)
        self.ev = Evaluator()
        self.config = config
        self.backtest_info = config['backtest_info']
        self.is_validation = (
            self.backtest_info['validation_type'] == 'fast_valid')
        self.check_backtest_setting()
        self.update_config()

    def update_config(self):
        """config辞書を更新
        """
        if self.config['config_target']['type'] == '2018ver':
            self.config['dnn'].update({'loss': '3class'})
        else:
            self.config['dnn'].update({'loss': 'MSELoss'})

        if self.config['model'] == 'dnn':
            self.config['backtest_info']['PurgedKFold'].update(
                {'lookback_window': 0})

    def check_backtest_setting(self):
        """バックテストの開始日と終了日の確認
        """
        assert self.backtest_info['start_date'] >= self.sp.index_date.min()
        assert self.backtest_info['end_date'] <= self.sp.index_date.max()

    def _make_backtest_term(self, start_date_train, term):
        """バックテストにおける各時点インデックスを格納した辞書を返す

        Parameters
        ----------
        start_date_train : pandas.core.indexes.datetimes.DatetimeIndex
            訓練期間の開始時点
        term : int
            訓練期間の終了時点をスライドさせる整数

        Returns
        -------
        dict_term : dict
            訓練(バリデーション)/テスト期間のインデックス時点が格納された辞書

        Note
        -------            
            テスト期間の終了時点がデータの最終時点を超えた場合，'end'と出力
        """
        train_month = self.backtest_info['train_month'] + \
            term*self.backtest_info['relearn_month']
        test_month = self.backtest_info['test_month']
        if self.is_validation:
            val_month = self.backtest_info['fast_valid']['val_month']

        end_date_train = start_date_train + \
            relativedelta(months=train_month) - relativedelta(days=1)
        if self.is_validation:
            start_date_val = end_date_train + relativedelta(days=1)
            end_date_val = start_date_val + \
                relativedelta(months=val_month) - relativedelta(days=1)
            start_date_test = end_date_val + relativedelta(days=1)
            end_date_test = start_date_test + \
                relativedelta(months=test_month) - relativedelta(days=1)
            dict_term = {
                'start_date_train': start_date_train,
                'end_date_train': end_date_train,
                'start_date_val': start_date_val,
                'end_date_val': end_date_val,
                'start_date_test': start_date_test,
                'end_date_test': end_date_test,
            }
        else:
            start_date_test = end_date_train + relativedelta(days=1)
            end_date_test = start_date_test + \
                relativedelta(months=test_month) - relativedelta(days=1)
            dict_term = {
                'start_date_train': start_date_train,
                'end_date_train': end_date_train,
                'start_date_test': start_date_test,
                'end_date_test': end_date_test,
            }

        if end_date_test < self.sp.index_date.max():
            return dict_term
        else:
            return 'end'

    def make_backtest_terms(self):
        """バックテストにおける各時点インデックスの辞書を全繰り返し分作成する

        Returns
        -------
        dict_terms : dict
            訓練(バリデーション)/テスト期間のインデックス時点が全繰り返し分格納された辞書
        """
        start_date_train = self.backtest_info['start_date']
        end_date = self.backtest_info['end_date']
        relearn_month = self.backtest_info['relearn_month']
        is_expanding = self.backtest_info['is_expanding']
        term = ((end_date.year-start_date_train.year+1)*12 +
                max(end_date.month-start_date_train.month, 0))/relearn_month
        term = int(term)
        dict_terms = {}
        dict_terms[0] = self._make_backtest_term(start_date_train, term=1)

        for i in range(1, term):
            if is_expanding:
                dict_temp = self._make_backtest_term(start_date_train, term=i)
            else:
                start_date_train += relativedelta(months=relearn_month)
                dict_temp = self._make_backtest_term(start_date_train, term=0)

            if dict_temp == 'end':
                break
            else:
                dict_terms[i] = dict_temp

        return dict_terms

    def validate(self, dict_term):
        """バリデーションによりハイパーパラメータをチューニングする

        Parameters
        ----------
        dict_term : dict
            訓練(バリデーション)/テスト期間のインデックス時点が格納された辞書

        Returns
        -------
        hyperparms_best : dict
            optunaにより選択されたハイパーパラメータ
        """
        X_train, y_train, X_val, y_val = self.sp.make_dataset(
            dict_term['start_date_train'],
            dict_term['end_date_train'],
            dict_term['start_date_val'],
            dict_term['end_date_val']
        )
        X_val = X_val.loc[y_val.index, :]
        model = DeepLearner(hyperparms=self.config[self.config['model']])
        model.tune(X_train, y_train, X_val, y_val)
        hyperparms_best = model.update_hyperparams()

        return hyperparms_best

    def validate_Kfold(self, dict_val):
        """KFoldによるクロスバリデーションによりハイパーパラメータの探索を実施

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Notes
        -----
        optunaの枝刈り機能は計算を高速にする一方，クロスバリデーションの際の適用方法は参照[1]の記載の通り，
        決まった方法がないと考えられる．本メソッドでは，参照[1]をもとに，
        「ホールドアウトのところは普通に枝刈りを導入し，枝刈りされず残ったパラメータの候補の全部か一部を枝刈りなしの
        CV の対象にする」方法をとることとした．

        References
        ----------
        [1] https://medium.com/@tomoto/optuna%E3%81%AEpruning%E3%81%8C%E6%8A%B1%E3%81%88%E3%82%8B%E8%AA%B2%E9%A1%8C-1a1c9dd870df
        """
        trials = {}
        # Holdごとに枝刈りを導入したハイパーパラメータ探索を実施
        for i, dict_ in enumerate(dict_val.values()):
            (X_train, y_train, X_val, y_val) = dict_.values()
            model = DeepLearner(hyperparms=self.config[self.config['model']])
            model.tune(X_train, y_train, X_val, y_val)

            for j, trial_ in enumerate(model.study.trials):
                # 枝刈りされず残ったパラメータの候補
                if str(trial_.state) == "TrialState.COMPLETE":
                    trials.update({str(i)+'_'+str(j): trial_})

        # 枝刈りされずに残ったパラメータを用いてクロスバリデーションを実施(枝刈りなし)
        e_val = pd.Series(list(range(len(trials))), index=list(trials.keys()))
        loss_min = 100000**10000
        for i, (_, trial_) in enumerate(trials.items()):
            model = DeepLearner(
                hyperparms=self.config[self.config['model']]
                )
            model.fit_cv(dict_val)
            e_val.iloc[i] = model.loss_sum
            if loss_min > model.loss_sum:
                loss_min = model.loss_sum
                best_model = model
                # 候補のうち，最もCVのスコアがよかったパラメータを記録
                hyperparms_best = trial_.params

        hyperparms_best = model.update_hyperparams(
            hyperparms_best_updated=hyperparms_best
            )

        self.e_val = e_val

        return model, hyperparms_best

    def backtest(self, dict_term, output_name):
        """1つの訓練期間パターンでバックテストを実施

        Parameters
        ----------
        dict_term : dict
            訓練(バリデーション)/テスト期間のインデックス時点が格納された辞書
        output_name : str
            出力するデータフレームの名前ラベル.

        Returns
        -------
        result : dict
            バックテストの結果を格納した辞書

        Raises
        ------
        バリデーションを実施する場合のパターンは後で作成
        """
        result = {}
        result['term'] = pd.DataFrame.from_dict(dict_term, orient='index').T
        if self.backtest_info['validation_type'] == 'fast_valid':
            hyperparms_best = self.validate(dict_term)
            X_train, y_train, X_test, _ = self.sp.make_dataset(
                dict_term['start_date_train'],
                dict_term['end_date_val'],
                dict_term['start_date_test'],
                dict_term['end_date_test']
            )
            model = DeepLearner(hyperparms=hyperparms_best)            
            model.fit(X_train, y_train, is_val=self.config[self.config['model']]["is_val"])
        elif self.backtest_info['validation_type'] == 'PurgedKFold':
            dict_val, X_test, _ = self.sp.make_dataset_valid(**dict_term)
            model, hyperparms_best = self.validate_Kfold(dict_val)
            X_train, y_train, X_test, _ = self.sp.make_dataset(**dict_term)
        else:
            X_train, y_train, X_test, _ = self.sp.make_dataset(**dict_term)
            model = DeepLearner(hyperparms=self.config[self.config['model']])
            model.fit(X_train, y_train, is_val=self.config[self.config['model']]["is_val"])

        y_pred = model.predict(X_test)
        futures_return = self.sp.futures_return.loc[X_test.index,
                                                    self.config['trade_target'][0]]
        signal = pd.Series(self.tr.make_signal(
            y_pred), index=futures_return.index)
        y_pred = pd.Series(y_pred, index=futures_return.index)
        trade_return, wealth = self.tr.calc_wealth(futures_return, signal)
        result['y_pred'] = y_pred
        result['signal'] = signal
        result['return'] = trade_return
        result['wealth'] = wealth
        result['performance'] = self.ev.calc_performance_all(
            trade_return,
            wealth,
            output_name,
            business_days=250
        )

        return result

    def summarize_results(self, results):
        """全期間を通したバックテスト結果を算出

        Parameters
        ----------
        results : dict
            すべての繰り返し分のバックテスト結果を格納した辞書

        Returns
        -------
        result_all : dict
            全期間を通したバックテスト結果を格納した辞書                
        """
        df_performance = []
        signals = []
        returns = []
        y_preds = []
        keys = []
        for key, result in results.items():
            temp = pd.concat([result['performance'], result['term'].T])
            keys += [key]
            df_performance.append(temp)
            signals.append(result['signal'])
            returns.append(result['return'])
            y_preds.append(result['y_pred'])

        df_performance = pd.concat(df_performance, axis=1)
        df_performance.columns = keys
        signals = pd.concat(signals)
        returns = pd.concat(returns)
        y_preds = pd.concat(y_preds)
        futures_return = self.sp.futures_return.loc[returns.index,
                                                    self.config['trade_target'][0]]
        trade_returns, wealth_all = self.tr.calc_wealth(
            futures_return, signals)
        performance_all = self.ev.calc_performance_all(
            returns, wealth_all, output_name='all', business_days=250)
        df_performance = pd.concat([performance_all, df_performance], axis=1)

        result_all = {
            'performance': df_performance,
            'signal': signals,
            'wealth': wealth_all,
            'return': returns,
            'y_pred': y_preds,
        }

        return result_all

    def backtest_all(self):
        """configにて実施した設定でバックテストを実施(最上位に位置するメソッド)

        Returns
        -------
        results : dict
            すべての繰り返し分のバックテスト結果を格納した辞書
        result_all : dict
            全期間を通したバックテスト結果を格納した辞書                
        """
        results = {}
        dict_terms = self.make_backtest_terms()
        for i, dict_term in dict_terms.items():
            print(f'実行中{str(i+1)}/{len(dict_terms)}')
            output_name = 'term'+str(i)
            results[output_name] = self.backtest(dict_term, output_name)

        result_all = self.summarize_results(results)

        return results, result_all
