import dash_core_components as dcc
from dash_core_components.Markdown import Markdown
import dash_html_components as html
import pathlib
import glob
import os


class TreePath:
    def __init__(self):
        self.text = ""
    
    def tree(self, path, layer=0, is_last=False, indent_current='　'):
        """ファイルのツリー構造を出力
        
        Notes
        -----
        https://qiita.com/horisuke/items/389ec60407b3baf45f25
        """
        if not pathlib.Path(path).is_absolute():
            path = str(pathlib.Path(path).resolve())

        # カレントディレクトリの表示
        current = path.split('/')[::-1][0]
        if layer == 0:
            self.text += '<'+current+'>'
        else:
            self.text += "\n"            
            branch = '└' if is_last else '├'
            self.text += '{indent}{branch}<{dirname}>'.format(indent=indent_current, branch=branch, dirname=current)

        # 下の階層のパスを取得
        paths = [p for p in glob.glob(path+'/*') if os.path.isdir(p) or os.path.isfile(p)]
        def is_last_path(i):
            return i == len(paths)-1

        # 再帰的に表示
        for i, p in enumerate(paths):

            indent_lower = indent_current
            if layer != 0:
                self.text += "\n"
                indent_lower += '　　' if is_last else '│　'

            if os.path.isfile(p):
                self.text += "\n"
                branch = '└' if is_last_path(i) else '├'
                self.text += '{indent}{branch}{filename}'.format(indent=indent_lower, branch=branch, filename=p.split('/')[::-1][0])
            if os.path.isdir(p):
                self.tree(p, layer=layer+1, is_last=is_last_path(i), indent_current=indent_lower)
                
    
def set_path(path='initial value'):
    tp = TreePath()    
    tp.tree(path)
    folder_markdown = f"""
    --------------------------------------------------
    {tp.text}
    """
    return html.Div([ 
        dcc.Input(
            id='path-temp', 
            value=path, 
            type='text'
        ),
        html.Button(
            id='my-botton_1', 
            n_clicks=0, 
            children='set folder'
            ),        
        # html.Div(id='my-div'),
        html.H4(children='Folder Stucture'),        
        dcc.Markdown(
            id='folder-structure',
            children=folder_markdown,            
            ),        
    ])