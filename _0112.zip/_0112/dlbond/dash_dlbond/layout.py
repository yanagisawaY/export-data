from os import access
import dash_core_components as dcc
import dash_html_components as html
import dash_table
import pandas as pd

# import from self-made modules
from .utils.generate_table import generate_table
from .utils.select_result import select_result
from .utils.set_path import set_path
from .pages.access_results import get_model_select
from .markdown.title import title_markdown
from .markdown.app_description import description_markdown, description_data
from .pages.plot_data import get_info_terms

# common setting
from .load_data import dfs_input
from ..utils.ensemble import get_models_info, ModelEnsembler
models_info = get_models_info()
ensembler = ModelEnsembler(dfs_input, models_info)

tab_selected_style = {
    "backgroundColor": "rgb(0, 0, 118)",
    "color": "white",
    "fontWeight": "bold",
}

this_layout = html.Div(
    children=[
        
        # Top tile
        dcc.Markdown(children=title_markdown),
        
        # tab        
        dcc.Tabs([
            # 1st Tab
            dcc.Tab(
                label="README",
                value='readme',
                selected_style=tab_selected_style,                        
                children=[
                    dcc.Markdown(children=description_markdown),
                ]
            ),
                        
            # 2nd Tab
# =============================================================================
#             dcc.Tab(
#                 label="backtest",
#                 value='reference',
#                 selected_style=tab_selected_style,                                        
#                 children=[
#                     html.H4(children='↓ モデルとタイムスタンプを選択'),
#                 ]
#             ),
# =============================================================================

            # 3rd Tab                        
            dcc.Tab(
                label="データ特性の確認",
                value='data table',
                selected_style=tab_selected_style,                                        
                children=[
                    html.Div([
                        get_info_terms(ensembler),                  
                        ]
                    ),
                ]
            ),

            # 4th Tab            
            dcc.Tab(
                label="全期間のバックテストサマリー",
                value='performance_summary_all',
                selected_style=tab_selected_style,                                        
                children=[
                    html.Button("PUSH ME", id="add_drop", n_clicks=0),
                    html.Div(id="model_dropdown", children=[]),                    
                ],
            ),            
        ],),
    ],
)
