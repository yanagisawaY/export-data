"""
Notes:
    1.バックテストを実行するクラス
    2.データ加工からモデルの学習までを実施する最上位クラス
"""
import numpy as np
import pandas as pd
import os
import datetime as dt
from dateutil.relativedelta import relativedelta

from ..models.dnn import DeepLearner
from ..models.booster import BoostLearner
from ..models.ensembler import EnsembleLearner
from .split import Splitter
from .storage import Storage
from .evaluator import Evaluator
from .trader import Trader

class BackTester:
    def __init__(self, dfs_input, config):
        self.sp = Splitter(dfs_input, config)
        self.tr = Trader(config)
        self.ev = Evaluator()
        self.config = config
        self.backtest_info = config['backtest_info']
        self.update_config(self.config['model'])
        
        self.path = os.getcwd()
        self.storage = Storage(now=dt.datetime.now().strftime("%Y%m%d_%H%M%S"), path=self.path)        
        self.estimator = self._call_estimator(self.config['model'])
    
    def _call_estimator(self, model_name):
        assert model_name in ["dnn", "lightgbm", "xgboost", "extratrees"]
        hyperparms = self.config[model_name]
        hyperparms.update({"model": model_name})
        
        estimator = {
            "dnn": DeepLearner,
            "lightgbm": BoostLearner,
            "xgboost": BoostLearner,            
            "extratrees": EnsembleLearner,
        }[model_name]
        estimator = estimator(hyperparms)
        
        return estimator    

    def update_config(self, model_name):
        """config辞書を更新
        """
        if self.config['config_target']['type'] == '2018ver':
            self.config[model_name].update({'loss': '3class'})
        elif self.config['config_target']['type'] == 'trend_scan_val':
            self.config[model_name].update({'loss': 'MSELoss'})
        elif self.config['config_target']['type'] == 'trend_scan_class':
            self.config[model_name].update({'loss': '2class'})
            
        if model_name in ["dnn", "lightgbm", "xgboost", "extratrees"]:
            self.config['backtest_info']['PurgedKFold_nonprune'].update(
                {'lookback_window': 0})
            self.config['backtest_info']['PurgedKFold_prune'].update(
                {'lookback_window': 0})            
            self.config['backtest_info']['PurgedKFold_nontune'].update(
                {'lookback_window': 0})            

    def check_backtest_setting(self, start_date, end_date):
        """バックテストの開始日と終了日の確認
        """
        assert start_date >= self.sp.index_date.min()
        assert end_date <= self.sp.index_date.max()

    def _make_backtest_term(self, start_date_train, term):
        """バックテストにおける各時点インデックスを格納した辞書を返す

        Parameters
        ----------
        start_date_train : pandas.core.indexes.datetimes.DatetimeIndex
            訓練期間の開始時点
        term : int
            訓練期間の終了時点をスライドさせる整数

        Returns
        -------
        dict_term : dict
            訓練(バリデーション)/テスト期間のインデックス時点が格納された辞書

        Note
        -------            
        * テスト期間の終了時点がデータの最終時点を超えた場合，'end'と出力
        
        * バックテスト期間の分割期間が最後のものは，データの最終時点までをテスト期間とする
        """
        train_month = self.backtest_info['train_month'] + \
            term*self.backtest_info['relearn_month']
        test_month = self.backtest_info['test_month']

        end_date_train = start_date_train + \
            relativedelta(months=train_month) - relativedelta(days=1)

        start_date_test = end_date_train + relativedelta(days=1)

        end_date_test_next = start_date_test + \
            relativedelta(months=test_month*2) - relativedelta(days=1)        

        end_date_test = start_date_test + \
            relativedelta(months=test_month) - relativedelta(days=1)
                
        if end_date_test_next > self.sp.index_date.max() and end_date_test < self.sp.index_date.max():
            # バックテスト期間の分割期間が最後のものは，データの最終時点までをテスト期間とする
            end_date_test = self.sp.index_date.max()
        
        dict_term = {
            'start_date_train': start_date_train,
            'end_date_train': end_date_train,
            'start_date_test': start_date_test,
            'end_date_test': end_date_test,
        }
        
        if end_date_test <= self.sp.index_date.max():
            return dict_term    
        else:
            return 'end'

    def make_backtest_terms(self, start_date, end_date, relearn_month, is_expanding):
        """バックテストにおける各時点インデックスの辞書を全繰り返し分作成する

        Returns
        -------
        dict_terms : dict
            訓練(バリデーション)/テスト期間のインデックス時点が全繰り返し分格納された辞書
        """
        self.check_backtest_setting(start_date, end_date)
        term = ((end_date.year-start_date.year+1)*12 +
                max(end_date.month-start_date.month, 0))/relearn_month
        term = int(term)
        dict_terms = {}
        start_date_train = start_date
        dict_terms[0] = self._make_backtest_term(start_date_train, term=1)

        for i in range(1, term):
            if is_expanding:
                dict_temp = self._make_backtest_term(start_date_train, term=i)
            else:
                start_date_train += relativedelta(months=relearn_month)
                dict_temp = self._make_backtest_term(start_date_train, term=0)

            if dict_temp == 'end':
                break
            else:
                dict_terms[i] = dict_temp

        return dict_terms
    
    def validate_Kfold_nonprune(self, dict_val):
        """KFoldによるクロスバリデーションによりハイパーパラメータの探索を実施

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Notes
        -----
        枝刈りを使用しない．

        References
        ----------
        [1] https://medium.com/@tomoto/optuna%E3%81%AEpruning%E3%81%8C%E6%8A%B1%E3%81%88%E3%82%8B%E8%AA%B2%E9%A1%8C-1a1c9dd870df
        """
        if "is_val" in self.config[self.config['model']].keys():
            is_val = self.config[self.config['model']]["is_val"]
        else:
            is_val = None
            
        model = self._call_estimator(self.config['model'])
        model.tune_Kfold_nonprune(
            dict_val, 
            is_val, 
            self.config["config_optuna"]["n_trials"],
            self.config["config_optuna"]["timeout"])
        hyperparms_best = model.update_hyperparams()
        model.fit_cv(dict_val)            
        
        return model, hyperparms_best
    
    def _learn_model(self, dict_term):
        """モデルの学習を実施

        Parameters
        ----------
        dict_term : dict
            訓練(バリデーション)/テスト期間のインデックス時点が格納された辞書

        Returns
        -------
        model : 
            学習済みモデル.
        X_test : pd.DataFrame
            テスト期間の説明変数データ.
        """
        if self.backtest_info['validation_type'] == 'PurgedKFold_nonprune':
            dict_val, X_test, _, processor_save = self.sp.make_dataset_valid(**dict_term)
            model, hyperparms_best = self.validate_Kfold_nonprune(dict_val)
            X_train, y_train, X_test, _, _ = self.sp.make_dataset(**dict_term)
        elif self.backtest_info['validation_type'] == 'PurgedKFold_nontune':
            dict_val, X_test, _, processor_save = self.sp.make_dataset_valid(**dict_term)
            model = self._call_estimator(self.config['model'])
            model.fit_cv(dict_val)
            X_train, y_train, X_test, _, _ = self.sp.make_dataset(**dict_term)                        
        else:
            X_train, y_train, X_test, _, processor_save = self.sp.make_dataset(**dict_term)
            model = self._call_estimator(self.config['model'])
            model.fit(X_train, y_train, is_val = self.config[self.config['model']]["is_val"])
        
        model.processor_save = processor_save
        
        return model, X_test
        
    def backtest(self, dict_term, output_name):
        """1つの訓練期間パターンでバックテストを実施

        Parameters
        ----------
        dict_term : dict
            訓練(バリデーション)/テスト期間のインデックス時点が格納された辞書
        output_name : str
            出力するデータフレームの名前ラベル.

        Returns
        -------
        result : dict
            バックテストの結果を格納した辞書

        Raises
        ------
        バリデーションを実施する場合のパターンは後で作成
        """
        result = {}

        model, X_test = self._learn_model(dict_term)
        
        if sum(["extracted_columns" in list(self.config.keys())]) == 0:
            # 使用した特徴量の列名を保存
            self.config["extracted_columns"] = X_test.columns
            
        y_pred = model.predict(X_test)
        futures_return = self.sp.futures_return.loc[
            X_test.index,
            self.config['trade_target'][0]
            ]
        try:
            signal = pd.Series(self.tr.make_signal(
                y_pred), index=futures_return.index)
            y_pred = pd.Series(y_pred, index=futures_return.index)
        except ValueError:
            signal = pd.Series(self.tr.make_signal(
                y_pred[:,1]), index=futures_return.index)
            y_pred = pd.Series(y_pred[:,1], index=futures_return.index)            
        
        trade_return, wealth = self.tr.calc_wealth(futures_return, signal)        
        output, output_trade, cm_all = self.ev.calc_performance_all(
            trade_return,
            wealth,
            futures_return,
            signal,
            output_name,
            business_days=250
        )

        result.update({
            "term": pd.DataFrame.from_dict(dict_term, orient='index').T,
            "y_pred": y_pred,
            "signal": signal,
            "return": trade_return,
            "wealth": wealth,
            "performance": output_trade,
            "confusion": cm_all,
            })        
        
        model.trader = self.tr
        self.storage.save(model, result, file_name=output_name)

        return result

    def summarize_results(self, results):
        """全期間を通したバックテスト結果を算出

        Parameters
        ----------
        results : dict
            すべての繰り返し分のバックテスト結果を格納した辞書

        Returns
        -------
        result_all : dict
            全期間を通したバックテスト結果を格納した辞書                
        """
        signals = []
        returns = []
        y_preds = []
        keys = []
        for key, result in results.items():
            keys += [key]
            signals.append(result['signal'])
            returns.append(result['return'])
            y_preds.append(result['y_pred'])
           
        signals = pd.concat(signals)
        returns = pd.concat(returns)
        y_preds = pd.concat(y_preds)
        futures_return = self.sp.futures_return.loc[returns.index,
                                                    self.config['trade_target'][0]]
        trade_returns, wealth_all = self.tr.calc_wealth(
            futures_return, signals)
        performance_all, output_trade, cm_all = self.ev.calc_performance_all(
            returns, 
            wealth_all, 
            futures_return,
            signals,            
            output_name='all', 
            business_days=250)

        result_all = {
            'performance': output_trade,
            'signal': signals,
            'wealth': wealth_all,
            'return': returns,
            'y_pred': y_preds,
        }

        return result_all

    def backtest_all(self, output_name="exam"):
        """configにて実施した設定でバックテストを実施(最上位に位置するメソッド)

        Returns
        -------
        results : dict
            すべての繰り返し分のバックテスト結果を格納した辞書
        result_all : dict
            全期間を通したバックテスト結果を格納した辞書                
        """
        results = {}        
        start_date_train = self.backtest_info['start_date']
        end_date = self.backtest_info['end_date']
        relearn_month = self.backtest_info['relearn_month']
        is_expanding = self.backtest_info['is_expanding']
        dict_terms = self.make_backtest_terms(
            start_date_train, end_date, relearn_month, is_expanding
            )
        for i, dict_term in dict_terms.items():
            print(f'実行中{str(i+1)}/{len(dict_terms)}')
            output_name_i = output_name + '/term'+str(i)
            output_name_i_temp = output_name + '_term'+str(i)            
            results[output_name_i_temp] = self.backtest(dict_term, output_name_i)

        result_all = self.summarize_results(results)
        # 結果の保存
        self.storage.save_result_all(result_all, file_name=output_name)
        self.storage.save_config(self.config)

        return results, result_all
