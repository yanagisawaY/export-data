# -*- coding: utf-8 -*-
"""
Created on Thu Jan 13 03:28:29 2022

@author: yana
"""


import pandas as pd
import numpy as np
import os
import glob
import datetime as dt
import shap

os.chdir(r"C:\Users\yana\Desktop\github\trade_index\notebooks")
from set_init import dfs_input, config, config_meta
from dlbond.utils.backtest_miner import BacktestMiner


bm = BacktestMiner(dfs_input, config, config_meta)
result = bm.mining(output_name="temp_mining")
