from ensemble import get_models_result, get_models_info, ModelEnsembler


class MetaBacktester(ModelEnsembler):
    def __init__(self, dfs_input, models_info):
        super().__init__(dfs_input, models_info)
    

