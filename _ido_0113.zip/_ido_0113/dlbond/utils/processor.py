"""
Notes:
    1.データ作成/処理のコード
    2.tech_maker.pyにて定めたDataMaker(テクニカル指標作成のクラス)を継承
    3.tech_funcにて定めたテクニカル指標作成関数を用いて処理を実施
"""
import pandas as pd
from dlbond.utils.tech_maker import DataMaker
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.decomposition import PCA
from .trend_scan import trend_scan

class Processor(DataMaker):
    """データ処理等を実施するクラス

    Parameters
    ----------
    DataMaker : class
        dfs_input : dict
            インプットデータが格納され辞書
        config : dict
            諸々の設定が格納され辞書        
    """    
    def __init__(self, dfs_input, config):
        super().__init__(dfs_input, config)
        self.config = config        
        self.config_features = config['config_features']
        self._check_input()        
        self.build_dataset()        
    
    def _check_input(self):
        assert isinstance(self.config, dict)
        assert isinstance(self.config['target_name'], list), (
            'Please input config["target_name"] as list even if only using one target.'
        )                
        return super()._check_input()

    def convert_target_flag(self, target_raw):
        """目的変数を10bs, 3bpを境に3分類にラベリング(2018年ロジック)

        Parameters
        ----------
        target_raw : pd.Series
            ターゲット指標のローデータ

        Returns
        -------
        flag : pd.Series
            ラベリング後のターゲット指標
        t1 : pd.Series
            リーケージに関する時点が格納されたインデックス(split.PurgedKFoldにて使用)

        Note
        -------
        リーケージ防止のため，flag_window_2018個のデータを最終時点から取り除いている
        """
        config = self.config['config_target']
        window = config['flag_window_2018']        
        diff = target_raw.shift(-1).rolling(window-1).max().shift(-window+1) - target_raw # 2日後～10日後の金利の最大値との差分
        flag_ = 2*(diff>config['basis_bp_top']*0.01) + 1*(diff<=config['basis_bp_top']*0.01)*(diff>config['basis_bp_sec']*0.01)
        flag = flag_[:-window] # リーケージの防止
        t1 = pd.Series(target_raw.iloc[window:].index, index=flag.index)        

        return flag, t1

    def convert_trend_scan(self, target_raw):
        """トレンドスキャン法によるt値を出力

        Parameters
        ----------
        target_raw : pd.Series
            ターゲット指標

        Returns
        -------
        t_values : pd.Series
            * config_targetがtrend_scan_valの場合 -> 線形トレンドのt値\n
            * config_targetがtrend_scan_classの場合 -> 線形トレンドのt値の符合(-1 or 1)            
            
        t1 : pd.Series
            リーケージに関する時点が格納されたインデックス(split.PurgedKFoldにて使用)            
        """
        config = self.config['config_target']
        molecule = target_raw.index
        close = target_raw
        span = config['scan_window']
        output = trend_scan(molecule, close, span)
        if self.config['config_target']["type"] == "trend_scan_class":
            t_values = (output['bin']>0)*1
            t_values = t_values.astype(int)            
        elif self.config['config_target']["type"] == "trend_scan_val":
            t_values = output['tVal']            
            t_values = t_values.astype(float)
            
        window = span[1]
        t1 = pd.Series(close.iloc[window:].index, index=t_values.index)        

        return t_values, t1
    
    def calc_target_return(self):
        """トレーディング対象のリターンを算出        

        Returns
        -------
        futures_return : pd.Series
            トレーディング対象のリターン.
        """
        futures_return = self.dfs_input['daily'][self.config['trade_target']].pct_change()
        
        return futures_return
    
    def build_dataset(self):
        """テクニカル指標への変換後のデータを加えた特長量データセットを作成(全データ期間でテクニカル指標を作成)

        self.X     : pd.DataFrame
            テクニカル指標を加えた特長量データセット
        self.y_raw : pd.Series    
            ターゲット指標のローデータ        
        """        
        self.y_raw = self.dfs_input['daily'][self.config['target_name']]
        self.futures_return = self.calc_target_return()
        return super().build_dataset()

    def make_target(self, start_date, end_date):
        """指定した期間の目的変数データセットを作成

        Parameters
        ----------
        start_date : pandas.core.indexes.datetimes.DatetimeIndex
            開始日
        end_date : pandas.core.indexes.datetimes.DatetimeIndex
            終了日

        Returns
        -------
        y : pd.Series
            指定した期間目的変数データセット(リンケージ防止あり)
        t1 : pd.Series
            リーケージに関する時点が格納されたインデックス(split.PurgedKFoldにて使用)                        

        Raises
        ------
        ValueError
            current version is only available for "trend_scan" or "2018ver" as input for config_target`s type
        """           
        df_target_raw = self.y_raw[start_date:end_date]
        if 'trend_scan' in self.config['config_target']['type']:
            y, t1 = self.convert_trend_scan(df_target_raw)
        elif self.config['config_target']['type'] == '2018ver':
            y, t1 = self.convert_target_flag(df_target_raw)
        else:
            raise ValueError('current version is only available for "trend_scan" or "2018ver" as input for config_target`s type')

        return y, t1

    def scale(self, X_train, X_test, method='StandardScaler'):
        '''MinMax変換により基準化を行う関数

        Parameters
        ----------
        X_train : pd.DataFrame
            訓練データ
        X_test : pd.DataFrame
            テストデータ
        method : str
            基準化方法を指定

        Returns
        -------
        X_train_scaled : pd.DataFrame
            基準化後の訓練データ
        X_test_scaled : pd.DataFrame
            基準化後のテストデータ
        '''
        if method == 'StandardScaler':
            self.scaler = StandardScaler()
        elif method == 'MinMaxScaler':
            self.scaler = MinMaxScaler()      
            
        self.scaler.fit(X_train)
        X_train_scaled = pd.DataFrame(self.scaler.transform(X_train), index = X_train.index, columns = X_train.columns)
        X_test_scaled = pd.DataFrame(self.scaler.transform(X_test), index = X_test.index, columns = X_test.columns)
        
        return X_train_scaled, X_test_scaled
    
    def extract_pca_names(self):
        pca_features = list(self.features.loc[self.features['PCA']==1,:].index)

        return pca_features

    def convert_pca(self, X_train, X_test, n_components, extract_pca_names):
        """訓練データを用いてPCAを適用．訓練データを用いてフィットさせた結果をもとにテストデータを変換

        Parameters
        ----------
        X_train : pd.DataFrame
            訓練データ
        X_test : pd.DataFrame
            テストデータ
        n_components : int
            PCAにより変換する際に考慮する主性成分数
        extract_pca_names : list
            PCAを実施する特長量のリスト        

        Returns
        -------
        X_train_pca : pd.DataFrame
            PCA変換後の訓練データ
        X_test_pca : pd.DataFrame
            PCA変換後のテストデータ
        """
        assert n_components <= len(extract_pca_names),(
            'PCA変換を実施する特長量数より大きい次元が設定されています'
        )
        self.pca = PCA(n_components=n_components, random_state=self.config['config_features']["random_state"])        
        X_train_extracted = X_train[extract_pca_names]
        self.pca.fit(X_train_extracted)        
        
        col_pca = ['PCA'+str(i+1) for i in range(n_components)]
        train_temp = pd.DataFrame(self.pca.transform(X_train_extracted), columns=col_pca, index=X_train.index)
        test_temp = pd.DataFrame(self.pca.transform(X_test[extract_pca_names]), columns=col_pca, index=X_test.index)
        X_train_pca = pd.concat([train_temp, X_train.drop(extract_pca_names, axis=1)], axis=1)
        X_test_pca = pd.concat([test_temp, X_test.drop(extract_pca_names, axis=1)], axis=1)      

        return X_train_pca, X_test_pca
