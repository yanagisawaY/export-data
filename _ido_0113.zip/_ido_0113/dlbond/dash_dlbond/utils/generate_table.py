import dash_table
import pandas as pd

def generate_table(df, max_rows=10, max_cols=30):
    return dash_table.DataTable(
        id='result_table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict("records"),
        export_format='csv',
        )