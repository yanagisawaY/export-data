import plotly.graph_objects as go

import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State

from ...utils.ensemble import get_models_result
from ..app import app
from ..utils.plot_terms import plot_terms
from ..utils.plot_target import plot_target_hist, plot_target_previous
from ..utils.plot_unsupervised import UnsupervisedLearner

style_common = {
    "width": "100%", 
    "display": "inline-block",
    "style": {
        "margin": "10%",
        'margin-bottom': '8%',
        },
    }

models_info = get_models_result()
model_list = list(models_info.keys())

def get_info_terms(ensembler):    
    def get_term_result():
        new_layout = html.Div([
            dcc.Dropdown(
            id="model_select_data",
            options=[{"label": i, "value": i} for i in model_list],
            placeholder=model_list[0],
        ),
        html.Div(id="timestamp_dropdown_data", children=[])
        ], style=style_common)
        
        return new_layout
    
    
    @app.callback(
        Output("timestamp_dropdown_data", "children"),
        Input("model_select_data", "value"),
    )
    
    
    def select_timestamp(model):
        timestamps = list(models_info[model].keys())
        new_layout = html.Div([
            dcc.Dropdown(
            id="timestamp_select_data",
            options=[{"label": i, "value": i} for i in timestamps],
            placeholder=timestamps[0],
        ),
        html.Div(
            id="term_dropdown_data", children=[],
            )
        ], style=style_common)
        
        return new_layout
    
    
    @app.callback(
        Output("term_dropdown_data", "children"),
        Input("timestamp_select_data", "value"),
        State("model_select_data", "value"),
        prevent_initial_call=True,
    )
    
    
    def select_term(timestamp, model):
        terms = [i for i in models_info[model][timestamp].keys() if "term" in i]
        new_layout = html.Div([
            dcc.Dropdown(
            id="term_select_data",
            options=[{"label": i, "value": i} for i in terms],
            value=terms,
            multi=True,
        ),
        html.H2(""),        
        html.Button("SHOW", id="show_result_term", n_clicks=0),        
        html.H2(""),    
        dcc.Loading(
            id='loading_1',
            type='dot',
            children=html.Div(
                id="fig_result_term", children=[],
                )
            )],
            style=style_common)
        
        return new_layout
    
    
    @app.callback(
        Output("fig_result_term", "children"),
        Input("show_result_term", "n_clicks"),
        State("term_select_data", "value"),
        State("timestamp_select_data", "value"),    
        State("model_select_data", "value"),
        prevent_initial_call=True,    
    )
    
    
    def show_result_terms(n_clicks, terms, timestamp, model):
        htmls = []
        for term in terms:
            results = models_info[model][timestamp][term]
            df = results["wealth"].reset_index()
            htmls.append(html.Div([
                dcc.Graph(id="wealth_"+term, figure=plot_terms(df, title_text=term)),
            ]))
            X_train, y_train, X_test, y_test, _ = ensembler.make_dataset(*results["term"].iloc[0,:])
            try:
                htmls.append(html.Div([
                    dcc.Graph(id="y_hist_"+term, figure=plot_target_hist(y_train, y_test)),
                ]))            
                htmls.append(html.Div([
                    dcc.Graph(id="y_previous_"+term, figure=plot_target_previous(y_train, y_test)),
                ]))
            except:
                print("Error - target analysis")
            
            try:
                ul = UnsupervisedLearner(X_train, n_components=16, random_state=0)
                ul_figs = ul.get_all_figs()            
                for ul_fig in ul_figs:   
                    htmls.append(html.Div([
                        dcc.Graph(
                            id="unsupervised_"+term, 
                            figure=ul_fig
                            ),
                    ]))
            except:
                print("Error unsperviserd analysis")

        return htmls
        
    return get_term_result()