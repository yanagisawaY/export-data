"""
Notes:
    1.テクニカル指標作成候補の引数群

"""
tech_config = {
    # 価格ベースの移動平均
    'SMA_raw'  : {
        'timeperiod' : [20, 40, 60],
        }, 
    'SMA_range'  : {
        'timeperiod' : [20, 40, 60],
        }, 
    'SMA_ratio'  : {
        'timeperiod' : [20, 40, 60],
        }, 

    # 価格ベースのボラティリティ
    'VOL_raw' : {
        'rollperiod' : [20, 40, 60], 
        },
    'VOL_range' : {
        'rollperiod' : [20, 40, 60], 
        'meanperiod' : [10]
        },
    'VOL_ratio' : {
        'rollperiod' : [20, 40, 60], 
        'meanperiod' : [10]
        },

    # MACD 
    'MACD' : {
        'fastperiod' : [12], 
        'slowperiod' : [26, 52], 
        'signalperiod' : [9]
        },

    # ROC
    'ROC' : {
        'timeperiod' : [10, 30, 60],
        },

    # RSI
    'RSI' : {
        'timeperiod' : [14, 28],
        },

    # RCI
    'RCI' : {
        'timeperiod' : [10, 20],
        },

    # 価格ベースのスキュー
    'SKEW_raw' : {
        'rollperiod' : [20, 40, 60], 
        },
    'SKEW_range' : {
        'rollperiod' : [20, 40, 60], 
        'meanperiod' : [10]
        },
    'SKEW_ratio' : {
        'rollperiod' : [20, 40, 60], 
        'meanperiod' : [10]
        },

    }

tech_ohlcv_config = {
    # ATR(Average True Range) 
    'ATR' : {
        'args'       : ['LAST', 'HIGH', 'LOW'],
        'timeperiod' : [14, 28],
        },

    # ストキャスティクス
    'STOCH' : {
        'args'       : ['LAST', 'HIGH', 'LOW'],
        'timeperiod' : [14, 28],
        },
        
    }