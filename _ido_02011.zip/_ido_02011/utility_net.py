from torch import nn
import torch
import copy
import pandas as pd
import numpy as np


class ONINorm(nn.Module):
    """

    Notes
    -----    
    `Controllable Orthogonalization in Training DNNs <https://openaccess.thecvf.com/content_CVPR_2020/html/Huang_Controllable_Orthogonalization_in_Training_DNNs_CVPR_2020_paper.html>`_

    `コード参照元 <https://github.com/huangleiBuaa/ONI>`_    
    """

    def __init__(self, T=10, norm_groups=1, *args, **kwargs):
        super(ONINorm, self).__init__()
        self.T = T
        self.norm_groups = norm_groups
        self.eps = 1e-5

    def matrix_power3(self, Input):
        B = torch.bmm(Input, Input)
        return torch.bmm(B, Input)

    def forward(self, port_rt: torch.Tensor, is_train=True):
        """
            ウェイトを変換させる行列Bを出力

        Parameters
        ----------
        port_rt : torch.Tensor
            直交変換前の特性ポートフォリオのリターン.
        is_train: bool
            学習フェイズであるか

        Returns
        -------
        convert_ht : torch.Tensor
            ウェイトに掛け合わせる直交変換用の行列.

        convert_ht@(直交返還前の隠れ層の合成ポートフォリオのウェイト)をかけることで，
        各々のポートフォリオを直交させる(ニュートン法を用いた直交変換)

        Notes
        -----
        As of 21/12/08 updated by Yanagisawa
        * 先行研究と異なり，Zをセンタリングしない

        centeringなくすことで収束は遅くなると予測されるが，
        (つまり特異値の初期値が悪くなる?ただポートフォリオの平均は-1<1に収まるためそこまでの劣化はないとも考えている)，
        先行研究と違い，パラメータの直交化ではなく，ポートフォリオの直交化が目的のため，
        convert_htの計算においてセンタリング値を戻す処理を実施しなくてもよい変換をする        
        """
        assert port_rt.shape[0] % self.norm_groups == 0
        # Z = port_rt.view(self.norm_groups, port_rt.shape[0] // self.norm_groups, -1)  # type: torch.Tensor
        # Zc = Z - Z.mean(dim=-1, keepdim=True)

        # type: torch.Tensor
        Zc = port_rt.view(self.norm_groups,
                          port_rt.shape[0] // self.norm_groups, -1)               
        S = torch.matmul(Zc, Zc.transpose(1, 2))
        eye = torch.eye(S.shape[-1]).to(S).expand(S.shape)
        S = S + self.eps*eye
        norm_S = S.norm(p='fro', dim=(1, 2), keepdim=True) # = (S**2).sum()**0.5
        S = S.div(norm_S)
# =============================================================================
#         
#         ###################################################################
#         check_condition = ((eye - S)**2).sum().item()
#         if check_condition > 1:
#             print(f"check condition {round(check_condition, 3)}")
#             import pdb
#             pdb.set_trace()
#          
#         import numpy.linalg as LA
#         S_ = torch.matmul(Zc, Zc.transpose(1, 2))
#         S_eigen = np.array(LA.eig(S_.detach().numpy().copy())[0])[0]
#         # S_mat = torch.tensor(np.array(LA.eig(S_.detach().numpy().copy())[1]))
#         # torch.matmul(S_.squeeze(), S_mat.squeeze())
#         assert round((S_eigen**2).sum()**0.5, 3) == round((S.detach().numpy().copy()**2).sum()**0.5, 3)
#         ###################################################################
# =============================================================================
        
        B = [torch.Tensor([]) for _ in range(self.T + 1)]
        W = [torch.Tensor([]) for _ in range(self.T + 1)]
        B[0] = torch.eye(S.shape[-1]).to(S).expand(S.shape)
        W[0] = B[0].matmul(Zc).div_(norm_S.sqrt())
        min_W = 10*100000
        for t in range(self.T):
            # B[t + 1] = torch.baddbmm(1.5, B[t], -0.5, self.matrix_power3(B[t]), S)            
            B[t + 1] = 1.5 * B[t] - 0.5 * (B[t]@B[t]@B[t]@S)
            W[t + 1] = B[t+1].matmul(Zc).div_(norm_S.sqrt())
            min_W_temp = (W[t + 1].squeeze()@W[t + 1].squeeze().T-torch.eye(S.shape[-1])).abs().sum()
            if min_W > min_W_temp:
                min_W = min_W_temp
                best_t = t + 1

        # W = B[self.T].matmul(Zc).div_(norm_S.sqrt())
        # W.view_as(port_rt)
        
        convert_ht = B[best_t].div_(norm_S.sqrt()).squeeze(0)

        return convert_ht

    def extra_repr(self):
        fmt_str = ['T={}'.format(self.T)]
        if self.norm_groups > 1:
            fmt_str.append('groups={}'.format(self.norm_groups))
        return ', '.join(fmt_str)


class XSNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''

    def __init__(self, hyperparms, input_num, layer_i):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(XSNet, self).__init__()
        layer_units = hyperparms['layer_list']
        layer_num = len(layer_units)
        layer = []
        layer.append(nn.Dropout(hyperparms['layer_dropout']))

        if layer_i >= 1:
            input_num_layer = layer_units[layer_i-1]
        elif layer_num == 1 or layer_i== 0:
            input_num_layer = input_num


        layer.append(nn.Linear(input_num_layer, layer_units[layer_i], bias=False))
        if layer_i < layer_num - 1:
            self.output_unit = layer_units[layer_i]            
        else:
            self.output_unit = layer_units[-1]

        layer.append(nn.ReLU())
        self.full = nn.Sequential(*layer)

    def forward(self, X):
        """順伝搬

        Parameters
        ----------
        X : torch.tensor
            (バッチ(時点), 銘柄, 特徴量)

        Returns
        -------
        hidden : torch.tensor
            (バッチ(時点), 銘柄, 合成ポートフォリオの数)

        Notes
        -----
        L-1層はクロスセクション方向に平均ゼロ，標準偏差1に標準化
        ->　ポートフォリオフォリオの総ウェイトが1となることが保証
        """
        hidden = torch.zeros(X.size(0), self.output_unit, X.size(1))
        for stock_i in range(X.size(1)):
            hidden[:, :, stock_i] = self.full(X[:, stock_i, :]).squeeze()
        
        hidden = (hidden - torch.mean(hidden, 2).unsqueeze(2).tile(hidden.shape[2]))/(
            torch.std(hidden, 2).unsqueeze(2).tile(hidden.shape[2]))
        hidden = hidden.transpose(1, 2)
        
        return hidden


class UtilityNet(nn.Module):
    def __init__(self, hyperparms, input_num):
        super(UtilityNet, self).__init__()
        self.layer_units = hyperparms['layer_list']
        if len(self.layer_units) > 0:
            last_unit = self.layer_units[-1]
        else:
            last_unit = input_num
        self.last = nn.Linear(last_unit, 1, bias=False)
        self.oln = ONINorm(T=hyperparms["newton_T"], norm_groups=1)
        self.mpn = nn.ModuleList([XSNet(hyperparms, input_num, layer_i) for layer_i in range(len(hyperparms['layer_list']))])
        self.network_type = hyperparms["network_type"]

    def forward(self, X, stock_nums, rt=None, mode="train"):
        weight_ht = self.call_hidden_weight(X, rt, mode)

        # calculate last layer
        weight_t = torch.zeros((weight_ht.shape[0], weight_ht.shape[2]))
        for stock_i in range(X.size(1)):
            weight_t[:, stock_i] = self.last(
                weight_ht[:, :, stock_i]).squeeze()

        stock_nums = stock_nums.unsqueeze(1).expand(-1, X.size(1))
        weight_t = weight_t/stock_nums

        return weight_t

    def call_hidden_weight(self, X, rt=None, mode="train"):
        # calculate L-1 layer
        weight_ht = X
        for i, net in enumerate(self.mpn):
            weight_ht = net.forward(weight_ht)
        
        # (バッチ(時点), 合成ポートフォリオの数, 銘柄)へ次元を変形
        weight_ht = weight_ht.transpose(1, 2)

        if self.network_type == "onc":
            if mode == "train":
                hidden_rt = torch.einsum('tkn,tn->tk', weight_ht, rt)
                convert_ht = self.oln(hidden_rt.T)
                self.convert_ht = convert_ht.detach()
                # temp = pd.DataFrame((hidden_rt@self.convert_ht).detach().numpy().copy())
                # print(temp.corr())
            else:
                convert_ht = self.convert_ht

            weight_ht = torch.einsum('tkn, km->tmn', weight_ht, convert_ht)
            # 直交変換させた際にウェイトが小さくスケーリングされるため，
            # クロスセクション方向に標準偏差が1となるようリスケーリングする
            weight_ht = weight_ht/weight_ht.std(dim=2, keepdim=True)

        return weight_ht

    def preserve_corr(self, weight_ht, rt):
        convert_rt_ = torch.einsum(
            'tkn,tn->tk', weight_ht, rt).detach().numpy().copy()
        convert_rt = pd.DataFrame(convert_rt_)
        import pdb
        pdb.set_trace()
