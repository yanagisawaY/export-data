import pandas as pd
import numpy as np
from pandas.core.algorithms import searchsorted
from sklearn.model_selection._split import _BaseKFold
from torch.functional import split
from dlbond.utils.processor import Processor

class PurgedKFold(_BaseKFold):
    """観測データが重複するときの時系列データに対する交差検証クラス

    Parameters
    ----------
    n_splits : int
        データの分割数
    t1 : pd.Series
        リーケージに関する時点が格納されたインデックス．

        例えば，t時点の特長量あるいは目的変数作成において，t+X時点の情報を用いて作成している場合，
        t時点のデータセットに対応するインデックスにt+X時点と記録されている．
    pct_embargo : float, optional
        エンバーゴによりデータを除去する割合, by default 0.01

    lookback_window : int, optional
        ルックバックウィンドウ期間, by default 0

        LSTMやTransformerなど，過去何時点かの時系列データを用いる場合を想定して使用．

        これらのモデルを想定しない場合，通常は0を指定する．

    Raises
    ------
    ValueError
        t1がpd.Seriesでない場合はエラー
    
    Notes
    -----
    1. 参照書籍のスニペット7.3を参考に作成
    2. pct_embargoは書籍をもとに0.01をデフォルト値に設定
    3. 時系列モデルのデータセット作成のためlookback_windowを追加
    """
    def __init__(
        self,
        n_splits,
        t1=None,        
        pct_embargo=0.01,
        lookback_window=0
    ):
        if not isinstance(t1, pd.Series):
            raise ValueError('Label Through Dates must be a pd.Series')
        super(PurgedKFold, self).__init__(n_splits, shuffle=False, random_state=None)
        self.t1 = t1
        self.lookback_window = lookback_window
        self.pct_embargo = pct_embargo

    def split(self, X):
        """データセットを分割するインデックスを作成する

        Parameters
        ----------
        X : pd.DataFrame
            特長量データ

        Yields
        -------
        train_indices : index
            訓練期間のインデックス列
        test_indices : index
            テスト期間のインデックス列
        """
        assert (X.index == self.t1.index).sum() == len(self.t1), (
            'X and ThruDateValues must have the same index'
        )
        indices = np.arange(X.shape[0])
        mbrg = int(X.shape[0]*self.pct_embargo)
        test_starts = [(i[0], i[-1]+1)
                       for i in np.array_split(np.arange(X.shape[0]), self.n_splits)]
        for i, j in test_starts:
            t0 = self.t1.index[i-self.lookback_window]
            test_indices = indices[max(i - self.lookback_window, 0):j]
            max_t1_index = self.t1.index.searchsorted(self.t1[test_indices].max())
            train_indices = self.t1.index.searchsorted(self.t1[self.t1<=t0].index)
            train_indices = np.concatenate((train_indices, indices[max_t1_index+mbrg-self.lookback_window:]))

            yield train_indices, test_indices


class WalkForward:
    """ウォークフォワード法によるデータの分割
    """
    def __init__(self, 
    split_ratio, 
    t1, 
    lookback_window
    ):
        if not isinstance(t1, pd.Series):
            raise ValueError('Label Through Dates must be a pd.Series')    
        self.split_ratio = split_ratio
        self.t1 = t1
        self.lookback_window = lookback_window

    def split(self, X):
        """データセットを分割するインデックスを作成する

        Parameters
        ----------
        X : pd.DataFrame
            特長量データ

        Returns
        -------
        train_indices : index
            訓練期間のインデックス列
        test_indices : index
            テスト期間のインデックス列
        """
        assert (X.index == self.t1.index).sum() == len(self.t1), (
            'X and ThruDateValues must have the same index'
        )
        indices = np.arange(X.shape[0])
        split_time = int(X.shape[0]*self.split_ratio)
        t0 = self.t1.index[split_time-self.lookback_window]
        test_indices = indices[max(t0 - self.lookback_window, 0):]
        train_indices = self.t1.index.searchsorted(self.t1[self.t1<=t0].index)

        return train_indices, test_indices


class Splitter(Processor):
    def __init__(self, dfs_input, config):
        super().__init__(dfs_input, config)

    def make_trainset(self, start_date, end_date):
        """訓練用データセットを作成する（リンケージ防止あり）

        Parameters
        ----------
        start_date : pandas.core.indexes.datetimes.DatetimeIndex
            訓練データの開始日
        end_date : pandas.core.indexes.datetimes.DatetimeIndex
            訓練データの終了日

        Returns
        -------
        X : pd.DataFrame
            説明変数データ
        y : pd.Series
            目的変数データ
        Note
        -------            
        リンケージ期間を削除しているため，X・yのインデックスの終了日はend_dateとは一致しない
        """
        y_train, t1 = self.make_target(start_date, end_date)
        index_excluded_linkage = y_train.index
        X_train = self.X.loc[index_excluded_linkage,:]

        return X_train, y_train, t1

    def make_testset(self, start_date, end_date):
        """テスト用データセットを作成する（目的変数のみリンケージ削除）

        Parameters
        ----------
        start_date : pandas.core.indexes.datetimes.DatetimeIndex
            テストデータの開始日
        end_date : pandas.core.indexes.datetimes.DatetimeIndex
            テストデータの終了日

        Returns
        -------
        X : pd.DataFrame
            説明変数データ(リンケージ削除なし)
        y : pd.Series
            目的変数データ(リンケージ削除)
        Note
        -------            
        yのみリンケージ期間を削除している．yのインデックスの終了日はend_dateとは一致しない
        """
        y_test, t1 = self.make_target(start_date, end_date)
        X_test = self.X.loc[start_date:end_date,:]

        return X_test, y_test, t1

    def make_dataset(self, start_date_train, end_date_train, start_date_test, end_date_test):
        """指定した期間の訓練データとテストデータを抽出する

        Parameters
        ----------
        start_date_train : pandas.core.indexes.datetimes.DatetimeIndex
            訓練開始時点
        end_date_train : pandas.core.indexes.datetimes.DatetimeIndex
            訓練終了時点
        start_date_test : pandas.core.indexes.datetimes.DatetimeIndex
            テスト開始時点
        end_date_test : pandas.core.indexes.datetimes.DatetimeIndex
            テスト終了時点

        Returns
        -------
        X_train : pd.DataFrame
            訓練期間の特長量データ        
        y_train : pd.DataFrame
            訓練期間の説明変数データ        
        X_test : pd.DataFrame
            テスト期間の特長量データ        
        y_test : pd.DataFrame
            テスト期間の説明変数データ        
        """
        X_train, y_train, _ = self.make_trainset(
            start_date_train, end_date_train)
        X_test, y_test, _ = self.make_testset(start_date_test, end_date_test)
        X_train, X_test = self.scale(X_train, X_test)
        pca_names = self.extract_pca_names()
        if len(pca_names) > 0:
            X_train, X_test = self.convert_pca(
                X_train, X_test, self.config['config_features']['n_components'], pca_names)

        return X_train, y_train, X_test, y_test

    def make_dataset_valid(self, start_date_train, end_date_train, start_date_test, end_date_test):
        """指定した期間の訓練データ，バリデーションデータ，テストデータを抽出

        Parameters
        ----------
        start_date_train : pandas.core.indexes.datetimes.DatetimeIndex
            訓練開始時点
        end_date_train : pandas.core.indexes.datetimes.DatetimeIndex
            訓練終了時点
        start_date_test : pandas.core.indexes.datetimes.DatetimeIndex
            テスト開始時点
        end_date_test : pandas.core.indexes.datetimes.DatetimeIndex
            テスト終了時点

        Returns
        -------
        dict_val : dict
            訓練期間データを用いた，KFoldのバリデーションデータセット
        X_test : pd.DataFrame
            テスト期間の特長量データ        
        y_test : pd.DataFrame
            テスト期間の説明変数データ        
        """
        pca_names = self.extract_pca_names()
        X_train, y_train, t1_train = self.make_trainset(
            start_date_train,
            end_date_train
        )
        cv_method = self.config['backtest_info']['validation_type']
        _config = self.config['backtest_info'][cv_method]
        #  リーケージ削除済みのデータを使用するため，t1は以下のように設定
        #  → 各時点において特長量データ(X)は未来の情報を参照していないため，以下のようにt1をおく        
        if cv_method == "PurgedKFold":
            cv = PurgedKFold(
                n_splits=_config['n_splits'],
                t1=t1_train,
                pct_embargo=_config['pct_embargo'],
                lookback_window=_config['lookback_window']
            )
        elif cv_method == "WalkForward":
            cv = WalkForward(
                split_ratio=_config["split_ratio"], 
                t1=t1_train, 
                lookback_window=_config["lookback_window"]
                )       

        dict_val = {}
        for i, (train_index, val_index) in enumerate(cv.split(X_train)):
            X_train_ = X_train.iloc[train_index, :]
            y_train_ = y_train.iloc[train_index]
            X_val_ = X_train.iloc[val_index, :]
            y_val_ = y_train.iloc[val_index]

            X_train_, X_val_ = self.scale(X_train_, X_val_)
            if len(pca_names) > 0:
                X_train_, X_val_ = self.convert_pca(
                    X_train_, X_val_, self.config['config_features']['n_components'],
                    pca_names
                )

            dict_val.update({
                i: {
                    "X_train": X_train_,
                    "y_train": y_train_,
                    "X_val_": X_val_,
                    "y_val_": y_val_,
                }
            })

        X_test, y_test, _ = self.make_testset(start_date_test, end_date_test)
        X_train, X_test = self.scale(X_train, X_test)
        if len(pca_names) > 0:
            X_train, X_test = self.convert_pca(
                X_train, X_test, self.config['config_features']['n_components'], pca_names)
 
        return dict_val, X_test, y_test