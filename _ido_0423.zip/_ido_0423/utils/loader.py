# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.データ作成のコード
    2.テクニカル指標作成に関わるものはconfig（別コード）にて設定

"""
import numpy as np
import pandas as pd
import datetime as dt
import time
import itertools
import talib as ta
from config.config import *

class DataLoader:
    def __init__(self, df_dict, hyperparms_company_common):
        self.df_dict = df_dict
        self.df = df_dict['Adj Close']        
        self.hyperparms_company_common = hyperparms_company_common
        try:
            self.use_col = self.hyperparms_company_common['use_col']
            if self.use_col == None:
                self.use_col = self.df.columns
        except KeyError:
            self.use_col = self.df.columns
        
        #　対数リターン
        self.df_pct = self.get_pct_change_log()
        
        # ポートフォリオのリバランス時点で観測するリターン
        # self.df_pct_port = self.get_pct_change()
        self.df_pct_port = self.get_pct_change_port()        
        
        self.index_date = self.df_pct.index
        if hyperparms_company_common['data_type'] == 'Tech' or hyperparms_company_common['data_type'] == 'RtTech':
            # テクニカル指標データの作成
            print('テクニカル指標データ作成...')
            start = time.time()
            dict_talib_all = self.make_technical_data()
            print(f'テクニカル指標作成完了: {round(time.time()-start)}sec')        
            self.dict_talib = self.change_technical_dict(dict_talib_all)    
            print(f'テクニカル指標変換完了: {round(time.time()-start)}sec')
        
        self.check_index()
            
    def check_index(self):
        assert self.hyperparms_company_common['rebalance_term'] >= 1

    def get_index(self, start_date, end_date):
        '''
            データ分割における日付を取得(lagとrebalance_termを考慮して説明変数データのindexを作成)

        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.

        Returns
        -------
        target_start_date : datetime
            予測データの開始日.(入力した日付がない場合，該当日以降のうち，最も近い日付)
        target_end_date : datetime
            予測データの終了日.(入力した日付がない場合，該当日以降のうち，最も近い日付)
        explained_start_date : datetime
            説明変数データの開始日.
        explained_end_date : datetime
            説明変数データの終了日.
        '''
        
        if (not isinstance(start_date, dt.datetime)) or (not isinstance(end_date, dt.datetime)):
            raise ValueError('start_date, end_dateはdatetime型にしてください')            
                    
        try:
            target_start_index = np.abs(self.index_date-start_date).argmin()
            target_start_date = self.index_date[target_start_index]
            
            if target_start_date < start_date:
                target_start_index = np.abs(self.index_date-start_date).argmin() + 1
                target_start_date = self.index_date[target_start_index]
                
            explained_start_index = target_start_index - self.hyperparms_company_common['lag'] - self.hyperparms_company_common['rebalance_term']
            explained_start_date = self.index_date[explained_start_index]
        except:
            raise ValueError('データ期間の開始日が範囲外です.rebalance_termとlagを考慮して日付を設定してください')
        
        assert explained_start_index >= 0,{
            'データ期間の開始日が範囲外です.rebalance_termとlagを考慮して日付を設定してください'            
            }
        
        try:
            target_end_index = np.abs(self.index_date-end_date).argmin()
            target_end_date = self.index_date[target_end_index]            
            explained_end_index = target_end_index - self.hyperparms_company_common['lag'] - self.hyperparms_company_common['rebalance_term']
            explained_end_date = self.index_date[explained_end_index]
        except:
            raise ValueError('データ期間の終了日が範囲外です.rebalance_termとlagを考慮して日付を設定してください')
                   
        return target_start_date, target_end_date, explained_start_date, explained_end_date

    def make_dataset(self, start_date, end_date, stock_i, split_id=0):
        '''
            説明変数データ，被説明変数データを作成

        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.
        stock_i : str
            銘柄のティッカー（説明変数）
        split_id : 
            データセットの開始時点パターン
        Returns
        -------
        X : pd.DataFrame
            説明変数データ.
        y : pandas.DataFrame
            予測データ.
        y_port : pandas.DataFrame
            バックテストにおける観測リターンデータ.
            （リバランスのずれを考慮している場合，yとは一致しない）
        '''
        target_start_date, target_end_date, explained_start_date, explained_end_date = self.get_index(start_date, end_date)

        if self.hyperparms_company_common['data_type'] == 'Tech':
            dict_talib_ = self.extract_technical_dict(self.dict_talib, explained_start_date, explained_end_date)
            X = dict_talib_[stock_i]
        elif self.hyperparms_company_common['data_type'] == 'RtTech':
            dict_talib_ = self.extract_technical_dict(self.dict_talib, explained_start_date, explained_end_date)
            X = dict_talib_[stock_i].drop('return', axis=1)
            X = pd.concat([self.df_pct[explained_start_date:explained_end_date], X], axis=1)
        elif self.hyperparms_company_common['data_type'] == 'Rt':
            X = self.df_pct[explained_start_date:explained_end_date]
        else:
            raise ValueError(r'hyperparms_company_commonのdata_typeに想定外のインプットが入力されています')            

        y = self.df_pct[target_start_date:target_end_date].loc[:, stock_i]
        
        X = X[split_id::self.hyperparms_company_common['rebalance_term']]
        y = y[split_id::self.hyperparms_company_common['rebalance_term']]
        
        y_port = self.df_pct_port[target_start_date:target_end_date].loc[:, stock_i][split_id::self.hyperparms_company_common['rebalance_term']]
        
        return X, y, y_port

    def get_pct_change(self):
        '''価格リターンの算出
        '''        
        output = self.df.pct_change(self.hyperparms_company_common['rebalance_term']).dropna(axis=0)
        return output

    def get_pct_change_log(self):
        '''対数リターンの算出
        '''                
        output = self.df.applymap(np.log).diff(self.hyperparms_company_common['rebalance_term']).dropna(axis=0)
        
        return output
    
    def get_pct_change_port(self):
        # 株式分割等の調整を始値でも実施
        adj_index = self.df_dict['Adj Close'] / self.df_dict['Close']
        adj_open = self.df_dict['Open'] * adj_index
        output = self.df_dict['Adj Close']/adj_open.shift(self.hyperparms_company_common['rebalance_term']-1) - 1
        output = output.dropna()
                
        return output
    
    def make_technical_data(self):
        '''
            テクニカル指標データの作成
            (dict_talibはconfig.pyにて設定)
        Parameters
        ----------
        start_date : datetime
            予測データの開始日.
        end_date : datetime
            予測データの終了日.        

        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''
        dict_talib = {}
        dict_talib['return'] = self.get_pct_change()
        dict_talib.update(self.make_technical_return())
        dict_talib.update(self.make_technical_close())
        dict_talib.update(self.make_technical_OHLCV())
        
        return dict_talib

    def extract_technical_dict(self, dict_talib, explained_start_date, explained_end_date):
        '''テクニカル指標の日付を統一
        Returns
        -------
        dict_talib_output : dict
            日付統一後のテクニカル指標データ.
        '''
        dict_talib_output = dict_talib.copy()
        for key, df in dict_talib.items():
            try:
                dict_talib_output[key] = df[explained_start_date:explained_end_date]
            except:
                raise ValueError(f'{key} : {explained_start_date.strftime("%Y-%m-%d")}以前の日付が存在しません．\nデータの最初の日付は{min(df.index).strftime("%Y-%m-%d")}です')

        return dict_talib_output

    def change_technical_dict(self, dict_talib):
        '''テクニカル指標の辞書を銘柄ごとに集約
        Returns
        -------
        dict_talib_stocks : dict [銘柄数] : {pd.DataFrame=(時点,テクニカル指標数)}
        '''
        dict_talib_stocks = {}
        for stock_i in self.df.columns:
            df_temp = [args[stock_i].rename(key) for key, args in dict_talib.items()]
            dict_talib_stocks[stock_i] = pd.concat(df_temp, axis=1)

        return dict_talib_stocks
        
    def make_technical_return(self):
        '''
            リターン系列のテクニカル指標データの作成
            (talib_returnはconfig.pyにて設定)
        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''                
        dict_talib = {}

        for name_i, args in talib_return.items():
            for key_i, args_i in args.items():
                for j in args_i:
                    if len(args) == 1:
                        key = 'r_' + name_i + str(j)
                    else:
                        key = 'r_' + name_i + '_' + str(key_i) + str(j)
                        
                    dict_talib[key] = self.df_pct.apply(eval('ta.' + name_i), **{key_i:j}).dropna()      
                   
        return dict_talib
    
    def make_technical_close(self):
        '''
            リターン系列のテクニカル指標データの作成
            (talib_closeはconfig.pyにて設定)
        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''                
        dict_talib_close = {}
        
        for name_i, args in talib_close.items():
            for key_i, args_i in args.items():
                for j in args_i:
                    if len(args) == 1:
                        key = 'p_' + name_i + str(j)
                    else:
                        key = 'p_' + name_i + '_' + str(key_i) + str(j)
                        
                    dict_talib_close[key] = self.df.apply(eval('ta.' + name_i), **{key_i:j}).dropna()      
                   
        return dict_talib_close
        
    def make_technical_OHLCV(self):
        '''
            リターン系列のテクニカル指標データの作成
            (talib_OHLCVはconfig.pyにて設定)
        Parameters
        ----------
        df : pd.DataFrame
            株価行列 (時点,銘柄数)
        Returns
        -------
        dict_talib : dict [テクニカル指標数] : {pd.DataFrame=(時点,銘柄数)}
            テクニカル指標データ.
        '''                
        dict_talib_OHLCV = {}
        
        def product_(args):
            if 'None' in args:
                result = args.copy()
            else:   
                product = [x for x in itertools.product(*args.values())]
                result = [dict(zip(args.keys(), r)) for r in product]
            
            return result
        
        for name_i, args in talib_OHLCV.items():
            procuct_list = product_(args)          
            for dict_i in procuct_list:
                if 'None' in dict_i:
                    key = 'ohlcv_' + name_i                                    
                else:
                    key = 'ohlcv_' + name_i + '_' + '_'.join(map(str, list(dict_i.values())))                    

                func_temp = eval('ta.' + name_i)
                temp = []                    
                for stock_ in self.df.columns:
                    try :
                        if OHLCV_type[name_i] == 2:
                            dict_temp = {'high' : self.df_dict['High'][stock_], 'low' : self.df_dict['Low'][stock_]}
                        elif OHLCV_type[name_i] == 3:
                            dict_temp = {'high' : self.df_dict['High'][stock_], 'low' : self.df_dict['Low'][stock_],
                                         'close' : self.df_dict['Close'][stock_]}                            
                        elif OHLCV_type[name_i] == 4:
                            dict_temp = {'high' : self.df_dict['High'][stock_], 'low' : self.df_dict['Low'][stock_],
                                         'close' : self.df_dict['Close'][stock_], 'volume' : self.df_dict['Volume'][stock_]}
                        elif OHLCV_type[name_i] == 5:
                            dict_temp = {'open' : self.df_dict['Open'][stock_], 'high' : self.df_dict['High'][stock_],
                                         'low' : self.df_dict['Low'][stock_], 'close' : self.df_dict['Close'][stock_]} 
                    except:
                        raise ValueError(f'{name_i}のOHLCV_typeを設定してください')
                        
                    if 'None' not in dict_i:
                        dict_temp.update(dict_i)
                        
                    temp.append(func_temp(**(dict_temp)))
                    
                df_temp = pd.concat(temp, axis=1).dropna()
                df_temp.columns = self.df.columns
                dict_talib_OHLCV[key] = df_temp
        
        return dict_talib_OHLCV