# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.None
"""

import lightgbm as lgb
import numpy as np
import random
import pandas as pd
        
def store_env(storing_list, X, y):
    """Create a callback for simply storing lightgbm.callback.CallbackEnv"""    
    # Reference : https://tawara.hatenablog.com/entry/2020/05/16/161144
    def _callback(env: lgb.callback.CallbackEnv):
        """Define callback function."""
        #model = env.model.__copy__()
        y_pred = env.model.predict(X)   
        storing_list.append([
            (y - y_pred)**2
        ])
        
    _callback.order = 20        
    return _callback


class DoubleEnsembleFS:
    def __init__(self, hyperparms_model):
        self.hyperparms_model = hyperparms_model
        self.num_submodels = self.hyperparms_model['num_submodels']
        self.hyperparms_submodels = self.hyperparms_model['hyperparms_submodels']
        self.SR_params = self.hyperparms_model['SR_params']        
        self.FS_params = self.hyperparms_model['FS_params']                
        self.submodel = self.hyperparms_model['submodel']
        self.models = []
        self.models_f_cols = []        
        
    def fit(self, X_train, y_train):
        '''モデルの学習（modelsに学習済みアンサンブルモデルを格納）
            
        Parameters
        ----------
        X_train : pd.DataFrame
            説明変数データ.(時点数, 特徴量)
        y_train : pd.Series
            予測ターゲット. (時点数,)
        '''
        # Set the weights and features for first sub-model
        weight = [1 for _ in range(X_train.shape[0])]
        f_cols = X_train.columns
        
        for k in range(self.num_submodels):
            print(f'Building submodel　{k}')
            model_k = self.train_submodel(X_train, y_train, weight, f_cols)
            self.models_f_cols.append(f_cols)
            self.models.append(model_k)
            weight = self.sample_reweighting(model_k, k)          
            f_cols = self.select_feature(X_train, y_train, k)
                                  
    def train_submodel(self, X_train, y_train, weight, f_cols):
        '''サブモデルの学習（ロスの情報も保存）

        Parameters
        ----------
        X_train : pd.DataFrame
            説明変数データ.(時点数, 特徴量)
        y_train : pd.Series
            予測ターゲット. (時点数,)
        weight : np.array (サンプル数,)
            サンプルへの重みづけ.
        f_cols : list
            説明変数に使用する列名.

        Returns
        -------
        model : TYPE
            学習済みモデル.
        '''
        X = X_train[f_cols].values
        y = y_train.values        

        try:    
            model = {'lightgbm': lgb.LGBMRegressor}[self.submodel]
            hyperparms = self.hyperparms_submodels
            hyperparms['random_state'] = self.hyperparms_model['random_seed']    
            model = model(**hyperparms)
            loss_curves = []                           # 弱学習器の保存
            my_callback = store_env(loss_curves, X, y) # callback関数を生成
            model.fit(X=X, y=y, sample_weight=weight, callbacks=[my_callback,], verbose=-1)
            
            # Retrieve the loss curvesC and the loss values L             
            model.loss_curves = np.concatenate(loss_curves, axis=0).T # (Num of samples(N), Num of iteration(trees) (T))  
            model.loss_L = model.loss_curves[:,-1]                    # (Num of samples(N), )
        except:
            raise ValueError(f'Unexcepcted input: check "hyperparms_model⇒submodels" : {self.submodel} is not in submodel')
                   
        return model
        
    @staticmethod
    def norm(C):
        '''normalization  function
            replaces  each  element  in  the  matrix  with  its  rank across other elements in the column
        '''        
        rank_ = np.argsort(np.argsort(C))
        min_val = min(rank_)
        max_val = max(rank_)
        rank = (rank_-min_val)/(max_val-min_val)
        
        return rank

    def sample_reweighting(self, model_k, k):
        '''学習曲線の結果をもとにサンプルへの重みづけを更新

        Parameters
        ----------
        model_k : 
            学習済みモデル.
        k : int
            サブモデル構築回数.

        Returns
        -------
        weight : np.array (サンプル数,)
            更新された重みづけ.
        '''
        num_samples = int(self.SR_params['C_ratio']*model_k.loss_curves.shape[1])        
        C_start = np.mean(model_k.loss_curves[:,0:num_samples], 1)
        C_end = np.mean(model_k.loss_curves[:,-num_samples:], 1)        
        h_value = self.SR_params['alpha1']*(-model_k.loss_L) + self.SR_params['alpha2']*self.norm(C_end/C_start)        
        
        # calculate the average h-value for the bth bin
        h_value_bound = np.quantile(h_value, [i/self.SR_params['bins_B'] for i in range(1, self.SR_params['bins_B'])])       
        h_value_bins = np.zeros(len(h_value))
        h_value_bins[np.where(h_value<h_value_bound[0])] = h_value[h_value<h_value_bound[0]].mean()        
        h_value_bins[np.where(h_value>=h_value_bound[-1])] = h_value[h_value>=h_value_bound[-1]].mean()                
        for i in range(1, len(h_value_bound)):
            h_value_bins[np.where((h_value<h_value_bound[i])&(h_value>=h_value_bound[i-1]))] = h_value[(h_value<h_value_bound[i])&(h_value>=h_value_bound[i-1])].mean()

        # calculate the sample weight       
        weight = 1/((self.SR_params['decay_gamma']**k)*h_value_bins+0.1)

        return weight
        
    def select_feature(self, X_train, y_train, k):
        '''説明変数の選択
            Algorithm3 FS: shuffling based feature selection

        Parameters
        ----------
        model_k : 
            学習済みモデル.
        f_cols : list
            説明変数で使用する列名
        X_train : pd.DataFrame(列名入り)
            説明変数データ.
        y_train : TYPE
            予測値データ.
        k : int
            サブモデル構築回数.
            
        Returns
        -------
        features_sampled : list
            選択した説明変数.
        '''
        y_pred = self.predict(X_train)
        L_bench = (y_train-y_pred)**2
        
        features = X_train.columns
        X_f = X_train.copy()
        g_f = []
        for i, feature in enumerate(features):
            random.seed(self.hyperparms_model['random_seed']+i+k)
            temp = X_train[feature].copy().values
            random.shuffle(temp)
            X_f[feature] = temp
            y_pred = self.predict(X_f)
            L_f = (y_train-y_pred)**2
            g_f.append(np.mean(L_f-L_bench)/np.std(L_f-L_bench))
                
        bins = len(self.FS_params['sample_ratio'])
        g_f = pd.DataFrame(g_f, columns=['val'])
        g_f_bins = pd.qcut(g_f['val'], [i/bins for i in range(bins+1)], labels=[i for i in range(bins)])
               
        features_sampled = []
        for i, index in enumerate(sorted(g_f_bins.unique(), reverse=True)):
            random.seed(self.hyperparms_model['random_seed']+i+k)            
            features_bins = [features[i] for i in g_f_bins[g_f_bins==index].index]                
            num_cols = round(len(features_bins)*self.FS_params['sample_ratio'][i])
            features_sampled += random.sample(list(features_bins), num_cols)
            
        return features_sampled
    
    def predict(self, X):
        '''学習済みモデルをもとに予測を実施

        Parameters
        ----------
        X : pd.DataFrame
            説明変数データ.

        Returns
        -------
        y_pred : pd.DataFrame
            予測値.
        '''
        assert len(self.models)>0, 'fitメソッドを先に実行してください'
            
        y_pred = np.zeros(X.shape[0])
        for model, f_cols in zip(self.models, self.models_f_cols):
            y_pred += model.predict(X[f_cols])
        
        # the average of all the K sub-models.
        y_pred = y_pred/len(self.models)
        
        return y_pred

        