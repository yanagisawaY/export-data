# -*- coding: utf-8 -*-
"""
「DoubleEnsemble: A New Ensemble Method Basedon Sample Reweighting and Feature Selection forFinancial Data Analysis」
https://arxiv.org/pdf/2010.01265.pdf

Notes:
    1.None
"""

import xgboost as xgb
import lightgbm as lgb
import numpy as np


def store_env(storing_list, X, y):
    """Create a callback for simply storing lightgbm.callback.CallbackEnv"""    
    # Reference : https://tawara.hatenablog.com/entry/2020/05/16/161144
    def _callback(env: lgb.callback.CallbackEnv):
        """Define callback function."""
        model = env.model.__copy__()
        y_pred = model.predict(X)   
        storing_list.append([
            y - y_pred
        ])
        
    _callback.order = 20        
    return _callback


class DoubleEnsemble:
    def __init__(self, hyperparms_model):
        self.hyperparms_model = hyperparms_model
        self.num_submodels = self.hyperparms_model['num_submodels']
        self.hyperparms_submodels = self.hyperparms_model['hyperparms_submodels']
        self.submodel = self.hyperparms_model['submodel']
        self.models = []
    
    def fit(self, X_train, y_train, X_val, y_val):
        '''            
            モデルの学習（modelsに学習済みアンサンブルモデルを格納）
            
        Parameters
        ----------
        X_train : pd.DataFrame
            説明変数データ.(時点数, 特徴量)
        y_train : pd.Series
            予測ターゲット. (時点数,)
        '''
        # Set the weights and features for first sub-model
        weight = [1 for _ in range(X_train.shape[0])]
        f_cols = X_train.columns
        
        models = []
        for k in range(self.num_submodels):
            model_k = self.train_submodel(X_train, y_train, weight, f_cols, X_val, y_val)
            models.append(model_k)
            
            import pdb
            pdb.set_trace()            

            loss_curves, loss_values = self.retrieve_loss(model_k)
            weight = self.sample_reweighting()
            f_cols = self.select_feature()
            
        self.models = models
   
    def train_submodel(self, X_train, y_train, weight, f_cols, X_val=[], y_val=[]):
        X = X_train[f_cols].values
        y = y_train.values        
        
        try:    
            model = {'lightgbm': lgb.LGBMRegressor}[self.submodel]
            hyperparms = self.hyperparms_submodels
            hyperparms['random_state'] = self.hyperparms_model['random_seed']            
            model = model(**hyperparms)
            loss_curves = []                      # 弱学習器の保存
            my_callback = store_env(loss_curves, X, y)  # callback関数を生成
            model.fit(X=X, y=y, sample_weight=weight, callbacks=[my_callback,])
             # (サンプル数N, 繰り返し(木の数)T) 
            model.loss_curves = np.concatenate(loss_curves, axis=0).T           
             # (サンプル数N, )             
            model.loss_L = np.sum(model.loss_curves, 1)
            
# =============================================================================
#             model = {'lightgbm': lgb.cv}[self.submodel]
#             hyperparms = self.hyperparms_submodels
#             hyperparms['random_state'] = self.hyperparms_model['random_seed']  
#             lgb_train = lgb.Dataset(X_train, y_train, weight=weight)        
#             
#             from sklearn.model_selection import KFold
#             folds = KFold(n_splits=5, shuffle=True, random_state=self.hyperparms_model['random_seed'])            
#             cv_result = model(hyperparms, lgb_train, folds=folds, num_boost_round=100, metrics='mae', return_cvbooster=True)
#             
#             cvbooster = cv_result['cvbooster']
#             split_indices = list(folds.split(X_train, y_train))
#             # Booster と学習に使ったデータの対応関係を取る
#             booster_split_mappings = list(zip(cvbooster.boosters, split_indices))
#             for booster, (_, val_index) in booster_split_mappings:
#                 # Booster が学習に使っていないデータ
#                 booster_val_x = X_train.iloc[val_index]
#             
#             cvbooster = cv_result['cvbooster']
# =============================================================================
            '''
            Note : https://lightgbm.readthedocs.io/en/latest/pythonapi/lightgbm.cv.html
                1.stratifiedはFalseと設定しないとregressionは実行されない．
                2.metricsはmaeで事前に指定
                3.return_cvbooster – Whether to return Booster models trained on each fold through CVBooster.
            '''            
                                   
        except:
            raise ValueError(f'Unexcepcted input: check "hyperparms_model⇒submodels" : {self.submodel} is not in submodel')
                   
        return model
    
    def retrieve_loss(self):
        pass
    
    def sample_reweighting(self):
        pass
    
    def select_feature(self):
        pass        
    


    
    
    
    