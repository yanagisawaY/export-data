
import pandas as pd
import torch
from ..utils.processor import make_torch_scaled_xs
from ..utils.util import base_port_return


class ResultSummarizer:
    def __init__(self, estimator, hyperparms):
        self.model = estimator.model
        self.stock_list = hyperparms["stock_list"]
        self.factor_list = hyperparms["factor_list"]
        
    def get_hidden_return(self, X, rt):
        """企業特性合成ポートフォリオのリターン

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)        
        rt: pd.DataFrame
            銘柄リターンデータ(時点, 銘柄)

        Returns
        -------
        hidden_rt : pd.DataFrame
            各企業特性合成ポートフォリオのリターン
        """
        hidden_weight = self.model.call_hidden_weight(
            X, rt=None, mode="predict")
        hidden_weight = hidden_weight / \
            torch.abs(hidden_weight).sum(2, keepdim=True)
        hidden_rt = torch.einsum(
            'tkn,tn->tk', hidden_weight, rt).detach().numpy().copy()
        hidden_rt = pd.DataFrame(hidden_rt)

        return hidden_rt

    def get_port_return(self, X, rt, weight_active=[]):
        """ポートフォリオのリターン（企業特性合成ポートフォリオのリターンも含めて）を取得

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)        
        rt: pd.DataFrame
            銘柄リターンデータ(時点, 銘柄)
        weight_active : list
            企業特性合成ポートフォリオへのオーバーウェイト. The default is [].
            指定しない場合，深層学習により学習したパラメータを呼び出す

        Returns
        -------
        port_all : pd.DataFrame
            DNNにより求めたポートフォリオのリターン            
        """
        X = make_torch_scaled_xs(X, self.factor_list, self.stock_list)

        if isinstance(rt, pd.DataFrame):
            rt = rt.values
        rt = torch.tensor(rt).float()

        rt_bench = base_port_return(rt)
        
        if len(weight_active) == 0:
            weight_active = [i[0] for i in self.model.last.parameters()][0]

        hidden_rt = self.get_hidden_return(X, rt)
        rt_active = hidden_rt@weight_active.detach().numpy().copy()
        port_rt = rt_bench + rt_active
        port_all = pd.concat(
            [port_rt, pd.Series(rt_bench), rt_active, hidden_rt], axis=1)
        port_all.columns = ["all", "bench", "active"] + \
            ["hidden_"+str(k_) for k_ in range(hidden_rt.shape[1])]

        return port_all