"""torchを用いて作成した深層学習モデルへインプットするデータセットの作成
"""
import numpy as np
import pandas as pd
import math
import torch


class XSDataLoader:
    """torch型のデータセットを作成するクラス
    """

    def __init__(self, X, y, batch_size, stock_list, factor_list, is_t_1):
        """
        Parameters
        ----------
        X : pd.DataFrame
            各銘柄の特徴量データセット
        y : pd.DataFrame
            各銘柄のリターンデータ      
        batch_size : int
            バッチサイズ
        stock_list : list
            銘柄のリスト
        factor_list : list
            特徴量のリスト
        is_t_1 : bool, optional
            翌期の特徴量データを使用する場合はTrue, by default True

        Raises
        ------
        ValueError
            pd.DataFrame出ない場合はエラー            
        """
        self.is_t_1 = is_t_1
        if not isinstance(X, pd.DataFrame) or not isinstance(y, pd.DataFrame):
            raise ValueError("X and y must be pd.DataFrame")
        self.X, self.y = X, y
        self.date_index = y.index
        self.batch_size = batch_size
        self.factor_list = factor_list
        self.stock_list = stock_list

    def _iter_t_1(self, index_start, index_end):
        array_t = np.zeros((
            index_end - index_start,
            len(self.stock_list),
            len(self.factor_list))
        )
        array_t_1 = np.zeros((
            index_end - index_start,
            len(self.stock_list),
            len(self.factor_list))
        )

        for i, index_ in enumerate(range(index_start, index_end)):
            df_t = self.X.loc[self.X["Date"] == self.date_index[index_], :].drop(
                ["Date"], axis=1)
            df_t_1 = self.X.loc[self.X["Date"] == self.date_index[index_+1],
                                :].drop(["Date"], axis=1)
            df_combined = pd.merge(df_t, df_t_1, how="left", on="stock")
            df_combined = df_combined.set_index("stock")

            array_t[i, :, :] = df_combined.iloc[:, :int(
                len(self.factor_list))].values
            array_t_1[i, :, :] = df_combined.iloc[:, int(
                len(self.factor_list)):].values
        X_t_torch = torch.tensor(array_t).float()
        X_t_1_torch = torch.tensor(array_t_1).float()
        y_torch = torch.tensor(
            self.y.loc[self.date_index[index_start:index_end], :].values).float()

        return X_t_torch, X_t_1_torch, y_torch

    def _iter_t(self, index_start, index_end):
        array_t = np.zeros((
            index_end - index_start,
            len(self.stock_list),
            len(self.factor_list))
        )
        for i, index_ in enumerate(range(index_start, index_end)):
            array_t[i, :, :] = self.X.loc[self.X["Date"] == self.date_index[index_], :].drop(
                ["Date"], axis=1).set_index("stock").values

        X_t_torch = torch.tensor(array_t).float()
        y_torch = torch.tensor(
            self.y.loc[self.date_index[index_start:index_end], :].values).float()

        return X_t_torch, y_torch

    def __iter__(self):
        """torch変換されたデータを作成するクラス

        Yields
        -------
        X_t_torch : torch.tensor
            t時点における各銘柄の特徴量データセット
            (銘柄, 時点, バッチサイズ)
        X_t_1_torch : torch.tensor
            t+1時点における各銘柄の特徴量データセット

            * is_t_1がTrueの場合，翌期の特徴量データセット(X_t_1_torch)が作成

            * is_t_1がFalseの場合，t時点における各銘柄の特徴量データセットのみ出力  
        y_torch : torch.tensor
            各時点における各銘柄のリターンデータ
        """
        if self.is_t_1:
            batch_set = math.floor((len(self.date_index)-1)/self.batch_size)
        else:
            batch_set = math.floor(len(self.date_index)/self.batch_size)

        for t in range(batch_set):
            index_start = int(self.batch_size * t)
            if self.is_t_1:
                if t+1 == batch_set:
                    index_end = len(self.date_index) - 1
                else:
                    index_end = int(self.batch_size * (t+1))
                yield self._iter_t_1(index_start, index_end)
            else:
                if t+1 == batch_set:
                    index_end = len(self.date_index)
                else:
                    index_end = int(self.batch_size * (t+1))
                yield self._iter_t(index_start, index_end)
