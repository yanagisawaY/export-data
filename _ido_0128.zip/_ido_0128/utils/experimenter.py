from ..utils.summarizer import ResultSummarizer
from ..utils.lrp import LRP
from ..utils.processor import make_torch_scaled_xs
from ..utils.portfolio_evaluator import PortfolioEvaluator

import pandas as pd
import time

def mystopwatch(func):
    def inner_func(*args):
        start = time.time()
        print(f'start...    {func.__name__}')
        result = func(*args)
        print(f'complete... {func.__name__}' +
              f" : {round(time.time()-start)}sec")
        return result
    return inner_func


class Experimenter:
    def __init__(self, hyperparms):
        self.hyperparms = hyperparms
        self.stock_list = hyperparms["stock_list"]
        self.factor_list = hyperparms["factor_list"]        

    @mystopwatch
    def learn(self, estimator, X_train, y_train, X_val, y_val):
        """DNNのパラメータ学習

        Parameters
        ----------
        estimator : function(pytorch module)
            モデル.
        X : np.array or pandas.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : np.array or pandas.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : np.array or pandas.DataFrame
            バリデーション期間における被説明変数(時点,)

        Returns
        -------
        estimator : function(pytorch module)
            学習済みモデル.
        """
        if self.hyperparms["is_tune"]:
            estimator.tune(
                X_train,
                y_train,
                X_val,
                y_val,
                self.hyperparms["n_trials"],
                self.hyperparms["timeout"]
            )
            self.hyperparms = estimator.update_hyperparams()
        estimator.fit(X_train, y_train, X_val, y_val)
        
        return estimator
    
    @mystopwatch
    def calc_weight(self, estimator, X_past, y_past, X_test, y_test):
        """ポートフォリオの重みづけ

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        X_past : np.array or pandas.DataFrame
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_past : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_test : np.array or pandas.DataFrame
            テスト期間における特徴量データ(銘柄×時点, 特徴量)            
        y_test : np.array or pandas.DataFrame
            テスト期間における被説明変数(時点,)

        Returns
        -------
        weight_test : dict
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.
            weight : pd.DataFrame
                ポートフォリオのウェイト
            theta : list
                企業特性合成ポートフォリオへのウェイト
            status : list
                最適化が成功したかどうかのリスト(中身はTrue or False)
            turnover : float
                ターンオーバー制約の上限値
            target_risk : float
                ターゲットリスクの上限値                
            weight_stockX : pd.DataFrame
                リバランスする銘柄数をXと制約を課して調整したポートフォリオのウェイト
        """
        weight_test = {}
        for turnover in self.hyperparms["turnover"]:
            for target_risk in self.hyperparms["target_risk"]:
                if turnover is None and target_risk is None:
                    weight_test_i = estimator.predict(X_test, rt_test=y_test)
                    theta_test_i = status_all_i = None
                elif turnover is None or target_risk is None:
                    continue
                else:
                    weight_test_i, theta_test_i, status_all_i = estimator.predict(
                        X_test, X_past, rt_train=y_past, rt_test=y_test, turnover=turnover, target_risk=target_risk
                        )
                key_ = "to_" + str(turnover) + "_tr_" + str(target_risk)
                weight_test_i = pd.DataFrame(
                        weight_test_i, index=y_test.index, columns=y_test.columns
                        )
                weight_test[key_] = {
                    "weight": weight_test_i,
                    "theta": theta_test_i,
                    "status": status_all_i,
                    "turnover": turnover,
                    "target_risk": target_risk,
                    }
                
                for stock_limit in self.hyperparms["stock_limit"]:
                    if stock_limit is None:
                        continue
                    weight_test_adjusted_i = estimator.adjust_weight(weight_test_i, y_test, stock_limit)
                    weight_test[key_].update({
                        "weight_stock" + str(stock_limit): weight_test_adjusted_i,
                        })
        
        assert len(weight_test) > 0,(
            "If the list of hyperparams['turnover'] contains None, " 
            + "then the list of hyperparams['target_risk'] must also contain None."
            )
        
        return weight_test

    @mystopwatch
    def calc_lrp_train(self, estimator, weight_test, X_past, y_past):
        """訓練データにおけるLRPを算出するメソッド

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        weight_test : dict
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        X_past : np.array or pandas.DataFrame
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_past : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)

        Returns
        -------
        port_lrp : dict
            port_lrp['train'] : dict
            各辞書の値(val)は以下で構成
            各時点におけるポートフォリオのLRP(企業特性合成ポートフォリオのLRPも結合させる)
            port_lrp[key] : pd.DataFrame
                keyの時点におけるポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ　+　ポートフォリオ)
            port_lrp['all'] : pd.DataFrame
                全時点におけるポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ　+　ポートフォリオ)
        """
        lrp = LRP(estimator, self.hyperparms)        
        stock_list_t = [y_past.columns[y_past.iloc[i, :] != 0]
                        for i in range(y_past.shape[0])]
        X_past = make_torch_scaled_xs(X_past, self.factor_list, self.stock_list)
        feature_lrp_torch = lrp.get_lrp(X_past)
        hidden_port_lrp = lrp.get_hidden_importance_lrp(X_past, feature_lrp_torch, stock_list_t)
                
        port_lrp = {}
        port_lrp["train"] = lrp.get_port_importance_lrp(hidden_port_lrp)
        
        return port_lrp
    
    @mystopwatch
    def calc_lrp(self, estimator, weight_test, X_test, y_test):
        """LRPを算出するメソッド

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        weight_test : dict
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        X_test : np.array or pandas.DataFrame
            テスト期間における特徴量データ(銘柄×時点, 特徴量)            
        y_test : np.array or pandas.DataFrame
            テスト期間における被説明変数(時点,)

        Returns
        -------
        port_lrp : dict
            port_lrp[key] : dict
            各設定(turnoverやtarget_risk)ごとのLRPの結果．各辞書の値(val)は以下で構成
                各時点におけるポートフォリオのLRP(企業特性合成ポートフォリオのLRPも結合させる)
                val[key] : pd.DataFrame
                    keyの時点におけるポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ　+　ポートフォリオ)
                val['all'] : pd.DataFrame
                    全時点におけるポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ　+　ポートフォリオ)
        """
        lrp = LRP(estimator, self.hyperparms)        
        stock_list_t = [y_test.columns[y_test.iloc[i, :] != 0]
                        for i in range(y_test.shape[0])]
        X_test = make_torch_scaled_xs(X_test, self.factor_list, self.stock_list)
        feature_lrp_torch = lrp.get_lrp(X_test)
        hidden_port_lrp = lrp.get_hidden_importance_lrp(X_test, feature_lrp_torch, stock_list_t)
        
        port_lrp = {}
        for key, val in weight_test.items():
            theta = val["theta"]
            if theta is None:
                theta = []
            port_lrp[key] = lrp.get_port_importance_lrp(hidden_port_lrp, weight_active=theta)
        
        return port_lrp

    @mystopwatch
    def calc_port_return(self, estimator, X_past, y_past, X_test, y_test):       
        """ポートフォリオのリターンを計算

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        X_past : np.array or pandas.DataFrame
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_past : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_test : np.array or pandas.DataFrame
            テスト期間における特徴量データ(銘柄×時点, 特徴量)            
        y_test : np.array or pandas.DataFrame
            テスト期間における被説明変数(時点,)

        Returns
        -------
        port_train : pd.DataFrame
            訓練データを用いて算出したDNNによるポートフォリオのリターン            
        port_test : TYPE
            テストデータを用いて算出したDNNによるポートフォリオのリターン            
        """
        rs = ResultSummarizer(estimator, self.hyperparms)            
        port_train = rs.get_port_return(X_past, y_past)
        port_test = rs.get_port_return(X_test, y_test)
        
        return port_train, port_test
            
    def get_port_performance(self, weight_test, y_test, hyperparms_portfolio, output_name, business_days):
        '''ポートフォリオのパフォーマンス結果を算出

        Parameters
        ----------
        weight_test : dict
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        y_test : 
            各資産のリターン
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        output_name : str
            resultの列名.(任意な列名を設定可能)

        Returns
        -------
        result : dict
            パフォーマンス結果とウェイトの情報を格納した辞書
            weight_testの各valに格納されたweightに対し，以下の結果を格納
            index_portfolio : pd.DataFrame
                ポートフォリオのインデックス推移.
            performance : pd.DataFrame
                ポートフォリオのパフォーマンス結果.
        '''        
        def _calc_port_perform(weight, y_port, hyperparms_portfolio, output_name, business_days):
            pe = PortfolioEvaluator(
                y_port, business_days, hyperparms_portfolio
                )
            return_portfolio = pe.calc_portfolio_return(weight)
            index_portfolio_ = pe.calc_wealth(return_portfolio)
            rt_bench = pe.calc_bench_return()
            bench_portfolio = pe.calc_wealth(rt_bench)
            performance = pe.make_peformance_result(weight, output_name)
            index_portfolio = pd.concat(
                [index_portfolio_, bench_portfolio, index_portfolio_-bench_portfolio], axis=1)
            index_portfolio.columns = [output_name, "bench", "alpha"]
            print(performance)
    
            return index_portfolio, performance
        
        import copy
        result = copy.deepcopy(weight_test)
        for key, val in weight_test.items():
            index_portfolio, performance = _calc_port_perform(val["weight"], y_test, hyperparms_portfolio, output_name, business_days)
            result[key].update({
                "index": index_portfolio,
                "performance": performance,
                })
        
        return result
            
            