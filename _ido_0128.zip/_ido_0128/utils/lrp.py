import numpy as np
import pandas as pd
import torch
from ..utils.processor import make_torch_scaled_xs


class LRP:
    def __init__(self, estimator, hyperparms):
        self.model = estimator.model
        self.stock_list = hyperparms["stock_list"]
        self.factor_list = hyperparms["factor_list"]

    def get_lrp(self, X, epsilon=1e-3):
        """各時点，各銘柄における企業特性の貢献度をLRP(Layer-wise relevance propagation)により算出

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)        
        epsilon : float, optional
            ハイパーパラメータ. The default is 1e-5.            

        Returns
        -------
        feature_lrp : torch.tensor
            各時点，各銘柄における企業特性の貢献度
            次元 = (時点, 銘柄, 企業特性)

        References
        ----------
        * Explaining nonlinear classification decisions with deep Taylor decomposition

        * `LRP を用いた深層学習株式リターン 予測モデルの解釈の試み <https://www.nikko-research.co.jp/wp-content/uploads/2019/10/rr_202003_iit01.pdf>`_
        """
        # L-1層におけるウェイトをもとに各層のユニットへの貢献度を通じて各特徴量の貢献度を求める
        contribution_tnj = self.model.mpn.forward(X).detach().transpose(1, 2)

        modules_list = dict(self.model.named_modules())
        modules_name = [i for i in list(
            modules_list.keys()) if 'mpn.full.' in i]

        # 中間層におけるパラメータを抽出
        lrp_params = {}
        for name_, params_ in self.model.named_parameters():
            if "last" not in name_:
                temp = name_.split(".weight")[0].split(".bias")[0]
                module_ = modules_list[temp]
                if "Linear" in str(module_) and ".weight" in name_:
                    lrp_params.update({name_: params_})

        X_ = X.detach()
        # 次元 = (時点, 銘柄, 企業特性)
        feature_lrp = torch.zeros(X_.shape)
        for stock_i in range(X_.shape[1]):
            # 各層における各ユニットの出力値
            X_hidden_ = {}
            out = X_[:, stock_i, :]
            X_hidden_.update({"input": out})
            for module_name in modules_name:
                module = modules_list[module_name]
                if "Dropout" not in str(module):
                    out = module(out)

                if "ReLU()" in str(module):
                    # ユニットの出力値 : out
                    X_hidden_.update({module_name: out})

            # l-1層のユニットiからl層のユニットjへの順伝搬の値を全層全ユニットで求める
            z_tij_propagation = {}
            keys_ = list(X_hidden_.keys())
            for i, xti in enumerate(X_hidden_.values()):
                if i < (len(keys_)-1):
                    module_name = keys_[i+1]
                    num = str(int(module_name.split(".")[-1])-2)
                    wji = lrp_params["mpn.full."+num+".weight"]
                    ztij = torch.zeros(
                        (xti.shape[0], xti.shape[1], wji.shape[0]))
                    for _t in range(ztij.shape[0]):
                        ztij[_t, :, :] = (wji*xti[_t, :]).T

                    ztj = torch.sum(ztij, 1, keepdim=True)

                    ratio_tij = ztij/(ztj+epsilon*torch.sign(epsilon/10+ztj))
                    z_tij_propagation.update({i: ratio_tij})

            # 貢献度を逆伝播により求める
            contribution_ti = contribution_tnj[:, stock_i, :]
            keys_ = list(reversed(list(X_hidden_.keys())))
            for i, ratio_tij in reversed(z_tij_propagation.items()):
                if torch.isnan(contribution_ti).sum() > 0:
                    # この時点のエラーは
                    # ztij/(ztj+epsilon*torch.sign(ztj))
                    # の分母が0になってしまう影響によるもの
                    print("#########\n error \n#########")
                    contribution_ti[torch.isnan(contribution_ti)] = 0

                r_tij_propagation = torch.zeros(ratio_tij.shape)
                for _t in range(ratio_tij.shape[0]):
                    r_tij_propagation[_t, :, :] = ratio_tij[_t,
                                                            :, :]*contribution_ti[_t, :]

                contribution_ti = torch.sum(r_tij_propagation, 2)

            feature_lrp[:, stock_i, :] = contribution_ti

        return feature_lrp

    def get_hidden_importance_lrp(self, X, feature_lrp_torch, stock_list_t):
        """業特性合成ポートフォリオのLRPの結果を算出

        Parameters
        ----------
        X : pandas.DataFrame or torch
            特徴量データ(銘柄×時点, 特徴量)，あるいはmake_torch_scaled_xs関数により変換済みのデータ
        feature_lrp_torch : torch.tensor
            各時点，各銘柄における企業特性の貢献度
            次元 = (時点, 銘柄, 企業特性)
        stock_list_t : list
            ユニバースに含まれる銘柄を時点ごとに保持したリスト.

        Returns
        -------
        hidden_port_lrp : dict
            各時点における企業特性合成ポートフォリオのLRP
            hidden_port_lrp[key] : pd.DataFrame
                keyの時点における企業特性合成ポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ)            
            port_lrp['all'] : pd.DataFrame
                全時点における企業特性合成ポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ)  
        """
        if isinstance(X, pd.DataFrame):
            X = make_torch_scaled_xs(X, self.factor_list, self.stock_list)
        hidden_weight = self.model.call_hidden_weight(
            X, rt=None, mode="predict").detach().transpose(1, 2)
        hidden_port_lrp_torch = torch.zeros(
            (feature_lrp_torch.shape[0],
             hidden_weight.shape[2], feature_lrp_torch.shape[2])
        )
        T = feature_lrp_torch.shape[0]

        hidden_port_lrp = {}
        hidden_port_lrp_all = pd.DataFrame(
            np.zeros(
                (hidden_port_lrp_torch.shape[1], hidden_port_lrp_torch.shape[2])),
            columns=self.factor_list
        )
        for t in range(T):
            temp = pd.DataFrame(
                feature_lrp_torch[t, :, :].detach().numpy().copy(),
                index=self.stock_list,
                columns=self.factor_list
            ).fillna(0)

            # 企業特性合成ポートフォリオのLRP
            is_flag = temp.index.isin(stock_list_t[t])
            hidden_port_lrp_torch[t, :, :] = torch.einsum(
                'in, nk->ik', hidden_weight[t, is_flag, :].T, feature_lrp_torch[t, is_flag, :])/len(stock_list_t[t])
            hidden_port_lrp_t = pd.DataFrame(
                hidden_port_lrp_torch[t, :, :].detach().numpy().copy(),
                columns=self.factor_list
            )
            hidden_port_lrp[t] = hidden_port_lrp_t
            hidden_port_lrp_all += hidden_port_lrp_t.values

        # LRPの時点平均
        hidden_port_lrp_all /= T
        hidden_port_lrp["all"] = hidden_port_lrp_all

        return hidden_port_lrp

    def get_port_importance_lrp(self, hidden_port_lrp, weight_active=[]):
        """ポートフォリオ全体のLRPの結果を算出

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)        
        stock_list_t : list
            ユニバースに含まれる銘柄を時点ごとに保持したリスト.

        Returns
        -------
        port_lrp : dict
            各時点におけるポートフォリオのLRP(企業特性合成ポートフォリオのLRPも結合させる)
            port_lrp[key] : pd.DataFrame
                keyの時点におけるポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ　+　ポートフォリオ)
            port_lrp['all'] : pd.DataFrame
                全時点におけるポートフォリオのLRP(特徴量, 企業特性合成ポートフォリオ　+　ポートフォリオ)
        """
        if len(weight_active) == 0:
            weight_active = [i[0].detach().numpy().copy()
                             for i in self.model.last.parameters()][0]

        port_lrp = {}
        for key, val in hidden_port_lrp.items():
            temp = pd.DataFrame(weight_active@val, columns=["all"]).T
            port_all_lrp_t = pd.concat([temp, val])
            port_lrp[key] = port_all_lrp_t

        return port_lrp
