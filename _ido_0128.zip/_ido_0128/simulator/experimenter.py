"""
Notes:
    本コードで使用しているクラス
    Experimenter
        シミュレーションデータを用いてモデル検証を実施するためのクラス
"""
from .simulator import Simulator
from ..utils.portfolio_evaluator import PortfolioEvaluator
from ..utils.experimenter import Experimenter
from ..models.comparative_model import ComparativeModel
from ..models.estimator import UtilityTrader

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import pickle


class SimulationExperimenter:
    def __init__(self, hyperparms):
        '''
            シミュレーションデータを用いてモデル検証を実施するクラス

        Parameters
        ----------        
            hyperparms : モデルのパラメータ        
        '''
        self.hyperparms = hyperparms
        self.business_days = 250/12
        self.estimator = {
            "UtilityTrader": UtilityTrader,
        }[self.hyperparms["model"]]

    def make_simulation_data(self, simulation_setting):
        '''シミュレーションデータの作成

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.

        Returns
        -------
        dict_output : dict
            シミュレーションデータ.
        '''
        self.sim = Simulator(simulation_setting)
        dict_output = self.sim.make_simulation_data()

        return dict_output

    def split_simulation(self, df_all, train_num=0, val_ratio=0):
        '''シミュレーションデータを訓練データとテストデータに分割

        Parameters
        ----------
        df_all : pd.DataFrame
            シミュレーションデータ.
        train_num : int, optional
            訓練データとテストデータを分割するインデックスの数値. The default is 0.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
        val_ratio : int
            訓練データのうちバリデーションデータに使用するデータ割合

        Returns
        -------
        X_train : pd.DataFrame
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : pd.DataFrame
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
        '''
        date_index = sorted(df_all["Date"].unique())
        y = df_all[["Date", "stock", "return"]]
        y = y.pivot(index="Date", columns="stock", values="return")
        X = df_all.drop(["return"], axis=1)

        # train_numのチェック
        assert isinstance(train_num, int)
        assert train_num >= 0 and train_num <= y.shape[0]
        if train_num == 0:
            train_num = int(y.shape[0]/2)

        val_num = int(train_num*(1-val_ratio))
        train_index = date_index[:val_num]
        test_index = date_index[train_num:]
        y_train = y.loc[train_index, :]
        y_test = y.loc[test_index, :]
        X_train = X.loc[X["Date"].isin(train_index), :]
        X_test = X.loc[X["Date"].isin(test_index), :]

        data_dict = {
            "X_train": X_train,
            "y_train": y_train,
            "X_test": X_test,
            "y_test": y_test,
        }

        if val_num > 0:
            val_index = date_index[val_num:train_num]
            X_val = X.loc[X["Date"].isin(val_index), :]
            y_val = y.loc[val_index, :]
            data_dict.update({
                "X_val": X_val,
                "y_val": y_val,
            })

        return data_dict

    def set_simulation(self, df_all, train_num: int, val_ratio: int):
        '''シミュレーションデータを用いてモデル学習・検証を実施

        Parameters
        ----------
        df_all : pd.DataFrame
            シミュレーションデータ.
        train_num : int
            訓練データとテストデータを分割するインデックスの数値.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
        val_ratio : float
            訓練データのうちバリデーションデータに使用するデータ割合

        Returns
        -------
        weight_test : pd.DataFrame
            テストデータにおける投資ウェイト.
        df_params : pd.DataFrame
            使用したパラメータ情報など
        df_info : pd.Series
            データの分割期間などの情報            
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点
        '''
        print('シミュレーションデータを用いた検証を開始')
        data_dict = self.split_simulation(df_all, train_num, val_ratio)
        if len(data_dict) == 4:
            X_train, y_train, X_test, y_test = data_dict.values()

            # 訓練データとテストデータに日付情報はないため，インデックスの数を代わりに保存
            self.train_start_date, self.train_end_date, self.test_start_date, self.test_end_date = \
                [0, y_train.shape[0], y_train.shape[0] +
                    1, y_train.shape[0]+y_test.shape[0]]
            return X_train, y_train, X_test, y_test
        else:
            X_train, y_train, X_test, y_test, X_val, y_val = data_dict.values()
            # 訓練データとテストデータに日付情報はないため，インデックスの数を代わりに保存
            self.train_start_date, self.train_end_date, self.val_start_date, self.val_end_date, self.test_start_date, self.test_end_date = \
                [
                    0,
                    y_train.shape[0],
                    y_train.shape[0] + 1,
                    y_train.shape[0]+y_val.shape[0],
                    y_train.shape[0]+y_val.shape[0]+1,
                    y_train.shape[0]+y_val.shape[0]+y_test.shape[0]
                ]

            self.hyperparms['stock_list'] = self.stock_list = y_train.columns
            self.hyperparms['factor_list'] = X_train.columns[2:]

            return X_train, y_train, X_test, y_test, X_val, y_val

    def get_simulation_result(self, simulation_setting, hyperparms_portfolio, hyperparms_comparative, output_name='sim1'):
        '''シミュレーションデータを用いたモデル学習結果に対し，パフォーマンス等の結果を保存

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        hyperparms_comparative : dict
            比較対象のモデルのハイパーパラメータ
        output_name : str
            resultの列名.(任意な列名を設定可能) The default is 'sim1'.

        Returns
        -------
        output : dict
            学習・バックテストの結果        
        '''
        # シミュレーションデータの生成
        df_all = self.make_simulation_data(simulation_setting)

        # シミュレーションデータの分割
        X_train, y_train, X_test, y_test, X_val, y_val = self.set_simulation(
            df_all,
            train_num=simulation_setting['train_num'],
            val_ratio=self.hyperparms["val_ratio"])

        output = {}
        result = {}
        ep = Experimenter(self.hyperparms)        
        # # STEP1 : estimate paramaters through backpropagation
        self.estimator = self.estimator(self.hyperparms)
        self.estimator = ep.learn(self.estimator, X_train, y_train, X_val, y_val)

        # STEP2 : optimize portfolio weight(optimize exporsure to hidden portfolio) under leverage constraint
        #       : adjust portfolio weight under the limitation of the number of stocks.        
        X_past = pd.concat([X_train, X_val], axis=0)
        y_past = pd.concat([y_train, y_val], axis=0)
        weight_test = ep.calc_weight(self.estimator, X_past, y_past, X_test, y_test)
        
        # STEP3 : Model Interpretation
        # calculate LRP
        port_lrp = ep.calc_lrp_train(self.estimator, weight_test, X_past, y_past)
        port_lrp.update(ep.calc_lrp(self.estimator, weight_test, X_test, y_test))

        # calculate portfolio return (+ hidden portfolio return)
        port_train, port_test = ep.calc_port_return(self.estimator, X_past, y_past, X_test, y_test)

        # summarize each result
        result.update({
            "model": self.estimator,
            "loss_info": self.estimator.loss_save,
            "port_train": port_train,
            "port_test": port_test,
            "port_lrp": port_lrp,
            })

        result_ = ep.get_port_performance(
            weight_test, y_test, hyperparms_portfolio, output_name, self.business_days
            )

        result.update({
            "result": result_,
            })
            
        # 比較モデルの学習/結果の出力
        if hyperparms_comparative['is_comparison']:
            weight_dict_other = self.get_simulation_result_other(
                df_all, hyperparms_comparative, train_num=simulation_setting['train_num'])
            for other_name, weight_test_other in weight_dict_other.items():
                index_, performance_ = self.get_portfolio_result(
                    weight_test_other, y_test, hyperparms_portfolio, output_name+'_'+other_name)
                result['index'] = pd.concat([result['index'], index_], axis=1)
                result['performance'] = pd.concat(
                    [result['performance'], performance_], axis=1)

        output[output_name] = result

        return output

    def get_simulation_result_other(self, df_all, hyperparms_comparative, train_num: int):
        '''比較モデルによるポートフォリオウェイトを算出

        Parameters
        ----------
        df_all : pd.DataFrame
            シミュレーションデータ.
        hyperparms_comparative : dict
            比較対象のモデルのハイパーパラメータ
        train_num : int
            訓練データとテストデータを分割するインデックスの数値.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割

        Returns
        -------
        weight_dict : dict
            比較モデルごとのポートフォリオウェイト.
        '''
        hyperparms_comparative['stock_list'] = self.stock_list
        cm = ComparativeModel(hyperparms_comparative)
        stock_num = len(self.stock_list)

        # シミュレーションデータの分割
        X_train, y_train, X_test, y_test = cm.split_simulation_data(
            df_all,
            train_num=train_num,
            val_ratio=self.hyperparms["val_ratio"])
        # ウェイトの算出
        weight_dict = cm.calc_weight_all_model(
            X_train, y_train, X_test, y_test, stock_num)

        return weight_dict

    def get_portfolio_result(self, weight, y_port, hyperparms_portfolio, output_name='result'):
        '''
            ポートフォリオのパフォーマンス結果を出力

        Parameters
        ----------
        weight : pd.DataFrame
            投資ウェイト.
        y_port : 
            各資産のリターン
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        output_name : str
            resultの列名.(任意な列名を設定可能)

        Returns
        -------
        index_portfolio : pd.DataFrame
            ポートフォリオのインデックス推移.
        performance : pd.DataFrame
            ポートフォリオのパフォーマンス結果.
        '''
        pe = PortfolioEvaluator(
            y_port, self.business_days, hyperparms_portfolio)
        return_portfolio = pe.calc_portfolio_return(weight)
        index_portfolio_ = pe.calc_wealth(return_portfolio)
        rt_bench = pe.calc_bench_return()
        bench_portfolio = pe.calc_wealth(rt_bench)
        performance = pe.make_peformance_result(weight, output_name)
        index_portfolio = pd.concat(
            [index_portfolio_, bench_portfolio, index_portfolio_-bench_portfolio], axis=1)
        index_portfolio.columns = [output_name, "bench", "alpha"]
        print(performance)

        return index_portfolio, performance

    def get_result_other(self, hyperparms_comparative, X_train, y_train, X_test, y_test):
        '''
            比較モデルによるポートフォリオウェイトを算出

        Parameters
        ----------
        hyperparms_comparative : dict
            比較対象のモデルのハイパーパラメータ
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.

        Returns
        -------
        weight_dict : dict
            比較モデルごとのポートフォリオウェイト.
        '''
        hyperparms_comparative['stock_list'] = self.stock_list
        cm = ComparativeModel(hyperparms_comparative)
        stock_num = len(self.stock_list)
        cm.set_index(y_train, y_test)

        # データの列名をstock_listに一致させる
        X_train, y_train = cm.check_df_columns(X_train, y_train)
        X_test, y_test = cm.check_df_columns(X_test, y_test)

        # 各ファクターの値を0-1ランク化
        X_train = cm.normalize_factor(X_train)
        X_test = cm.normalize_factor(X_test)

        # データのreshape
        X_train, y_train = cm.reshape_data(X_train, y_train)
        X_test, y_test = cm.reshape_data(X_test, y_test)

        # 欠損値処理
        X_train, y_train = cm.drop_na(X_train, y_train)
        # X_test, y_test = cm.drop_na(X_test, y_test)

        # ウェイトの算出
        weight_dict = cm.calc_weight_all_model(
            X_train, X_test, y_train, y_test, stock_num)

        return weight_dict

    def plot_simlation_data(self, dict_output):
        '''シミュレーションデータをプロットする（本機能は任意に実施可能なメソッド）

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''
        rt_all = dict_output['return']
        X = dict_output['factor']['I_0']
        df_plot = pd.DataFrame(
            [X.values.reshape(-1), rt_all.values.reshape(-1)], index=['X', 'y']).T
        plt.figure()
        sns.regplot(x='X', y='y', data=df_plot,
                    scatter_kws={'alpha': 0.1, 'color': 'black'},
                    line_kws={'color': 'red'})
        plt.show()
        print(f'corr : {df_plot.corr()}')

    def get_simulation_states(self):
        '''シミュレーションデータで生成された状態の情報を出力

        Returns
        -------
        states : pd.DataFrame
            サンプリングされた状態 (年代, 企業特性)
        '''
        states = pd.DataFrame(self.sim.states, columns=self.sim.factor_I)

        return states

    def output_result(self, all_result, path_output):
        '''学習済みのハイパーパラメータをフォルダに出力(pickleファイル)
        Parameters
        ----------
        all_result : dict
            学習・バックテストの結果   
        path_output : str
            ファイルの出力フォルダ.
        '''
        def pickle_dump(obj, path):
            with open(path, mode='wb') as f:
                pickle.dump(obj, f)

        pickle_dump(all_result, path_output+'\\all_result.pkl')
