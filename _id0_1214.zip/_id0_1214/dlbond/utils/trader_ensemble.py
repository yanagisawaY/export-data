import pandas as pd
from .trader import Trader


class TraderEnsembler:
    def __init__(self):
        self.y_pred_ensembled = None    
        self.potion_ensembled = None            
    
    def position_ensemble(self, signals):
        