import pandas as pd
import numpy as np


class Trader:
    def __init__(self, config):
        self.config = config
        self.cost_buy = config['config_trade']['cost_buy']
        self.cost_sell = config['config_trade']['cost_sell']

    def make_signal(self, y_pred):
        """予測値をもとに売買シグナルを作成

        Parameters
        ----------
        y_pred : pd.Series
            予測値

        Returns
        -------
        signal : pd.Series
            売買シグナル
        """
        target_type = self.config['config_target']['type']
        if target_type == 'trend_scan_val':
            threshold = self.config['config_trade'][target_type]['threshold']
            signal = 1*(y_pred >= threshold) - 1*(y_pred <= -threshold)
        elif target_type == 'trend_scan_class':
            threshold = self.config['config_trade'][target_type]['threshold']
            y_pred = y_pred.argmax(1)
            signal = 1*(y_pred >= threshold) - 1*(y_pred <= -threshold)            
        else:
            raise ValueError(
                'current version is only supported trend_scan_val. please wait for some updates coming soon...')

        return signal

    def calc_tradecost(self, signal):
        """投資量を固定した場合の取引コストを算出(取引コストは売り買いそれぞれで設定)

        Parameters
        ----------
        signal : pd.Series
            売買シグナル

        Returns
        -------
        cost_index : pd.Series
            売買コスト
        """
        signal = pd.Series(signal)
        weight_diff = signal.diff().fillna(0).copy()  # 投資量を常に固定した場合のウェイト変化を算出
        cost_index = np.abs(weight_diff.fillna(0)*(weight_diff > 0))*self.cost_buy + \
            np.abs(weight_diff.fillna(0)*(weight_diff < 0))*self.cost_sell

        return cost_index

    def calc_return(self, futures_return, signal):
        """トレードの結果の富の計算

        Parameters
        ----------
        futures_return : pd.Series
            トレーディング対象のリターン.
        signal : pd.Series
            売買シグナル

        Returns
        -------
        trade_return : pd.Series
            トレードによるリターン（各時点で取引コストを引いている）
        """
        cost_index = self.calc_tradecost(signal)
        trade_return = futures_return*signal
        cost_index.index = trade_return.index    
        trade_return = trade_return - cost_index
    
        return trade_return

    def calc_wealth(self, futures_return, signal):
        """トレードの結果の富の計算

        Parameters
        ----------
        futures_return : pd.Series
            トレーディング対象のリターン.
        signal : pd.Series
            売買シグナル

        Returns
        -------
        wealth : pd.Series
            トレードによる累積リターン
        """
        trade_return = self.calc_return(futures_return, signal)
        wealth = (1 + trade_return).cumprod()

        return trade_return, wealth