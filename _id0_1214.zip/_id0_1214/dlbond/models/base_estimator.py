from sklearn.base import BaseEstimator, RegressorMixin, ClassifierMixin
from sklearn.utils.estimator_checks import check_estimator

class ModelWrapper:
    def __init__(self, estimator):
        self.estimator = estimator
    
    def predict(self, X):
        return self.estimator.fit(X)
    
    def fit(self, X, y):
        return self.estimator.fit(X, y)
    
    def tune(self, X, y):
        pass


    
    

