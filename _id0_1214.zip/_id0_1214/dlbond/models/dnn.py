"""
Standard Deep model
"""
from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import OneHotEncoder
import pandas as pd
import numpy as np
import optuna
from optuna.trial import TrialState

class DeepNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''
    def __init__(self, hyperparms, input_num, output_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(DeepNet, self).__init__()
        layer_units = hyperparms['layer_list']        
        layer_num = len(layer_units)
        layer = []
        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(input_num, layer_units[0]))
        layer.append(nn.BatchNorm1d(layer_units[0]))
        layer.append(nn.ReLU())
        if layer_num > 1:
            for i in range(layer_num-1):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))
                layer.append(nn.Linear(layer_units[i], layer_units[i+1]))
                layer.append(nn.BatchNorm1d(layer_units[i+1]))
                layer.append(nn.ReLU())

        layer.append(nn.Dropout(hyperparms['layer_dropout']))                    
        layer.append(nn.Linear(layer_units[-1], output_num))
        if output_num == 3:
            layer.append(nn.Softmax(dim=1))
        self.full = nn.Sequential(*layer)
                            
    def forward(self, X):        
        output = self.full(X)
        
        return output.squeeze()


class DeepLearner:
    '''DNNの学習を行うクラス
    '''    
    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout  : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        self.hyperparms = hyperparms
        self.study = None                            
        self.is_fit_cv = False      
        assert hyperparms['min_ephoch'] < hyperparms['epoch']

    def get_tensor(self, X, y):
        """テンソル型に変換

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            被説明変数(時点,)

        Returns
        -------
        X : torch.tensor
            特徴量データ(時点, 特徴量)
        y : torch.tensor
            被説明変数(時点,)
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(y, pd.DataFrame):
            y = y.values
            
        X = torch.Tensor(X)
        if self.hyperparms['loss'] == 'MSELoss':            
            y = torch.Tensor(y)
        elif self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':            
            y = torch.Tensor(y).squeeze().long()            

        return X, y
    
    def _criterion(self):
        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()
            
        return criterion
    
    def _train(self, loader, model, criterion, is_val, X_val, y_val):
        loss_val_min = 10000**1000
        patience_count = 0
        loss_save = []
        optimizer = torch.optim.Adam(model.parameters(), lr = self.hyperparms['lr'])                       
        for epoch in range(self.hyperparms['epoch']):
            for X_, y_ in loader:
                if X_.shape[0] > 1:
                    y_pred = model.forward(X_)
                    loss = criterion(y_pred, y_)
                    loss.backward()
                    optimizer.step()
            
            if is_val and epoch > self.hyperparms['min_ephoch']:
                with torch.no_grad():
                    y_pred_val = model.forward(X_val)
                    loss_val = criterion(y_pred_val, y_val).item()
                    if loss_val_min > loss_val:
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1
                    loss_save += [loss.item(), loss_val]
                
                if (epoch+1)%100==0:
                    print(f'{epoch+1}/{self.hyperparms["epoch"]} : train {round(loss.item(), 3)} - val {round(loss_val, 3)}')

                if patience_count >= self.hyperparms["patience_max"]:
                    print(f'{epoch+1}/{self.hyperparms["epoch"]} (early stop): train {round(loss.item(), 3)} - val {round(loss_val, 3)}')                    
                    break
            else:                
                loss_save += [loss.item()]                
                if (epoch+1)%100==0:
                    print(f'{epoch+1}/{self.hyperparms["epoch"]} : {round(loss.item(), 4)}')        

        return model, loss_save                    
        
    def _fit(self, X, y, X_val=[], y_val=[]):
        """バリデーションデータのインプットに応じてモデル学習を実行

        Parameters
        ----------
        X : torch.tensor
            特徴量データ(時点, 特徴量)
        y : torch.tensor
            被説明変数(時点,)
        X_val : torch.tensor
            バリデーションデータ用の特徴量データ(時点, 特徴量)
        y_val : torch.tensor
            バリデーションデータ用の被説明変数(時点,)            
        
        Returns
        -------
        model : 
            学習済みモデル
        loss_save : pd.DataFrame
            エポックごとの目的関数値

        Notes
        -----
        X_valとy_valがインプットされていない場合，早期停止を実施しない
        """ 
        torch.manual_seed(self.hyperparms['random_state'])
        is_val = (len(X_val) > 0 and len(y_val) > 0)
                    
        df = TensorDataset(X, y)
        loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=False)
        input_num = X.size(1)

        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
            model = DeepNet(self.hyperparms, input_num, output_num=1)  
        elif self.hyperparms['loss'] == '2class':
            criterion = nn.CrossEntropyLoss()
            model = DeepNet(self.hyperparms, input_num, output_num=2)             
        elif self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()
            model = DeepNet(self.hyperparms, input_num, output_num=3) 

        model, loss_save = self._train(loader, model, criterion, is_val, X_val, y_val)
        loss_save = pd.DataFrame(loss_save)
        
        return model, loss_save
    
    def fit(self, X, y, is_val=False):
        """モデル学習を実行

        Parameters
        ----------
        X : torch.tensor
            特徴量データ(時点, 特徴量)
        y : torch.tensor
            被説明変数(時点,)            
        is_val : bool, optional
            バリデーションデータを用いた早期停止条件を課す場合はTrue, by default False

        Attributes
        ----------
        model : 
            学習済みモデル
        loss_save : pd.DataFrame
            エポックごとの目的関数値
        """
        X, y = self.get_tensor(X, y)
        if is_val:
            val_num = int(X.shape[0]*(1-self.hyperparms["val_early_stop"]))
            X_, y_ = X, y
            X = X_[:val_num,:]
            y = y_[:val_num]
            X_val = X_[val_num:,:]
            y_val = y_[val_num:]
            self.model, self.loss_save = self._fit(X, y, X_val, y_val)
        else:
            self.model, self.loss_save = self._fit(X, y)

    def fit_cv(self, dict_val):
        """モデル学習を実行

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        models : 
            各ホールドのデータセットで学習したモデル
        lossed_save : pd.DataFrame
            各ホールドのデータセットにおけるエポックごとの目的関数値
        """
        models = {}
        losses_save = {}
        loss_sum = 0
        for i, dict_ in dict_val.items():
            (X_train, y_train, X_val, y_val) = dict_.values()
            X_train, y_train = self.get_tensor(X_train, y_train)
            X_val, y_val = self.get_tensor(X_val, y_val)
            self.model, loss_save = self._fit(X_train, y_train, X_val, y_val)
            y_pred = self.predict(X_val)
            criterion = self._criterion()
            _, y_pred = self.get_tensor(X_val, y_pred)                
            loss_sum += criterion(y_val, y_pred).item()

            models.update({i: self.model})
            losses_save.update({i: loss_save})
        
        self.models = models
        self.losses_save = losses_save
        self.is_fit_cv = True        
        self.loss_sum = loss_sum
    
    def predict_cv(self, X, ensemble_weight=[]):
        """CVを用いて学習したモデルの予測値をアンサンブルした予測値を出力

        Parameters
        ----------
        X : torch.tensor
            特長量データ．
        ensemble_weight : list, optional
            各モデルの出力値の重みづけ．特に設定しない場合，等ウェイトの予測値を出力．

        Returns
        -------
        y_pred_ensembled : np.array
            アンサンブルした予測値
        """
        if len(ensemble_weight) == 0:
            ensemble_weight = [1/len(self.models) for _ in range(len(self.models))]
        
        y_pred_ensembled = np.zeros(X.shape[0])
        for i, model in enumerate(self.models.values()):
            y_pred = model.forward(X).detach().numpy().copy()
            y_pred_ensembled += ensemble_weight[i]*y_pred
        
        return y_pred_ensembled

    def predict(self, X):
        """学習したパラメータをもとに予測値を出力

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量) 

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        X = torch.Tensor(X)
        if self.is_fit_cv:
            y_pred = self.predict_cv(X)
        else:
            y_pred = self.model.forward(X)
            y_pred = y_pred.detach().numpy().copy()

        return y_pred

    def tune(self, X, y, X_val, y_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : np.array or pandas.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : np.array or pandas.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        Raises
        ------
        optuna.exceptions.TrialPruned
            Handle pruning based on the intermediate value.

        References
        ----------
            [1] https://optuna.org/
            [2] https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        """
        torch.manual_seed(self.hyperparms['random_state'])
        X, y = self.get_tensor(X, y)
        df = TensorDataset(X, y)
        loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=True)
        X_val, y_val = self.get_tensor(X_val, y_val)
        input_num = X.size(1)

        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif  self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()

        hyperparms = self.hyperparms

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform('layer_dropout', 0, 1.0)

            n_layers = trial.suggest_int("n_layers", 1, 3)
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [trial.suggest_int("n_units_l{}".format(i), 4, 128)]

            if self.hyperparms['loss'] == 'MSELoss':            
                model = DeepNet(hyperparms, input_num, output_num=1)  
            elif  self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
                model = DeepNet(hyperparms, input_num, output_num=3) 

            optimizer = torch.optim.Adam(model.parameters(), lr)               
            for epoch in range(hyperparms['epoch']):
                for X_, y_ in loader:
                    if X_.shape[0] > 1:
                        y_pred = model.forward(X_)                    
                        loss = criterion(y_pred, y_)
                        loss.backward()
                        optimizer.step()

                with torch.no_grad():
                    y_pred_val = model.forward(X_val)
                    loss = criterion(y_pred_val, y_val).item()

                trial.report(loss, epoch)

                # Handle pruning based on the intermediate value.
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()

            return loss

        sampler = optuna.samplers.TPESampler(seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler,
                                    pruner=optuna.pruners.SuccessiveHalvingPruner())
        study.optimize(objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"])
        self.study = study

    def tune_Kfold_nonprune(self, dict_val, is_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化をPurgedKfoldにより実施（枝刈りアルゴリズムを使用しない）

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
            [1] https://optuna.org/
            [2] https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        """
        torch.manual_seed(self.hyperparms['random_state'])
        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif  self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()

        hyperparms = self.hyperparms

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform('layer_dropout', 0, 1.0)

            n_layers = trial.suggest_int("n_layers", 1, 3)
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [trial.suggest_int("n_units_l{}".format(i), 4, 128)]

            loss_all = 0
            for i, dict_ in enumerate(dict_val.values()):
                print(f"{i}/{len(dict_val)} fold")
                (X_train, y_train, X_val, y_val) = dict_.values()

                torch.manual_seed(self.hyperparms['random_state']+i)
                X_train, y_train = self.get_tensor(X_train, y_train)
                df = TensorDataset(X_train, y_train)
                loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=False)
                X_val, y_val = self.get_tensor(X_val, y_val)
                input_num = X_train.size(1)
            
                if self.hyperparms['loss'] == 'MSELoss':            
                    model = DeepNet(hyperparms, input_num, output_num=1)  
                elif self.hyperparms['loss'] == '2class':
                    model = DeepNet(hyperparms, input_num, output_num=2)                     
                elif self.hyperparms['loss'] == '3class':
                    model = DeepNet(hyperparms, input_num, output_num=3) 
    
                model, loss_save = self._train(loader, model, criterion, is_val, X_val, y_val)
                loss_all  += loss_save[-1]
            
            loss_all = loss_all/len(dict_val)

            return loss_all

        sampler = optuna.samplers.TPESampler(seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler)
        study.optimize(objective, n_trials=n_trials, timeout=timeout)
        self.study = study

    def tune_Kfold_prune(self, dict_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化をPurgedKfoldにより実施（枝刈りアルゴリズムを使用）

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        Notes
        -----
        枝刈り方法について試行錯誤の中で作成したメソッド．（後に削除する可能性あり）        
        """
        torch.manual_seed(self.hyperparms['random_state'])
        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()

        hyperparms = self.hyperparms

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform('layer_dropout', 0, 1.0)

            n_layers = trial.suggest_int("n_layers", 1, 3)
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [trial.suggest_int("n_units_l{}".format(i), 4, 128)]

            models = {}
            loaders = {}
            for i, dict_ in enumerate(dict_val.values()):
                print(f"{i}/{len(dict_val)} fold prune ver")
                (X_train, y_train, X_val, y_val) = dict_.values()

                torch.manual_seed(self.hyperparms['random_state']+i)
                X_train, y_train = self.get_tensor(X_train, y_train)
                df = TensorDataset(X_train, y_train)
                loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=False)
                X_val, y_val = self.get_tensor(X_val, y_val)
                input_num = X_train.size(1)
            
                if self.hyperparms['loss'] == 'MSELoss':            
                    model = DeepNet(hyperparms, input_num, output_num=1)  
                elif self.hyperparms['loss'] == '2class':                    
                    model = DeepNet(hyperparms, input_num, output_num=2)                      
                elif self.hyperparms['loss'] == '3class':
                    model = DeepNet(hyperparms, input_num, output_num=3) 
                
                models.update({i: model})
                loaders.update({i: loader})

            optimizer = torch.optim.Adam(model.parameters(), lr)               

            for epoch in range(hyperparms['epoch']):
                loss_all = 0                            
                for i, loader in loaders.items():
                    for X_, y_ in loader:
                        if X_.shape[0] > 1:
                            y_pred = models[i].forward(X_)                    
                            loss = criterion(y_pred, y_)
                            loss.backward()
                            optimizer.step()

                    with torch.no_grad():
                        y_pred_val = models[i].forward(X_val)
                        loss_all += criterion(y_pred_val, y_val).item()
            
                loss_all = loss_all/len(dict_val)

                trial.report(loss_all, epoch)

                # Handle pruning based on the intermediate value.
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()
                    
            return loss_all

        sampler = optuna.samplers.TPESampler(seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler,
                                    pruner=optuna.pruners.SuccessiveHalvingPruner())
        study.optimize(objective, n_trials=n_trials, timeout=timeout)
        self.study = study
        
    def update_hyperparams(self, hyperparms_best_updated={}):
        """optunaにより調整したハイパーパラメータの辞書の更新

        Parameters
        ----------
        hyperparms_best_updated : dict
            更新されたハイパーパラメータ (チューニングされたパラメータのみ)

            指定しない場合，tuneにより調整されたstudyのbest_trialが参照される．

        Raises
        ----------
        optunaのハイパーパラメータ最適化( tune )を先に実行する

        Returns
        -------
        hyperparms_best : dict
            更新したハイパーパラメータの辞書
        """
        if len(hyperparms_best_updated) == 0:            
            if self.study is None:
                raise ValueError('tuneを実行してください')                    
            hyperparms_best = self.hyperparms
            hyperparms_best_updated = self.study.best_trial.params            
        else:
            assert isinstance(hyperparms_best_updated, dict)
            hyperparms_best = self.hyperparms            
        
        hyperparms_best['layer_list'] = []
        for layer in range(hyperparms_best_updated['n_layers']):
            hyperparms_best['layer_list'] += [hyperparms_best_updated['n_units_l'+str(layer)]]            
        hyperparms_best['lr'] = hyperparms_best_updated['lr']
        hyperparms_best['layer_dropout'] = hyperparms_best_updated['layer_dropout']        
        self.hyperparms = hyperparms_best

        return hyperparms_best

