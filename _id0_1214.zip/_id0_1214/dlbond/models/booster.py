

import lightgbm as lgb
import xgboost as xgb
import numpy as np
import pandas as pd

class BoostLearner:
    '''ブースティング系モデルの学習を行うクラス
    '''    
    def __init__(self, hyperparms):
        '''
        hyperparms : dict
        '''
        self.hyperparms = hyperparms
        self.hyperparms_model = self.hyperparms[hyperparms["model"]]
        self.study = None                            
        self.is_fit_cv = False        
    
    def _call_categorical_features(self):
        self.categorical_features = ""
        
    def _call_criterion_lgb(self):
        if self.hyperparms['loss'] == 'MSELoss':        
            self.hyperparms_model["objective"] = "regression"
            self.hyperparms_model["metric"] = "rmse"
        elif self.hyperparms['loss'] == '2class':
            self.hyperparms_model["objective"] = "binary"
            self.hyperparms_model["metric"] = "binary_logloss"            
        elif self.hyperparms['loss'] == '3class':        
            self.hyperparms_model["objective"] = "multiclass"
            self.hyperparms_model["metric"] = "multi_logloss"
            self.hyperparms_model["num_class"] = 3
            
    def _call_criterion_xgb(self):
        if self.hyperparms['loss'] == 'MSELoss':
            self.hyperparms_model["objective"] = "reg:squarederror"
            self.hyperparms_model["eval_metric"] = "rmse"
        elif self.hyperparms['loss'] == '2class':
            self.hyperparms_model["objective"] = "binary:logistic"
            self.hyperparms_model["eval_metric"] = "logloss"
        elif self.hyperparms['loss'] == '3class':
            self.hyperparms_model["objective"] = "multi:softmax"
            self.hyperparms_model["eval_metric"] = "mlogloss" 
            self.hyperparms_model["num_class"] = 3
        
    def _call_model(self):
        if self.hyperparms["model"] == "lightgbm":
            self._call_criterion_lgb()
        elif self.hyperparms["model"] == "xgboost":
            self._call_criterion_xgb()
        
        self._call_categorical_features()
        model = {
            "xgboost": xgb,
            "lightgbm": lgb,
            }[self.hyperparms["model"]]
        
        return model
    
    def _set_dataset_lgb(self, X, y, X_val=[], y_val=[]):
        lgb_train = lgb.Dataset(
            X, 
            y,
            categorical_feature=self.categorical_features,
            free_raw_data=False
            )

        if len(X_val)>0 and len(y_val)>0:
            lgb_val = lgb.Dataset(
                X_val, 
                y_val, 
                reference=lgb_train,
                categorical_feature=self.categorical_features,
                free_raw_data=False
                )
            
            return lgb_train, lgb_val
        else:
            return lgb_train
    
    def _set_dataset_xgb(self, X, y, X_val=[], y_val=[]):
        xgb_train = xgb.DMatrix(
            X, 
            label=y
            )

        if len(X_val)>0 and len(y_val)>0:
            xgb_val = xgb.DMatrix(
                X_val, 
                label=y_val
                )
            
            return xgb_train, xgb_val
        else:
            return xgb_train        
    
    def set_dataset(self, X, y, X_val=[], y_val=[]):        
        _set_dataset = {
            "lightgbm": self._set_dataset_lgb,
            "xgboost": self._set_dataset_xgb,            
            }[self.hyperparms["model"]]
        
        if len(X_val)>0 and len(y_val)>0:
            d_train, d_val = _set_dataset(X, y, X_val, y_val)
            
            return d_train, d_val
        else:
            d_train = _set_dataset(X, y)            
            
            return d_train
                
    def _fit(self, X, y, X_val=[], y_val=[]):
        model = self._call_model()
        evals_result = {}        
        if len(X_val)>0 and len(y_val)>0:
            d_train, d_val = self.set_dataset(X, y, X_val, y_val)
            model.train(
                self.hyperparms_model,
                d_train,
                num_boost_round=self.hyperparms["num_boost_round"], # 学習の回数
                valid_names=['train', 'valid'],                     # 学習経過で表示する名称
                valid_sets=[d_train, d_val],                        # モデル検証のデータセット
                evals_result=evals_result,                          # 学習の経過を保存
                # categorical_feature=self.categorical_features,    # カテゴリー変数を設定
                early_stopping_rounds=self.hyperparms["early_stopping_rounds"], # アーリーストッピング# 学習
                verbose_eval=-1 # 学習の経過の非表示     
                )               
        else:
            d_train = self.set_dataset(X, y)
            model.train(
                self.hyperparms_model,
                d_train,
                num_boost_round=self.hyperparms["num_boost_round"], # 学習の回数
                # categorical_feature=self.categorical_features, # カテゴリー変数を設定                
                valid_names=['train'],     # 学習経過で表示する名称
                valid_sets=[d_train],      # モデル検証のデータセット 
                evals_result=evals_result, # 学習の経過を保存                
                verbose_eval=-1            # 学習の経過の非表示
                )
            
        return model, evals_result
    
    def fit(self, X, y, is_val=False):
        """モデル学習を実行

        Parameters
        ----------
        X : torch.tensor
            特徴量データ(時点, 特徴量)
        y : torch.tensor
            被説明変数(時点,)            
        is_val : bool, optional
            バリデーションデータを用いた早期停止条件を課す場合はTrue, by default False

        Attributes
        ----------
        model : 
            学習済みモデル
        loss_save : pd.DataFrame
            エポックごとの目的関数値
        """
        if is_val:
            val_num = int(X.shape[0]*(1-self.hyperparms["val_early_stop"]))
            X_, y_ = X, y
            X = X_[:val_num,:]
            y = y_[:val_num]
            X_val = X_[val_num:,:]
            y_val = y_[val_num:]
            self.model, self.evals_result = self._fit(X, y, X_val, y_val)
        else:
            self.model, self.evals_result = self._fit(X, y)

    def predict_cv(self, X, ensemble_weight=[]):
        """CVを用いて学習したモデルの予測値をアンサンブルした予測値を出力

        Parameters
        ----------
        X : torch.tensor
            特長量データ．
        ensemble_weight : list, optional
            各モデルの出力値の重みづけ．特に設定しない場合，等ウェイトの予測値を出力．

        Returns
        -------
        y_pred_ensembled : np.array
            アンサンブルした予測値
        """
        if len(ensemble_weight) == 0:
            ensemble_weight = [1/len(self.models) for _ in range(len(self.models))]
        
        y_pred_ensembled = np.zeros(X.shape[0])
        for i, model in enumerate(self.models.values()):
            y_pred = model.predict(X)
            y_pred_ensembled += ensemble_weight[i]*y_pred
        
        return y_pred_ensembled    

    def predict(self, X):
        """学習したパラメータをもとに予測値を出力

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量) 

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        X = torch.Tensor(X)
        if self.is_fit_cv:
            y_pred = self.predict_cv(X)
        else:
            y_pred = self.model.forward(X)
            y_pred = y_pred.detach().numpy().copy()

        return y_pred
        
    def fit_cv(self, dict_val):
        """モデル学習を実行

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        models : 
            各ホールドのデータセットで学習したモデル
        lossed_save : pd.DataFrame
            各ホールドのデータセットにおけるエポックごとの目的関数値
        """
        models = {}
        losses_save = {}
        loss_sum = 0
        for i, dict_ in dict_val.items():
            (X_train, y_train, X_val, y_val) = dict_.values()            
            self.model, loss_save = self._fit(X_train, y_train, X_val, y_val)
            y_pred = self.predict(X_val)
            import pdb
            pdb.set_trace()

            models.update({i: self.model})
            losses_save.update({i: loss_save})
        
        self.models = models
        self.losses_save = losses_save
        self.is_fit_cv = True        
        self.loss_sum = loss_sum
    
    def predict_cv(self, X, ensemble_weight=[]):
        """CVを用いて学習したモデルの予測値をアンサンブルした予測値を出力

        Parameters
        ----------
        X : torch.tensor
            特長量データ．
        ensemble_weight : list, optional
            各モデルの出力値の重みづけ．特に設定しない場合，等ウェイトの予測値を出力．

        Returns
        -------
        y_pred_ensembled : np.array
            アンサンブルした予測値
        """
        if len(ensemble_weight) == 0:
            ensemble_weight = [1/len(self.models) for _ in range(len(self.models))]
        
        y_pred_ensembled = np.zeros(X.shape[0])
        for i, model in enumerate(self.models.values()):
            y_pred = model.forward(X).detach().numpy().copy()
            y_pred_ensembled += ensemble_weight[i]*y_pred
        
        return y_pred_ensembled

    def predict(self, X):
        """学習したパラメータをもとに予測値を出力

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量) 

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        X = torch.Tensor(X)
        if self.is_fit_cv:
            y_pred = self.predict_cv(X)
        else:
            y_pred = self.model.forward(X)
            y_pred = y_pred.detach().numpy().copy()

        return y_pred

    def tune(self, X, y, X_val, y_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : np.array or pandas.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : np.array or pandas.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        Raises
        ------
        optuna.exceptions.TrialPruned
            Handle pruning based on the intermediate value.

        References
        ----------
            [1] https://optuna.org/
            [2] https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        """
        torch.manual_seed(self.hyperparms['random_state'])
        X, y = self.get_tensor(X, y)
        df = TensorDataset(X, y)
        loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=True)
        X_val, y_val = self.get_tensor(X_val, y_val)
        input_num = X.size(1)

        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif  self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()

        hyperparms = self.hyperparms

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform('layer_dropout', 0, 1.0)

            n_layers = trial.suggest_int("n_layers", 1, 3)
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [trial.suggest_int("n_units_l{}".format(i), 4, 128)]

            if self.hyperparms['loss'] == 'MSELoss':            
                model = DeepNet(hyperparms, input_num, output_num=1)  
            elif  self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
                model = DeepNet(hyperparms, input_num, output_num=3) 

            optimizer = torch.optim.Adam(model.parameters(), lr)               
            for epoch in range(hyperparms['epoch']):
                for X_, y_ in loader:
                    if X_.shape[0] > 1:
                        y_pred = model.forward(X_)                    
                        loss = criterion(y_pred, y_)
                        loss.backward()
                        optimizer.step()

                with torch.no_grad():
                    y_pred_val = model.forward(X_val)
                    loss = criterion(y_pred_val, y_val).item()

                trial.report(loss, epoch)

                # Handle pruning based on the intermediate value.
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()

            return loss

        sampler = optuna.samplers.TPESampler(seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler,
                                    pruner=optuna.pruners.SuccessiveHalvingPruner())
        study.optimize(objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"])
        self.study = study

    def tune_Kfold_nonprune(self, dict_val, is_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化をPurgedKfoldにより実施（枝刈りアルゴリズムを使用しない）

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
            [1] https://optuna.org/
            [2] https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        """
        torch.manual_seed(self.hyperparms['random_state'])
        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif  self.hyperparms['loss'] == '2class' or self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()

        hyperparms = self.hyperparms

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform('layer_dropout', 0, 1.0)

            n_layers = trial.suggest_int("n_layers", 1, 3)
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [trial.suggest_int("n_units_l{}".format(i), 4, 128)]

            loss_all = 0
            for i, dict_ in enumerate(dict_val.values()):
                print(f"{i}/{len(dict_val)} fold")
                (X_train, y_train, X_val, y_val) = dict_.values()

                torch.manual_seed(self.hyperparms['random_state']+i)
                X_train, y_train = self.get_tensor(X_train, y_train)
                df = TensorDataset(X_train, y_train)
                loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=False)
                X_val, y_val = self.get_tensor(X_val, y_val)
                input_num = X_train.size(1)
            
                if self.hyperparms['loss'] == 'MSELoss':            
                    model = DeepNet(hyperparms, input_num, output_num=1)  
                elif self.hyperparms['loss'] == '2class':
                    model = DeepNet(hyperparms, input_num, output_num=2)                     
                elif self.hyperparms['loss'] == '3class':
                    model = DeepNet(hyperparms, input_num, output_num=3) 
    
                model, loss_save = self._train(loader, model, criterion, is_val, X_val, y_val)
                loss_all  += loss_save[-1]
            
            loss_all = loss_all/len(dict_val)

            return loss_all

        sampler = optuna.samplers.TPESampler(seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler)
        study.optimize(objective, n_trials=n_trials, timeout=timeout)
        self.study = study
