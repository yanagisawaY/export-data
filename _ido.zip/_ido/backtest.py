import os
import glob
from omegaconf import DictConfig
import hydra
import mlflow

from ppopt.backtest.backtester_utility import UtilityBacktester
from ppopt.utils.mlflow_writer import MlflowWriter
from ppopt.utils.preloader import PreLoader
from ppopt.utils.portfolio_evaluator import PortfolioEvaluator
from ppopt.utils.visualize import Visualizer
from config.config_factor_category import CONFIG_FACTOR_CATEGORY


@hydra.main(config_path="config", config_name="config_backtest")
def main(cfg: DictConfig):
    PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"
    preloader = PreLoader(PATH_DATA)
    X_train, y_train, X_test, y_test, factor_list = preloader.make_dataset(
        cfg.train_test_term[0],
        cfg.train_test_term[1],
        cfg.train_test_term[2],
        cfg.train_test_term[3]
    )

    # hydraのmultirunsの結果をmlflowで一元管理するため，以下を設定
    path_head = hydra.utils.get_original_cwd()
    mlflow.set_tracking_uri(
        'file:\\' + path_head + '\\mlruns')
    writer = MlflowWriter(experiment_name=cfg.experiment)
        
    backtester = UtilityBacktester(cfg.hyperparms)
    visualizer = Visualizer(config_factor_category=CONFIG_FACTOR_CATEGORY)
    
    estimators = backtester.load_estimators(path_head)
    weight_test, theta_test, _, weight_test_with_hidden = backtester.calc_weight_roll(
        estimators, X_test, y_test, X_train, y_train)
    
    tags = {
        "train_start": cfg.train_test_term[0],
        "train_end": cfg.train_test_term[1],
        "test_start": cfg.train_test_term[2],
        "test_end": cfg.train_test_term[3],
        }

    writer.create_new_run(tags)
    writer.log_params_from_omegaconf_dict(cfg)

    # save portfolio performance
    pe = PortfolioEvaluator(y_test, weight_test, cfg.hyperparms)
    performance_test = pe.calc_portfolio_performance()
    visualizer.save_performance_table(
        performance_test["performance"], title="[test]performance.html")
    pe.log_performance_to_metric(performance_test, writer)
    
    port_rt_with_hidden_test = backtester._calc_port_return(
        weight_test_with_hidden, y_test)
    visualizer.save_return_fig(
        df_port=performance_test["rt_port"],
        port_rt_with_hidden=port_rt_with_hidden_test,
        title="[test]port_rt_all.html",
        theta=theta_test
    )
    
    # Hydraの成果物をArtifactに保存
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/config.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/hydra.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/overrides.yaml"))
    # htmlファイルを保存
    files_html = glob.glob(os.path.join(os.getcwd() + "/*.html"))
    for file in files_html:
        writer.log_artifact(file)

    writer.set_terminated()
            

if __name__ == "__main__":
    main()