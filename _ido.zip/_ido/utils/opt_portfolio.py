# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 03:30:08 2021

@author: 猛
"""
import numpy as np
from cvxopt import matrix
from cvxopt.solvers import qp
import pulp

def max_sharpe(mean_t, var_t):
    P = matrix(var_t)
    q = matrix([0.0] * len(mean_t))
    A = matrix(mean_t).T
    b = matrix(1.0)
    G = matrix(np.eye(len(mean_t)))
    h = matrix([0.0] * len(mean_t))
    sol = qp(P, q, G, h, A, b)
    weight = [i/sum(list(sol['x'])) for i in list(sol['x'])]
    
    return weight


def min_lpm(mean_t, samples_t, r_goal = 0, r_e = 0.002):
    problem = pulp.LpProblem('PortfolioOpt', pulp.LpMinimize)
    # 変数の設定
    xj = [pulp.LpVariable(name='xj_{}'.format(i), lowBound=0) for i in range(len(mean_t))]
    dt = [pulp.LpVariable(name='dt_{}'.format(i), lowBound=0) for i in range(samples_t.shape[0])]
        
    # 目的関数
    problem += pulp.lpSum([dt[i] for i in range(samples_t.shape[0])]), "Objective"            
    # 制約
    # LPM関連    
    problem += pulp.lpSum([samples_t[i,j] * xj[j] + dt[i] for i in range(samples_t.shape[0]) for j in range(len(mean_t))]) >= r_goal
    problem += pulp.lpSum([dt[i] for i in range(samples_t.shape[0])]) >= 0
    
    # 要求期待収益率
    problem += pulp.lpSum([mean_t[j]*xj[j] for j in range(len(mean_t))]) >= r_e
    # 予算制約
    problem += pulp.lpSum([xj[j] for j in range(len(mean_t))]) == 1
    
    status = problem.solve()
    print(pulp.LpStatus[status])
    
    weight = [pulp.value(xj[i]) for i in range(len(mean_t))]
    
    return weight