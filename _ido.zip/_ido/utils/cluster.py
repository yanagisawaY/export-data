# -*- coding: utf-8 -*-
"""
クラスタリングを実施
@author: Yanagisawa
"""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples

def cluster_KMeans_base(corr, max_num_clusters, n_init, random_state=0):
    '''
        ONCベースクラスタリングを実施
        アセットマネージャーのためのファイナンス機械学習 P.78

    Parameters
    ----------
    corr : np.array or pd.DataFrame
        相関係数行列
    max_num_clusters : int
        クラスター数の最大値.
    n_init : int
        初期化計算の繰り返し回数. (k_means++におけるn_initではない)
    random_state : init
        ランダムシード

    Returns
    -------
    corr1 : pd.DataFrame
        クラスターごとに並び変えた相関係数行列.
    clusters : dict
        各クラスターに属する行（列）番号を記録.
    silh : pd.Series
        シルエットスコア.
    '''
    # corrの行方向に対し，相関係数行列を作成する
    if not isinstance(corr, pd.DataFrame):
        corr = pd.DataFrame(corr)
    
    x = (0.5*(1-corr))**0.5
    silh = pd.DataFrame()
        
    for init in range(n_init):
        for i in range(2, max_num_clusters):
            kmeans_ = KMeans(n_clusters=i, n_init=10, random_state=random_state+init)
            kmeans_ = kmeans_.fit(x)
            silh_ = silhouette_samples(x, kmeans_.labels_)
            stat = (silh_.mean()/silh_.std(), silh.mean()/silh.std())
            
            if isinstance(stat[1], pd.Series) or (stat[0] > stat[1]):
                silh, kmeans = silh_, kmeans_
            
    idx_new = np.argsort(kmeans.labels_)
    corr1 = corr.iloc[idx_new,:]
    corr1 = corr1.iloc[:,idx_new]
    clusters = {i : corr.columns[np.where(kmeans.labels_==i)[0]].tolist() for i in np.unique(kmeans.labels_)}
    silh = pd.Series(silh, index=x.index)
    
    return corr1, clusters, silh
    
    
    
    