# -*- coding: utf-8 -*-
"""
スクレイピングを行うモジュール
@author: Yanagisawa
"""
import requests
from bs4 import BeautifulSoup
import pandas as pd
import datetime as dt

def get_quant_news(date):
    '''
        https://www.academic-quant-news.com/
        Academic Quant Newsより論文タイトル，URL，概要を取得する関数
        
    Parameters
    ----------
    date : datetime.datetime
        年月日
        
    Returns
    -------
    df : pd.DataFrame
        該当日の論文の情報（タイトル，URL，概要）が格納されたデータフレーム
    '''
    assert type(date) is dt.datetime # データの型チェック
    
    year = str(date.year)
    month = str(date.month).zfill(2)
    date = date.strftime('%Y-%m-%d')
    
    URL_ORG = 'https://www.academic-quant-news.com'
    url = URL_ORG+'/'+year+'/'+month+ '/research-articles-for-'+date+'.html'
    
    response = requests.get(url)
    html = response.text
    soup = BeautifulSoup(html, 'html.parser')
    
    # HPのタイトルを取得
    # hp_title = soup.title.getText()
    # 論文タイトルの取得
    papers_title = [text.getText() for text in soup.find_all('a', {'class': 'researcharticle-title'})]
    # 論文URLの取得
    papers_URL = [text.find_all('a')[0].get('href') for text in soup.find_all('div', {'class': 'researcharticle'})]
    # 論文の概要を取得
    papers_text = [text.getText() for text in soup.find_all('span', {'class': 'researcharticle-text'})]
    
    df = pd.DataFrame([papers_title, papers_URL, papers_text], index=['title', 'URL', 'summary']).T
    df['Data'] =  date
    
    return df

