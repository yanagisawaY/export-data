# -*- coding: utf-8 -*-
"""
@author: Yanagisawa
"""
import sys
import pandas as pd
import numpy as np
import math
import random
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import torch

class DataGenerator:
    def __init__(self, hyperparms, df):
        '''
            データ作成に関わるクラス        

        Parameters
        ----------
        df : pandas.DataFrame
            全データの日付
        hyperparms : dict
            ハイパーパラメータ  
        '''
        index_all = df.index        
        assert type(df.index) is pd.core.indexes.datetimes.DatetimeIndex
        
        self.df = df
        self.index_all = index_all
        self.hyperparms = hyperparms
        self.history_length = self.hyperparms['history_length']
        self.context_length = self.hyperparms['context_length']        
        self.prediction_length = self.hyperparms['prediction_length']
        self.lag_expalin = self.hyperparms['lag_expalin']
        self.batch_size = self.hyperparms['batch_size']
        self.learning_period = self.hyperparms['learning_period']
        self.test_period = self.hyperparms['test_period']
        self.target_names = self.hyperparms['target_names']
        self.random_seed = self.hyperparms['random_seed']
        
        self.lag_period = self.history_length-self.context_length        
        assert self.lag_period >= self.lag_expalin                
        assert self.test_period >= self.lag_period+self.history_length
        
    def split_train_test_index(self, train_start_index):        
        upper_len = len(self.index_all) - self.learning_period - self.test_period
        test_set = int(int(upper_len*10/self.test_period)/10)
        train_start_index_list = [train_start_index+self.learning_period+(i-1)*self.test_period if i > 0 else train_start_index for i in range(test_set - 1)]
        test_start_index_list = [i+self.learning_period for i in train_start_index_list]
        
        return train_start_index_list, test_start_index_list

    def split_index_(self, start_index, index_all):       
        '''
        日付インデックスを作成
        
        Parameters
        ----------        
        start_index : int -> 訓練期間の開示時点を指定（history_length-context_length以上に設定） 
        Notes :
            context_periodが学習期間．history_periodはラグも含めた期間
        '''
        assert start_index >= self.lag_period
        batch_history_period = index_all[(start_index-self.lag_period):(start_index+self.context_length),]
        batch_context_period = index_all[(start_index):(start_index+self.context_length),]        
        batch_future_period = index_all[(start_index+self.context_length):(start_index+self.context_length+self.prediction_length),]
        batch_learning_period = index_all[start_index:(start_index+self.context_length+self.prediction_length),]
        
        return batch_history_period, batch_context_period, batch_future_period, batch_learning_period

    def make_df_lagged(self):
        '''
            説明変数の時点をlag_explain分ずらし，目的変数と説明変数データを作成
        '''
        df_target = self.df[self.target_names].iloc[self.lag_expalin:,]
        features = self.df.drop(self.target_names, axis=1)
        features.iloc[self.lag_expalin:,:] = features.iloc[:-self.lag_expalin,:].values
        features_lagged = features.iloc[self.lag_expalin:,]
                
        return df_target, features_lagged
            
    def split_train_test(self, df_lagged, train_start_index, test_start_index):
        '''
            訓練データとテストデータに分割する

        Parameters
        ----------
        df : data.frame
        Returns
        -------
        df_train : data.frame
            訓練データ
        df_test : data.frame
            テストデータ

        '''
        df_train, df_test = \
            df_lagged[train_start_index-self.lag_period:train_start_index+self.learning_period-self.lag_period], \
            df_lagged[test_start_index-self.lag_period-self.history_length:test_start_index+self.test_period-self.lag_period]

        return df_train, df_test
    
    def scale(self, df_train, df_test, method='StandardScaler'):
        '''
            MinMax変換により基準化を行う関数

        Parameters
        ----------
        df_train : TYPE
            訓練データ
        df_test : TYPE
            テストデータ
        method : 
            基準化方法を指定

        Returns
        -------
        df_train_scaled : TYPE
            基準化後の訓練データ
        df_test_scaled : TYPE
            基準化後のテストデータ

        '''
        if method == 'StandardScaler':
            self.scaler = StandardScaler()
        elif method == 'MinMaxScaler':
            self.scaler = MinMaxScaler()      
            
        self.scaler.fit(df_train)        
        df_train_scaled = pd.DataFrame(self.scaler.transform(df_train), index = df_train.index, columns = df_train.columns)
        df_test_scaled = pd.DataFrame(self.scaler.transform(df_test), index = df_test.index, columns = df_test.columns)
        
        return df_train_scaled, df_test_scaled 
    
    def get_batch(self, feature_train, random_seed, mode='train'):
        '''
            バッチデータの作成

        Parameters
        ----------
        feature_train : pd.DataFrame
            バッチデータを作成する元のデータ.

        Returns
        -------
        past_batch : torch.tensor
            (batch_size, history_length, num_features)
        future_batch : torch.tensor
            (batch_size, prediction_length, num_features)
        '''
        index_dates = feature_train.index
        num_features = feature_train.shape[1]
        
        if mode == 'train':
            start_indices = len(index_dates)-(self.history_length+self.prediction_length)            
            past_batch = np.zeros((self.batch_size, self.history_length, num_features))
            future_batch = np.zeros((self.batch_size, self.prediction_length, num_features))       
            for batch_i in range(self.batch_size):
                np.random.seed(random_seed+batch_i)  
                sample_start = np.random.randint(start_indices)
                past_batch[batch_i,:,:] = feature_train[sample_start:(sample_start+self.history_length)].values
                future_batch[batch_i,:,:] = feature_train[(sample_start+self.history_length):(sample_start+self.history_length+self.prediction_length)].values
        elif mode == 'fit':
            start_indices = len(index_dates)-(self.history_length)  
            past_batch = np.zeros((start_indices, self.history_length, num_features))
            future_batch = np.zeros((start_indices, 1, num_features))
            for batch_i in range(start_indices):
                past_batch[batch_i,:,:] = feature_train[batch_i:(batch_i+self.history_length)].values
                future_batch[batch_i,0,:] = feature_train[(batch_i+self.history_length):(batch_i+self.history_length+self.prediction_length)].values[0,:]
        else:
            raise ValueError('mode : "train" or "test"')                
            
        past_batch = torch.from_numpy(past_batch).type(torch.Tensor)
        future_batch = torch.from_numpy(future_batch).type(torch.Tensor)
        
        return past_batch, future_batch    

    def make_trainloader(self, features_lagged_train, df_target_train, random_seed):
        '''
        past_time_feat
            Dynamic features of past time series (batch_size, history_length,
            num_features)
        past_target_cdf
            Past marginal CDF transformed target values (batch_size,
            history_length, target_dim)            
        future_time_feat
            Future time features (batch_size, prediction_length, num_features)
        future_target_cdf
            Future marginal CDF transformed target values (batch_size,
            prediction_length, target_dim)
        '''              
        past_time_feat, future_time_feat = self.get_batch(features_lagged_train, random_seed)
        past_target_cdf, future_target_cdf = self.get_batch(df_target_train, random_seed)
        
        return past_time_feat, past_target_cdf, future_time_feat, future_target_cdf

    def make_fitloader(self, features_lagged_test, df_target_test):
        '''
        past_time_feat
            Dynamic features of past time series (batch_size, history_length,
            num_features)
        past_target_cdf
            Past marginal CDF transformed target values (batch_size,
            history_length, target_dim)            
        future_time_feat
            Future time features (batch_size, prediction_length, num_features)
        future_target_cdf
            Future marginal CDF transformed target values (batch_size,
            prediction_length, target_dim)
        '''              
        past_time_feat, future_time_feat = self.get_batch(features_lagged_test, random_seed=0, mode='fit')
        past_target_cdf, future_target_cdf = self.get_batch(df_target_test, random_seed=0, mode='fit')
        
        return past_time_feat, past_target_cdf, future_time_feat, future_target_cdf
    
    def setting(self, train_start_index, test_start_index):
        assert train_start_index >= self.lag_period
        df_target, features_lagged = self.make_df_lagged()

        self.df_target_train, self.df_target_test = self.split_train_test(df_target, train_start_index, test_start_index)
        self.features_lagged_train, self.features_lagged_test = self.split_train_test(features_lagged, train_start_index, test_start_index)
        self.df_target_train_scaled, self.df_target_test_scaled = self.scale(self.df_target_train, self.df_target_test)            
        self.features_lagged_train_scaled, self.features_lagged_test_scaled = self.scale(self.features_lagged_train, self.features_lagged_test)

    def get_loader(self, random_seed, is_target_scale=False):
        if is_target_scale:
            past_time_feat, past_target_cdf, future_time_feat, future_target_cdf \
                =  self.make_trainloader(self.features_lagged_train_scaled, self.df_target_train_scaled, random_seed)                
        else:
            past_time_feat, past_target_cdf, future_time_feat, future_target_cdf \
                =  self.make_trainloader(self.features_lagged_train_scaled, self.df_target_train, random_seed)
                
        return past_time_feat, past_target_cdf, future_time_feat, future_target_cdf
               
    def get_loader_fit(self, random_seed, is_test=True, is_target_scale=False):
        if is_test:
            if is_target_scale:
                past_time_feat, past_target_cdf, future_time_feat, future_target_cdf \
                    =  self.make_fitloader(self.features_lagged_test_scaled, self.df_target_test_scaled)                
            else:
                past_time_feat, past_target_cdf, future_time_feat, future_target_cdf \
                    =  self.make_fitloader(self.features_lagged_test_scaled, self.df_target_test)
        else:
            if is_target_scale:
                    past_time_feat, past_target_cdf, future_time_feat, future_target_cdf \
                        =  self.make_fitloader(self.features_lagged_train_scaled, self.df_target_train_scaled, random_seed)                
            else:
                past_time_feat, past_target_cdf, future_time_feat, future_target_cdf \
                    =  self.make_fitloader(self.features_lagged_train_scaled, self.df_target_train, random_seed)            
                
        return past_time_feat, past_target_cdf, future_time_feat, future_target_cdf


    def get_index_fit(self, is_test=True):
        if is_test:
            learning_all_period = self.df_target_test.index
            future_period = self.df_target_test[(self.history_length):].index
        else:
            learning_all_period = self.df_target_train.index
            future_period = self.df_train_test[(self.history_length):].index        
        
        return learning_all_period, future_period 
