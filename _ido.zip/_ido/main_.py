import pandas as pd
from config.config_model import hyperparms
from config.config_backtest import hyperparms_portfolio

from ppopt.utils.backtester_utility import UtilityBacktester
from ppopt.models.model_utility import UtilityTrader

PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"

def make_explain_target(df, index_date : list = []):
    if len(index_date) == 0:
        index_date = df["Date"].unique()

    df_extracted = df.loc[df["Date"].isin(index_date), :]
    df_extracted = df_extracted.set_index(["Date", "stock"])
    y = df_extracted["ret"]
    is_drop = y==0
    y = y.loc[~is_drop] 
    X = df_extracted.loc[~is_drop, :].drop("ret", axis=1)
    
    return X, y


# df_train = pd.read_csv(PATH_DATA + "/train.csv.gz", index_col=0)
# X_train, y_train = make_explain_target(df_train)
# del df_train
# df_val = pd.read_csv(PATH_DATA + "/valid.csv.gz", index_col=0)
# X_val, y_val = make_explain_target(df_val)
# del df_val
df_test = pd.read_csv(PATH_DATA + "/test.csv.gz", index_col=0)
# X_test, y_test = make_explain_target(df_test)
# del df_test

# Light Pattern1
# X_train, y_train = make_explain_target(df_train, index_date=df_train["Date"].unique()[0:120])
# X_val, y_val = make_explain_target(df_train, index_date=df_train["Date"].unique()[120:180])
# X_test, y_test = make_explain_target(df_train, index_date=df_train["Date"].unique()[180:183])

# Light Pattern2
X_train, y_train = make_explain_target(df_test, index_date=df_test["Date"].unique()[140:220])
X_val, y_val = make_explain_target(df_test, index_date=df_test["Date"].unique()[220:250])
X_test, y_test = make_explain_target(df_test, index_date=df_test["Date"].unique()[250:300])


corr_train = pd.concat([X_train, y_train], axis=1).corr(method="spearman")["ret"].sort_values()
corr_test = pd.concat([X_test, y_test], axis=1).corr(method="spearman")["ret"].sort_values()


hyperparms.update({
    "factor_list": [i for i in X_train.columns if i not in ["stock", "Date"]],    
    })
backtester = UtilityBacktester(hyperparms)


# # STEP1 : estimate paramaters through backpropagation
estimator = UtilityTrader(hyperparms)
estimator = backtester.learn(estimator, X_train, y_train, X_val, y_val)

# STEP2 : optimize portfolio weight(optimize exporsure to hidden portfolio) under leverage constraint
#       : adjust portfolio weight under the limitation of the number of stocks.        
X_past = pd.concat([X_train, X_val], axis=0)
y_past = pd.concat([y_train, y_val], axis=0)
weight_info = backtester.calc_weight(estimator, X_past, y_past, X_test, y_test)

# STEP3 : Model Interpretation
# calculate LRP
mode = "train"
port_lrp_train, factor_lrp_train, factor_coef_train = backtester.calc_lrp(estimator, weight_info, X_past, y_past, mode)
mode = "test"
port_lrp_test, factor_lrp_test, factor_coef_test = backtester.calc_lrp(estimator, weight_info, X_test, y_test, mode)

# calculate portfolio return (+ hidden portfolio return)
port_train, port_test = backtester.calc_port_return(weight_info, y_past, y_test)

output_name = "temp"
performance_all = backtester.get_port_performance(
    weight_info, y_past, y_test, hyperparms_portfolio, output_name
    )

# summarize each result
estimator.loss_save.plot()
result = {
    "model": estimator,
    "loss_info": estimator.loss_save,
    "weight_info": weight_info,
    "port_train": port_train,
    "port_test": port_test,
    "port_lrp_train": port_lrp_train,
    "factor_coef_train": factor_coef_train,
    "port_lrp_test": port_lrp_test,
    "factor_coef_test": factor_coef_test,
    "performance": performance_all,
    }

# visualize result
from ppopt.utils.visualize import Visualizer
from config.config_factor_data import config_factor_category
visualizer = Visualizer(result, config_factor_category)
figs = visualizer.call_fig_all()

# output result
import datetime as dt
import os
time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
path_output = ".\\Result\\" + time_now
os.makedirs(path_output, exist_ok=True)
import pickle
with open(path_output + "/result.pkl", mode="wb") as f:
    pickle.dump(result, f)
    
with open(path_output + "/result_fig.html", 'a') as f:
    for fig in figs:
        f.write(fig.to_html(full_html=False, include_plotlyjs='cdn'))
    
    
    
