# -*- coding: utf-8 -*-
"""
@author: Yanagisawa
"""
import os
import numpy as np
import sys
import pandas as pd
import torch
import random
import matplotlib.pyplot as plt
import time
import datetime as dt
PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\normalizing_flow'
os.chdir(PATH_HEAD)

from utils import data_generator
from model import trainer_flow, tempflow_network

# 投資対象をJPYで統一
df_org = pd.read_csv('data/index_data.csv', encoding = 'utf-8').set_index('Date')
df_org['Treasury_JPY'] = df_org['SPBDU10T Index'] * df_org['JPY BGN Curncy']
df_org['SPX_JPY'] = df_org['SPXT Index'] * df_org['JPY BGN Curncy']
df_org.loc['Code', 'Treasury_JPY'] = 1
df_org.loc['Code', 'SPX_JPY'] = 1

def convert(x):
    if x[0] == 1:
        # x = np.log(x[1:]).diff()
        x = x[1:].pct_change()
    elif x[0] == 2:
        x = x[1:].diff()
    elif x[0] == 3:
        x = x[1:]
    else:
        raise ValueError('Codeは1~3の値を選択')
    return x

target_names = ['Treasury_JPY', 'SPX_JPY', 'TPXDDVD Index', 'SPJGBTR Index']
df_org.loc['Code', target_names] = 1
df_converted = df_org.apply(convert).replace([np.inf, -np.inf], np.nan).dropna()

pattern = 1
for pattern in [0, 1, 2]:
    time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
    path_output = PATH_HEAD + '/result/' + time_now  
    os.makedirs(path_output, exist_ok=True)    
    col_extracted = ['JPY BGN Curncy', 'VIX Index', 'MOVE Index', 'IMM5JNCN Index', 'CESIJPY Index']
    if pattern == 0 or pattern == 1:
        # ボラティリティの計算
        new_col = [i+'_vol' for i in target_names]
        window_size = 20
        df_ = df_converted.iloc[1:,:]
        df_[new_col] = df_[target_names].rolling(window_size).std()
        if pattern == 1:
            use_col = target_names + new_col + col_extracted
        else:
            use_col = target_names + new_col
        df = df_[use_col].dropna()
        df.index = pd.to_datetime(df.index)
    else:
        drop_names = ['SPX Index', 'TPX Index']
        df = df_converted.drop(drop_names, axis=1)
        df.index = pd.to_datetime(df.index)   
        if pattern == 99:
            new_col = [i+'_vol' for i in target_names]
            window_size = 20
            df_ = df_converted.iloc[1:,:]
            df_[new_col] = df_[target_names].rolling(window_size).std()        
            
        
    #%%
    hyperparms = {
        'random_seed'          : 777,    
        'lr'                   : 1e-3,
        'batch_size'           : 64,
        'lag_num'              : 3,
        'lag_expalin'          : 1,
        'learning_period'      : 250,
        'test_period'          : 100,
        'target_names'         : target_names,
        'epoch'                : 100,
        'num_parallel_samples' : 1000,    
        }
    
    target_dim = len(hyperparms['target_names'])
    feature_dim = df.shape[1] - target_dim
    
    hyperparms_train = {
        'input_size'         : target_dim*hyperparms['lag_num'] + feature_dim,
        'num_layers'         : 2,
        'num_cells'          : 128,
        'cell_type'          : 'GRU',
        'history_length'     : 50,
        'context_length'     : 40,
        'prediction_length'  : 50,
        'dropout_rate'       : 0.3,
        'lags_seq'           : [i+1 for i in range(hyperparms['lag_num'])],
        'target_dim'         : target_dim,
        'flow_type'          : 'RealNVP',
        'n_blocks'           : 4,
        'hidden_size'        : 128,
        'n_hidden'           : 4,
        }
    
    '''
        0.勾配更新関連パラメータ
            'lr'                　: 学習パラメータ,
        1.RNNのパラメータ
            'input_size'         : RNN特徴量の次元数,concat（xt-1, ct-1）の次元数（ターゲットの目的変数+共変量の特徴量）
            'num_layers'         : RNNの層数,
            'num_cells'          : 隠れ層の数,
            'cell_type'          : 'LSTM' or 'GRU'
            'dropout_rate'       : ドロップアウト,    
        2.推論時のパラメータ    
                (example)
                <-----------'history_length'---------><--'prediction_length'->
                <-Lagging period-><-'context_length'->                  
            'history_length'     : 訓練期間,history_length - context_lengthの期間は説明変数などでラグを確保する期間                                
            'context_length'     : RNNの隠れ層の初期状態学習するwarm-up期間,
            'prediction_length'  : RNNの隠れ層が与えられたもとで推論を実施する推定期間,
            
        3.Parameters of Normalizing Flow
            'flow_type'          : 'RealNVP' or 'MAF',
            'n_blocks'           : カップリングレイヤーの層数,
            'hidden_size'        : 1つカップリングレイヤーの隠れ層の数,
            'n_hidden'           : 1つカップリングレイヤーの隠れ層の層数,
        4.データ生成に関わるパラメータ     
            'target_dim'         : 目的変数の次元数,        
            'conditioning_length': 共変量の次元数,   
            'lags_seq'           : List[int]　=> list of lag indices to be used.目的変数を説明変数に入れる際のラグ設定
                                  目的変数に対するラグの設定
                                  [1, 2, 3]とすればラグ3まで考慮
                                  [1, 7]とすれば1, 7時点前のラグを考慮
                                  ※ lags_seqはhistory_length - context_lengthの期間より長いものは設定できない
    '''
    
    hyperparms.update(hyperparms_train)
    
    #%%
    import numpy as np    
    import itertools
    from pypfopt.efficient_frontier import EfficientFrontier
    from utils import opt_portfolio
    epoch = hyperparms['epoch']
    train_start_index = 10
    
    dg = data_generator.DataGenerator(hyperparms, df)
    train_start_index_list, test_start_index_list = dg.split_train_test_index(train_start_index)
    
    result_all = []
    weight_all = pd.DataFrame()
    mean_all = pd.DataFrame()
    sd_all = pd.DataFrame()
    coef_all = pd.DataFrame()
    error_save = []
    for i, (train_start_index, test_start_index) in enumerate(zip(train_start_index_list, test_start_index_list)):
        print(f'再学習期間パターン...{i+1} / {len(train_start_index_list)}')
        # 乱数の設定
        torch.manual_seed(hyperparms['random_seed'])
        torch.cuda.manual_seed(hyperparms['random_seed'])
                
        model = tempflow_network.TempFlow(**hyperparms_train)
        optimizer = torch.optim.Adam(model.parameters(), lr = hyperparms['lr'])
            
        start = time.time()
        hist_loss = []
        # データ分割の設定
        dg.setting(train_start_index, test_start_index)
        for epoch_i in range(epoch):
            # バッチで取得するデータを乱数ごとに変更
            random_seed = hyperparms['random_seed'] + epoch_i
            past_time_feat, past_target_cdf, future_time_feat, future_target_cdf = dg.get_loader(random_seed)
            running_loss = 0    
            loss = model(past_time_feat, past_target_cdf, future_time_feat, future_target_cdf)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
                
            print('epoch:[%2d/%2d] loss:%1.4f' % (epoch_i+1, epoch, running_loss))
        
        # サンプリング
        past_time_feat_test, past_target_cdf_test, future_time_feat_test, future_target_cdf_test = \
            dg.get_loader_fit(random_seed, is_test=True)
        num_parallel_samples = hyperparms['num_parallel_samples']
        
        print("サンプリング中")
        start = time.time()
        samples = []
        learning_all_period, future_period = dg.get_index_fit(is_test=True)
        samples = model.sample(past_time_feat_test, past_target_cdf_test, 
                               future_time_feat_test, num_parallel_samples, is_unroll = True).to('cpu').detach().numpy().copy()
        
        elapse_time = time.time() - start
        print(f'サンプリング数{num_parallel_samples}: {round(elapse_time)}sec ({round(elapse_time/60)}min)')
        
        # 平均と共分散行列の計算
        samples_sd = pd.DataFrame(np.std(samples, axis=1), index=future_period, columns=hyperparms['target_names'])
        samples_mean = pd.DataFrame(np.mean(samples, axis=1), index=future_period, columns=hyperparms['target_names'])
        samples_var = np.stack([np.cov(samples[t,:,:].T) for t in range(samples.shape[0])], axis=0)
        samples_coef = np.stack([np.corrcoef(samples[t,:,:].T) for t in range(samples.shape[0])], axis=0)    
        samples_coef_flatten = samples_coef.reshape(-1,len(hyperparms['target_names'])**2)
        col_coef = [i+'_'+j for i, j in itertools.product(hyperparms['target_names'], hyperparms['target_names'])]
        samples_coef = pd.DataFrame(samples_coef_flatten, index=future_period, columns=col_coef)  
        

        print('ポートフォリオのウェイト算出')
        is_pyopt = False
    
        weight_test = np.zeros((hyperparms['test_period'], len(hyperparms['target_names'])))
        if is_pyopt:    
            # シャープレシオ最大化によるウェイト計算
            for t in range(hyperparms['test_period']):
                mean_t = samples_mean.iloc[t,:]
                var_t = samples_var[t,:,:]       
                count_i = 0
                try:
                    ef = EfficientFrontier(mean_t, var_t)            
                    weight = ef.max_sharpe(risk_free_rate=0)
                    weight_test[t,] = list(weight.values())
                except:
                    try:
                        ef = EfficientFrontier(mean_t, var_t)
                        weight = ef.max_sharpe(risk_free_rate=0)
                        weight_test[t,] = list(weight.values())
                    except:            
                        error_save.append(mean_t.name)
                        print(f'エラー{t} ：nanを入力')
                        weight_test[t,] = [np.nan for _ in range(len(hyperparms['target_names']))]
        else:
            from pypfopt.efficient_frontier import EfficientCVaR
            for t in range(hyperparms['test_period']):
                mean_t = samples_mean.iloc[t,:]
                var_t = samples_var[t,:,:]               
                samples_t = pd.DataFrame(samples[t,:,:], columns=hyperparms['target_names'])                      
                try:
                    # weight = opt_portfolio.max_sharpe(mean_t, var_t)
                    # weight = opt_portfolio.min_lpm(mean_t, samples_t, r_goal = 0, r_e = 0.002)
                    ec = EfficientCVaR(mean_t, samples_t, beta=0.95)
                    target_return = 0.001
                    if all(mean_t <= target_return):
                        target_return = mean_t.mean()
                        
                    weight = ec.efficient_return(target_return=target_return)
                    weight_test[t,] = list(weight.values())
                except:
                    error_save.append(mean_t.name)
                    print(f'エラー{t} ：nanを入力')
                    weight_test[t,] = [np.nan for _ in range(len(hyperparms['target_names']))]                
            
        weight_test = pd.DataFrame(weight_test, columns=hyperparms['target_names'], index=future_period)
        
        #weight_test.to_csv(path_output + '/weight_'+str(i)+'.csv')
        #samples_mean.to_csv(path_output + '/mean_'+str(i)+'.csv')
        #samples_sd.to_csv(path_output + '/sd_'+str(i)+'.csv')
        #samples_coef.to_csv(path_output + '/coef_'+str(i)+'.csv')    
        
        # concat
        weight_all = pd.concat([weight_all, weight_test], axis=0)
        mean_all = pd.concat([mean_all, samples_mean], axis=0)
        sd_all = pd.concat([sd_all, samples_sd], axis=0)    
        coef_all = pd.concat([coef_all, samples_coef], axis=0)
    
    weight_all.to_csv(path_output + '/weight_all.csv')
    mean_all.to_csv(path_output + '/mean_all.csv')
    sd_all.to_csv(path_output + '/sd_all.csv')
    coef_all.to_csv(path_output + '/coef_all.csv')
    pd.DataFrame(error_save, columns=['error_stamp']).to_csv(path_output + '/weight_errorr.csv')
    df[target_names].to_csv(path_output + '/df_org.csv')