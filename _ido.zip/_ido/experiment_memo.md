* 実行パターン

'''
python main.py hyperparms.epoch=150 hyperparms.network_type=onc,None hyperparms.layer_list=[64,4],[4] train_test_term=[19920101,20121231,20130101,20161231],[19920101,20131231,20140101,20161231],[19920101,20141231,20150101,20161231],[19920101,20151231,20160101,20161231] experiment=roll -m
'''