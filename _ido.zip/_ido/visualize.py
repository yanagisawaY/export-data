import datetime as dt
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.figure_factory as ff


class Visualizer:
    """plotlyによる可視化の図を作成
    """

    def __init__(self, all_result: dict, start: dt.datetime, end: dt.datetime, result_name: str, data_type: str, pattern_name: str, port_name : str):
        self.all_result = all_result
        self.result_name = result_name
        self.dict_info = self.all_result["output"][result_name]
        self.data_type = data_type
        self.pattern_name = pattern_name
        self.start = start
        self.end = end
        self.PLOT_RETURN_ROW = 3  # plot_returnにて使用する行数
        self.port_name = port_name

    def _set_color_setting(self, key):
        color_palette = {
            "factor_color": px.colors.qualitative.Light24,
            "hidden_color": px.colors.qualitative.Antique,
        }[key]

        return color_palette

    def _make_factor_color(self, factor_category_dict):
        factor_category_unique = sorted(
            list(set(factor_category_dict.values())))
        color_list = self._set_color_setting("factor_color")
        assert len(factor_category_unique) <= len(color_list)
        category_color = {
            category: color_list[i] for i, category in enumerate(factor_category_unique)}
        factor_color_dict = {feature: category_color[category]
                             for feature, category in factor_category_dict.items()}

        return factor_color_dict

    def _call_factor_category(self, factor_category_dict={}):
        if len(factor_category_dict) == 0:
            factor_category_dict = {
                "I_0": "type_I0",
                "I_1": "type_I0",
                "I_2": "type_I1",
                "I_3": "type_I2",
            }

        return factor_category_dict

    def get_performance_table(self):       
        all_pettern = self.dict_info["result"].keys()
        performance = []
        for pattern_name in all_pettern:
            temp = self.dict_info["result"][pattern_name]["performance"]
            temp.loc["パターン", :] = pattern_name
            performance.append(temp)
        
        performance = pd.concat(performance, axis=1)
        fig = go.Figure(
            data=[go.Table(
                header=dict(values=[""] + list(performance.columns)),
                cells=dict(values=[list(performance.index)] + [[j if not isinstance(j, float) or isinstance(j, str) or np.abs(
                    j) > 100 else round(j, 3) for j in list(performance.iloc[:, i])] for i in range(performance.shape[1])])
            )
            ]
        )
        
        return fig

    def plot_loss(self):
        fig = px.line(self.dict_info["loss_info"], title=self.result_name)
        fig.update_xaxes(title_text="epoch")
        fig.update_yaxes(title_text="Sharpe Ratio(月率)")

        return fig
    
    def get_port_return(self, df_port_org):        
        df_port = df_port_org.loc[(df_port_org.index >= self.start) & (
            df_port_org.index <= self.end), :].cumsum()        
        port_index = self.dict_info["result"][self.pattern_name]["index"][self.port_name]
        if self.data_type != "train":
            # 累積和リターンで計算していることを用いて差分リターンを計算
            # テストデータでは取引コスト控除後のリターンを使用
            df_port.iloc[:, :3] = port_index.loc[df_port.index, :] - port_index.loc[df_port.index[0] > port_index.index].iloc[-1, :]
        
        return df_port

    def get_corr_plot(self):
        df_port_org = self.dict_info["port_" + self.data_type]
        df_port = self.get_port_return(df_port_org)
        hidden_name = [i for i in df_port.columns if "hidden" in i]
        fig = ff.create_annotated_heatmap(
            df_port[hidden_name].corr().round(3).values,
            x=hidden_name,
            y=hidden_name,
            annotation_text=df_port[hidden_name].corr().round(3).values,
            showscale=True).update_yaxes(autorange="reversed")
        
        return fig
            
    def call_fig_all(self, factor_category_dict={}):
        figs = [self.call_fig(factor_category_dict)]
        figs += [self.get_performance_table()]
        figs += [self.plot_loss()]
        figs += [self.get_corr_plot()]
        
        return figs

    def call_fig(self, factor_category_dict={}):        
        df_port_org = self.dict_info["port_" + self.data_type]
        df_port = self.get_port_return(df_port_org)
        port_lrp_dict = self.dict_info["port_lrp"]
        estimator = self.dict_info["model"]
        weight_active = [i[0].detach().numpy().copy()
                         for i in estimator.model.last.parameters()][0]
        theta_train = pd.DataFrame(
            [weight_active for _ in range(df_port_org.shape[0])],
            index=df_port_org.index,
            columns=[f"hidden_{i}" for i in range(len(weight_active))]
        )
        if self.data_type != "train":
            theta_test = self.dict_info['result'][self.pattern_name]['theta']
        else:
            theta_test = None

        df_lrp = self.extract_lrp(self.start, self.end, port_lrp_dict)
        fig = self.call_main_layout(port_name=list(df_lrp.index))
        fig = self.plot_lrp(
            fig, df_lrp, self._call_factor_category(factor_category_dict))
        fig = self.plot_return(fig, df_port, theta_train, theta_test)
        fig = self.update_layout(fig)
        
        return fig

    def call_main_layout(self, port_name: list):
        fig = go.Figure()
        fig = make_subplots(
            rows=len(port_name)+self.PLOT_RETURN_ROW-1,
            cols=2,
            shared_xaxes="all",
            specs=[[{"colspan": 2, "secondary_y": True}, None] for _ in range(
                self.PLOT_RETURN_ROW)] + [[{"rowspan": len(port_name) - 1}, {}]]
            + [[None, {}] for _ in range(len(port_name) - 2)],
            subplot_titles=["", "", ""] + port_name,
            vertical_spacing=0.05,
            horizontal_spacing=0.05,
            row_width=[0.12, 0.12, 0.12, 0.14, 0.1, 0.3]
        )
        fig.update_layout(
            autosize=True,
            width=1600,
            height=1400,
        )

        return fig

    def extract_lrp(self, start, end, port_lrp_dict):
        dict_selected = port_lrp_dict[self.pattern_name]
        term_candidate = [i for i in dict_selected.keys() if i != "all"]
        term_selected = [i for i in term_candidate if (
            pd.to_datetime(i) >= start) & (pd.to_datetime(i) <= end)]
        df_lrp = 0
        for term in term_selected:
            df_lrp += dict_selected[term]
        df_lrp /= len(term_selected)

        return df_lrp

    def plot_lrp(self, fig, df_lrp, factor_category_dict):
        factor_color_dict = self._make_factor_color(factor_category_dict)
        port_num = df_lrp.shape[1]

        for port_id in range(port_num):
            if port_id == 0:
                row = port_id + 1 + self.PLOT_RETURN_ROW
                col = 1
            else:
                row = port_id + self.PLOT_RETURN_ROW
                col = 2
            x = list(df_lrp.columns)
            y = df_lrp.iloc[port_id, :]
            color_x = [factor_color_dict[factor] for factor in x]
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=list(y),
                    marker_color=color_x,
                    text=list(factor_category_dict.values()),
                    name=list(df_lrp.index)[port_id],
                    legendgroup='1',
                    showlegend=False,
                ),
                row=row,
                col=col,
            )
            try:
                fig.add_annotation(
                    x=y.idxmax(),
                    y=y.max(),
                    text=y.idxmax(),
                    showarrow=True,
                    arrowhead=1,
                    row=row,
                    col=col,
                )
            except Exception as e:
                print(e)

        return fig

    def plot_return(self, fig, df_port, theta_train, theta_test):
        hidden_name = [i for i in df_port.columns if "hidden" in i]
        for i, name_ in enumerate(["model", "bench"]):
            fig.add_trace(
                go.Scatter(
                    x=df_port.index,
                    y=df_port[name_],
                    name=name_,
                    line=dict(color=["red", "blue"][i]),
                    legendgroup='2',
                ),
                row=1,
                col=1
            )
        fig.add_trace(
            go.Scatter(
                x=df_port.index,
                y=df_port["active"],
                name="累積超過リターン(rhs)",
                fill="tozeroy",
                mode="none",
                line=dict(color="purple"),
                legendgroup='2',
            ),
            secondary_y=True,
            row=1,
            col=1,
        )
        hidden_color_list = self._set_color_setting("hidden_color")
        for j, name_hidden in enumerate(hidden_name):
            fig.add_trace(
                go.Scatter(
                    x=df_port.index,
                    y=df_port[name_hidden],
                    name=name_hidden,
                    legendgroup='3',
                    line=dict(
                        color=hidden_color_list[j],
                        dash='dot'
                    ),
                    xaxis="x2",
                ),
                row=2,
                col=1,
            )

    
        if self.data_type == "train" or theta_test is None:
            theta = theta_train
        else:
            theta = theta_test
        
        for j, name_hidden in enumerate(hidden_name):
            fig.add_trace(
                go.Bar(
                    x=df_port.index,
                    y=theta.iloc[:, j].values,
                    text=name_hidden,
                    name=name_hidden,
                    legendgroup='4',
                    showlegend=False,                    
                    marker=dict(
                        color=hidden_color_list[j],
                    ),      
                    xaxis="x2",
                ),
                row=3,
                col=1,
            )
            fig.update_layout(barmode='group')
            
        return fig

    def update_layout(self, fig):
        fig.update_layout(
            title=dict(
                text="<b>[" + self.data_type + "]" + f" <b>【{self.pattern_name}】 <b>" + self.start.strftime(
                    "%y/%m") + " - <b>" + str(self.end.strftime("%y/%m")),
                font=dict(size=26, color="grey"),
                y=0.95,
            ),
            legend=dict(
                x=0,
                y=1,
                orientation="h"
            ),
            xaxis=dict(
                tickformat="%y/%m",
            ),
            xaxis2=dict(
                tickformat="%y/%m",
            ),
        )
        fig.update_xaxes(
            matches="x",
            showspikes=True
        )
        fig.update_yaxes(showspikes=True)

        return fig
