# -*- coding: utf-8 -*-
"""
米国取引所上場銘柄のTTicekrは以下を参考に取得（信憑性は定かではないので注意）
https://qiita.com/matsxxx/items/0348af6ed1b1a2a2b84a
ファーマフレンチのデータはpandas-datareaderを使用して取得
docs：https://pandas-datareader.readthedocs.io/en/latest/readers/famafrench.html
"""
import pandas_datareader.data as web
import pandas as pd
import yfinance as yf
import os
import pickle

class TickTaker:
    def __init__(self):
        pass
    
    @classmethod
    def symbols_nyse(self):
        others_list = 'ftp://ftp.nasdaqtrader.com/symboldirectory/otherlisted.txt'
        other = pd.read_csv(others_list, sep='|')
        #NYSEのものを取得する
        company_nyse = other[other['Exchange']=='N'][['ACT Symbol', 'Security Name']]
        #ETFはMYSE MKT、NYSE ARCA、MATSがある。
        etf_other = other[other['ETF'] == 'Y'][['ACT Symbol', 'Security Name', 'Exchange']]   
        #indexはリセットする
        company_nyse = company_nyse.reset_index(drop=True)
        etf_other = etf_other.reset_index(drop=True)
        #ACT Symbol -> Symbol
        company_nyse = company_nyse.rename(columns={'ACT Symbol':'Symbol'})
        etf_other = etf_other.rename(columns={'ACT Symbol':'Symbol'})
    
        return company_nyse, etf_other
    
    @classmethod
    def symbols_nasdaq(self):
        nasdaq_list = 'ftp://ftp.nasdaqtrader.com/symboldirectory/nasdaqlisted.txt'        
        nasdaq = pd.read_csv(nasdaq_list, sep='|')
        #StatusがNormalのものだけを取得する
        nasdaq_normal = nasdaq[nasdaq['Financial Status']=='N']
        #Test issueでないものを選択する
        nasdaq_normal = nasdaq_normal[nasdaq_normal['Test Issue']=='N']
        #ETFかどうかで判別
        company_nasdaq = nasdaq_normal[nasdaq_normal['ETF']=='N'][['Symbol', 'Security Name']]
        etf_nasdaq = nasdaq_normal[nasdaq_normal['ETF']=='Y'][['Symbol', 'Security Name']]
        #indexはリセットする
        company_nasdaq = company_nasdaq.reset_index(drop=True)
        etf_nasdaq = etf_nasdaq.reset_index(drop=True)
    
        return company_nasdaq, etf_nasdaq
    
    @classmethod
    def symbols_all(self):
        print('NYSEとNASDAQWのTickerを取得中...')
        company_nyse, etf_other = self.symbols_nyse()
        company_nasdaq, etf_nasdaq = self.symbols_nasdaq()
        #NYSEとNASDAQは区別する
        company_nyse['Market'] = 'NYSE'
        company_nasdaq['Market'] = 'NASDAQ'    
        #NASDAQのETFも区別しておく
        etf_nasdaq['Exchange'] = 'NASDAQ'#etf_otherのcolum名に合わせる
        df_stock_ticker = pd.concat([company_nyse, company_nasdaq], ignore_index=True, sort=False)
        stock_ticker = list(pd.Series([i.split('$')[0].split('.')[0] for i in df_stock_ticker['Symbol']]).unique())        
        df_etf_ticker = pd.concat([etf_other, etf_nasdaq], ignore_index=True, sort=False)
        etf_ticker = list(pd.Series([i.split('$')[0].split('.')[0] for i in df_etf_ticker['Symbol']]).unique())
        print(f'株式データ重複削除：{df_stock_ticker.shape[0]} ⇒　{len(stock_ticker)}')
        
        return stock_ticker, etf_ticker, df_stock_ticker, df_etf_ticker
    

if __name__ == 'main':
    # 諸設定
    start_date = '1998-01-01'
    end_date = '2021-02-17'
    PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\trader_company\data' # データの出力箇所の指定
    os.chdir(PATH_HEAD)
    
# =============================================================================
#     stock_ticker, etf_ticker, df_stock_ticker, df_etf_ticker = TickTaker.symbols_all()
#     stock_list = yf.download(stock_ticker, start_date, end_date)
#     df_stock = stock_list['Adj Close']
# =============================================================================
    
    # SP500銘柄（現在の構成銘柄から過去にさかのぼるため生存バイアスが大きい）
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
    sp500_ticker = pd.read_html(url)[0].Symbol.values.tolist()    
    # sp500銘柄の終値を１つのDataFrameに格納
    sp500_list = yf.download(sp500_ticker, start_date, end_date)
    feature_list = ['Volume', 'Open', 'High', 'Low', 'Close', 'Adj Close']
    sp500_dict = {x : sp500_list[x] for x in feature_list}
        
    with open('sp500.pickle', 'wb') as f:
        pickle.dump(sp500_dict, f)
     
    df_sp500 = sp500_list['Adj Close']
    # flag = [x.day==1 for x in df_sp500_temp.index.date]
    # df_sp500 = df_sp500_temp.loc[flag]
    df_sp500.to_csv('SP500.csv')
    
    # データの出力
# =============================================================================
#     df_stock.to_csv('stock_data.csv')
#     df_stock.head(100).to_csv('stock_data_head100.csv')
# =============================================================================
#     df_famafrench.to_csv('famafrench_data.csv')
    