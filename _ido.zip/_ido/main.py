# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import openpyxl
import pandas as pd
import datetime as dt
import os
import pickle

# パスの設定
PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\trader_company'
os.chdir(PATH_HEAD)
from get_result import get_result, output_result

#%%
# 事前に設定する項目    
hyperparms_company_common = {
    'N_trader_num'        : 100,
    'Aggregate'           : 'linear', # 'average', 'linear', 'random_forest'
    'Q_quantile_educate'  : 0.5,
    'formula_num_max'     : 10,
    'lookback_window_max' : 10,    
    'lag'                 : 1,        
    'random_seed'         : 7777,  
    'method_measure'      : 'CR', # 'CR', 'SR', 'DDR'
    'method_sampling'     : 'GMM',
    'fit_times'           : 5,
    'GMM_n_components'    : 10,
    'Aggregate_parms'     : {'random_state' : 777, 'n_estimators' : 100,},
    'is_hist_plot'        : False,
    'use_col'             : None,
    'data_type'           : 'Rt', # 'Tech', 'RtTech'
    'trader_pred_dict' : {
    'is_trader_pred'      : False,
    'pred_method'         : 'random_forest',
    'trader_pred_ratio'   : 0.5, 
    'trader_parms'        : {'random_state' : 777, 'n_estimators' : 100,},        
        }
    }   

'''
hyperparms_company_common : ハイパーパラメータ
    'N_trader_num'        : トレーダー数
    'Aggregate'           : 集約方法の指定
            'average'         : トレーダーの予測値平均 
            'linear'          : トレーダーの予測値をインプットとした線形回帰による予測
            'random_forest'   : トレーダーの予測値をインプットとしたランダムフォレストによる予測 
    'Q_quantile_educate'  : パフォーマンスの悪いトレーダーを教育する割合
    'formula_num_max'     : 各トレーダーの戦略（公式）の候補数の最大値
    'lookback_window_max' : 各銘柄のリターンの参照期間候補の最大値
    'lag'                 : 説明変数の時点と被説明変数の時点のラグ
    'random_seed'         : ランダムシード
    'method_measure'      : トレーダーのパフォーマンス測定基準
            'CR'              : 累積リターン
            'SR'　　　　　　　　　　　: シャープレシオ
            'DDR'             : DDR(リスクが半分散)
    'method_sampling'     : トレーダー生成時のサンプリング方法
            'GMM'             : 混合正規分布によるサンプリング
            'categorical'     : カテゴリカル分布によるサンプリング
    'fit_times'           : レーダー生成の繰り返し回数
    'GMM_n_components'    : 混合正規分布のフィット時におけるクラスター数
    'Aggregate_parms'     : 集約方法で用いるモデルのハイパーパラメータ
            'random_state'    : 乱数シード
            'n_estimators'    : ランダムフォレストで用いる木の数
    'is_hist_plot'        : トレーダー生成時に，トレーダーの予測値と実際の値のヒストグラムを表示する場合はTrueを指定
    'use_col'             : 説明変数に使用するの列の指定（Noneの場合は全てのデータを使用）        
    'data_type'           : 説明変数データのパターン
        'Rt'                  : 銘柄リターン(原論文と同じ)    
        'Tech'                : テクニカル指標のみ
        'RtTech'              : 銘柄リターン + テクニカル指標                    
    'is_trader_pred'      : トレーダーの1戦略ごとにリターン予測を実施する場合はTrue
    'trader_pred_dict'    : トレーダーのリターン予測手法に関する辞書
        'pred_method'         : トレーダーのリターン予測手法
            'random_forest'       : ランダムフォレストによる予測     
        'trader_pred_ratio'   : トレーダーのリターン予測に使用する訓練データの割合
        'trader_parms'        : トレーダーのリターン予測手法で用いるモデルのハイパーパラメータ
                'random_state'    : 乱数シード
                'n_estimators'    : ランダムフォレストで用いる木の数    
'''

hyperparms_portfolio = {
    'split_num'              : 10,
    'portfolio_type'         : 'Simple',
    'turnover_stock_uplimit' : 4,
    'cost_buy'               : 0,
    'cost_sell'              : 0,
    'calc_type'              : 'cumulative',    
    'wealth_init'            : 100,    
    }

'''
hyperparms_portfolio : dict
    split_num              : 分位数.
    portfolio_type         : ポートフォリオの構築方法の選択
        LongShort              : 最上位の分位群をロング，最下位の分位群をショート
        Long                   : 最上位の分位群のロング
        Long_const             : 組み入れ銘柄数制限付き，最上位の分位群のロング
        Simple                 : 予測リターンが正のものをロング，負のものをショート
    turnover_stock_uplimit : 組み入れ変更銘柄数の上限
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
'''

#%%
# データセットの入力
with open(PATH_HEAD+'\\data\\sp500.pickle', 'rb') as f:
    df_dict_org = pickle.load(f) 

# yahooファイナンスデータゆえの特殊対応
df_dict = {}
for name, df_ in df_dict_org.items():
    df_.index = pd.to_datetime(df_.index)
    df_dict[name] = df_.iloc[[i!=0 for i in df_.count(1)],:].dropna(axis=1)
    del df_

del df_dict_org
    
# 訓練，テスト期間の設定
all_setting = {
    'start_year'                : 2016, # is_get_dictでTrueとした場合の訓練データの開始期間（）
    'end_year'                  : 2018,
    'year_term_train'           : 2,
    'year_term_test'            : 1,
    'is_get_dict'               : False,
    'df_dict'                   : df_dict,
    'hyperparms_company_common' : hyperparms_company_common,
    'hyperparms_portfolio'      : hyperparms_portfolio,
    'stock_list'                : df_dict['Adj Close'].columns[:100],
    }

'''
all_setting : dict
    start_year                : 訓練開始年
    end_year                  : 訓練終了年
    year_term_train           : 訓練データ年数
    year_term_test            : テストデータ年数
    is_get_dict               : テストデータ分割方法の指定
                                True  : year_term_trainごとのスライド方式
                                False : 論文と同じ訓練/テスト期間(2000-2010が訓練期間) 
    df_dict                   : 株価データ（dict形式 : OHLCVデータ）
    hyperparms_company_common : Trader-Company法のパラメータ
    hyperparms_portfolio      : ポートフォリオ構築のパラメータ
    stock_list                : 分析対象銘柄のTicker
'''

#%%
# 実行
output_all = {}
time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
for seed_ in [1, 2, 3]:
    for data_type_ in ['Rt']: #, 'Tech', 'RtTech']:
        hyperparms_company_common['random_seed'] = seed_
        hyperparms_company_common['data_type'] = data_type_        
        pattern_name = 'seed' + str(seed_) + '_' + str(data_type_  )
        all_setting['pattern_name'] = pattern_name
        output_all[pattern_name] = get_result(**all_setting)

# 結果の出力        
path_output = PATH_HEAD + '\\Result\\' + time_now
os.makedirs(path_output, exist_ok=True)
output_result(output_all, path_output)
               
#%%
# パラメータの使用頻度を算出
# =============================================================================
# hyperparms_company_learned = tc.hyperparms_company_learned
# ticker_counts, activation_counts, operator_counts = tc.calc_parms_frequency(df_pct.columns, hyperparms_company_learned)
# ticker_counts.iloc[:30,:].plot.bar()
# activation_counts.plot.bar()
# operator_counts.plot.bar()
# =============================================================================