# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    
"""
import pandas as pd
import datetime as dt
import os
import pickle

# パスの設定
PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\cross_section_ensemble'
os.chdir(PATH_HEAD)
from get_result import ResultMaker

# データセットの入力
with open(PATH_HEAD+'\\data\\sp500.pickle', 'rb') as f:
    df_dict_org = pickle.load(f) 

# yahooファイナンスデータゆえの特殊対応
df_dict = {}
for name, df_ in df_dict_org.items():
    df_.index = pd.to_datetime(df_.index)
    # 1列すべてがNANであるデータは削除，それ以外は行に欠損があってもデータを保持
    df_dict[name] = df_.iloc[[i!=0 for i in df_.count(1)],:].dropna(how='all', axis=1)
    del df_

del df_dict_org

# 銘柄のセクター情報を取得
df_info = pd.read_csv(PATH_HEAD+'\\data\\SP500_info.csv', index_col=1)
# 各銘柄のもつ属性（セクター情報）
ticker_info = df_info['GICS Sector'].to_dict()

#%%
# 事前に設定する項目    
hyperparms_company_common = {
    'N_trader'            : 500,
    'M_strategy'          : 2,
    'K_factor'            : 3,    
    'Aggregate'           : 'quantile', # 'average', 'quantile', 'cluster'
    'Q_quantile_educate'  : 0.5,
    'lag'                 : 1,        
    'rebalance_term'      : 30,
    'random_seed'         : 7777,
    'method_measure'      : 'SR', # 'CR', 'SR', 'DDR'
    'method_sampling'     : 'GMM',    
    'fit_times'           : 3,
    'GMM_n_components'    : 10, # 10
    'trader_long'         : 0.90,
    'trader_short'        : 0.1,    
    'trader_type'         : 'LongShort',
    'cost'                : 0.005,
    'Aggregate_quantile'  : 0.5,    
    'max_num_clusters'    : 5,
    'n_init_clusters'     : 3
    }
'''
hyperparms_company_common : ハイパーパラメータ
    'N_trader_num'        : トレーダー数
    'Aggregate'           : 集約方法の指定
            'average'        : トレーダーのポートフォリオを等ウェイトでアンサンブル
            'quantile'       : 上位Aggregate_quantileのトレーダーのポートフォリオを等ウェイトでアンサンブル
            'clusetr'        : トレーダーをONCクラスタリングし，それぞれのクラスタごとに等ウェイトポートフォリオを形成
                                ⇒各インデックスのリターン，リスクよりシャープレシオ最大化を実施してウェイトを実施し，アンサンブルウェイトを決定
    'Q_quantile_educate'  : パフォーマンスの悪いトレーダーを生成する際の閾値割合
    'formula_num_max'     : 各トレーダーの戦略（公式）の候補数の最大値
    'lag'                 : 説明変数の時点と被説明変数の時点のラグ
    'rebalance_term'      : リバランスの頻度（説明変数のサンプリング頻度）
    'random_seed'         : ランダムシード
    'method_measure'      : トレーダーのパフォーマンス測定基準
            'CR'              : 累積リターン
            'SR'　　　　　　　　　　　: シャープレシオ
            'DDR'             : DDR(リスクが半分散)
    'method_sampling'     : トレーダー生成時のサンプリング方法
            'GMM'             : 混合正規分布によるサンプリング
    'fit_times'           : レーダー生成の繰り返し回数
    'GMM_n_components'    : 混合正規分布のフィット時におけるクラスター数
    'Aggregate_quantile'  : Aggregeteをquantileを選択した場合の閾値割合
    'max_num_clusters'　　　: Aggregeteをclusetrを選択した場合の最大クラスタ数
    'n_init_clusters'     : Aggregeteをclusetrを選択した場合の初期化計算繰り返し数
'''

hyperparms_portfolio = {
    'cost_buy'               : 0.01,
    'cost_sell'              : 0.01,
    'calc_type'              : 'cumulative',    
    'wealth_init'            : 100,    
    }

'''
hyperparms_portfolio : dict
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
'''

# 訓練，テスト期間の設定
all_setting = {
    'start_year'                : 2001, # is_get_dictでTrueとした場合の訓練データの開始期間（）
    'end_year'                  : 2020,
    'year_term_train'           : 10,
    'year_term_test'            : 5,
    'is_get_dict'               : True,
    'hyperparms_portfolio'      : hyperparms_portfolio,
    'stock_list'                : df_dict['Adj Close'].columns,
    }
'''
all_setting : dict
    start_year                : 訓練開始年
    end_year                  : 訓練終了年
    year_term_train           : 訓練データ年数
    year_term_test            : テストデータ年数
    is_get_dict               : テストデータ分割方法の指定
                                True  : year_term_trainごとのスライド方式
                                False : 固定の訓練/テスト期間(ResultMaker内で固定されている設定) 
    hyperparms_portfolio      : ポートフォリオ構築のパラメータ
    stock_list                : 分析対象銘柄のTicker
'''
#%%
# 実行
time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
    
# パターン数大きくしすぎるとメモリが限界に達する可能性があるため，適度にoutput_resultで出力
for seed_ in [1]:
    hyperparms_company_common['random_seed'] = seed_
    pattern_name = 'seed' + str(seed_)
    all_setting['pattern_name'] = pattern_name
    rm = ResultMaker(df_dict, hyperparms_company_common, ticker_info)
    all_result = rm.get_all_result(all_setting)
    
    # 結果の出力        
    path_output = PATH_HEAD + '\\Result\\' + time_now
    os.makedirs(path_output, exist_ok=True)
    rm.output_result(all_result, path_output)
    