import pandas as pd
import os
import glob
from omegaconf import DictConfig
import hydra
from ppopt.models.learner import ModelLearner
from ppopt.backtest.backtester import BacktesterDetecter
from ppopt.backtest.backtester_utility import UtilityBacktester
from ppopt.backtest.backtester_regressor import RegBacktester
from ppopt.utils.portfolio_evaluator import PortfolioEvaluator
from ppopt.utils.mlflow_writer import MlflowWriter
from ppopt.utils.visualize import Visualizer
from config.config_factor_category import CONFIG_FACTOR_CATEGORY

import mlflow
from mlflow.utils.mlflow_tags import MLFLOW_RUN_NAME

PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"

def make_explain_target(df, index_date : list = []):
    if len(index_date) == 0:
        index_date = df["Date"].unique()

    df_extracted = df.loc[df["Date"].isin(index_date), :]
    df_extracted = df_extracted.set_index(["Date", "stock"])
    y = df_extracted["ret"]
    is_drop = y==0
    y = y.loc[~is_drop] 
    X = df_extracted.loc[~is_drop, :].drop("ret", axis=1)
    
    return X, y


# df_train = pd.read_csv(PATH_DATA + "/train.csv.gz", index_col=0)
# X_train, y_train = make_explain_target(df_train)
# del df_train
# df_val = pd.read_csv(PATH_DATA + "/valid.csv.gz", index_col=0)
# X_val, y_val = make_explain_target(df_val)
# del df_val
df_test = pd.read_csv(PATH_DATA + "/test.csv.gz", index_col=0)
# X_test, y_test = make_explain_target(df_test)
# del df_test

# Light Pattern1
# X_train, y_train = make_explain_target(df_train, index_date=df_train["Date"].unique()[0:120])
# X_val, y_val = make_explain_target(df_train, index_date=df_train["Date"].unique()[120:180])
# X_test, y_test = make_explain_target(df_train, index_date=df_train["Date"].unique()[180:183])

# Light Pattern2
X_train, y_train = make_explain_target(df_test, index_date=df_test["Date"].unique()[140:220])
# X_val, y_val = make_explain_target(df_test, index_date=df_test["Date"].unique()[220:250])
X_test, y_test = make_explain_target(df_test, index_date=df_test["Date"].unique()[220:300])
factor_list = [i for i in X_train.columns if i not in ["stock", "Date"]]


@hydra.main(config_path="config", config_name="config_model")
def main(cfg: DictConfig):
    experiment_name = "UtilityTrader"
    writer = MlflowWriter(experiment_name=experiment_name)

    learner = ModelLearner(cfg.hyperparms, factor_list)
    # estimate paramaters through backpropagation
    estimator = learner.call_estimator_init(
        model_name="UtilityTrader")
    estimators = learner.learn(estimator, X_train, y_train)
    loss_save = learner.summarize_estimators_loss(estimators)
    learner.save_model(estimators)

    visualizer = Visualizer(config_factor_category=CONFIG_FACTOR_CATEGORY)
    visualizer.save_fig_loss(loss_save, title="loss.html")    
    
    # backtest
    backtester = UtilityBacktester(cfg.hyperparms_portfolio)
    weight_test = backtester.calc_weight(
        estimators, X_test, y_test, X_train, y_train)

    tags = {
        MLFLOW_RUN_NAME: "trial0",
        }
    writer.create_new_run(tags)
    writer.log_params_from_omegaconf_dict(cfg)

    # save portfolio performance
    pe = PortfolioEvaluator(y_test, weight_test, cfg.hyperparms_portfolio)
    performance_test = pe.calc_portfolio_performance()
    visualizer.save_performance_table(performance_test["performance"], title="[test]performance.html")
    pe.log_performance_to_metric(performance_test, writer)

    # save portfolio return corr
    weight_test_, weight_train = backtester.calc_train_test_port_weight(
        estimators, X_test, X_train)
    port_rt_with_hidden_test, port_rt_with_hidden_train = backtester.calc_train_test_port_rt(
        weight_test_, y_test, weight_train, y_train)
    visualizer.save_corr_plot(port_rt_with_hidden_train, title="[train]corr_all.html")
    visualizer.save_corr_plot(port_rt_with_hidden_test, title="[test]corr_all.html")

    # save portfolio cumsum return(test)
    theta_test = backtester.fill_theta(
        estimators, theta_index=port_rt_with_hidden_test.index)
    visualizer.save_return_fig(
        df_port=performance_test["rt_port"],
        port_rt_with_hidden=port_rt_with_hidden_test,
        title="[test]port_rt_all.html",
        theta=theta_test
        )
    
    # save portfolio performance(train)
    pe_train = PortfolioEvaluator(y_train, weight_train["all"], cfg.hyperparms_portfolio)
    performance_train = pe_train.calc_portfolio_performance()
    visualizer.save_performance_table(performance_train["performance"], title="[train]performance.html")

    # save portfolio cumsum return(train)
    theta_train = backtester.fill_theta(
        estimators, theta_index=port_rt_with_hidden_train.index)
    visualizer.save_return_fig(
        df_port=performance_train["rt_port"],
        port_rt_with_hidden=port_rt_with_hidden_train,
        title="[train]port_rt_all.html",
        theta=theta_train
        )    
       
    # save lrp
    for fold, estimator in estimators.items():
        # save lrp(train)
        port_lrp, _, factor_coef = backtester.calc_lrp(
            estimator, X_train, y_train, factor_list)
        visualizer.save_fig_lrp(
            port_lrp, title="[train]lrp_fold{}.html".format(fold))
        visualizer.save_fig_lrp_coef(
            factor_coef, title="[train]lrp_coef_fold{}.html".format(fold))
        visualizer.save_fig_lrp_timeseries(
            port_lrp, title="[train]lrp_timeseries_fold{}.html".format(fold))
        
        # save lrp(test)
        port_lrp, _, factor_coef = backtester.calc_lrp(
            estimator, X_test, y_test, factor_list)
        visualizer.save_fig_lrp(
            port_lrp, title="[test]lrp_fold{}.html".format(fold))
        visualizer.save_fig_lrp_coef(
            factor_coef, title="[test]lrp_coef_fold{}.html".format(fold))
        visualizer.save_fig_lrp_timeseries(
            port_lrp, title="[test]lrp_timeseries_fold{}.html".format(fold))  

        # save corr 
        weight_test, weight_train = backtester.calc_train_test_port_weight(
            estimator, X_test, X_train)
        port_rt_with_hidden_test, port_rt_with_hidden_train = backtester.calc_train_test_port_rt(
            weight_test, y_test, weight_train, y_train)
        visualizer.save_corr_plot(
            port_rt_with_hidden_train, 
            title="[train]corr_fold{}.html".format(fold))
        visualizer.save_corr_plot(
            port_rt_with_hidden_test, 
            title="[test]corr_fold{}.html".format(fold))
    
    # Hydraの成果物をArtifactに保存
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/config.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/hydra.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/overrides.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), "estimators.pkl"))
    # htmlファイルを保存
    files_html = glob.glob(os.path.join(os.getcwd() + "/*.html"))
    for file in files_html:
        writer.log_artifact(file)
                
    writer.set_terminated() 
    
if __name__ == "__main__":
    main()