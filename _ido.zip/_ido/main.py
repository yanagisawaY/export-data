# -*- coding: utf-8 -*-
"""
期間をさかのぼって過去論文のリンクも取得
（2019/3/7～より取得可能．それ以前はデータが存在しないため注意）
@author: Yangaisawa
"""
PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\scraping'

import os
import datetime as dt
import pandas as pd
os.chdir(PATH_HEAD)
from utils.get_paper import get_quant_news

#%%
start_date = dt.datetime(2020, 5, 18)
end_date = dt.datetime(2021, 5, 18)

df_all_list = []
for i in range((end_date-start_date).days+1):
    date = start_date + dt.timedelta(i)
    print(f'{date.strftime("%y-%m-%d")}')
    df_all_list.append(get_quant_news(date))

df_all = pd.concat(df_all_list).reset_index(drop=True)
output_csvname = start_date.strftime("%y%m%d")+'_'+end_date.strftime("%y%m%d")

os.makedirs('output', exist_ok=True)
df_all.to_csv('output/'+output_csvname+'.csv', encoding='utf_8')

