import os
import glob
from omegaconf import DictConfig
import hydra
import mlflow
# from mlflow.utils.mlflow_tags import MLFLOW_RUN_NAME

from ppopt.models.learner import ModelLearner
from ppopt.backtest.backtester_utility import UtilityBacktester
from ppopt.utils.portfolio_evaluator import PortfolioEvaluator
from ppopt.utils.preloader import PreLoader
from ppopt.utils.mlflow_writer import MlflowWriter
from ppopt.utils.visualize import Visualizer
from config.config_factor_category import CONFIG_FACTOR_CATEGORY



@hydra.main(config_path="config", config_name="config_model")
def main(cfg: DictConfig):
    PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"
    preloader = PreLoader(PATH_DATA)
    X_train, y_train, X_test, y_test, factor_list = preloader.make_dataset(
        cfg.train_test_term[0],
        cfg.train_test_term[1],
        cfg.train_test_term[2],
        cfg.train_test_term[3]
    )

    # hydraのmultirunsの結果をmlflowで一元管理するため，以下を設定
    # path_mlruns = hydra.utils.get_original_cwd() + "/mlruns"
    mlflow.set_tracking_uri(
        'file:\\' + hydra.utils.get_original_cwd() + '\\mlruns')
    writer = MlflowWriter(experiment_name=cfg.experiment)

    learner = ModelLearner(cfg.hyperparms, factor_list)
    # estimate paramaters through backpropagation
    estimator = learner.call_estimator_init(
        model_name="UtilityTrader")
    estimators = learner.learn(estimator, X_train, y_train)
    loss_save = learner.summarize_estimators_loss(estimators)
    learner.save_model(estimators)

    visualizer = Visualizer(config_factor_category=CONFIG_FACTOR_CATEGORY)
    visualizer.save_fig_loss(loss_save, title="loss.html")

    # backtest
    backtester = UtilityBacktester(cfg.hyperparms_portfolio)
    weight_test = backtester.calc_weight(
        estimators, X_test, y_test, X_train, y_train)

    tags = {
        "train_start": cfg.train_test_term[0],
        "train_end": cfg.train_test_term[1],
        "test_start": cfg.train_test_term[2],
        "test_end": cfg.train_test_term[3],
        }

    writer.create_new_run(tags)
    writer.log_params_from_omegaconf_dict(cfg)

    # save portfolio performance
    pe = PortfolioEvaluator(y_test, weight_test, cfg.hyperparms_portfolio)
    performance_test = pe.calc_portfolio_performance()
    visualizer.save_performance_table(
        performance_test["performance"], title="[test]performance.html")
    pe.log_performance_to_metric(performance_test, writer)

    # save portfolio return corr
    weight_test_, weight_train = backtester.calc_train_test_port_weight(
        estimators, X_test, X_train)
    port_rt_with_hidden_test, port_rt_with_hidden_train = backtester.calc_train_test_port_rt(
        weight_test_, y_test, weight_train, y_train)
    visualizer.save_corr_plot(
        port_rt_with_hidden_train, title="[train]corr_all.html")
    visualizer.save_corr_plot(port_rt_with_hidden_test,
                              title="[test]corr_all.html")

    # save portfolio cumsum return(test)
    theta_test = backtester.fill_theta(
        estimators, theta_index=port_rt_with_hidden_test.index)
    visualizer.save_return_fig(
        df_port=performance_test["rt_port"],
        port_rt_with_hidden=port_rt_with_hidden_test,
        title="[test]port_rt_all.html",
        theta=theta_test
    )

    # save portfolio performance(train)
    pe_train = PortfolioEvaluator(
        y_train, weight_train["all"], cfg.hyperparms_portfolio)
    performance_train = pe_train.calc_portfolio_performance()
    visualizer.save_performance_table(
        performance_train["performance"], title="[train]performance.html")

    # save portfolio cumsum return(train)
    theta_train = backtester.fill_theta(
        estimators, theta_index=port_rt_with_hidden_train.index)
    visualizer.save_return_fig(
        df_port=performance_train["rt_port"],
        port_rt_with_hidden=port_rt_with_hidden_train,
        title="[train]port_rt_all.html",
        theta=theta_train
    )

    if not isinstance(estimators, dict):
        estimators = {0: estimators}
        
    # save lrp
    for fold, estimator in estimators.items():
        # save lrp(train)
        port_lrp, _, factor_coef = backtester.calc_lrp(
            estimator, X_train, y_train, factor_list)
        visualizer.save_fig_lrp(
            port_lrp, title="[train]lrp_fold{}.html".format(fold))
        visualizer.save_fig_lrp_coef(
            factor_coef, title="[train]lrp_coef_fold{}.html".format(fold))
        visualizer.save_fig_lrp_timeseries(
            port_lrp, title="[train]lrp_timeseries_fold{}.html".format(fold))

        # save lrp(test)
        port_lrp, _, factor_coef = backtester.calc_lrp(
            estimator, X_test, y_test, factor_list)
        visualizer.save_fig_lrp(
            port_lrp, title="[test]lrp_fold{}.html".format(fold))
        visualizer.save_fig_lrp_coef(
            factor_coef, title="[test]lrp_coef_fold{}.html".format(fold))
        visualizer.save_fig_lrp_timeseries(
            port_lrp, title="[test]lrp_timeseries_fold{}.html".format(fold))

        if isinstance(estimators, dict):
            # save corr
            weight_test, weight_train = backtester.calc_train_test_port_weight(
                estimator, X_test, X_train)
            port_rt_with_hidden_test, port_rt_with_hidden_train = backtester.calc_train_test_port_rt(
                weight_test, y_test, weight_train, y_train)
            visualizer.save_corr_plot(
                port_rt_with_hidden_train,
                title="[train]corr_fold{}.html".format(fold))
            visualizer.save_corr_plot(
                port_rt_with_hidden_test,
                title="[test]corr_fold{}.html".format(fold))

    # Hydraの成果物をArtifactに保存
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/config.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/hydra.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/overrides.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), "estimators.pkl"))
    # htmlファイルを保存
    files_html = glob.glob(os.path.join(os.getcwd() + "/*.html"))
    for file in files_html:
        writer.log_artifact(file)

    writer.set_terminated()


if __name__ == "__main__":
    main()
