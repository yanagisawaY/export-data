import os
import glob
from omegaconf import DictConfig
import hydra
import mlflow
# from mlflow.utils.mlflow_tags import MLFLOW_RUN_NAME

from ppopt.models.learner import ModelLearner
from ppopt.backtest.backtester_regressor import RegBacktester
from ppopt.utils.portfolio_evaluator import PortfolioEvaluator
from ppopt.utils.preloader import PreLoader
from ppopt.utils.mlflow_writer import MlflowWriter
from ppopt.utils.visualize import Visualizer
from config.config_factor_category import CONFIG_FACTOR_CATEGORY


@hydra.main(config_path="config", config_name="config_regressor")
def main(cfg: DictConfig):
    PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"
    preloader = PreLoader(PATH_DATA)
    X_train, y_train, X_test, y_test, factor_list = preloader.make_dataset(
        cfg.train_test_term[0],
        cfg.train_test_term[1],
        cfg.train_test_term[2],
        cfg.train_test_term[3]
    )

    # hydraのmultirunsの結果をmlflowで一元管理するため，以下を設定
    # path_mlruns = hydra.utils.get_original_cwd() + "/mlruns"
    mlflow.set_tracking_uri(
        'file:\\' + hydra.utils.get_original_cwd() + '\\mlruns')
    writer = MlflowWriter(experiment_name=cfg.experiment)

    learner = ModelLearner(cfg.hyperparms, factor_list)
    # estimate paramaters through backpropagation
    estimator = learner.call_estimator_init(
        model_name="Regressor")
    estimators = learner.learn(estimator, X_train, y_train)
    loss_save = learner.summarize_estimators_loss(estimators)
    learner.save_model(estimators)

    visualizer = Visualizer(config_factor_category=CONFIG_FACTOR_CATEGORY)
    visualizer.save_fig_loss(loss_save, title="loss.html")

    # backtest
    backtester = RegBacktester(cfg.hyperparms_portfolio)
    weight_test = backtester.calc_weight(
        estimators, X_test)

    tags = {
        "train_start": cfg.train_test_term[0],
        "train_end": cfg.train_test_term[1],
        "test_start": cfg.train_test_term[2],
        "test_end": cfg.train_test_term[3],
        }

    writer.create_new_run(tags)
    writer.log_params_from_omegaconf_dict(cfg)

    # save portfolio performance
    pe = PortfolioEvaluator(y_test, weight_test, cfg.hyperparms_portfolio)
    performance_test = pe.calc_portfolio_performance()
    visualizer.save_performance_table(
        performance_test["performance"], title="[test]performance.html")
    pe.log_performance_to_metric(performance_test, writer)
    visualizer.save_cumsum_return_only(
        performance_test["rt_port"], title="[test]port_rt.html")
    
    # shap
    # select backgroud for shap
    import torch
    import numpy as np
    import shap
    import matplotlib.pyplot as plt
    import matplotlib.pylab as pylab
    np.random.seed(cfg.hyperparms.random_state)
    background = torch.Tensor(X_train.iloc[np.random.choice(
        X_train.shape[0], 100, replace=False), :].values)
    X_processed_ = torch.Tensor(X_test.values)
    if isinstance(estimators, dict):
        shap_values = 0
        for i, estimator_ in estimators.items():
            # DeepExplainer to explain predictions of the model
            print("{} : calc shap...".format(i))
            explainer = shap.DeepExplainer(estimator_.model, background)
            # compute shap values
            shap_values_ = explainer.shap_values(X_processed_)
            
            fig = plt.gcf()
            shap.summary_plot(shap_values_, X_test, show=False)
            pylab.tight_layout()
            fig.savefig("shap_summary_{}.png".format(i))
            plt.close()

            fig = plt.gcf()
            shap.summary_plot(shap_values_, X_test, plot_type="bar", show=False)
            pylab.tight_layout()
            fig.savefig("shap_summary_bar_{}.png".format(i))
            plt.close()
                            
            # writer.log_figure(fig, "shap_summary_{}.png".format(i))
            shap_values += shap_values_
        
        shap_values /= len(estimators)
    else:
        # DeepExplainer to explain predictions of the model
        explainer = shap.DeepExplainer(estimator, background)
        # compute shap values
        shap_values = explainer.shap_values(X_test)    

    fig = plt.gcf()
    shap.summary_plot(shap_values, X_test, show=False)
    pylab.tight_layout()
    fig.savefig("shap_summary_all.png")
    plt.close()
 
    fig = plt.gcf()
    shap.summary_plot(shap_values, X_test, plot_type="bar", show=False)
    pylab.tight_layout()
    fig.savefig("shap_summary_bar_all.png")
    plt.close()

       
    # Hydraの成果物をArtifactに保存
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/config.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/hydra.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), ".hydra/overrides.yaml"))
    writer.log_artifact(os.path.join(os.getcwd(), "estimators.pkl"))
    # htmlファイルを保存
    files_html = glob.glob(os.path.join(os.getcwd() + "/*.html"))
    for file in files_html:
        writer.log_artifact(file)
    # pngファイルを保存
    files_png = glob.glob(os.path.join(os.getcwd() + "/*.png"))
    for file in files_png:
        writer.log_artifact(file)
        
    writer.set_terminated()


if __name__ == "__main__":
    main()
