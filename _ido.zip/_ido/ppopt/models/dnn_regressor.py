"""
教師学習にて使用するDNNのクラス
"""
import copy
from multiprocessing.sharedctypes import Value
from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd
from .base_estimator import ModelBase
from ..utils.util import check_input
from ..utils.processor import scale_xs


class DeepNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''

    def __init__(self, hyperparms, input_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(DeepNet, self).__init__()
        layer_units = hyperparms['layer_list']
        layer_num = len(layer_units)
        layer = []
        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(input_num, layer_units[0]))
        layer.append(nn.BatchNorm1d(layer_units[0]))
        layer.append(nn.ReLU())
        if layer_num > 1:
            for i in range(layer_num-1):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))
                layer.append(nn.Linear(layer_units[i], layer_units[i+1]))
                layer.append(nn.BatchNorm1d(layer_units[i+1]))
                layer.append(nn.ReLU())

        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(layer_units[-1], 1))
        self.full = nn.Sequential(*layer)

    def forward(self, X):
        output = self.full(X)

        return output


class Regressor(ModelBase):
    '''DNNの学習を行うクラス
    
    Paramters
    ---------
    hyperparms : dict
        深層学習のハイパーパラメータ.
    factor_list : list
        使用するファクターのリスト
    '''
    def __init__(self, hyperparms, factor_list):
        super().__init__(hyperparms)
        self.hyperparms = hyperparms
        self.factor_list = factor_list
        self.fit_col = None
        
    def _call_loader(self, X, y, batch_size):
        X = scale_xs(X)
        X = torch.Tensor(X.values)        
        y = torch.Tensor(y.values)
        df = TensorDataset(X, y)
        
        loader = DataLoader(
            df, batch_size=min(batch_size, y.shape[0]), shuffle=False)
        
        return loader
        
    def fit_yield(self, X, y, X_val, y_val, hyperparms={}):
        '''see also _fit method
        '''                    
        torch.manual_seed(hyperparms['random_state'])        
        loader = self._call_loader(X, y, self.hyperparms["batch_size"])

        if X_val is not None:
            loader_val = self._call_loader(X_val, y_val, y_val.shape[0])
            is_val = True
        else:
            is_val = False

        # 早期停止条件用の設定
        loss_val_min = 10000**100
        patience_count = 0
        upper_patience_count = hyperparms["upper_patience_count"]
        min_epoch = hyperparms["min_epoch"]

        input_num = len(self.factor_list)
        self.model = DeepNet(hyperparms, input_num)
        optimizer = torch.optim.Adam(
            self.model.parameters(), lr=hyperparms['lr'])
        criterion = nn.MSELoss()

        for epoch in range(hyperparms['epoch']):
            for X_t, y_t in loader:
                self.model.train()
                y_pred = self.model.forward(X_t).squeeze()
                loss = criterion(y_pred, y_t)
                    
                if hyperparms["l2_norm"] > 0:
                    # L2-normの正則化項を追加
                    l2 = torch.tensor(0., requires_grad=True)
                    for w in self.model.parameters():
                        l2 = l2 + hyperparms["l2_norm"]*torch.norm(w)**2
                    loss = loss + l2

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            if is_val:
                with torch.no_grad():
                    self.model.eval()
                    for X_val, y_val in loader_val:
                        y_val_pred = self.model.forward(X_val).squeeze()
                        loss_val = criterion(y_val_pred, y_val).item()
                    
                    if loss_val_min > loss_val:
                        # バリデーションデータにおける評価値が最も良いパラメータを保持
                        self.best_params = copy.deepcopy(
                            self.model.state_dict())
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1

                    if patience_count > upper_patience_count and epoch > min_epoch:
                        print(
                            f"[BREAK] {epoch+1}/{hyperparms['epoch']} train {round(loss.item(), 4)} val {round(loss_val, 4)}")
                        break

                    print(
                        f"{epoch+1}/{hyperparms['epoch']} train {round(loss.item(), 4)} val {round(loss_val, 4)}")

                    yield [loss.item(), loss_val]
            else:
                print(
                    f"{epoch+1}/{hyperparms['epoch']} train {round(loss.item(), 4)}")
                yield [loss.item()]
                
    def fit(self, X, y, X_val=None, y_val=None, hyperparms={}):
        '''モデルのパラメータを学習

        Parameters
        ----------        
        X : pandas.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series (MultiIndex("Date", "stock"))
            リターンデータ(銘柄×時点,)
        X_val : pd.DataFrame (MultiIndex("Date", "stock"))
            バリデーションデータにおける特徴量データ(銘柄×時点, 特徴量)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        y_val : pd.DataFrame (MultiIndex("Date", "stock"))
            バリデーションデータにおけるリターンデータ(銘柄×時点,)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        hyperparms : dict
            ハイパーパラメータの辞書, デフォルトではclassが保持するhyperparamsを参照．

        Return
        ------
        model : 
            学習済みモデル

        Notes
        -----
        * optunaによる刈り取りアルゴリズムを利用できるように_fit_yieldにてyieldを使用
        * tune methodなどでも使用するため，fit methodと分離
        '''
        # データの型チェック
        check_input(X, y)
        if X is not None and y is not None:
            check_input(X_val, y_val)  
            
        if len(hyperparms) == 0:
            hyperparms = copy.deepcopy(self.hyperparms)
        
        loss_save = pd.DataFrame([
            loss_list for loss_list in self.fit_yield(X, y, X_val, y_val, hyperparms)])
        if X_val is None and y_val is None:
            loss_save.columns = ["train"]
        else:
            loss_save.columns = ["train", "val"]

        self.loss_save = loss_save

        if hyperparms["best_params"]:
            self.model.load_state_dict(copy.deepcopy(self.best_params))

    def predict(self, X):
        '''予測リターンを算出
        
        Paramters
        ---------
        X : pd.DataFrame
            特徴量データ(銘柄×時点, 特徴量)

        Return
        ------
        y_pred : pd.Series (MultiIndex("Date", "stock"))
            予測リターン(銘柄×時点,)
        '''
        index_ = X.index
        X = scale_xs(X)
        X = torch.Tensor(X.values)
        y_pred = pd.Series(self.model.forward(X).squeeze().detach().numpy().copy())
        y_pred.index = index_
        
        return y_pred