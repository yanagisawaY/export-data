import copy
import pandas as pd
from sklearn import metrics
import torch
from torch import nn
from ..utils.loader import XSDataLoader
from .utility_net import UtilityNet

from .base_estimator import ModelBase
from ..utils.processor import scale_xs, make_torch_scaled_from_df
from ..utils.optimizer import weight_under_leverage
from ..utils.util import base_port_return, calc_active_return, check_input, get_universe_slice_list


class UtilityLoss(nn.Module):
    """目的関数のモジュール
    """

    def __init__(self, utility_type: str, gamma: float):
        super().__init__()
        self.utility_type = utility_type
        self.gamma = gamma

    def forward(self, port_rt):
        if self.utility_type == "CRRA":
            utility = ((1 + port_rt)**(1 - self.gamma))/(1 - self.gamma)
            utility = utility.mean()
        elif self.utility_type == "MV":
            utility = torch.mean(port_rt) - self.gamma*torch.var(port_rt)/2
        elif self.utility_type == "SR":
            utility = torch.mean(port_rt)/torch.std(port_rt)
        else:
            raise ValueError(f"このバージョンには対応していません : {self.utility_type}")

        return utility


class UtilityTrader(ModelBase):
    '''DNNの学習を行うクラス

    Paramters
    ---------        
    hyperparms : Dict[str: Any]
    ハイパーパラメータの辞書            
    
        Examples
        --------
        >>> hyperparams = {
        >>> "model": "UtilityTrader",  # モデル名(UtilityTrader以外は想定していない)
        >>> "random_state": 1,  # 乱数シード
        >>> "batch_size": None,  # バッチサイズ（1バッチは1か月データに相当．Noneの場合，全データを使用してバッチ学習を実施）
        >>> "layer_list": [64, 4], # [30, 20, 4],  # 深層学習の各レイヤーのユニット数(リストのサイズが中間層の数)
        >>> "layer_dropout": 0.05,  # ドロップアウト
        >>> "l2_norm": 0,  # 1e-3,  # l2正則化項への罰則
        >>> "lr": 1e-3,  # Adamに適用する学習率
        >>> "epoch": 1000,  # エポック数
        >>> "newton_T": 8,  # ONCアルゴリズムを適用する場合の繰り返し回数
        >>> "best_params": True,  # バリデーションデータの評価値が最もよいハイパーパラメータを採用する場合True
        >>> "network_type": "onc",, # ネットワーク構造の指定 onc -> ONCアルゴリズムを適用,しない場合は"None"
        >>> "upper_patience_count": 100, # バリデーションデータがupper_patience_count回連続して向上しないことが続いた場合，早期停止を実施
        >>> "min_epoch": 500, # upper_patience_countによる早期停止を適用しない最低学習回数    
        >>>         
        >>> # 目的関数の設定(utility_type = 'SR', 'return_mode' = 'active'の場合，IR最大化となる)
        >>> "utility_type" : "SR",  # SR -> シャープレシオ(R/R)最大化, MV -> 最小分散, CRRA -> CRRA型効用最大化
        >>> "return_mode": "active",  # active -> アクティブリターンを使用して目的関数を最大化, all -> ベンチマーク含めたポートフォリオリターンを使用して目的関数最大化
        >>> "gamma": 10,  # CRRA型効用を用いる場合のリスク回避係数    
        }
    factor_list : list
        使用するファクターのリスト        
    writer : MlflowWriter wrapper | None
        mlflowのラッパークラス
    '''

    def __init__(self, hyperparms, factor_list):
        super().__init__(hyperparms)
        self.factor_list = factor_list
        self.model = []

    def fit_yield(self, X, y, X_val, y_val, hyperparms={}):
        '''see also _fit method
        '''        
        X = scale_xs(X)      
        torch.manual_seed(hyperparms['random_state'])
        batch_size = hyperparms["batch_size"]
        loader = XSDataLoader(X, y, batch_size)

        if X_val is not None:
            X_val = scale_xs(X_val)
            loader_val = XSDataLoader(X_val, y_val, y_val.shape[0])
            is_val = True
        else:
            is_val = False

        # 早期停止条件用の設定
        loss_val_min = 10000**100
        patience_count = 0
        upper_patience_count = hyperparms["upper_patience_count"]
        min_epoch = hyperparms["min_epoch"]

        input_num = len(self.factor_list)
        self.model = UtilityNet(hyperparms, input_num)        
        optimizer = torch.optim.Adam(
            self.model.parameters(), lr=hyperparms['lr'])
        criterion = UtilityLoss(
            hyperparms["utility_type"],
            hyperparms["gamma"])

        for epoch in range(hyperparms['epoch']):
            for X_t, y_t, universe_index in loader:
                self.model.train()
                weight_t = self.model.forward(
                    X_t, universe_index, rt=y_t, mode="train")
                rt_active = calc_active_return(weight_t, y_t, universe_index)

                if hyperparms["return_mode"] == "all":
                    rt_bench = base_port_return(y_t, universe_index)
                    port_rt = rt_bench + rt_active
                    loss = - criterion(port_rt)
                elif hyperparms["return_mode"] == "active":
                    loss = - criterion(rt_active)
                else:
                    raise ValueError("return_modeは'all'か'active'と入力")

                if hyperparms["l2_norm"] > 0:
                    # L2-normの正則化項を追加
                    l2 = torch.tensor(0., requires_grad=True)
                    for w in self.model.parameters():
                        l2 = l2 + hyperparms["l2_norm"]*torch.norm(w)**2
                    loss = loss + l2
                
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            if is_val:
                with torch.no_grad():
                    self.model.eval()
                    for X_val, y_val, universe_index_val in loader_val:
                        weight_val = self.model.forward(
                            X_val, universe_index_val, rt=y_val, mode="predict")
                        rt_active = calc_active_return(weight_val, y_val, universe_index_val)
                        if hyperparms["return_mode"] == "all":
                            rt_bench = base_port_return(y_val, universe_index_val)
                            port_rt = rt_bench + rt_active
                            loss_val = - criterion(port_rt).item()
                        elif hyperparms["return_mode"] == "active":
                            loss_val = - criterion(rt_active).item()

                    if loss_val_min > loss_val:
                        # バリデーションデータにおける評価値が最も良いパラメータを保持
                        self.best_params = copy.deepcopy(
                            self.model.state_dict())
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1

                    if patience_count > upper_patience_count and epoch > min_epoch:
                        print(
                            f"[BREAK] {epoch+1}/{hyperparms['epoch']} train {- round(loss.item(), 4)} val {- round(loss_val, 4)}")
                        break

                    print(
                        f"{epoch+1}/{hyperparms['epoch']} train {- round(loss.item(), 4)} val {- round(loss_val, 4)}")

                    loss_train = -loss.item()
                    loss_val = -loss_val
                    yield [loss_train, loss_val]
            else:
                print(
                    f"{epoch+1}/{hyperparms['epoch']} train {- round(loss.item(), 4)}")
                loss_train = -loss.item()
                
                yield [loss_train]

    def fit(self, X, y, X_val=None, y_val=None, hyperparms={}):
        '''モデルのパラメータを学習

        Parameters
        ----------        
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series (MultiIndex("Date", "stock"))
            リターンデータ(銘柄×時点,) 
        X_val : pd.DataFrame (MultiIndex("Date", "stock"))
            バリデーションデータにおける特徴量データ(銘柄×時点, 特徴量)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        y_val : pd.Series (MultiIndex("Date", "stock"))
            バリデーションデータにおけるリターンデータ(銘柄×時点,)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        hyperparms : Dict[Any]
            ハイパーパラメータの辞書, デフォルトではclassが保持するhyperparamsを参照．

        Return
        ------
        model : 
            学習済みモデル

        Notes
        -----
        * optunaによる刈り取りアルゴリズムを利用できるようにfit_yieldにてyieldを使用
        * ModelBaseクラスのtune methodでも使用
        '''
        # データの型チェック
        check_input(X, y)
        if X_val is not None and y_val is not None:
            check_input(X_val, y_val)  
        
        if len(hyperparms) == 0:
            hyperparms = copy.deepcopy(self.hyperparms)

        loss_save = pd.DataFrame([
            loss_list for loss_list in self.fit_yield(X, y, X_val, y_val, hyperparms)])
        if X_val is None and y_val is None:
            loss_save.columns = ["train"]
        else:
            loss_save.columns = ["train", "val"]

        self.loss_save = loss_save
        
        if hyperparms["layer_dropout"] > 0 and hyperparms["network_type"]=="onc":
            self.retrain_onc_convert_ht(X, y, hyperparms)

        if hyperparms["best_params"] and X_val is not None and y_val is not None:
            self.model.load_state_dict(copy.deepcopy(self.best_params))
        
    def retrain_onc_convert_ht(self, X, y, hyperparms):
        """ドロップアウトを適用した場合，直交変換行列の値のみを全データを使用して学習する
        (直交変換行列のみを学習し，他のパラメータは更新しない)        

        Parameters
        ----------
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series (MultiIndex("Date", "stock"))
            リターンデータ(銘柄×時点,) 
        hyperparms : Dict[Any]
            ハイパーパラメータの辞書

        Returns
        -------
        None
        """
        X = scale_xs(X)
        torch.manual_seed(hyperparms['random_state'])
        batch_size = hyperparms["batch_size"]
        loader = XSDataLoader(X, y, batch_size)
        self.model.eval()
        for X_t, y_t, universe_index in loader:
            hidden_weight = self.model.call_hidden_weight(
                X_t, universe_index, rt=y_t, mode="train")
        
        # self._hidden_weight = hidden_weight
        
    def predict(self, X, is_add_hidden_weight=False):
        '''ポートフォリオのウェイトを算出

        Parameters
        ----------        
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト(予測)期間における特徴量データ(銘柄×時点, 特徴量)        
        is_add_hidden_weight : bool
            合成ポートフォリオ(L-1層のLSポートフォリオ)のウェイトもあわせて出力する場合はTrue
            -> この場合は出力のweightはpd.DataFrameとなり，列方向に合成ポートフォリオのウェイトが追加される
        
        Return
        ------
        weight : pd.Series or pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト行列(銘柄*各時点)
            is_add_hidden_weight = Trueの場合，pd.DataFrameで出力
        '''
        date_test = sorted(X.index.get_level_values("Date").unique())        
        universe_test_index = get_universe_slice_list(X.index, date_test)
        return self.predict_forward(X, universe_test_index, is_add_hidden_weight)

    def predict_hidden(self, X, is_add_hidden_weight=False):
        '''ポートフォリオのウェイトを算出

        Parameters
        ----------        
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト(予測)期間における特徴量データ(銘柄×時点, 特徴量)        
        is_add_hidden_weight : bool
            合成ポートフォリオ(L-1層のLSポートフォリオ)のウェイトもあわせて出力する場合はTrue
            -> この場合は出力のweightはpd.DataFrameとなり，列方向に合成ポートフォリオのウェイトが追加される
        
        Return
        ------
        hidden_weight : np.array
            L-1層におけるLSポートフォリオのウェイト.(銘柄*時点,)
            is_add_hidden_weight = Trueの場合，pd.DataFrameで出力
        '''
        date_index = sorted(X.index.get_level_values("Date").unique())        
        universe_index = get_universe_slice_list(X.index, date_index)
        check_input(X, y=None)        
        X_torch = make_torch_scaled_from_df(X)
        
        self.model.eval()
        hidden_weight = self.model.call_hidden_weight(
            X_torch, universe_index, rt=None, mode="predict").detach().numpy().copy()
        
        return hidden_weight
    
    def predict_under_leverage(self, hidden_weight_current, hidden_weight_past, rt_past, rt_test, turnover, target_risk):
        '''レバレッジ制約のもとでポートフォリオのウェイトを算出

        Parameters
        ----------        
        hidden_weight_current : np.array
            特徴量データ(銘柄×時点, 特徴量)
        hidden_weight_past : np.array
            
        rt_test: pd.Series (MultiIndex("Date", "stock"))
            テスト期間における銘柄リターン            
        rt_past: pd.Series (MultiIndex("Date", "stock"))
            訓練期間における銘柄リターン            
        turnover : float, default: None
            売買回転率の上限制約．Noneの場合，self.hyperparamsに与えられたturnoverを参照
        target_risk : float, default: None
            リスク制約の上限値            
        
        Return
        ------
        weight : pd.Series or pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト行列(銘柄*各時点)
            is_add_hidden_weight = Trueの場合，pd.DataFrameで出力
        theta : pd.Series
            各企業特性合成ポートフォリオにおけるエクスポージャー
        status_all : list
            最適化が成功したかどうかを格納したリスト        
        
        Notes
        -----
        * otimizer.weight_under_leverageが実行される際にpulpパッケージがインストールされるため，
        pulpをインストールしていなかった場合，本メソッドを実行時にエラーとなる
        '''
        date_test = sorted(X.index.get_level_values("Date").unique())        
        universe_test_index = get_universe_slice_list(X.index, date_test)        
        check_input(X, rt_test)
        check_input(X_past, rt_past)
        X_torch = make_torch_scaled_from_df(X)
        date_past = sorted(rt_past.index.get_level_values("Date").unique())
        universe_past_index = get_universe_slice_list(rt_past.index, date_past) 
        X_torch_past = make_torch_scaled_from_df(X_past)
        
        self.model.eval()
        hidden_weight_current = self.model.call_hidden_weight(
            X_torch, universe_test_index, rt=None, mode="predict").detach().numpy().copy()
        hidden_weight_past = self.model.call_hidden_weight(
            X_torch_past, universe_past_index, rt=None, mode="predict").detach().numpy().copy()
        
        weight, theta, status_all = weight_under_leverage(
            hidden_weight_current, hidden_weight_past, rt_past, rt_test, turnover, target_risk
            )
            
        return weight, theta, status_all

    def predict_forward(self, X, universe_test_index, is_add_hidden_weight):
        """ネットワークの順伝搬の結果をもとにポートフォリオのウェイトを算出

        Parameters
        ----------
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)        
        universe_test_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]  
        is_add_hidden_weight : bool
            合成ポートフォリオ(L-1層のLSポートフォリオ)のウェイトもあわせて出力する場合はTrue
            -> この場合は出力のweightはpd.DataFrameとなり，列方向に合成ポートフォリオのウェイトが追加される

        Returns
        -------
        weight : pd.Series or pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト行列(銘柄*各時点)
            is_add_hidden_weight = Trueの場合，pd.DataFrameで出力
        """
        check_input(X, y=None)        
        X_torch = make_torch_scaled_from_df(X)
        self.model.eval()
        weight_add = self.model.forward(
            X_torch, universe_test_index, rt=None, mode="predict").detach().numpy().copy()
        
        weight_add = pd.Series(weight_add, index=X.index)
        weight_bench = weight_add.groupby("Date").apply(lambda x:(1/x.count()))
        weight = weight_bench + weight_add
        
        if is_add_hidden_weight:
            hidden_weight_current = self.model.call_hidden_weight(
                X_torch, universe_test_index, rt=None, mode="predict").detach().numpy().copy()                
            weight = self.add_hidden_weight(weight, hidden_weight_current)
            
        return weight

    def add_hidden_weight(self, weight, hidden_weight_current):
        """合成ポートフォリオ(L-1層のLSポートフォリオ)のウェイトをweightに結合

        Parameters
        ----------
        weight : pd.Series
            ポートフォリオのウェイト行列(銘柄*各時点)
        hidden_scaled : np.arary
            基準化後の合成ポートフォリオ(L-1層のポートフォリオ)のウェイト
            (バッチ(時点)*(各時点の)銘柄, 合成ポートフォリオの数)

        Returns
        -------
        weight : pd.DataFrame
            ポートフォリオのウェイト行列(銘柄*各時点, [ポートフォリオのウェイト, 各合成ポートフォリオのウェイト])
        """
        hidden_weight_current = pd.DataFrame(hidden_weight_current)
        hidden_weight_current.index = weight.index
        hidden_weight_current.columns = ["hidden_{}".format(i) for i in range(hidden_weight_current.shape[1])]
        weight.name = "all"
        weight = pd.concat([weight, hidden_weight_current], axis=1)
        
        return weight
        