import copy
import pickle
import os
import pandas as pd
from ..utils.decorater import mystopwatch
from ..utils.util import make_foldset
from .model_utility import UtilityTrader
from .dnn_regressor import Regressor


class ModelLearner:
    """モデルの学習を行うクラス
    
    Paramters
    ---------        
    hyperparms : Dict[str: Any]
    ハイパーパラメータの辞書
    factor_list : list
        使用するファクターのリスト
    """

    def __init__(self, hyperparms, factor_list):
        self.hyperparms = hyperparms
        self.factor_list = factor_list

    def call_estimator_init(self, model_name: str):
        """推定モデルの呼び出し

        Parameters
        ----------
        model_name : str
            モデルの名称

        Returns
        -------
        estimator
            推定モデル(学習前モデル)
        """
        estimator = {
            "UtilityTrader": UtilityTrader,
            "Regressor": Regressor,
        }[model_name](self.hyperparms, self.factor_list)

        return estimator

    def make_foldset(
            self, X: pd.DataFrame, y: pd.Series, fold: int, embargo: int):
        """Kfoldのデータセットを作成
        see also util.make_foldset

        Parameters
        ----------
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series (MultiIndex("Date", "stock"))
            リターンデータ(銘柄×時点,)
        fold : int
            作成するホールドの分割数（fold数）
        embargo : int
            テスト期間より後の時点に作成される訓練データに設ける猶予期間

        Yields
        ------
            ホールドごとに訓練データセット(特徴量のデータセット，リターンデータ),
            バリデーションデータセット(特徴量のデータセット，リターンデータ)
        """
        return make_foldset(X, y, fold, embargo)

    @mystopwatch
    def learn_all_term(self, estimator):
        pass

    @mystopwatch
    def learn(self, estimator, X, y, X_val=None, y_val=None):
        """パラメータを学習

        self.hyperparms["cv_method"] == "PseudoPurgedKfold"
        -> learn_allfold
        self.hyperparms["cv_method"] == None
        -> learn_onefold

        Parameters
        ----------
        estimator : function(pytorch module)
            モデル.
        X_train : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(時点×銘柄, 特徴量)
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点×銘柄,)

        * hyperparms["cv_method"] == Noneの場合，以下の引数として設定可能
        X_val : pd.DataFrame (MultiIndex("Date", "stock")) | None
            バリデーション期間における特徴量データ(時点, 特徴量)
            -> Noneの場合，バリデーションデータにおける評価値を計算しない            
        y_val : pd.Series (MultiIndex("Date", "stock")) | None
            バリデーション期間における被説明変数(時点×銘柄,)
            -> Noneの場合，バリデーションデータにおける評価値を計算しない

        Raises
        ------
        * PseudoPurgedKfoldを使用する場合，バリデーションデータ(X_val, y_val)はNoneとする
        """
        if self.hyperparms["cv_method"] == "PseudoPurgedKfold":
            assert X_val is None and y_val is None, (
                "PseudoPurgedKfoldを使用する場合，バリデーションデータはNoneとする"
            )
            cv_method = self.hyperparms["cv_method"]
            estimators = self.learn_allfold(
                estimator, X, y, self.hyperparms[cv_method]["fold"],
                self.hyperparms[cv_method]["embargo"])
        elif (self.hyperparms["cv_method"] is None or
              self.hyperparms["cv_method"] == "None"):
            estimators = self.learn_onefold(estimator, X, y, X_val, y_val)

        return estimators

    def learn_allfold(self, estimator, X, y, fold: int, embargo: int):
        """Kfoldのデータセットごとにパラメータを推定し，各ホールドの推定結果を辞書で記録し，返す

        Parameters
        ----------
        estimator : function(pytorch module)
            モデル.
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series (MultiIndex("Date", "stock"))
            リターンデータ(銘柄×時点,)
        fold : int
            作成するホールドの分割数（fold数）
        embargo : int
            テスト期間より後の時点に作成される訓練データに設ける猶予期間
            
        Returns
        -------
        estimators : Dict[str: function(pytorch module)]
            各ホールドのデータセットで学習した推定モデル
        """
        estimators = {}

        for fold_num, (X_train, y_train, X_val, y_val) in self.make_foldset(
                X, y, fold, embargo):
            print("fold {} / {}".format(fold_num + 1, fold))
            estimator_ = copy.deepcopy(estimator)
            estimators[fold_num] = self.learn_onefold(
                estimator_, X_train, y_train, X_val, y_val)

        return estimators

    @mystopwatch
    def learn_onefold(
            self,
            estimator,
            X_train,
            y_train,
            X_val=None,
            y_val=None,
            ):
        """1foldにおけるパラメータを学習

        Parameters
        ----------
        estimator : function(pytorch module)
            モデル.
        X_train : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(時点×銘柄, 特徴量)
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点×銘柄,)
        X_val : pd.DataFrame (MultiIndex("Date", "stock")) | None
            バリデーション期間における特徴量データ(時点, 特徴量)
            -> Noneの場合，バリデーションデータにおける評価値を計算しない            
        y_val : pd.Series (MultiIndex("Date", "stock")) | None
            バリデーション期間における被説明変数(時点×銘柄,)
            -> Noneの場合，バリデーションデータにおける評価値を計算しない

        Returns
        -------
        estimator : function(pytorch module)
            学習済みモデル.

        Notes
        -----
        * is_tuneがTrueの場合，optunaを用いてハイパーパラメータを探索\n
        -> さらにis_pruneがTrueの場合，枝刈りアルゴリズムを使用してチューニングを実施
        -> 最終的に選ばれたハイパーパラメータを用いて再度学習を実施
        """
        start_date = y_train.index.get_level_values("Date").min()
        end_date = y_train.index.get_level_values("Date").max()
        if X_val is not None and y_val is not None:
            start_date = min(
                start_date, y_val.index.get_level_values("Date").min())
            end_date = max(
                end_date, y_val.index.get_level_values("Date").max())

        if self.hyperparms["is_tune"] and X_val is not None and y_val is not None:
            if self.hyperparms["is_prune"]:
                # 枝刈りアルゴリズムを使用
                estimator.tune_prune(
                    X_train,
                    y_train,
                    X_val,
                    y_val,
                )
            else:
                # 枝刈りアルゴリズムを使用しない
                estimator.tune(
                    X_train,
                    y_train,
                    X_val,
                    y_val,
                )
            self.hyperparms = estimator.update_hyperparams()

        estimator.fit(X_train, y_train, X_val, y_val)
        estimator.learning_date_ = (start_date, end_date)

        return estimator

    def save_model(self, estimators: dict, path: str = None):
        """学習済みモデルのpkl形式で保存

        Parameters
        ----------
        estimators : dict
            学習済みモデル
        path : str, optional | None
            出力先の絶対パス, デフォルトではカレントディレクトリを参照

        Notes
        -----
        * hydra使用した場合, cwdはoutputs/以下の日付ディレクトリとなることに注意
        """
        if path is None:
            file_path = 'estimators.pkl'
        else:
            file_path = os.path.join(path, 'estimators.pkl')

        with open(file_path, 'wb') as f:
            pickle.dump(estimators, f)

    def summarize_estimators_loss(self, estimators):
        """estimatorsの各ホールドのlossをデータフレームに集約する

        Parameters
        ----------
        estimators : Dict
            学習済みモデルが格納された辞書.

        Returns
        -------
        loss_save : pd.DataFrame
            各ホールドの損失関数値をまとめたデータフレーム.
        """
        if isinstance(estimators, dict):            
            loss_save = []
            for fold_, estimator_ in estimators.items():
                temp = estimator_.loss_save.copy(deep=True)
                temp.columns = ["{}(fold{})".format(i, fold_) for i in temp.columns]
                loss_save.append(temp)
            loss_save = pd.concat(loss_save, axis=1)
        else:
            loss_save = estimators.loss_save.copy(deep=True)
        
        return loss_save