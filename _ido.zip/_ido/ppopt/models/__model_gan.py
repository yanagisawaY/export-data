import copy
import numpy as np
import torch
from torch import nn
from ..utils.loader import XSDataLoader
from .utility_net import UtilityNet

from base_estimator import ModelBase
from ..utils.processor import make_torch_scaled_xs, scale_xs
from ..utils.optimizer import weight_under_leverage
from ..utils.util import convert_numpy, base_port_return


class SdfLoss(nn.Module):
    def __init__(self, leverage, stock_time_count):
        super().__init__()
        self.leverage = leverage
        self.stock_time_count = stock_time_count
        self.time_num = stock_time_count.shape[0]
        self.stock_num = stock_time_count.shape[1]
        
    def calc_return(self, rt, w, weight_add):
        port_weight = torch.ones(w.size())/w.shape[1] + weight_add
        port_rt = torch.einsum('nm,nm->n', rt, port_weight)
        
        return port_rt
        
    def forward(self, rt, w, g):
        # GMM        
        weight_add = w/w.shape[1]
        port_rt = self.calc_return(rt, w, weight_add)
        sdf_ = (1 - port_rt).unsqueeze(1).tile(self.stock_num)

        # モーメントの次元を追加
        sdf = sdf_.unsqueeze(2).repeat(1, 1, g.shape[2])
        stock_time_count = self.stock_time_count.unsqueeze(2).repeat(1, 1, g.shape[2])
        rt_tiled = rt.unsqueeze(2).repeat(1, 1, g.shape[2])

        # Our moment conditions are averaged over the sample of all instrumented stocks
        #   - > Deep Learining in Asset Pricing chapter B:Generative Adversarial Methods of Moments
        alpha = sdf*rt_tiled*g
        
        utility_ = torch.sum((stock_time_count*torch.sum(alpha, 0))**2)
        utility = torch.mean(utility_/(self.time_num*stock_time_count))
        
        return utility


class GanTrader(ModelBase):
    '''DNNの学習を行うクラス
    '''

    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        super().__init__(hyperparms)
        self.factor_list = self.hyperparms["factor_list"]
        self.model = []

    def _fit(self, X, y, X_val, y_val, hyperparms={}):
        '''

        Parameters
        ----------        
        X : pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pandas.DataFrame
            被説明変数(時点,銘柄)
        X_val : pd.DataFrame
            バリデーションデータにおける特徴量データ(銘柄×時点, 特徴量)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        y_val : pd.DataFrame
            バリデーションデータにおける被説明変数(時点,銘柄)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        hyperparms : dict
            ハイパーパラメータの辞書, デフォルトではclassが保持するhyperparamsを参照．

        Return
        ------
        model : 
            学習済みモデル
        '''
        if len(hyperparms) == 0:
            hyperparms = copy.deepcopy(self.hyperparms)
        
        stock_list = list(y.columns)
        X = scale_xs(X, self.factor_list)
        torch.manual_seed(hyperparms['random_state'])
        batch_size = min(hyperparms["batch_size"], y.shape[0])
        loader = XSDataLoader(X, y, batch_size, stock_list,
                              self.factor_list, is_t_1=hyperparms["is_cost"])

        if X_val is not None:
            X_val = scale_xs(X_val, self.factor_list)
            assert hyperparms["is_cost"] == False, "current version is only supported False"
            stock_list = list(y_val.columns)
            loader_val = XSDataLoader(X_val, y_val, y_val.shape[0], stock_list,
                                      self.factor_list, is_t_1=hyperparms["is_cost"])
            is_val = True
        else:
            is_val = False

        # 早期停止条件用の設定
        loss_val_min = 10000**100
        patience_count = 0
        upper_patience_count = hyperparms["upper_patience_count"]
        min_epoch = hyperparms["min_epoch"]

        input_num = len(self.factor_list)
        model = UtilityNet(hyperparms, input_num)
        optimizer = torch.optim.Adam(
            model.parameters(), lr=hyperparms['lr'])
        criterion = UtilityLoss(
            hyperparms["utility_type"],
            hyperparms["gamma"])

        loss_save = []
        for epoch in range(hyperparms['epoch']):
            for X_t, y_t in loader:
                model.train()
                stock_nums = (y_t != 0).sum(1)
                weight_t = model.forward(X_t, stock_nums, rt=y_t, mode="train")
                rt_active = torch.einsum('tn,tn->tn', weight_t, y_t).sum(1)
                rt_bench = base_port_return(y_t)
                port_rt = rt_bench + rt_active
                loss = - criterion(port_rt)

                # L2-normの正則化項を追加
                l2 = torch.tensor(0., requires_grad=True)
                for w in model.parameters():
                    l2 = l2 + hyperparms["l2_norm"]*torch.norm(w)**2
                loss = loss + l2

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            if is_val:
                with torch.no_grad():
                    model.eval()
                    for X_val, y_val in loader_val:
                        stock_nums = (y_val != 0).sum(1)
                        weight_val = model.forward(
                            X_val, stock_nums, rt=y_val, mode="predict")
                        rt_active = torch.einsum(
                            'tn,tn->tn', weight_val, y_val).sum(1)
                        rt_bench = base_port_return(y_val)
                        port_rt = rt_bench + rt_active
                        loss_val = - criterion(port_rt).item()
                    if loss_val_min > loss_val:
                        # バリデーションデータにおける評価値が最も良いパラメータを保持
                        best_params = copy.deepcopy(model.state_dict())
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1
                    loss_save += [[loss.item(), loss_val]]

                    if patience_count > upper_patience_count and epoch > min_epoch:
                        print(
                            f"[BREAK] {epoch+1}/{hyperparms['epoch']} train {- round(loss.item(), 4)} val {- round(loss_val, 4)}")
                        break

                print(
                    f"{epoch+1}/{hyperparms['epoch']} train {- round(loss.item(), 4)} val {- round(loss_val, 4)}")
            else:
                loss_save += [-loss.item()]
                print(
                    f"{epoch+1}/{hyperparms['epoch']} train {- round(loss.item(), 4)}")
            
        if hyperparms["best_params"]:
            model.load_state_dict(copy.deepcopy(best_params))

        return model, loss_save

    def fit(self, X, y, X_val=None, y_val=None):
        '''モデルのパラメータを学習

        Parameters
        ----------        
        X : pd.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.DataFrame
            被説明変数(時点,銘柄)
        X_val : pd.DataFrame
            バリデーションデータにおける特徴量データ(銘柄×時点, 特徴量)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        y_val : pd.DataFrame
            バリデーションデータにおける被説明変数(時点,銘柄)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない            
        '''
        self.model, self.loss_save = self._fit(X, y, X_val, y_val)

    def predict(self, X, X_past=[], rt_train=[], rt_test=[], turnover=None, target_risk=None):
        '''

        Parameters
        ----------        
        X : np.array or pandas.DataFrame
            テスト(予測)期間における特徴量データ(銘柄×時点, 特徴量)        
        X_past: np.array
            訓練期間における特長特徴量データ
        rt_train: np.array
            訓練期間における銘柄リターン            
        rt_test: np.array
            テスト期間における銘柄リターン
        weight : np.dnarray
            テスト期間におけるポートフォリオのウェイト
        turnover : float, default: None
            売買回転率の上限制約．Noneの場合，self.hyperparamsに与えられたturnoverを参照
        target_risk : float, default: None
            リスク制約の上限値            
        '''
        stock_list = sorted(X["stock"].unique())
        if len(X_past) > 0:
            X_past = make_torch_scaled_xs(
                X_past, self.factor_list, stock_list)
            rt_train = convert_numpy(rt_train)
            rt_test = convert_numpy(rt_test)
            self.model.eval()
            hidden_weight_current = self.model.call_hidden_weight(
                X, rt=None, mode="predict").detach().numpy().copy()
            hidden_weight_past = self.model.call_hidden_weight(
                X_past, rt=None, mode="predict").detach().numpy().copy()
            if turnover is None:
                turnover = self.hyperparms["turnover"]
            if target_risk is None:
                target_risk = self.hyperparms["target_risk"]

            return weight_under_leverage(
                hidden_weight_current, hidden_weight_past, rt_train, rt_test, stock_list, turnover, target_risk
            )
        else:
            X = make_torch_scaled_xs(X, self.factor_list, stock_list)
            self.model.eval()
            stock_nums = torch.tensor((rt_test != 0).sum(1).values).float()
            weight_add = self.model.forward(
                X, stock_nums, rt=None, mode="predict").detach().numpy().copy()
            weight_bench = np.ones(weight_add.shape)/weight_add.shape[1]
            weight = weight_bench + weight_add

            return weight