import datetime as dt
import pandas as pd
import numpy as np
from tqdm import tqdm

def convert_pandas_df(
        data_type : str,
        PATH_DATA : str):
    assert data_type == "train" or data_type == "valid" or data_type == "test"
    print(f"loading...{data_type}")
    
    df_chr = np.load(PATH_DATA + "/char/Char_" + data_type + ".npz")    
    ### Notes
    # df_chr["data"]     : (時点, 銘柄, 特性) ランク処理後の特性データ
    #                    : 欠損値には-99.99が格納
    #                    : train (240, 3686, 47)
    # df_chr["date"]     : (時点) 時点データ
    # df_chr["variable"] : (特性) 特性名称
    
    stock_name = [f"stock{i}" for i in range(df_chr["data"].shape[1])]
    
    # 0番目の要素にリターンデータが格納
    RETURN_INDEX = 0
    rt = pd.DataFrame(
        df_chr["data"][:, :, RETURN_INDEX], 
        index=df_chr["date"], 
        columns=stock_name,
        )
    is_drop = rt!=-99.99
    
    df = []
    variable_names = df_chr["variable"]
    for time_i, yymm in tqdm(enumerate(df_chr["date"])):
        df_temp = pd.DataFrame(
            df_chr["data"][time_i, :, :],
            index=stock_name,
            columns=variable_names
            )
        df_temp["Date"] = dt.datetime(
            int(str(yymm)[:4]),
            int(str(yymm)[4:6]),
            int(str(yymm)[6:8])
            )
        df_temp = df_temp.reset_index().rename({"index": "stock"}, axis='columns')
        is_drop = df_temp["ret"]!=-99.99
        df_temp = df_temp[is_drop]
        df.append(df_temp)
    
    df = pd.concat(df)
    
    print("writing...")
    df.to_csv(PATH_DATA + "/" + data_type + ".csv.gz")


if __name__ == "__main__":
    PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"
    for data_type in ["test"]:# ["train", "valid"]:
        convert_pandas_df(data_type, PATH_DATA)