import numpy as np
import pandas as pd
import torch
from .util import get_universe_slice_list
        

def scale_xs(X: pd.DataFrame):
    """データの標準化

    * クロスセクション方向にランク化 → 平均0，標準偏差1に標準化

    * 欠損値はクロスセクション方向に中央値で補完し，その後標準化を実施

    Parameters
    ----------
    X : pd.DataFrame (MultiIndex("Date", "stock"))
        標準化前の特徴量データ(銘柄×時点, 特徴量).

    Returns
    -------
    X_scale : pd.DataFrame (MultiIndex("Date", "stock"))
        標準化後の特徴量データ(銘柄×時点, 特徴量).

    References
    ---------
    .. [1] Brandt, M. W., P. Santa-Clara, and R. Valkanov (2009) “Parametric Portfolio Policies: 
        Exploiting Characteristics in the Cross-Section of Equity Returns,” Review of Financial Studies, 22, 3411–3447.
    """
    date_indexes = sorted(X.index.get_level_values("Date").unique())
    for i in X.dtypes:
        assert i == float
    universet_index = get_universe_slice_list(X.index, date_indexes)

    X_scale = X.copy(deep=True)
    for date_index in universet_index:
        X_date = X[date_index].fillna(
            X[date_index].median()).rank(axis=1, pct=True)
        X_scale[date_index] = (X_date - np.mean(X_date.values, axis=1,
                               keepdims=True)) / np.std(X_date.values, axis=1, keepdims=True)

    return X_scale

def make_torch_scaled_from_df(X):
    """もとのクロスセクションデータの標準化を実施，torch.tensorかつfloat型変換

    Parameters
    ----------
    X : pd.DataFrame (MultiIndex("Date", "stock"))
        標準化前の特徴量データ(銘柄×時点, 特徴量).

    Returns
    -------
    X_torch : torch.tensor
        標準化後，torch.tensor型に変換された特徴量データ(銘柄×時点, 特徴量).
    
    Notes
    -----
    * models.model_utility.UtilityTrader.predict_under_leverageや
    models.model_utility.UtilityTrader.predict_forward時でのデータの加工として本関数を使用
    """
    X_torch = torch.tensor(scale_xs(X).values).float()
    
    return X_torch