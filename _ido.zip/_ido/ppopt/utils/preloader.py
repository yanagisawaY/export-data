import pandas as pd
import os

from .decorater import mystopwatch


class PreLoader:
    def __init__(self, path_data):
        self.path_data = path_data

    def call_data(self):
        df = pd.read_csv(
            os.path.join(self.path_data, "test.csv.gz"),
            index_col=0)

        return df

    def make_explain_target(self, df, is_extract):
        df_extracted = df.loc[is_extract, :]
        df_extracted = df_extracted.set_index(["Date", "stock"])
        y = df_extracted["ret"]
        is_drop = y == 0
        y = y.loc[~is_drop]
        X = df_extracted.loc[~is_drop, :].drop("ret", axis=1)

        return X, y

    def _make_dataset(self, df, train_start, train_end, test_start, test_end):
        index_date = pd.to_datetime(df["Date"].copy(deep=True))
        is_train = (index_date >= pd.to_datetime(str(train_start))) & (
            index_date <= pd.to_datetime(str(train_end)))
        X_train, y_train = self.make_explain_target(df, is_extract=is_train)
        is_test = (index_date >= pd.to_datetime(str(test_start))) & (
            index_date <= pd.to_datetime(str(test_end)))
        X_test, y_test = self.make_explain_target(
            df, is_extract=is_test)
        factor_list = [
            i for i in X_train.columns if i not in ["stock", "Date"]]

        return X_train, y_train, X_test, y_test, factor_list

    @mystopwatch
    def make_dataset(
            self, train_start: int, train_end: int, test_start: int, test_end: int):
        """データセットの呼び出し
        """
        df = self.call_data()
        return self._make_dataset(
            df, train_start, train_end, test_start, test_end)
