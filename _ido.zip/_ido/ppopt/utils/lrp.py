from matplotlib.pyplot import axis
import numpy as np
import pandas as pd
from sklearn import linear_model
from .processor import make_torch_scaled_from_df, scale_xs
from .util import get_universe_slice_list


class LRP:
    """ポートフォリオのウェイトに対し，LRP(Layer-wise relevance propagation)により各ファクターの貢献度を算出
    
    Notes
    -----
    * simple-LRP法によりLRPを算出
    * メモリ消費節約のため，一度に参照するデータ数制限(self.BACTH_FOR_MEMORY_SAFETY)を設けて貢献度を算出
    -> 層l+1ユニットjから層lユニットiの伝播を各時点で銘柄で保持すると，中間層の設定によってはメモリ消費が膨大になることを回避
    (see also get_contribution_backward)
    
    References
    ----------
    .. [1] Bach, Sebastian, et al. "On pixel-wise explanations for non-linear classifier decisions by layer-wise relevance propagation." PloS one 10.7 (2015): e0130140.
    """   

    def __init__(
        self,
        estimator,
        factor_list,
        ):
        self.model = estimator.model
        self.factor_list = factor_list

    def get_unit_params(self):
        """ネットワークの中間層におけるパラメータを取得

        Return
        ------
        lrp_params: Dict[str: np.array]
            ネットワークの中間層におけるパラメータ
        """
        modules_list = dict(self.model.named_modules())
        lrp_params = {}
        layer_num = 0
        for name_, params_ in self.model.named_parameters():
            if "last" not in name_:
                temp = name_.split(".weight")[0].split(".bias")[0]
                module_ = modules_list[temp]
                if "Linear" in str(module_) and ".weight" in name_:
                    layer_num += 1
                    lrp_params.update({layer_num: params_.detach().numpy().copy()})

        return lrp_params

    def get_unit_value(self, X_torch, universe_index):
        """各層における各ユニットの出力値を取得

        Parameters
        ----------
        X_torch : torch.tensor
            標準化後，torch.tensor型に変換された特徴量データ(銘柄×時点, 特徴量).
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]             
    
        Returns
        -------
        zj_units : Dict[str: np.array]
            層l+1ユニットjの出力値 (各層における各ユニットの出力値)
        """
        modules_dict = dict(self.model.named_modules())
        modules_name = [i for i in list(
            modules_dict.keys()) if 'mpn.full.' in i]
        zj_units = {}
        out = X_torch
        layer_num = 0
        zj_units.update({layer_num: out.numpy().copy()})
        for i, module_name in enumerate(modules_name):
            module = modules_dict[module_name]
            if "Dropout" not in str(module) and "XSNorm()" not in str(module):
                # Dropoutは計算しない
                out = module(out)
            elif "XSnorm()" in str(module):
                out = module(out, universe_index)

            if "Linear(" in str(module):
                # 出力層の値を取得
                # Linear層の出力値を取得
                # ->層lユニットiから層l+1ユニットjへ順伝搬する値を計算する際に使用
                layer_num += 1
                zj_units.update({layer_num: out.detach().numpy().copy()})
        
        return zj_units

    def get_unit_forward(self, zj_units, lrp_params, batch_slice):
        """層lユニットiから層l+1ユニットjへ順伝搬する値を取得

        Parameters
        ----------
        zj_units : Dict[str: np.array]
            層l+1ユニットjの出力値 (各層における各ユニットの出力値)
        lrp_params: Dict[str: np.array]
            ネットワークの中間層におけるパラメータ
        batch_slice : slice
            参照するインデックス

        Yields
        ------
        zij_units_l : np.array[batch, i, j]
            層lユニットiから層l+1ユニットjへ順伝搬する値
            
        Notes
        -----
        * get_contribution_backwardにおけるメモリ消費節約のため，一度に参照するデータインデックスをbatch_sliceのみに絞っている        
        """
        for layer_l in reversed(range(len(lrp_params))):
            zij_units_l = np.einsum(
                'bi, ji->bij', zj_units[layer_l][batch_slice], lrp_params[layer_l+1])

            yield zij_units_l

    def get_contribution_backward(
            self, zj_units, lrp_params, contribution_j, universe_index, hidden_num):
        """層l+1ユニットjから層lユニットiへ逆伝搬する貢献度を取得

        Parameters
        ----------
        zj_units : Dict[str: np.array]
            層l+1ユニットjの出力値 (各層における各ユニットの出力値)
        lrp_params: Dict[str: np.array]
            ネットワークの中間層におけるパラメータ
        contribution_j : torch.tensor
            時点, 銘柄ごとにおける企業特性合成ポートフォリオのウェイト(時点*銘柄).
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]                         
        hidden_num : int
            隠れ層のインデックス番号
            
        Returns
        -------
        contribution_all : np.array
            時点, 銘柄ごとにおける各特徴量の貢献度(時点*銘柄, 特徴量)       
        
        Notes
        -----
        * 時点ごとにLRPを算出(メモリの節約)
        """
        contribution_all = np.zeros((
            len(contribution_j), len(self.factor_list)))

        # simple LRPを適用(LRP合計値がポートフォリオのウェイトと一致)
        epsilon = 0
        
        for universe in universe_index:            
            contribution_j_copy = contribution_j.detach().numpy().copy()[universe]
                
            for layer_num, zij_units_l in enumerate(self.get_unit_forward(zj_units, lrp_params, universe)):
                if layer_num == 0:
                    # L-1層における1ユニット(一つの企業特性合成ポートフォリオ)を参照
                    # 変数名を同一のものを使用し，メモリを節約
                    zij_units_l = np.einsum(
                        'bi, b->bi', 
                        zij_units_l[:, :, hidden_num],
                        1/((zij_units_l[:, :, hidden_num]).sum(1)
                            + epsilon*np.sign((zij_units_l[:, :, hidden_num]).sum(1))))
                                        
                    zij_units_l = np.nan_to_num(zij_units_l)
                    contribution_j_copy = np.einsum(
                        'bi, b->bi', zij_units_l, contribution_j_copy)
                else:
                    # 変数名を同一のものを使用し，メモリを節約                
                    zij_units_l = np.einsum(
                        'bij, bj->bij',
                        zij_units_l,
                        1/(zij_units_l.sum(1) + epsilon*np.sign(zij_units_l.sum(1))))
                        
                    zij_units_l = np.nan_to_num(zij_units_l)
                    contribution_j_copy = np.einsum(
                        'bij, bj->bij', zij_units_l, contribution_j_copy).sum(2).squeeze()
                   
            contribution_all[universe, :] = contribution_j_copy/(
                contribution_j_copy.shape[0]*contribution_j_copy.std())
            
        return contribution_all

    def calc_hidden_lrp(self, X_torch, hidden_weight, universe_index):
        """L-1層の1ユニットのLRP(一つの企業特性合成ポートフォリオ)を計算

        Parameters
        ----------
        X_torch : torch.tensor
            標準化後，torch.tensor型に変換された特徴量データ(銘柄×時点, 特徴量).
        hidden : torch.tensor
            基準化後の合成ポートフォリオ(L-1層のポートフォリオ)のウェイト
            (バッチ(時点)*(各時点の)銘柄, 合成ポートフォリオの数)
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]             

        Returns
        -------
        hidden_lrp : np.array
            時点, 銘柄ごとにおける各特徴量の貢献度(時点*銘柄, 特徴量, 合成ポートフォリオの数).
        
        Notes
        -----
        * oncアルゴリズムを使用する場合，最後に直交変換行列をかけ，クロスセクション方向に標準偏差が1となるよう標準化する
        """
        # 中間層におけるパラメータを抽出
        lrp_params = self.get_unit_params()
        # 各層における各ユニットの出力値
        zj_units = self.get_unit_value(X_torch, universe_index)
        
        hidden_lrp = np.zeros((X_torch.shape[0], X_torch.shape[1], hidden_weight.shape[1]))
        for hidden_num in range(hidden_weight.shape[1]):
            contribution_j = hidden_weight[:, hidden_num].detach()
            # 層l+1ユニットjから層lユニットiへ逆伝搬させて貢献度を算出
            hidden_lrp[:, :, hidden_num] = self.get_contribution_backward(
                    zj_units,
                    lrp_params,
                    contribution_j,
                    universe_index,
                    hidden_num)

        if self.model.network_type == "onc":
            hidden_lrp = np.einsum(
                'bik, kt->bit', 
                hidden_lrp, 
                self.model.convert_ht.numpy().copy()
                )
            for universe in universe_index:
                # UtilityNet.call_hidden_weightと同様に
                # クロスセクション方向に標準偏差が1となるよう標準化する
                temp = hidden_lrp[universe, :, :]
                hidden_lrp[universe, :, :] = \
                    temp/(temp.shape[0]*temp.sum(axis=1, keepdims=True).std(axis=0, keepdims=True))
                    
        return hidden_lrp
    
    def summarize_factor_lrp(self, X, hidden_lrp_dict):
        """各企業特性合成ポートフォリオごとの貢献度をファクターごとにまとめた辞書をかえす

        Parameters
        ----------
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト(予測)期間における特徴量データ(銘柄×時点, 特徴量)        
        hidden_lrp_dict : Dict[str : pd.DataFrame (MultiIndex("Date", "stock"))]
            各時点，各銘柄における企業特性合成ポートフォリオごとの特徴量の貢献度        

        Returns
        -------
        factor_lrp : Dict[str: pd.DataFrame]
            factor_lrp[factor: dict]
            lrp: 各企業特性合成ポートフォリオごとの貢献度をファクターごとにまとめた辞書.
        factor_coef : pd.DataFrame
            LRPにより求めた貢献度をを説明変数，各特徴量の値を被説明変数として単回帰した際の回帰係数
        """
        factor_lrp = {}
        factor_coef = []
        X = scale_xs(X)
        for factor in self.factor_list:
            col_ = [factor]
            df_factor_lrp = [X[factor]]            
            x = X[factor]            
            coef = []
            for key in hidden_lrp_dict.keys():
                col_ += [key]
                y = hidden_lrp_dict[key][factor]
                df_factor_lrp.append(y)       
                clf = linear_model.LinearRegression()
                try:
                    clf.fit(x.values.reshape(-1, 1), y.values)
                except Exception as e:
                    # print(f"### [{col_}] ###\n {e}\n")
                    try:
                        clf.fit(
                            x[~y.isna()].values.reshape(-1, 1), 
                            y.dropna().values)
                    except ValueError as e:
                        print(f"### [{col_}] ###\n {e}\n")
                    
                coef.append(clf.coef_)
            
            df_factor_lrp = pd.concat(df_factor_lrp, axis=1)
            df_factor_lrp.columns = col_
            coef = pd.Series(
                np.concatenate(coef),
                index=list(hidden_lrp_dict.keys()))
            factor_lrp[factor] = df_factor_lrp
            coef.name = factor
            factor_coef.append(coef)
        
        factor_coef = pd.concat(factor_coef, axis=1)
        factor_coef.columns = self.factor_list
        
        return factor_lrp, factor_coef

    def get_hidden_lrp(self, X, universe_index):
        """各時点，各銘柄における企業特性の貢献度をLRP(Layer-wise relevance propagation)により算出

        Parameters
        ----------
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            標準化前の特徴量データ(銘柄×時点, 特徴量)
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...] 

        Returns
        -------
        hidden_lrp_dict : Dict[str : pd.DataFrame (MultiIndex("Date", "stock"))]
            各時点，各銘柄における企業特性合成ポートフォリオごとの特徴量の貢献度        
        """
        # L-1層におけるウェイトをもとに各層のユニットへの貢献度を通じて各特徴量の貢献度を求める
        X_torch = make_torch_scaled_from_df(X)
        self.model.eval()
        hidden_weight = self.model.mpn.forward(X_torch, universe_index).detach()
        hidden_lrp = self.calc_hidden_lrp(X_torch, hidden_weight, universe_index)
               
        hidden_lrp_dict = {}
        for hidden_num in range(hidden_lrp.shape[2]):
            key_ = "hidden_{}".format(hidden_num)
            feature_lrp = pd.DataFrame(
                hidden_lrp[:, :, hidden_num],
                columns=self.factor_list)
            feature_lrp.index = X.index
            hidden_lrp_dict[key_] = feature_lrp
            
        return hidden_lrp_dict

    def get_port_hidden_lrp(self, hidden_lrp_dict):
        """企業特性合成ポートフォリオのLRPの結果を算出(各時点におけるLRPの合計値を特徴量ごとに算出)

        Parameters
        ----------
        hidden_lrp_dict : Dict[str : pd.DataFrame (MultiIndex("Date", "stock"))]
            各時点，各銘柄における企業特性合成ポートフォリオごとの特徴量の貢献度        
               
        Returns
        -------
        hidden_port_lrp_dict : Dict[str : pd.DataFrame]
            各時点における企業特性合成ポートフォリオにおける特徴量の貢献度
        """
        hidden_port_lrp_dict = {}
        for hidden_name, feature_lrp in hidden_lrp_dict.items():
            hidden_port_lrp_dict[hidden_name] = feature_lrp.groupby(["Date"]).sum()
                    
        return hidden_port_lrp_dict

    def calc_port_lrp(self, hidden_port_lrp_dict, weight_active=None):
        """ポートフォリオ全体のLRPの結果を算出

        Parameters
        ----------
        hidden_lrp_dict : Dict[str : pd.DataFrame]
            各時点，各銘柄における企業特性合成ポートフォリオごとの特徴量の貢献度        
        weight_active : pd.DataFrame
            各時点ごとにおける企業特性合成ポートフォリオへの重みづけウェイト
            Noneの場合，ネットワークの最終層のパラメータをもとにポートフォリオ全体のLRPを算出
    
        Returns
        -------
        port_lrp_dict : Dict[str: pd.DataFrame (MultiIndex("Date", "stock"))]
            各時点のポートフォリオにおける特徴量のLRPが格納された辞書
            keyにはポートフォリオの種類が格納("all", "hidden_0", ... )            
        """
        time_num = hidden_port_lrp_dict['hidden_0'].shape[0]
        factor_num = hidden_port_lrp_dict['hidden_0'].shape[1]

        hidden_port_lrp = np.zeros((time_num, factor_num, len(hidden_port_lrp_dict)))
        for hidden_num, hidden_port_lrp_df in enumerate(hidden_port_lrp_dict.values()):
            hidden_port_lrp[:, :, hidden_num] = hidden_port_lrp_df.values
                        
        if weight_active is None:
            weight_active = self.model.last.state_dict()["weight"].numpy().copy()
            weight_active = np.repeat(weight_active, time_num, axis=0)
        elif isinstance(weight_active, pd.DataFrame):
            weight_active_array = weight_active.values
            indexes = hidden_port_lrp_df.index
            date_list = sorted(indexes.get_level_values("Date").unique())
            universe_index = get_universe_slice_list(indexes, date_list)
            weight_active = np.zeros((hidden_port_lrp.shape[0], hidden_port_lrp.shape[2]))
            for i, universe in enumerate(universe_index):
                weight_active[universe, :] = weight_active_array[i, :]
        else:
            raise ValueError("weight_activeはNoneかpd.DataFrameを入力")
        
        port_lrp = np.einsum(
            'bik, bk->bi',
            hidden_port_lrp, 
            weight_active
            )
        
        port_all_lrp = pd.DataFrame(
            port_lrp,
            index = hidden_port_lrp_df.index,
            columns=self.factor_list
            )
        port_lrp_dict = {"all": port_all_lrp}
        port_lrp_dict.update(hidden_port_lrp_dict)
        
        return port_lrp_dict
        