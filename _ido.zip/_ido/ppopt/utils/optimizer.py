import numpy as np
import pandas as pd
from .util import get_universe_slice_list


def solve_opt(
    weight_bench: np.array,
    weights_char: np.array,
    weight_hold: np.array,
    rit: np.array,
    target_risk: float,
    turnover: float,
    is_print: bool = True,
):
    """リスク制約,売買回転率制約,空売り禁止制約のもとでアクティブリターンが最大となるポートフォリオのウェイトを算出

    Parameters
    ----------
    weight_bench : np.array
        リバランス時点におけるベンチマークポートフォリオのウェイト (銘柄数)
    weights_char : list
        企業特性合成ポートフォリオのウェイト [(合成ポートフォリオの数, t時点の銘柄数) for t in range(時点)]
    weight_hold : np.array
        リバランス時点における保有ポートフォリオのウェイト(銘柄数)
    rit : list
        各銘柄のリターン [(t時点の銘柄数) for t in range(時点)]
    target_risk : float
        リスク制約の上限値
    turnover : float
        売買回転率の上限
    is_print : bool
        最適化結果のプリント(任意設定)

    Return
    ------
    weight : np.array
        各資産へのウェイト
    theta : list
        企業特性合成ポートフォリオへのウェイト
    is_status : bool
        最適解が求まった場合はTrueを返す

    Notes
    -----
    * 線形計画法により定式化

    * リスクは，ベンチマークリターンを下回るダウンサイドリスクとして定義

    * 時点ごとにユニバースに含まれる銘柄数が異なる場合にも対応

    References
    ----------
    .. [1] https://github.com/coin-or/pulp
    """
    try:
        import pulp
    except ModuleNotFoundError:
        print(
            "レバレッジ制約のもとでの最適化を実施する場合，"
            + "pulpパッケージのインストールが必要です")

    stock_num = len(weight_bench)
    T = len(rit)
    K = weights_char[0].shape[0]
    stock_num_list = [rit[t].shape[0] for t in range(T)]
    stock_num_list.append(stock_num)
    problem = pulp.LpProblem('ActiveOpt', pulp.LpMaximize)

    # 決定変数
    theta = [pulp.LpVariable(name='theta_{}'.format(
        k), cat="Continuous") for k in range(K)]
    # 補助変数
    yt = [pulp.LpVariable(name='yt_{}'.format(t), lowBound=0,
                          cat="Continuous") for t in range(T)]
    dti = [pulp.LpVariable(name='dti_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]
    alpha = pulp.LpVariable(name='alpha', cat="Continuous")

    # 目的関数
    problem += alpha, "Objective"

    # リスク制約
    problem += pulp.lpSum([yt[t] for t in range(T)])/T <= target_risk

    # アクティブリターンからの不足分
    for t in range(T):
        problem += pulp.lpSum([(theta[k]*weights_char[t][k, i])*rit[t][i]
                               for k in range(K) for i in range(stock_num_list[t])]) + yt[t] >= 0

    # 期待アクティブリターン
    sum_at = []
    for t in range(T):
        sum_at += [(theta[k]*weights_char[t][k, i])*rit[t][i]
                   for k in range(K) for i in range(stock_num_list[t])]
    problem += pulp.lpSum(sum_at)/T == alpha

    # 投資制約
    # リバランス時点の売買回転率上限制約
    problem += pulp.lpSum([dti[i]
                          for i in range(stock_num_list[T])]) <= turnover
    for i in range(stock_num):
        # # リバランス時点の空売り禁止制約
        problem += weight_bench[i] + pulp.lpSum(
            [theta[k]*weights_char[T][k, i] for k in range(K)]) >= 0
        # # リバランス時点の購入ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) - weight_hold[i] - dti[i] <= 0
        # リバランス時点の売却ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) - weight_hold[i] + dti[i] >= 0

    status = problem.solve()
    weight_add = [sum([pulp.value(theta[k])*weights_char[T][k, i]
                       for k in range(K)]) for i in range(stock_num)]

    weight = np.array(
        [weight_bench[i] + weight_add[i] for i in range(stock_num)])

    status = pulp.LpStatus[status]
    theta = [pulp.value(theta[k]) for k in range(K)]

    if is_print:
        turnover_ = np.sum(np.abs(weight-weight_hold))
        print(
            f'Status {status} 目的関数値 = {pulp.value(problem.objective)} turnover {round(turnover_, 3)}')

    is_status = status == "Optimal"

    return weight, theta, is_status


def weight_under_leverage(
        hidden_weight_current,
        hidden_weight_past,
        rt_past,
        rt_test,
        turnover,
        target_risk):
    """制約条件のもと各企業特性合成ポートフォリオのエクスポージャーを最適化

    Parameters
    ----------
    hidden_weight_current : np.array
        将来時点における企業特性合成ポートフォリオのウェイト
        (時点×各時点銘柄, 合成ポートフォリオの数)
    hidden_weight_past : np.array
        過去時点における企業特性合成ポートフォリオのウェイト
        (時点×各時点銘柄, 合成ポートフォリオの数)
    rt_past : pd.Series (MultiIndex("Date", "stock"))
        訓練データの銘柄リターン (時点×各時点銘柄,)
    rt_test : pd.Series (MultiIndex("Date", "stock"))
        テストデータの銘柄リターン (時点×各時点銘柄,)
    turnover : float
        売買回転率の上限制約．
    target_risk : float
        リスク制約の上限値            

    Returns
    -------
    weight : pd.Series (MultiIndex("Date", "stock"))
        最適化後のポートフォリオのウェイト
    theta : pd.Series
        各企業特性合成ポートフォリオにおけるエクスポージャー
    status_all : list
        最適化が成功したかどうかを格納したリスト

    Notes
    -----
    * 等ウェイトポートフォリオをベンチマークとして設定    
    """
    date_indexes_past = sorted(rt_past.index.get_level_values("Date").unique())
    universe_index_past = get_universe_slice_list(
        rt_past.index, date_indexes_past)
    date_indexes_test = sorted(rt_test.index.get_level_values("Date").unique())
    universe_index_test = get_universe_slice_list(
        rt_test.index, date_indexes_test)

    # 過去時点のリターン情報や隠れ層のリターン情報を用いて最適化を実施
    weights_char = [hidden_weight_past[date_index,
                                       :].T for date_index in universe_index_past]
    # 最終時点のリターンは除去
    rit = [rt_past[date_index] for date_index in universe_index_past[:-1]]
    theta = []
    weight = []
    status_all = []
    for t, date_index in enumerate(universe_index_test):
        weights_char.append(hidden_weight_current[date_index, :].T)

        # 1時点前のリターンを追加
        if t > 0:
            rit.append(rt_test[universe_index_test[t-1]])
        else:
            rit.append(rt_past[universe_index_past[-1]])

        # 等ウェイトポートフォリオをベンチマークとして設定
        stock_num = len(rt_test[date_index])
        weight_bench = np.ones(stock_num)/stock_num
        # wight_holdはもともとリバランス時点の保有ポートフォリオという位置づけだが，
        # これを等ウェイトとすることでレバレッジ制約(ベンチマークからの乖離)を織り込んだ問題として最適化
        weight_hold = np.ones(stock_num)/stock_num
        weight_t, theta_t, is_status = solve_opt(
            weight_bench,
            weights_char,
            weight_hold,
            rit,
            target_risk,
            turnover,
            is_print=True,
        )

        status_all.append(is_status)
        weight.append(weight_t)
        theta.append(pd.Series(theta_t, index=[
            "hidden_"+str(k) for k in range(len(theta_t))]))

    weight = pd.Series(np.concatenate(weight))
    weight.index = rt_test.index
    theta = pd.concat(theta, axis=1).T

    return weight, theta, status_all


def adjust_weight_under_stocklimit(weight, rt, stock_limit, mode="change"):
    """売買銘柄数の上限数を課した場合のポートフォリオのウェイトを計算

    Parameters
    ----------
    weight : pd.DataFrame (MultiIndex("Date", "stock"))
        各時点における各銘柄への投資ウェイト (時点×各時点銘柄, [all, hidden_0, ...])
    rt : pd.Series (MultiIndex("Date", "stock"))
        各時点における各銘柄のリターン (時点×各時点銘柄,)        
    stock_limit : int
        売買銘柄数の上限数.
    weight_init : np.array
        初期のリバランス時点のにおけるポートフォリオの保有ウェイト(銘柄).\n
        特に設定しない場合(デフォルト)は，等ウェイトポートフォリオを設定
    mode: str
        ウェイトの調整方法の指定（それぞれの設定ごとに，以下の点を留意）
        "change" -> 初期時点以外は前の期間に調整した投資ウェイトを使用
                    → 実際の経路に依存したバックテストを想定した場合はこちらを使用
                    → ファクターの効果が期間が経過するごとに弱まる
                    （前の期間の情報に依存して次の期間のウェイトが調整される→さらにその調整されたウェイトをもとに次の期のウェイトが調整...）
        "nonchange" -> 前の期間に調整した投資ウェイトは使用せず，weightに格納された前の期間の投資ウェイトを参照する
                    → ファクターの効果が期間は，changeほど弱まることはない
                    （前の期間の情報に依存して次の期間のウェイトが調整される→調整されたウェイトを使用せず，weightに格納された前の期のウェイトをもとに次の期のウェイトが調整...）
                    → バックテスト期間全体の経路を考慮した調整ではなくなる

    Returns
    -------
    weight_adjusted : pd.Series (MultiIndex("Date", "stock"))
        各時点における各銘柄への投資ウェイト (時点×各時点銘柄,)
    """
    if isinstance(weight, pd.DataFrame):
        assert "all" in weight.columns, (
            "weightの列名にallを含む形式"
        )
    else:
        weight = pd.DataFrame(weight, columns=["all"])
        
    assert mode == "change" or mode == "nonchange"
    date_indexes = sorted(weight.index.get_level_values("Date").unique())
    universe_index = get_universe_slice_list(weight.index, date_indexes)

    port_col = "all"
    weight_adjusted = [weight[port_col].iloc[universe_index[0]]]
    for i, (date_index, date_index_next) in enumerate(
        zip(universe_index[:-1], universe_index[1:])):
        if i == 0 or mode == "nonchange":
            weight_t_1 = weight.iloc[date_index][port_col]
        elif mode == "change":
            # 初期時点以外は前の期間に調整した投資ウェイトを使用
            weight_t_1 = weight_adjusted[i]

        weight_t_1 = weight.iloc[date_index][port_col]
        weight_t_1 = weight_t_1.droplevel("Date")
        weight_t = weight.iloc[date_index_next][port_col]
        index_t = weight_t.index
        weight_t = weight_t.droplevel("Date")

        # t-1時点のポートフォリオをt時点まで保有した際のウェイト
        universe_t_1_t = sorted(
            list(set(weight_t_1.index) & set(weight_t.index)))
        port_rt_1 = (weight_t_1.loc[universe_t_1_t] *
                     rt.iloc[date_index].droplevel("Date")[universe_t_1_t]).sum()
        weight_hold_t = weight_t_1.loc[universe_t_1_t]*(
            1 + rt.iloc[date_index].droplevel("Date")[universe_t_1_t])/(1 + port_rt_1)

        # ウェイト変化の算出
        weight_combined = pd.merge(
            weight_hold_t.reset_index(),
            weight_t.reset_index(),
            on="stock", how="outer").fillna(0)
        weight_combined = weight_combined.set_index("stock")
        weight_combined.columns = ["hold", "t"]
        weight_diff_ = weight_combined.diff(axis=1).dropna(axis=1).squeeze()
        weight_diff = weight_diff_.loc[weight_t.index]

        # 新規組み入れ銘柄の抽出
        universe_new = sorted(
            list(set(weight_t.index) - set(weight_t_1.index)))

        # リバランス銘柄の抽出
        weight_diff_nonnew = weight_diff.drop(universe_new)
        universe_rebalance = list(weight_diff_nonnew.sort_values(
            ascending=True).head(stock_limit).index)
        
        # リバランスを実施せずホールドする銘柄の抽出
        universe_hold = list(
            weight_t.index[~weight_t.index.isin(universe_new + universe_rebalance)])

        # ウェイトの更新
        # 新規組み入れ銘柄のウェイト更新
        weight_updated = np.zeros(weight_t.shape[0])
        weight_updated[weight_t.index.get_indexer(
            universe_new)] = weight_diff.loc[universe_new].values
        # リバランスを実施せずホールドする銘柄のウェイト更新
        weight_updated[weight_t.index.get_indexer(
            universe_hold)] = weight_hold_t.loc[universe_hold].values
        # リバランス銘柄のウェイト更新
        weight_res_sum = 1 - weight_diff.loc[universe_new].sum() \
            - weight_hold_t.loc[universe_hold].sum()
        weight_updated[weight_t.index.get_indexer(universe_rebalance)] = weight_res_sum * (
            weight_t[universe_rebalance]/weight_t[universe_rebalance].sum())

        weight_updated = pd.Series(weight_updated)
        weight_updated.index = index_t
        weight_adjusted.append(weight_updated)

        # assert len(weight_t) == len(weight_updated)
        # assert len(weight_updated) == (
        #     len(universe_hold) + len(universe_new) + len(universe_rebalance))

    weight_adjusted = pd.concat(weight_adjusted)
    
    return weight_adjusted
