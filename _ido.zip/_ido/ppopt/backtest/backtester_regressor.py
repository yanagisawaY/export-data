import copy
import numpy as np
import pandas as pd

from ..utils.portfolio_evaluator import PortfolioEvaluator
from ..utils.decorater import mystopwatch
from ..models.dnn_regressor import Regressor


class RegBacktester:
    def __init__(self, hyperparms, hyperparms_learn):
        super().__init__(hyperparms, hyperparms_learn)
        self.hyperparms = hyperparms

    def call_estimator_init(self, model_name: str):
        hyperparms = copy.deepcopy(self.hyperparms[model_name])
        hyperparms.update({"optuna_scope": self.hyperparms["optuna_scope"]})
        hyperparms.update({"factor_list": self.hyperparms["factor_list"]})
        estimator = {
            "dnn": Regressor,
        }[model_name](hyperparms)

        return estimator

    @mystopwatch
    def calc_weight(self, y_pred):
        '''予測リターンをもとにポートフォリオを構築

        Parameters
        ----------
        y_pred : pd.DadtaFrame
            モデルの予測リターン.

        Returns
        -------
        weight : np.array
            ポートフォリオのウェイト.
        '''
        df_pred = y_pred.pivot(index="Date", columns="stock", values="pred")
        stock_num = df_pred.shape[1]

        if self.hyperparms['portfolio_type'] == 'LongShort':
            score_long = df_pred.apply(
                lambda x: x - x.quantile(self.hyperparms['long_ratio']))
            score_short = df_pred.apply(
                lambda x: -(x - x.quantile(self.hyperparms['short_ratio'])))
            long_num = np.repeat((score_long.values >= 0).sum(1)[
                                 :, np.newaxis], stock_num, axis=1)
            short_num = np.repeat((score_short.values >= 0).sum(1)[
                                  :, np.newaxis], stock_num, axis=1)
            weight = (score_long >= 0)/long_num - \
                1*(score_short >= 0)/short_num
        elif self.hyperparms['portfolio_type'] == 'Long':
            score_long = df_pred.apply(
                lambda x: x - x.quantile(self.hyperparms['long_ratio']))
            long_num = np.repeat((score_long.values >= 0).sum(1)[
                                 :, np.newaxis], stock_num, axis=1)
            weight = (score_long >= 0)/long_num - \
                1*(score_short >= 0)/short_num
        else:
            raise ValueError(
                f'portfolio_type must be long_ratio or short_ratio. : {self.hyperparms["portfolio_type"]}')

        return weight

    def get_port_performance(self, weight_test, y_test, hyperparms_portfolio, output_name, business_days):
        '''ポートフォリオのパフォーマンス結果を算出

        Parameters
        ----------
        weight_test : dict
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        y_test : 
            各資産のリターン
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        output_name : str
            resultの列名.(任意な列名を設定可能)

        Returns
        -------
        result : dict
            パフォーマンス結果とウェイトの情報を格納した辞書
            weight_testの各valに格納されたweightに対し，以下の結果を格納
            index_portfolio : pd.DataFrame
                ポートフォリオのインデックス推移.
            performance : pd.DataFrame
                ポートフォリオのパフォーマンス結果.
        '''
        def _calc_port_perform(weight, y_port, hyperparms_portfolio, output_name, business_days):
            pe = PortfolioEvaluator(
                y_port, business_days, hyperparms_portfolio
            )
            return_portfolio = pe.calc_portfolio_return(weight)
            index_portfolio_ = pe.calc_wealth(return_portfolio)
            rt_bench = pe.calc_bench_return()
            bench_portfolio = pe.calc_wealth(rt_bench)
            performance = pe.make_peformance_result(weight, output_name)
            index_portfolio = pd.concat(
                [index_portfolio_, bench_portfolio, index_portfolio_-bench_portfolio], axis=1)
            index_portfolio.columns = [output_name, "bench", "alpha"]
            print(performance)

            return index_portfolio, performance

        index_portfolio, performance = _calc_port_perform(
            weight_test, y_test, hyperparms_portfolio, output_name, business_days)

        result = {output_name: {
            "index": index_portfolio,
            "performance": performance,
        }}

        return result
