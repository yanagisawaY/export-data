import copy
import numpy as np
import pandas as pd

from ..utils.portfolio_evaluator import PortfolioEvaluator
from ..utils.decorater import mystopwatch
from ..utils.util import check_input
from ..models.dnn_regressor import Regressor



class RegBacktester:
    def __init__(self, hyperparms):
        self.hyperparms = hyperparms

    def calc_weight(self, estimators, X, is_permission_leak=False):
        """予測リターンをもとにLSポートフォリオのウェイトを算出

        Parameters
        ----------
        estimators : Dict[int: function(torch base model)]
            学習済みモデルが格納された辞書.
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        is_permission_leak : bool
            アンサンブルさせる際にモデルのリークを許容しない場合はTrueとする
            (Xの期間中を訓練期間に含んだモデルはアンサンブルに含まれない)
                                
        Returns
        -------
        weight : pd.Series or pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト
        """
        check_input(X, y=None)
        
        if isinstance(estimators, dict):
            y_pred = self.ensemble_estimators(
                estimators, X, is_permission_leak)
        else:
            start_date = pd.to_datetime(X.index.get_level_values("Date").min())
            assert (not is_permission_leak and
                    start_date <= pd.to_datetime(estimators.learning_date_[1]))
            y_pred = estimators.predict(X)
        
        weight = self.calc_weight_from_pred(y_pred)
        
        return weight

    def ensemble_estimators(self, estimators, X, is_permission_leak=False):
        """予測リターンをアンサンブルする

        Parameters
        ----------
        estimators : Dict[int: function(torch base model)]
            学習済みモデルが格納された辞書.
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        is_permission_leak : bool
            アンサンブルさせる際にモデルのリークを許容しない場合はTrueとする
            (Xの期間中を訓練期間に含んだモデルはアンサンブルに含まれない)
                                
        Returns
        -------
        y_pred : pd.Series (MultiIndex("Date", "stock"))
            予測リターン
        """          
        start_date = pd.to_datetime(X.index.get_level_values("Date").min())

        y_pred = None
        count_model = 0
        for i, estimator_ in estimators.items():
            if (not is_permission_leak and
                    start_date <= pd.to_datetime(estimator_.learning_date_[1])):
                continue

            if y_pred is None:
                y_pred = estimator_.predict(X)
            else:
                y_pred += estimator_.predict(X)

            count_model += 1

        if y_pred is None:
            raise ValueError(
                "is_permisson_leak=True, but all estimators are including leak"
            )
        else:
            y_pred /= count_model

        return y_pred
        
    def calc_weight_from_pred(self, y_pred):
        '''予測リターンをもとにポートフォリオを構築

        Parameters
        ----------
        y_pred : pd.Series (MultiIndex("Date", "stock"))
            モデルの予測リターン.

        Returns
        -------
        weight : np.array
            ポートフォリオのウェイト.
        '''
        
        def relu(x):
            return x * (x > 0)
        
        long_universe = y_pred.groupby("Date").apply(
            lambda x: relu(np.sign(x-x.quantile(self.hyperparms["long_ratio"]))))
        long_universe = long_universe/long_universe.groupby("Date").sum()
        short_universe = y_pred.groupby("Date").apply(
            lambda x: relu(np.sign(x.quantile(self.hyperparms["short_ratio"])-x)))
        short_universe = short_universe/short_universe.groupby("Date").sum()
        if self.hyperparms['portfolio_type'] == 'LongShort':
            weight = long_universe - short_universe
        elif self.hyperparms['portfolio_type'] == 'Long':
            weight = long_universe
        elif self.hyperparms["portfolio_type"] == "active_port":
            weight_bench = y_pred.groupby("Date").apply(lambda x:(1/x.count()))
            weight = weight_bench + self.hyperparms["leverage"]*(
                long_universe - short_universe)
        else:
            raise ValueError(
                "portfolio_type must be long_ratio or short_ratio or active_port"
                + f": {self.hyperparms['portfolio_type']}")

        return weight