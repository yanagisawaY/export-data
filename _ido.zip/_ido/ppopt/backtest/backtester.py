from .backtester_regressor import RegBacktester
from .backtester_utility import UtilityBacktester


class BacktesterDetecter:
    def __init__(self, estimators, hyperparms):
        self.hyperparms = hyperparms
    
    def detect_model(self, estimators):
        if isinstance(estimators, dict):
            model_name = estimators[0].__class__.__name__
        else:
            model_name = estimators.__class__.__name__
    
        backtester = {
            "UtilityTrader": UtilityBacktester,
            "Regressor": RegBacktester,
        }[model_name](self.hyperparms)
    
        return backtester
