from ..utils.lrp import LRP
from ..utils.decorater import mystopwatch
from ..utils.util import check_input, get_universe_slice_list
from ..utils.optimizer import weight_under_leverage, adjust_weight_under_stocklimit

import numpy as np
import pandas as pd


class UtilityBacktester:
    def __init__(self, hyperparms):
        self.hyperparms = hyperparms
    
    def _call_portfolio_params(self):
        self.target_risk = self.hyperparms["target_risk"]        
        self.turnover = self.hyperparms["turnover"]
        self.stock_limit = self.hyperparms["stock_limit"]
        is_predict_under_leverage = not (self.target_risk is None or self.turnover is None)
        is_predict_under_stock_limit = not (self.stock_limit is None)
        
        return is_predict_under_leverage, is_predict_under_stock_limit

    def ensemble_predict(
        self,
        estimators,
        X,
        is_add_hidden_weight=True,
        is_permission_leak=True
        ):
        """estimatorsをアンサンブルした予測ウェイトを算出

        Parameters
        ----------
        estimators : Dict[int: function(torch base model)]
            学習済みモデルが格納された辞書.
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            特徴量データ(銘柄×時点, 特徴量)
        is_add_hidden_weight : bool
            合成ポートフォリオ(L-1層のLSポートフォリオ)のウェイトもあわせて出力する場合はTrue
            -> この場合は出力のweightはpd.DataFrameとなり，列方向に合成ポートフォリオのウェイトが追加される
        is_permission_leak : bool
            アンサンブルさせる際にモデルのリークを許容しない場合はTrueとする
            (Xの期間中を訓練期間に含んだモデルはアンサンブルに含まれない)

        Returns
        -------
        weight : pd.Series or pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト行列(銘柄*各時点)
            is_add_hidden_weight = Trueの場合，pd.DataFrameで出力
        """
        check_input(X, y=None)
        assert isinstance(estimators, dict)
        
        start_date = pd.to_datetime(X.index.get_level_values("Date").min())
        
        weight = None
        count_model = 0
        for i, estimator_ in estimators.items():
            if (not is_permission_leak and
                start_date <= pd.to_datetime(estimator_.learning_date_[1])):
                continue
                
            if weight is None:
                weight = estimator_.predict(X, is_add_hidden_weight)
            else:
                weight += estimator_.predict(X, is_add_hidden_weight)
            
            count_model += 1
        
        if weight is None:
            raise ValueError(
                "is_permisson_leak=True, but all estimators are including leak"
                )
        else:
            weight /= count_model
        
        return weight
       
    @mystopwatch
    def calc_weight(
            self, estimators, X_test, y_test=None, X_train=None, y_train=None):
        """ポートフォリオのウェイトをターンオーバー制約などの制限のもと算出

        Parameters
        ----------
        estimators : Dict[int: function(torch base model)]
            学習済みモデルが格納された辞書.        
        X_test : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト期間における特徴量データ(銘柄×時点, 特徴量)
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)
        X_train : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点,)

        Returns
        -------
        weight : pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト
                    
        * is_predict_under_leverage= Trueの場合，以下が返り値となる
        weight : pd.Series (MultiIndex("Date", "stock"))
            最適化後のポートフォリオのウェイト
        theta : pd.Series
            各企業特性合成ポートフォリオにおけるエクスポージャー
        status_all : list
            最適化が成功したかどうかを格納したリスト
        """
        is_predict_under_leverage, is_predict_under_stock_limit = self._call_portfolio_params()
        if is_predict_under_leverage:
            hidden_weight_current = self.ensemble_predict(
                estimators,
                X_test,
                is_add_hidden_weight=True,
                is_permission_leak=False).drop("all", axis=1).values
            hidden_weight_train = self.ensemble_predict(
                estimators,
                X_train,
                is_add_hidden_weight=True,
                is_permission_leak=True).drop("all", axis=1).values
            return weight_under_leverage(
                hidden_weight_current,
                hidden_weight_train,
                y_train,
                y_test,
                self.turnover,
                self.target_risk
                )
        else:
            weight = self.ensemble_predict(
                estimators,
                X_test,
                is_add_hidden_weight=False,
                is_permission_leak=False)
        
        if is_predict_under_stock_limit:
            weight = adjust_weight_under_stocklimit(
                weight, y_test, self.stock_limit)
        
        return weight
    
    @mystopwatch
    def calc_lrp(self, estimator, X, y, factor_list, theta: pd.DataFrame = None):
        """LRPを用いて特徴量の貢献度を算出するメソッド

        Parameters
        ----------
        estimator : function(pytorch module)
            学習済みモデル.
        X : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト期間における特徴量データ(銘柄×時点, 特徴量)            
        y : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)
        factor_list : List[str]
            使用するファクターのリスト
        theta : pd.DataFrame
            各企業特性合成ポートフォリオへのエクスポージャー
            
        Returns
        -------
        port_lrp : Dict[str: pd.DataFrame]
            各時点のポートフォリオにおける特徴量の貢献度(企業特性合成ポートフォリオの特徴量の貢献度も結合させる)
            hidden_Xポートフォリオにおける各時点の特徴量の貢献度
        factor_lrp : Dict[str: pd.DataFrame]
            各企業特性合成ポートフォリオごとの貢献度をファクターごとにまとめた辞書.
        factor_coef : pd.DataFrame
            LRPにより求めた貢献度を説明変数，各特徴量の値を被説明変数として単回帰した際の回帰係数
        """
        lrp = LRP(estimator, factor_list)
        date_list = sorted(y.index.get_level_values("Date").unique())        
        universe_index = get_universe_slice_list(y.index, date_list)
        hidden_lrp_dict = lrp.get_hidden_lrp(X, universe_index)
        hidden_port_lrp_dict = lrp.get_port_hidden_lrp(hidden_lrp_dict)

        if theta is None:
            port_lrp_dict = lrp.calc_port_lrp(hidden_lrp_dict)
            factor_lrp, factor_coef = lrp.summarize_factor_lrp(
                X, port_lrp_dict)
            port_lrp = lrp.calc_port_lrp(hidden_port_lrp_dict)
        else:
            port_lrp_dict = lrp.calc_port_lrp(
                hidden_lrp_dict, weight_active=theta)
            factor_lrp, factor_coef = lrp.summarize_factor_lrp(
                X, port_lrp_dict)
            port_lrp = lrp.calc_port_lrp(
                hidden_port_lrp_dict, weight_active=theta)

        return port_lrp, factor_lrp, factor_coef

    def _calc_port_return(self, weight, rt):       
        """ポートフォリオ(+ 企業特性合成ポートフォリオ)のリターンを計算

        Parameters
        ----------
        weight : pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト
        rt : pd.Series (MultiIndex("Date", "stock"))
            リターンデータ

        Returns
        -------
        port_rt_with_hidden : pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオ(+ 企業特性合成ポートフォリオ)のリターン
        """
        port_rt_with_hidden = (
            weight*np.repeat(rt.values[:, np.newaxis],
                                    weight.shape[1], axis=1)).sum(level="Date")
        
        return port_rt_with_hidden

    def calc_train_test_port_weight(
        self, estimators, X_test, X_train):
        """訓練期間とテスト期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のリターンを返す

        Parameters
        ----------
        estimators : Dict[str: model] | model
            学習済みモデル
        X_test : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト期間における特徴量データ(銘柄×時点, 特徴量)
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)
        X_train : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点,)            

        Returns
        -------
        weight_test : pd.DataFrame      
            訓練期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のウェイト
        weight_train : pd.DataFrame
            テスト期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のウェイト        
        
        Notes
        -----
        * 本メソッドではレバレッジ制約などによる最適化を実施しないウェイトを返す            
        """        
        if isinstance(estimators, dict):
            weight_train = self.ensemble_predict(
                            estimators,
                            X_train,
                            is_add_hidden_weight=True,
                            is_permission_leak=True)
            weight_test = self.ensemble_predict(
                            estimators,
                            X_test,
                            is_add_hidden_weight=True,
                            is_permission_leak=False)   
        else:
            weight_train = estimators.predict(
                X_train, is_add_hidden_weight=True)
            weight_test = estimators.predict(
                X_test, is_add_hidden_weight=True)
            
        return weight_test, weight_train

    def calc_train_test_port_rt(
        self, weight_test, y_test, weight_train, y_train):
        """訓練期間とテスト期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のリターンを返す

        Parameters
        ----------
        weight_test : pd.DataFrame      
            訓練期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のウェイト
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)
        weight_train : pd.DataFrame
            テスト期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のウェイト                            
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点,)            

        Returns
        -------
        port_rt_with_hidden_test : pd.DataFrame
            テスト期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のリターン        
        port_rt_with_hidden_train : pd.DataFrame      
            訓練期間におけるポートフォリオ(+ 企業特性合成ポートフォリオ)のリターン
        """                    
        port_rt_with_hidden_train = self._calc_port_return(
            weight_train, y_train)
        port_rt_with_hidden_test = self._calc_port_return(
            weight_test, y_test)
        
        return port_rt_with_hidden_test, port_rt_with_hidden_train
        
    def fill_theta(self, estimators, theta_index):
        """企業特性合成ポートフォリオへの重みづけを算出

        Parameters
        ----------
        estimators : Dict[str: model] | model
            学習済みモデル
        theta_index : pd.Index
            データフレームに付与するインデックス
        """
        def _fill_theta(estimator, theta_index):
            weight_active = [i[0].detach().numpy().copy()
                            for i in estimator.model.last.parameters()][0]
            theta = pd.DataFrame(
                [weight_active for _ in range(len(theta_index))],
                index=theta_index,
                columns=[f"hidden_{i}" for i in range(len(weight_active))])
            
            return theta
        
        if isinstance(estimators, dict):
            theta = 0
            for estimator in estimators.values():
                theta += _fill_theta(estimator, theta_index)
            
            theta /= len(estimators)
        else:
            theta = _fill_theta(estimators, theta_index)
        
        return theta