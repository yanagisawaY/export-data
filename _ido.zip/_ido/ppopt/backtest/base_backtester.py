import enum
from operator import index
import os
import pickle
import hydra
import pandas as pd
from ..utils.optimizer import adjust_weight_under_stocklimit


class BaseBacktester:
    def __init__(self, hyperparms):
        self.hyperparms = hyperparms

    def _call_portfolio_params(self):
        self.target_risk = self.hyperparms["target_risk"]
        self.turnover = self.hyperparms["turnover"]
        self.stock_limit = self.hyperparms["stock_limit"]
        is_predict_under_leverage = not (
            self.target_risk is None or self.turnover is None)
        is_predict_under_stock_limit = not (
            self.stock_limit is None)

        return is_predict_under_leverage, is_predict_under_stock_limit 

    def load_estimators(self, path_head):
        """指定した出力パスから推定済みモデルを読み込み

        Parameters
        ----------
        path_head : str
            読み込みパス

        Returns
        -------
        estimators_all : Dict[str: model]
            推定済みモデルを格納した辞書
        """
        estimators_all = {}
        learnin_date = []
        for i, estimator_dir in enumerate(self.hyperparms["estimators"]):
            with open(
                os.path.join(
                    path_head, estimator_dir), 'rb') as f:
                estimators = pickle.load(f)

            for key, estimator_ in estimators.items():
                key_new = "{}_{}".format(i, key)
                estimators_all[key_new] = estimator_
                learnin_date.append(
                    estimator_.learning_date_[1])

        self.learnin_date_set = sorted(list(set(learnin_date)))

        return estimators_all

    def calc_weight_roll(self, estimators, X_test, y_test, X_train, y_train):
        """制約条件のもとでポートフォリオのウェイトを最適化

        Parameters
        ----------
        estimators : Dict[int: function(torch base model)]
            学習済みモデルが格納された辞書.        
        X_test : pd.DataFrame (MultiIndex("Date", "stock"))
            テスト期間における特徴量データ(銘柄×時点, 特徴量)
        y_test : pd.Series (MultiIndex("Date", "stock"))
            テスト期間における被説明変数(時点,)
        X_train : pd.DataFrame (MultiIndex("Date", "stock"))
            訓練期間における特徴量データ(銘柄×時点, 特徴量)            
        y_train : pd.Series (MultiIndex("Date", "stock"))
            訓練期間における被説明変数(時点,)

        Returns
        -------
        weight : pd.DataFrame (MultiIndex("Date", "stock"))
            ポートフォリオのウェイト
        theta : pd.Series | None
            各企業特性合成ポートフォリオにおけるエクスポージャー
        status_all : list | None
            最適化が成功したかどうかを格納したリスト
        weight_test_with_hidden : pd.DataFrame (MultiIndex("Date", "stock"))
            制約条件付きの最適化実施前のポートフォリオのウェイトと企業特性合成ポートフォリオのウェイト
            
        Notes
        -----
        * is_predict_under_leverage = Falseの場合，thetaとstatus_allはNoneとなる         
        """
        index_test = pd.to_datetime(X_test.index.get_level_values("Date"))
        is_predict_under_leverage, _ = self._call_portfolio_params()
        weight = []
        theta = []
        status_all = []
        weight_test_with_hidden = []
        
        for i, train_end_date in enumerate(self.learnin_date_set):
            estimators_ensembled = {}
            for key, estimator_ in estimators.items():
                est_end = pd.to_datetime(estimator_.learning_date_[1])
                if self.hyperparms["is_roll_model"] and est_end == pd.to_datetime(train_end_date):
                    estimators_ensembled.update({key: estimator_})                    
                elif est_end <= pd.to_datetime(train_end_date):
                    estimators_ensembled.update({key: estimator_})
            
            if i+1 == len(self.learnin_date_set):
                is_test_extracted = train_end_date <= index_test
            else:
                is_test_extracted = (train_end_date <= index_test) & (
                    self.learnin_date_set[i+1] > index_test)
                
            X_test_new = X_test.iloc[
                is_test_extracted, :]
            y_test_new = y_test.iloc[is_test_extracted]
            if sum(~is_test_extracted) > 0:
                X_train_new = pd.concat(
                    [X_train, X_test.iloc[~is_test_extracted, :]])
                y_train_new = pd.concat(
                    [y_train, y_test.iloc[~is_test_extracted]])
            else:
                X_train_new = X_train.copy(deep=True)
                y_train_new = y_train.copy(deep=True)

            weight_test_with_hidden_ = self.ensemble_predict(
                estimators_ensembled,
                X_test_new,
                is_add_hidden_weight=True,
                is_permission_leak=False)
            weight_test_with_hidden.append(weight_test_with_hidden_)
            
            if not is_predict_under_leverage:
                weight_ = self.calc_weight(
                    estimators_ensembled,
                    X_test_new,
                    y_test_new,
                    X_train_new,
                    y_train_new)
                theta_ = self.fill_theta(
                    estimators_ensembled,
                    weight_test_with_hidden_.index
                )
            else:
                weight_, theta_, status_all_ = self.calc_weight(
                    estimators_ensembled,
                    X_test_new,
                    y_test_new,
                    X_train_new,
                    y_train_new)
                status_all.append(status_all_)                
            weight.append(weight_)                
            theta.append(theta_)
                        
        weight = pd.concat(weight)
        weight_test_with_hidden = pd.concat(weight_test_with_hidden)        
        theta = pd.concat(theta)        
        if not is_predict_under_leverage:
            status_all = None
        
        weight = self.calc_under_stock_limit(weight, y_test)
            
        return weight, theta, status_all, weight_test_with_hidden

    def calc_under_stock_limit(self, weight, y_test):
        _, is_predict_under_stock_limit = self._call_portfolio_params()
        if is_predict_under_stock_limit:
            weight = adjust_weight_under_stocklimit(
                weight, y_test, self.hyperparms["stock_limit"])
        
        return weight

    def fill_theta(self, estimators, theta_index):
        """企業特性合成ポートフォリオへの重みづけを算出

        Parameters
        ----------
        estimators : Dict[str: model] | model
            学習済みモデル
        theta_index : pd.Index
            データフレームに付与するインデックス
        """
        def _fill_theta(estimator, theta_index):
            weight_active = [i[0].detach().numpy().copy()
                             for i in estimator.model.last.parameters()][0]
            theta = pd.DataFrame(
                [weight_active for _ in range(len(theta_index))],
                index=theta_index,
                columns=[f"hidden_{i}" for i in range(len(weight_active))])

            return theta

        if isinstance(estimators, dict):
            theta = 0
            for estimator in estimators.values():
                theta += _fill_theta(estimator, theta_index)

            theta /= len(estimators)
        else:
            theta = _fill_theta(estimators, theta_index)

        return theta