# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    本コードで使用しているクラス
    Experimenter
        シミュレーションデータを用いてモデル検証を実施するためのクラス
"""
from get_result import ResultMaker
from _simulation.simulator import Simulator
from models.comparative_model import ComparativeModel

import pandas as pd
import seaborn as sns    
import matplotlib.pyplot as plt

class Experimenter(ResultMaker):
    def __init__(self, hyperparms_company_common):
        '''
            シミュレーションデータを用いてモデル検証を実施するクラス
        
        Parameters
        ----------        
            hyperparms_company_common : モデルのパラメータ        
        '''
        super().__init__(df_dict={}, hyperparms_company_common=hyperparms_company_common, ticker_info={})  
        self.hyperparms_company_common = hyperparms_company_common

    def make_simulation_data(self, simulation_setting):
        '''
            シミュレーションデータの作成

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.

        Returns
        -------
        dict_output : dict
            シミュレーションデータ.
        '''
        self.sim = Simulator(simulation_setting)
        dict_output = self.sim.make_simulation_data()                
        
        return dict_output
    
    def split_simulation(self, dict_output, train_num=0):
        '''
            シミュレーションデータを訓練データとテストデータに分割

        Parameters
        ----------
        dict_output : dict
            シミュレーションデータ.
        train_num : TYPE, optional
            訓練データとテストデータを分割するインデックスの数値. The default is 0.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割

        Returns
        -------
        X_train : dict
            訓練データにおける企業特性データ.
        y_train : pd.DataFrame
            訓練データにおける銘柄のリターン.
        X_test : dict
            テストデータにおける企業特性データ.
        y_test : pd.DataFrame
            テストデータにおける銘柄のリターン.
        '''
        y = dict_output['return']
        X = dict_output['factor']
        
        # train_numのチェック
        assert isinstance(train_num, int)
        assert train_num >= 0 and train_num <= y.shape[0]        
        if train_num == 0:
            train_num = int(y.shape[0]/2)
                   
        y_train = y.iloc[:train_num,:]
        y_test = y.iloc[train_num:,:]        
        X_train = {}
        X_test = {}        
        for key, val in X.items():
            temp = X[key]
            X_train[key] = temp.iloc[:train_num,:]
            X_test[key] = temp.iloc[train_num:,:]    
        
        return X_train, X_test, y_train, y_test
                
    def set_simulation(self, dict_output, train_num : int):
        '''
            シミュレーションデータを用いてモデル学習・検証を実施
            
        Parameters
        ----------
        dict_output : dict
            シミュレーションデータ.
        train_num : int
            訓練データとテストデータを分割するインデックスの数値.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
            
        Returns
        -------
        weight_test : pd.DataFrame
            テストデータにおける投資ウェイト.
        df_params : pd.DataFrame
            使用したパラメータ情報など
        df_info : pd.Series
            データの分割期間などの情報            
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点
        '''
        print('シミュレーションデータを用いた検証を開始')
        X_train, X_test, y_train, y_test = self.split_simulation(dict_output, train_num)
        self.stock_list = X_train['I_0'].columns
        self.hyperparms_company_common['stock_list'] = self.stock_list
        self.hyperparms_company_common['factor_list'] = list(X_train.keys())
        # 訓練データとテストデータに日付情報はないため，インデックスの数を代わりに保存
        self.train_start_date, self.train_end_date, self.test_start_date, self.test_end_date = \
            [0, y_train.shape[0], y_train.shape[0]+1, y_train.shape[0]+y_test.shape[0]]
            
        return X_train, X_test, y_train, y_test
    
    def get_simulation_result(self, simulation_setting, hyperparms_portfolio, hyperparms_comparative, output_name = 'sim1'):
        '''
            シミュレーションデータを用いたモデル学習結果に対し，パフォーマンス等の結果を保存

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        hyperparms_comparative : dict
            比較対象のモデルのハイパーパラメータ
        output_name : str
            resultの列名.(任意な列名を設定可能) The default is 'sim1'.

        Returns
        -------
        output : dict
            学習・バックテストの結果        
        '''
        # シミュレーションデータの生成
        dict_output = self.make_simulation_data(simulation_setting)
        
        # シミュレーションデータの分割
        X_train, X_test, y_train, y_test = self.set_simulation(dict_output, train_num=simulation_setting['train_num'])
        weight_test, df_params, df_info, traders_performance_log = self.learn(X_train, y_train, X_test, y_test)        
        
        # 結果の集約
        output = {}
        result = {}   
        result['df_params'] = df_params
        result['traders_performance_log'] = traders_performance_log
        result['df_info'] = df_info
        result['index'], result['performance'] = self.get_portfolio_result(weight_test, y_test, hyperparms_portfolio, output_name)
        
        # 比較モデルの学習/結果の出力
        if hyperparms_comparative['is_comparison']:
            weight_dict_other = self.get_simulation_result_other(dict_output, hyperparms_comparative, train_num=simulation_setting['train_num'])
            for other_name, weight_test_other in weight_dict_other.items():
                index_, performance_ = self.get_portfolio_result(weight_test_other, y_test, hyperparms_portfolio, output_name+'_'+other_name)
                result['index'] = pd.concat([result['index'], index_], axis=1)
                result['performance'] = pd.concat([result['performance'], performance_], axis=1)
                
        output[output_name] = result
        
        return output
        
    def get_simulation_result_other(self, dict_output, hyperparms_comparative, train_num : int):
        '''
            比較モデルによるポートフォリオウェイトを算出

        Parameters
        ----------
        dict_output : dict
            シミュレーションデータ.
        hyperparms_comparative : dict
            比較対象のモデルのハイパーパラメータ
        train_num : int
            訓練データとテストデータを分割するインデックスの数値.
            0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
            
        Returns
        -------
        weight_dict : dict
            比較モデルごとのポートフォリオウェイト.
        '''
        hyperparms_comparative['stock_list'] = self.stock_list
        cm = ComparativeModel(hyperparms_comparative)
        stock_num = dict_output['return'].shape[1]
        # データの分割
        X_train, X_test, y_train, y_test = cm.split_simulation_data(dict_output, train_num)
        # ウェイトの算出
        weight_dict = cm.calc_weight_all_model(X_train, X_test, y_train, y_test, stock_num)
        
        return weight_dict
        
    def plot_simlation_data(self, dict_output):
        '''
            シミュレーションデータをプロットする（本機能は任意に実施可能なメソッド）

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''
        rt_all = dict_output['return']
        X = dict_output['factor']['I_0']
        df_plot = pd.DataFrame([X.values.reshape(-1), rt_all.values.reshape(-1)], index=['X', 'y']).T
        plt.figure()
        sns.regplot(x='X', y='y', data=df_plot,
                    scatter_kws={'alpha' : 0.1, 'color' : 'black'},
                    line_kws={'color': 'red'})
        plt.show()
        print(f'corr : {df_plot.corr()}')

    