# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    本コードで使用しているクラス
    StockSimulator
        株式リターンのシミュレーションデータ生成を実施するクラス
    Simulator　-> StockSimulatorを継承
        シミュレーションデータの生成を実施するクラス
"""
import numpy as np
import pandas as pd

class StockSimulator:
    def __init__(self, simulation_setting):
        '''
            株式リターンのシミュレーションデータ生成を実施するクラス

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''
        self.random_seed = simulation_setting['random_seed']
        self.stock_num = simulation_setting['stock_num']        
        self.time_span = simulation_setting['time_span']
        self.year_term = simulation_setting['year_term']
        self.sigma_epsilon = simulation_setting['sigma_epsilon']
        self.market_u = simulation_setting['market_u']
        self.market_sigma = simulation_setting['market_sigma']
        self.beta_u = simulation_setting['beta_u']
        self.beta_sigma = simulation_setting['beta_sigma']
        self.alpha_sigma = simulation_setting['alpha_sigma']
        self.delta_mean = simulation_setting['delta_mean']
        self.factor_num = len(self.delta_mean)
        self.delta_sigma =simulation_setting['delta_sigma']
        np.random.seed(self.random_seed)
        
    def generate_marcket_return(self):
        '''
        Returns
        -------
        market_r : np.array
            マーケットリターン (銘柄，年代)
        '''
        market_r = self.market_u + np.random.randn(self.time_span, self.year_term)*self.market_sigma
        
        return market_r

    def generate_marcket_beta(self):
        '''
        Returns
        -------
        beta : np.array
            マーケットリターンへの感応度 (銘柄，年代)
        '''
        beta = self.beta_u + np.random.randn(self.stock_num, self.year_term)*self.beta_sigma
        
        return beta

    def generate_noise(self):
        '''
        Returns
        -------
        epsilon : np.array
            非システマティックリスクの誤差項(銘柄, 時点， 年代)
        '''
        epsilon = np.random.randn(self.stock_num, self.year_term)*self.sigma_epsilon
        
        return epsilon

    def generate_alpha_noise(self):
        '''
        Returns
        -------
        alpha_noise : np.array
            アルファリターンの誤差項(銘柄，年代)
        '''
        alpha_noise = np.random.randn(self.stock_num, self.year_term)*self.alpha_sigma
        
        return alpha_noise

    def generate_characteristic(self):
        '''
        Returns
        -------
        characteristic : np.array
            企業特性(銘柄，年代, 企業特性数)
        '''
        characteristic = np.random.randn(self.stock_num, self.year_term, self.factor_num)
        self.characteristic = characteristic
        
        return characteristic

    def generate_delta(self):
        '''
        Returns
        -------
        delta : np.array
            期間yごとに変動する企業特性への感応度(年代, 企業特性)
        '''
        delta_var = np.random.randn(self.year_term, self.factor_num)*self.delta_sigma
        delta = np.tile(np.array(self.delta_mean), (self.year_term, 1)) + delta_var        
        
        return delta
    
    def calc_alpha_term(self, X, delta, alpha_noise):
        '''
        Returns
        -------
        alpha : np.array
            アルファリターン(銘柄, 時点， 年代)
        '''
        alpha = np.einsum("mts, ts->mts", X, delta).sum(2) + alpha_noise
        alpha = np.repeat(alpha[:,np.newaxis,:], self.time_span, axis=1)
        
        return alpha

    def calc_market_term(self, market_r, beta):
        '''
        Returns
        -------
        market_term  : np.array
            マーケットリターン(銘柄, 時点， 年代)
        '''
        # サンプルリターンの計算
        market_term = np.einsum("mts, mts->mts", 
                                np.repeat(beta[:,np.newaxis,:], self.time_span, axis=1), 
                                np.repeat(market_r[np.newaxis,:,:], self.stock_num, axis=0))
        
        return market_term

    def sum_terms(self):
        '''
        Returns
        -------
        market_term  : np.array
            マーケットリターン(銘柄, 時点， 年代)
        '''
        # マーケットリターンの生成        
        self.market_r = self.generate_marcket_return()
        beta = self.generate_marcket_beta()
        market_term = self.calc_market_term(self.market_r, beta)
        
        # アルファリターンの生成
        X = self.generate_characteristic()
        delta = self.generate_delta()
        alpha_noise = self.generate_alpha_noise()
        alpha = self.calc_alpha_term(X, delta, alpha_noise)
        
        rt = alpha + market_term
                    
        return rt
    
    def sample_return(self):
        '''
            サンプリングを実施．
        Returns
        -------
        samples  : pd.DataFrame
            マーケットリターン(銘柄, 時点×年代)
        '''        
        rt = self.sum_terms()
        samples = np.zeros([self.time_span*self.year_term, self.stock_num])
        for i in range(rt.shape[2]):
            samples[i*rt.shape[1]:(i*rt.shape[1]+rt.shape[1]),:] = rt[:,:,i].T

        self.stock_names = ['stock_'+str(i) for i in range(self.stock_num)]
        samples = pd.DataFrame(samples, columns=self.stock_names) 
            
        return samples


class Simulator(StockSimulator):
    def __init__(self, simulation_setting):
        '''
            シミュレーションデータ生成を実施するクラス

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''        
        super().__init__(simulation_setting)
        self.redundant_num = simulation_setting['redundant_num']
        self.redundant_noise = simulation_setting['redundant_noise']
        self.factor_noise_num = simulation_setting['factor_noise_num']
        self.factor_noise = simulation_setting['factor_noise']
        
    def orgnanize_characteristic(self):
        '''
            企業特性データをリターンと同じサイズで出力

        Returns
        -------
        X_output : np.array
            企業特性データ.(銘柄，時点×年代, 企業特性数)
        '''
        X = self.characteristic        
        X_output = np.zeros([self.time_span*self.year_term, self.stock_num, self.factor_num])
        for i in range(self.year_term):
            X_output[i*self.time_span:(i*self.time_span+self.time_span),:,:] = np.repeat(X[:,i,:][np.newaxis,:,:], self.time_span, axis=0)
            
        return X_output

    def make_factor_dict(self, X_output):
        '''
            企業特性データを辞書形式で保存

        Parameters
        ----------
        X_output : np.array
            企業特性データ.(銘柄，時点×年代, 企業特性数)

        Returns
        -------
        factor_dict : dict
            企業特性データが格納された辞書.
        factor_I : list
            企業特性データの名前（I_1，などの名前を設定）.
        '''
        factor_dict = {}
        factor_I = []
        for i in range(X_output.shape[2]):
            name = 'I_'+str(i)
            factor_I.append(name)
            factor_dict[name] = pd.DataFrame(X_output[:,:,i], columns=self.stock_names)

        return factor_dict, factor_I

    def generate_redundancy(self, factor_dict, factor_I):
        '''
            冗長な企業特性を生成

        Parameters
        ----------
        factor_dict : dict
            企業特性データの辞書.
        factor_I : list
            企業特性データの名前（I_1，などの名前を設定）.

        Returns
        -------
        factor_dict : dict
            冗長な特徴量が追加された企業特性データの辞書.
        '''
        temp = [1/np.abs(i+0.0000001) for i in self.delta_mean]
        prob = [i/sum(temp) for i in temp]
        
        for j in range(self.redundant_num):
            name_I = np.random.choice(factor_I, p=prob)
            name = 'R_'+str(j)
            coef = 1 + (np.random.rand()-0.5)/0.5
            temp = factor_dict[name_I]*coef + np.random.randn(self.year_term*self.time_span, self.stock_num)*self.redundant_noise
            factor_dict[name] = pd.DataFrame(temp, columns=self.stock_names)        
            
        return factor_dict
    
    def generate_noise(self, factor_dict):
        '''
            無関係な企業特性を生成

        Parameters
        ----------
        factor_dict : dict
            企業特性データの辞書.

        Returns
        -------
        factor_dict : dict
            企業特性とは無関係なデータが追加された企業特性データの辞書.
        '''
        for j in range(self.factor_noise_num ):
            name = 'N_'+str(j)
            temp = np.random.randn(self.year_term*self.time_span, self.stock_num)*self.factor_noise
            factor_dict[name] = pd.DataFrame(temp, columns=self.stock_names)
            
        return factor_dict
    
    def make_simulation_data(self):
        '''
            シミュレーションデータを生成

        Returns
        -------
        dict_output : dict
            シミュレーションデータ.
        '''
        return_samples = self.sample_return()
        X_output = self.orgnanize_characteristic()
        factor_dict_, factor_I = self.make_factor_dict(X_output)
        factor_dict_ = self.generate_redundancy(factor_dict_, factor_I)
        factor_dict = self.generate_noise(factor_dict_)
        
        # シミュレーションデータを辞書に保存
        dict_output = {
            'return' : return_samples,
            'factor' : factor_dict,  
            }

        return dict_output
    