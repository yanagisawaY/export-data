import numpy as np
from scipy.stats import geninvgauss
from scipy.stats import invgamma
#import matplotlib.pyplot as plt

#######################################################################
def FFBS_for_CDLM(Y,X,mu_alpha_0,sigma_alpha_0,G,sigma_1,sigma_2,gammna_shape1,gammna_shape2):
    #J.DURBIN&S.J.KOOPMAN(2002)
    #https://www.jstor.org/stable/4140605?seq=1
    #Y = X × alpha+ sigma_1(時変の重回帰)
    #alpha_t = G × alpha_t-1 + sigma_2を考える(Rは単位行列を仮定)
    
    #入力
    # Y         ---- 観測方程式のアウトプット (T期×次元m) 上から下に、過去から将来へなっているデータ
    # X         ---- 観測方程式の説明変数 (T期 ×　次元m × 次元n) 上から下に、過去から将来へなっているデータ、事前に定数項を入れる必要あり
    # mu_alpha_0    ---- 時点0の回帰係数の平均(事前分布) (次元n) 
    # sigma_alpha_0 ---- 時点0の回帰係数の分散(事前分布) (次元n × 次元n)
    # G         ---- transition_matrices　(T期 ×　次元n ×　次元n)
    # sigma_1   ---- 観測方程式のボラ　(T期×次元m ×次元m) T-1期でもOK
    # sigma_2   ---- 状態方程式のボラ　(T期 ×次元n ×　次元n)
    # gammna_shape1 ----- ガンマ分布の事前分布
    # gammna_shape2 ----- ガンマ分布の事前分布
    
    #出力
    # smoothed_alpha     ---- スムージングされた回帰係数 (T期 ×　次元n)
    # V                  ---- ボラティリティ

    #見やすくするため文字の置き換え
    T=Y.shape[0] #データ期間
    n=sigma_2.shape[1] #説明変数の数
    m=Y.shape[1]
    
    #以下、Algorithm2の1
    alpha_0_plus = np.random.multivariate_normal(mu_alpha_0.T, sigma_alpha_0) #初期値の乱数生成
    
    omega  = np.zeros((T*m+T*n,T*m+T*n)) 
    for t in range(T):
        for i in range(m):
            for s in range(m):
                omega[t*m+i,t*m+s]=sigma_1[t,i,s] 
    for t in range(T):
        for i in range(n):
            for s in range(n):
                omega[T*m+t*n+i,T*m+t*n+s]=sigma_2[t,i,s]       
    w_plus = np.random.multivariate_normal(np.zeros(T*m+T*n), omega) #omegaからwの乱数生成
    
    Y_plus = np.zeros((T,m))
    alpha_plus = np.zeros((T,n))
    alpha_plus[0,:]=alpha_0_plus
    for t in range(T):
        Y_plus[t,:]=X[t,:,:]@alpha_plus[t,:]+ w_plus[t*m:(t+1)*m]
        if t<T-1: #将来予測は使わないため
            alpha_plus[t+1,:]=G[t,:,:]@alpha_plus[t,:]+ w_plus[T*m+t*n:T*m+(t+1)*n]

    #以下、Algorithm2の2
    def Kalman_filter_and_smoother(Y,V_Flag):
        #以下、Algorithm2の2       
        v = np.zeros((T,m))
        K = np.zeros((T,n,m))
        a = np.zeros((T,n))
        F = np.zeros((T,m,m))
        L = np.zeros((T,n,n))
        P = np.zeros((T,n,n))
        a[0,:] = mu_alpha_0
        P[0,:,:] = sigma_alpha_0
        for t in range(T): #Kalman filter 式(3)
            v[t,:] = Y[t,:]-X[t,:,:]@a[t,:]
            F[t,:,:] = X[t,:,:]@P[t,:,:]@X[t,:,:].T + sigma_1[t,:,:]
            K[t,:] = G[t,:,:]@P[t,:,:]@X[t,:,:].T@np.linalg.pinv(F[t,:,:])
            L[t,:,:] = G[t,:,:]-K[t,:,:]@X[t,:,:]
            if t<T-1:#将来予測は使わないため
                a[t+1,:] = G[t,:,:]@a[t,:] + K[t,:,:]@v[t,:]
                P[t+1,:,:] = G[t,:,:]@P[t,:,:]@L[t,:,:].T + sigma_2[t,:,:]
        
        #Vを出すための乱数生成
        V=1
        if V_Flag>0:
            S=gammna_shape2        
            for t in range(T):
               S = S+v[t,:].T@np.linalg.pinv(F[t,:,:])@v[t,:]
               #S = (t+gammna_shape1)*S+v[t,:].T@np.linalg.pinv(F[t,:,:])@v[t,:]
            V=invgamma.rvs((T+gammna_shape1)/2, scale=(gammna_shape2+S)/2)
            
        r = np.zeros((T,n))
        for t in reversed(range(1,T)): # smoother 式(4)
            r[t-1,:] = X[t,:,:].T@np.linalg.pinv(F[t,:,:])@v[t,:] + L[t,:,:].T@r[t,:]
        alpha_hat = np.zeros((T,n))
        alpha_hat[0,:] = a[0,:]+P[0,:,:]@(X[0,:].T@np.linalg.pinv(F[t,:,:])@v[0,:] + L[0,:,:].T@r[0,:])
        for t in range(T-1):
            alpha_hat[t+1] = G[t,:,:]@alpha_hat[t] + sigma_2[t,:,:]@r[t,:]
        return alpha_hat, V
    
    alpha_hat,V = Kalman_filter_and_smoother(Y,1)
    alpha_hat_plus,_ = Kalman_filter_and_smoother(Y_plus,0)            
    #以下、Algorithm2の3
    smoothed_alpha = alpha_hat - alpha_hat_plus + alpha_plus
    return smoothed_alpha, V
################################################################################################################
#データの読み込み
Data = np.loadtxt("D:/分析用/testdata.csv", delimiter=',')
#見やすくするため文字の置き換え
T=Data.shape[0] #データ期間
n=Data.shape[1]-1#説明変数の数
m=Data.shape[1]

###############################################################################################################
#事前分布や初期パラメーターの設定
np.random.seed(seed=777) #シード値
num=10000 #mcmcの回数
alpha=0.9 #0への収束の強さパラメーター
beta=1 #1期前の回帰係数への収束の強さパラメーター、beta>alphaは必須
myu=0 #回帰係数をどこに収束させたいか、基本は0
latent_n=np.ones((T-2,n))
gammna_shape1=1 #分散の逆ガンマ分布の形状
gammna_shape2=1 #分散の逆ガンマ分布の形状
S=T #分散の初期値
Y = np.ones((T, m))*myu
Y[:,0]=Data[:,0]

X=np.zeros((T,m,n))
for i in range(T):
 X[i,:,:]=np.concatenate([Data[i,np.newaxis, 1:],np.eye(n)])
mu_alpha_0=np.zeros(n) #モデル上固定
sigma_alpha_0=np.eye(n)
sigma_1=np.zeros((T,m,m))
sigma_2=np.zeros((T,n,n))
G=np.zeros((T,n,n))
V=invgamma.rvs((gammna_shape1+T)/2, scale=S*(gammna_shape1+T)/2)
for t in range(T):
    sigma_1[t,:,:]=np.eye(m)*V
    sigma_2[t,:,:]=np.eye(n)*V
    G[t,:,:]=np.eye(n)


################################################################################################################
#データ保存用の空箱
Q_for_save=np.zeros((T*m,num*m))
V_for_save=np.zeros(num)
lambda_beta_for_save=np.zeros(((T-1)*n,num*n))
latent_n_for_save=np.zeros(((T-2)*n,num))
smoothed_theta_for_save=np.zeros((T*n,num))
################################################################################################################
#ここからMCMC
for it in range(num):
    #1 FFBS   
    smoothed_theta, V = FFBS_for_CDLM(Y,X,mu_alpha_0,sigma_alpha_0,G,sigma_1,sigma_2,gammna_shape1,gammna_shape2) 
    #2 Lambdaのサンプリング    
    lambda_alpha=np.zeros((2,n,n))
    lambda_n=np.zeros((T-2,n,n))
    lambda_beta=np.zeros((T-1,n,n))
    for t in range(2):
        for i in range(n):
            if smoothed_theta[t,i]-myu>0:
                lambda_alpha[t,i,i]=geninvgauss.rvs(1/2, alpha*abs(smoothed_theta[t,i]-myu), scale=abs(smoothed_theta[t,i]-myu)/alpha,size=1)
            else:#エラー時の仮の値
                lambda_alpha[t,i,i]=geninvgauss.rvs(1/2, alpha*0.0000001, scale=0.0000001/alpha,size=1)
    for t in range(T-2):
        for i in range(n):
            if latent_n[t,i]>0:
                if smoothed_theta[t,i]-myu>0:
                    lambda_n[t,i,i]=geninvgauss.rvs(1/2, latent_n[t,i]*(beta-alpha)*abs(smoothed_theta[t,i]-myu), scale=abs(smoothed_theta[t,i]-myu)/alpha,size=1)
                else:#エラー時の仮の値
                    lambda_n[t,i,i]=geninvgauss.rvs(1/2, latent_n[t,i]*(beta-alpha)*0.0000001, scale=0.0000001/alpha,size=1)
            else:
                lambda_n[t,i,i]=0
    for t in range(T-1):
        for i in range(n):
            if smoothed_theta[t+1,i]-smoothed_theta[t,i]>0:
                lambda_beta[t,i,i]=geninvgauss.rvs(1/2, beta*abs(smoothed_theta[t+1,i]-smoothed_theta[t,i]), scale=abs(smoothed_theta[t+1,i]-smoothed_theta[t,i])/beta,size=1)
            else:#エラー時の仮の値
                lambda_beta[t,i,i]=geninvgauss.rvs(1/2, beta*0.0000001, scale=0.0000001/beta,size=1)
    
    #3 lambda_nのサンプリング
    for t in range(T-2):
        for i in range(n):
            p= alpha/beta*np.exp(-(beta-alpha)*abs(smoothed_theta[t,i]-myu))
            latent_n[t,i] = 100 #pが小さいと動かないため、仮の値
            if p>0:
                latent_n[t,i] = np.random.geometric(p)
            
    #Vのサンプリング
    Q=np.zeros((T,m,m))
    Q[:,0,0]=1
    for i in range(1,m):
        Q[0,i,i]=lambda_alpha[0,i-1,i-1]
        Q[T-1,i,i]=lambda_alpha[1,i-1,i-1]
    for t in range(1,T-1):
        for i in range(1,m):
            Q[t,i,i]=lambda_n[t-1,i-1,i-1]
        
    #Y,X,sigma_1,sigma_2,sigma_alpha_0を新しくする
    sigma_alpha_0=V* Q[0,1:m,1:m]
    for t in range(1,T): 
        sigma_1[t-1,:,:]= V* Q[t,:,:]
    for t in range(T-1):
        sigma_2[t,:,:]=V* lambda_beta[t,:,:]
    for t in range(1,T-1):
        for i in range(n):
            if latent_n[t-1,i]>0:
                X[t,1+i,i]=1
                Y[t,i+1]=myu
            else:
                X[t,1+i,i]=0
                Y[t,i+1]=0               
    
    #どんどん保存していく
    V_for_save[it]=V
    for t in range(T):
        for i in range(m):
           Q_for_save[t*m+i,it*m+i]=Q[t,i,i]
           if t<T-1 and i<n:
               lambda_beta_for_save[t*n+i,it*n+i]= lambda_beta[t,i,i]
           if t<T-2 and i<n:
               latent_n_for_save[t*n+i,it]=latent_n[t,i]
           if i<n: 
               smoothed_theta_for_save[t*n+i,it]=smoothed_theta[t,i]
    if it in range(999,100000,1000):           
        np.savetxt('D:/分析用/Q'+str(it)+'.csv', Q_for_save,delimiter=",")
        np.savetxt('D:/分析用/lambda_beta'+str(it)+'.csv', lambda_beta_for_save,delimiter=",")
        np.savetxt('D:/分析用/latent_n'+str(it)+'.csv', latent_n_for_save,delimiter=",")
        np.savetxt('D:/分析用/smoothed_theta'+str(it)+'.csv', smoothed_theta_for_save,delimiter=",")

#    heta_result=np.average(smoothed_theta_for_save[:,5000:9999],axis = 1)   
#    theat_show=np.zeros((n,T))   
#    for t in range(T):
#        for i in range(n):
#            theat_show[i,t]=theta_result[t*n+i]