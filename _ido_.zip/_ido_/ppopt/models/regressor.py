from ..utils.portfolio_evaluator import PortfolioEvaluator
from ..utils.decorater import mystopwatch
import copy
import numpy as np
import pandas as pd
from .dnn_regressor import DeepLearner
from typing import List, Dict
from typing import Optional


class Regressor:
    def __init__(self, hyperparms):
        '''シミュレーションデータを用いてモデル検証を実施するクラス

        Parameters
        ----------        
        hyperparms_company_common : dict
            モデルのパラメータ        
        '''
        self.hyperparms = hyperparms

    def _call_estimator(self, model_name: str):
        hyperparms = copy.deepcopy(self.hyperparms[model_name])
        hyperparms.update({"optuna_scope" : self.hyperparms["optuna_scope"]})
        hyperparms.update({"factor_list" : self.hyperparms["factor_list"]})
        estimator = {
            "dnn": DeepLearner,
        }[model_name](hyperparms)

        return estimator

    @mystopwatch
    def learn(self, estimator, X_train, y_train, X_val, y_val):
        """DNNのパラメータ学習

        Parameters
        ----------
        estimator : function(pytorch module)
            モデル.
        X : pd.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : pd.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : pd.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : pd.DataFrame
            バリデーション期間における被説明変数(時点,)

        Returns
        -------
        estimator : function(pytorch module)
            学習済みモデル.
        
        Notes
        -----
        * is_tuneがTrueの場合，optunaを用いてハイパーパラメータを探索\n
        -> さらにis_pruneがTrueの場合，枝刈りアルゴリズムを使用してチューニングを実施
        -> 最終的に選ばれたハイパーパラメータを用いて再度学習を実施
        """
        if self.hyperparms["is_tune"]:
            if self.hyperparms["is_prune"]:
                # 枝刈りアルゴリズムを使用
                estimator.tune_prune(
                        X_train,
                        y_train,
                        X_val,
                        y_val,
                    )
            else:
                # 枝刈りアルゴリズムを使用しない                
                estimator.tune(
                    X_train,
                    y_train,
                    X_val,
                    y_val,
                )
            self.hyperparms = estimator.update_hyperparams()
            
        estimator.fit(X_train, y_train, X_val, y_val)
        
        return estimator

    @mystopwatch
    def calc_weight(self, y_pred):
        '''予測リターンをもとにポートフォリオを構築

        Parameters
        ----------
        y_pred : pd.DadtaFrame
            モデルの予測リターン.

        Returns
        -------
        weight : np.array
            ポートフォリオのウェイト.
        '''
        df_pred = y_pred.pivot(index="Date", columns="stock", values="pred")
        stock_num = df_pred.shape[1]
        
        if self.hyperparms['portfolio_type'] == 'LongShort':
            score_long = df_pred.apply(lambda x: x - x.quantile(self.hyperparms['long_ratio']))
            score_short = df_pred.apply(lambda x: -(x - x.quantile(self.hyperparms['short_ratio'])))   
            long_num = np.repeat((score_long.values>=0).sum(1)[:, np.newaxis], stock_num, axis=1)
            short_num = np.repeat((score_short.values>=0).sum(1)[:, np.newaxis], stock_num, axis=1)
            weight = (score_long >= 0)/long_num - 1*(score_short >= 0)/short_num
        elif self.hyperparms['portfolio_type'] == 'Long':
            score_long = df_pred.apply(lambda x: x - x.quantile(self.hyperparms['long_ratio']))
            long_num = np.repeat((score_long.values>=0).sum(1)[:, np.newaxis], stock_num, axis=1)
            weight = (score_long >= 0)/long_num - 1*(score_short >= 0)/short_num
        else:
            raise ValueError(
                f'portfolio_type must be long_ratio or short_ratio. : {self.hyperparms["portfolio_type"]}')

        return weight
            
    def get_port_performance(self, weight_test, y_test, hyperparms_portfolio, output_name, business_days):
        '''ポートフォリオのパフォーマンス結果を算出

        Parameters
        ----------
        weight_test : dict
            諸条件のもと算出したポートフォリオのウェイト情報を格納した辞書.\n
            see 'calc_weight' method.
        y_test : 
            各資産のリターン
        hyperparms_portfolio : dict
            ポートフォリオのパラメータ.
        output_name : str
            resultの列名.(任意な列名を設定可能)

        Returns
        -------
        result : dict
            パフォーマンス結果とウェイトの情報を格納した辞書
            weight_testの各valに格納されたweightに対し，以下の結果を格納
            index_portfolio : pd.DataFrame
                ポートフォリオのインデックス推移.
            performance : pd.DataFrame
                ポートフォリオのパフォーマンス結果.
        '''        
        def _calc_port_perform(weight, y_port, hyperparms_portfolio, output_name, business_days):
            pe = PortfolioEvaluator(
                y_port, business_days, hyperparms_portfolio
                )
            return_portfolio = pe.calc_portfolio_return(weight)
            index_portfolio_ = pe.calc_wealth(return_portfolio)
            rt_bench = pe.calc_bench_return()
            bench_portfolio = pe.calc_wealth(rt_bench)
            performance = pe.make_peformance_result(weight, output_name)
            index_portfolio = pd.concat(
                [index_portfolio_, bench_portfolio, index_portfolio_-bench_portfolio], axis=1)
            index_portfolio.columns = [output_name, "bench", "alpha"]
            print(performance)
    
            return index_portfolio, performance
        
        index_portfolio, performance = _calc_port_perform(weight_test, y_test, hyperparms_portfolio, output_name, business_days)

        result = {output_name: {
            "index": index_portfolio,
            "performance": performance,
            }}
        
        return result

