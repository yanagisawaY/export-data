"""
教師学習にて使用するDNNのクラス
"""
import copy
from multiprocessing.sharedctypes import Value
from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd
from .base_estimator import ModelBase
from ..utils.util import check_input


class DeepNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''

    def __init__(self, hyperparms, input_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(DeepNet, self).__init__()
        layer_units = hyperparms['layer_list']
        layer_num = len(layer_units)
        layer = []
        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(input_num, layer_units[0]))
        layer.append(nn.BatchNorm1d(layer_units[0]))
        layer.append(nn.ReLU())
        if layer_num > 1:
            for i in range(layer_num-1):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))
                layer.append(nn.Linear(layer_units[i], layer_units[i+1]))
                layer.append(nn.BatchNorm1d(layer_units[i+1]))
                layer.append(nn.ReLU())

        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(layer_units[-1], 1))
        self.full = nn.Sequential(*layer)

    def forward(self, X):
        output = self.full(X)

        return output.squeeze()


class DeepLearner(ModelBase):
    '''DNNの学習を行うクラス
    '''

    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        super().__init__(hyperparms)
        self.hyperparms = hyperparms
        self.factor_list = hyperparms["factor_list"]        
        self.fit_col = None
        
    def _call_loader(self, X, y, batch_size):
        X, y = self._convert_Xy(X, y)
        X = torch.Tensor(X)        
        y = torch.Tensor(y)
        df = TensorDataset(X, y)
        
        loader = DataLoader(
            df, batch_size=min(batch_size, y.shape[0]), shuffle=False)
        
        return loader
    
    def _convert_Xy(self, X, y):
        """教師学習用のデータセットを作成

        Parameters
        ----------
        X : pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series
            リターンデータ(銘柄×時点,)
            
        Returns
        -------
        X : np.array
            特徴量データ.
        y : np.array
            リターンデータ(銘柄×時点,)
        
        Notes
        -----
        * Xとyの作成において，日付と銘柄の種類を統一
        """
        import pdb
        pdb.set_trace()
        Xy = pd.merge(X, y, how="inner", on=["Date", "stock"])
        is_drop = Xy["ret"]==0
        X = Xy.loc[~is_drop, self.factor_list].values
        y = Xy.loc[~is_drop, "value"].values
        
        return X, y
        
    def fit_yield(self, X, y, X_val, y_val, hyperparms={}):
        '''see also _fit method
        '''                    
        torch.manual_seed(hyperparms['random_state'])        
        loader = self._call_loader(X, y, self.hyperparms["batch_size"])

        if X_val is not None:
            loader_val = self._call_loader(X_val, y_val, y_val.shape[0])
            is_val = True
        else:
            is_val = False

        # 早期停止条件用の設定
        loss_val_min = 10000**100
        patience_count = 0
        upper_patience_count = hyperparms["upper_patience_count"]
        min_epoch = hyperparms["min_epoch"]

        input_num = len(self.factor_list)
        self.model = DeepNet(hyperparms, input_num)
        optimizer = torch.optim.Adam(
            self.model.parameters(), lr=hyperparms['lr'])
        criterion = nn.MSELoss()

        for epoch in range(hyperparms['epoch']):
            for X_t, y_t in loader:
                self.model.train()
                y_pred = self.model.forward(X_t)
                loss = criterion(y_pred, y_t)
                    
                if hyperparms["l2_norm"] > 0:
                    # L2-normの正則化項を追加
                    l2 = torch.tensor(0., requires_grad=True)
                    for w in self.model.parameters():
                        l2 = l2 + hyperparms["l2_norm"]*torch.norm(w)**2
                    loss = loss + l2

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

            if is_val:
                with torch.no_grad():
                    self.model.eval()
                    for X_val, y_val in loader_val:
                        y_val_pred = self.model.forward(X_val)
                        loss_val = criterion(y_val_pred, y_val).item()
                    
                    if loss_val_min > loss_val:
                        # バリデーションデータにおける評価値が最も良いパラメータを保持
                        self.best_params = copy.deepcopy(
                            self.model.state_dict())
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1

                    if patience_count > upper_patience_count and epoch > min_epoch:
                        print(
                            f"[BREAK] {epoch+1}/{hyperparms['epoch']} train {round(loss.item(), 4)} val {round(loss_val, 4)}")
                        break

                    print(
                        f"{epoch+1}/{hyperparms['epoch']} train {round(loss.item(), 4)} val {round(loss_val, 4)}")

                    yield [loss.item(), loss_val]
            else:
                print(
                    f"{epoch+1}/{hyperparms['epoch']} train {round(loss.item(), 4)}")
                yield [loss.item()]
                
    def fit(self, X, y, X_val=None, y_val=None, hyperparms={}):
        '''モデルのパラメータを学習

        Parameters
        ----------        
        X : pandas.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series
            リターンデータ(銘柄×時点,)
        X_val : pd.DataFrame
            バリデーションデータにおける特徴量データ(銘柄×時点, 特徴量)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        y_val : pd.DataFrame
            バリデーションデータにおけるリターンデータ(銘柄×時点,)\n
            -> Noneの場合，バリデーションデータにおける評価値を計算しない
        hyperparms : dict
            ハイパーパラメータの辞書, デフォルトではclassが保持するhyperparamsを参照．

        Return
        ------
        model : 
            学習済みモデル

        Notes
        -----
        * optunaによる刈り取りアルゴリズムを利用できるように_fit_yieldにてyieldを使用
        * tune methodなどでも使用するため，fit methodと分離
        '''
        # データの型チェック
        check_input(X, y)
        if X is not None and y is not None:
            check_input(X_val, y_val)  
            
        if len(hyperparms) == 0:
            hyperparms = copy.deepcopy(self.hyperparms)
        
        loss_save = pd.DataFrame([
            loss_list for loss_list in self.fit_yield(X, y, X_val, y_val, hyperparms)])
        if X_val is None and y_val is None:
            loss_save.columns = ["train"]
        else:
            loss_save.columns = ["train", "val"]

        self.loss_save = loss_save

        if hyperparms["best_params"]:
            self.model.load_state_dict(copy.deepcopy(self.best_params))

    def predict(self, X):
        '''予測リターンを算出
        
        Paramters
        ---------
        X : pd.DataFrame
            特徴量データ(銘柄×時点, 特徴量)

        Return
        ------
        y_pred : pd.DataFrame
            予測リターン(銘柄×時点, 3)
            ※ Date, stock列を追加
        '''
        indices = X[["Date", "stock"]].reset_index(drop=True)
        X = X[self.factor_list].values
        X = torch.Tensor(X)
        y_pred = self.model.forward(X).detach().numpy().copy()
        y_pred = pd.DataFrame(y_pred, columns=["pred"])
        y_pred = pd.concat([indices, y_pred], axis=1)
        
        return y_pred