import copy
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.figure_factory as ff


class Visualizer:
    """plotlyによる可視化の図を作成
    """

    def __init__(self, result: dict, config_factor_data: dict):
        self.result = result
        self.pattern_list = list(result["port_test"].keys())
        self.config_factor_data = config_factor_data
        self.PLOT_RETURN_ROW = 3  # plot_returnにて使用する行数
        self.factor_list = []
        for factor in self.config_factor_data.values():
            self.factor_list += factor
        self.data_type_list = ["train", "test"]
            
    def _set_color_setting(self, key):
        color_palette = {
            "factor_color": px.colors.qualitative.Light24,
            "hidden_color": px.colors.qualitative.Antique,
        }[key]

        return color_palette

    def _make_factor_color(self, config_factor_data):
        factor_category_unique = sorted(
            list(set(config_factor_data.keys())))
        color_list = self._set_color_setting("factor_color")
        assert len(factor_category_unique) <= len(color_list)
        category_color = {
            category: color_list[i] for i, category in enumerate(factor_category_unique)}
        factor_color_dict = {}

            
        factor_color_dict = {factor: category_color[category]
                             for category, val in self.config_factor_data.items()\
                                 for factor in self.factor_list if factor in val}

        return factor_color_dict

    def get_performance_table(self):
        pattern_list = self.result["performance"].keys()

        performance = []
        for pattern in pattern_list:
            if "_train" not in pattern:
                temp = self.result["performance"][pattern]["performance"]
                performance.append(temp.iloc[:, 0])

        performance = pd.concat(performance, axis=1)
        performance = pd.concat([performance, temp.iloc[:, 1]], axis=1)        
        
        fig = go.Figure(
            data=[go.Table(
                header=dict(values=[""] + list(performance.columns)),
                cells=dict(
                    values=[list(performance.index)] + [[j if not isinstance(j, float) or
                                                         isinstance(j, str) or np.abs(j) > 100 else round(j, 3)
                                                         for j in list(performance.iloc[:, i])]
                                                        for i in range(performance.shape[1])])
            )
            ]
        )

        return fig

    def plot_loss(self):
        fig = px.line(self.result["loss_info"])
        fig.update_xaxes(title_text="epoch")
        fig.update_yaxes(title_text="Sharpe Ratio(月率)")

        return fig

    def get_corr_plot(self, pattern):
        figs = []
        for data_type in self.data_type_list:       
            df_port_hidden = self.result["port_{}".format(data_type)][pattern]
                
            hidden_name = [i for i in df_port_hidden.columns if "hidden" in i]
            fig = ff.create_annotated_heatmap(
                df_port_hidden[hidden_name].corr().round(3).values,
                x=hidden_name,
                y=hidden_name,
                annotation_text=df_port_hidden[hidden_name].corr().round(3).values,
                showscale=True).update_yaxes(autorange="reversed")
            fig.update_layout(
                title=dict(
                    text="<b>[{}] <b>【{}】".format(data_type, pattern),
                    font=dict(size=26, color="grey"),
                    y=0.95,
                ),
            )            
            figs.append(fig)

        return figs

    def call_fig_all(self):
        figs = []
        for pattern in self.pattern_list:
            figs += self.call_fig(pattern)
            figs += self.get_corr_plot(pattern)
        figs.append(self.get_performance_table())
        figs.append(self.plot_loss())

        return figs

    def call_fig(self, pattern):        
        figs = []
        for data_type in self.data_type_list:
            df_port_hidden = self.result["port_{}".format(data_type)][pattern]
            if data_type=="train":
                port_lrp_dict = self.result["port_lrp_train"]
                df_port = self.result["performance"]['{}_weight_train'.format(pattern)]['rt_port'].cumsum()
                estimator = self.result["model"]
                factor_coef = self.result['factor_coef_train']
            else:
                df_port = self.result["performance"]['{}_weight'.format(pattern)]['rt_port'].cumsum()
                port_lrp_dict = self.result["port_lrp_test"][pattern]
                factor_coef = self.result['factor_coef_test'][pattern]

            theta = self.result["weight_info"][pattern]["theta"]
            if theta is None:
                weight_active = [i[0].detach().numpy().copy()
                                 for i in estimator.model.last.parameters()][0]
                theta = pd.DataFrame(
                    [weight_active for _ in range(df_port_hidden.shape[0])],
                    index=df_port_hidden.index,
                    columns=[f"hidden_{i}" for i in range(len(weight_active))])
  
            df_lrp = self.extract_lrp(port_lrp_dict, data_type)
            fig = self.call_main_layout(port_name=list(df_port_hidden.columns))
            fig = self.plot_lrp(
                fig, df_lrp)
            fig = self.plot_lrp_coef(fig, factor_coef)
            fig = self.plot_return(fig, df_port, df_port_hidden, theta)
            fig = self.update_layout(fig, data_type, pattern)
            figs += [fig]

        return figs

    def call_main_layout(self, port_name: list):
        fig = go.Figure()
        specs = [[{"colspan": 2, "secondary_y": True}, None] for _ in range(self.PLOT_RETURN_ROW)] + \
                [[{"rowspan": len(port_name) - 1}, {}]] + [[None, {}] for _ in range(len(port_name) - 2)] + \
                [[{"rowspan": len(port_name) - 1}, {}]] + [[None, {}] for _ in range(len(port_name) - 2)]
        fig = make_subplots(
            rows=(len(port_name)-1)*2+self.PLOT_RETURN_ROW,
            cols=2,
            shared_xaxes="all",
            specs=specs,
            subplot_titles=["", "", ""] + port_name,
            vertical_spacing=0.02,
            horizontal_spacing=0.02,
            row_width=[0.52/(len(specs)-3) for _ in range(len(specs)-3)]+[0.12, 0.20, 0.20]
        )
        fig.update_layout(
            # autosize=True,
            width=1600,
            height=2400,
        )

        return fig

    def extract_lrp(self, df_lrp, date_type):
        df_lrp_output = copy.deepcopy(df_lrp)
        
        for key, df_lrp_ in df_lrp_output.items():
            df_lrp_ = df_lrp_.apply(lambda x: x/sum(abs(x)), axis=1)
            df_lrp_ = df_lrp_.reset_index().melt(id_vars="Date", var_name="factor")
            df_lrp_["category"] = df_lrp_["factor"].apply(
                lambda x: [key for key, val in self.config_factor_data.items() if x in val][0])
            df_lrp_output[key] = df_lrp_

        return df_lrp_output

    def plot_lrp(self, fig, dict_lrp):
        factor_color_dict = self._make_factor_color(self.config_factor_data)
        
        for port_id, (key, df_lrp) in enumerate(dict_lrp.items()):
            if port_id == 0:
                row = port_id + 1 + self.PLOT_RETURN_ROW
                col = 1
            else:
                row = port_id + self.PLOT_RETURN_ROW
                col = 2
            x = self.factor_list
            y = df_lrp.set_index(["Date", "factor", "category"]).sum(level=["factor"]).loc[x]
            color_x = [factor_color_dict[factor] for factor in x]
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=list(y.values.squeeze()),
                    marker_color=color_x,
                    text=[key for key, val in self.config_factor_data.items() for j in self.factor_list if j in val],
                    name=key,
                    legendgroup='1',
                    showlegend=False,
                ),
                row=row,
                col=col,
            )
            try:
                vis_rank_num = 3
                y_ = y.abs().sort_values("value", ascending=False).head(vis_rank_num)
                for j in range(vis_rank_num):
                    factor_ = y_.iloc[j,:].name
                    fig.add_annotation(
                        x=factor_,
                        y=y.loc[factor_].values[0],
                        text=factor_,
                        showarrow=True,
                        arrowhead=1,
                        row=row,
                        col=col,
                    )
            except Exception as e:
                print(f"[要チェック] \n{e}")

        return fig

    def plot_lrp_coef(self, fig, factor_coef):
        factor_color_dict = self._make_factor_color(self.config_factor_data)
        
        for port_id, port_name in enumerate(factor_coef.index):
            if port_id == 0:
                row = port_id + self.PLOT_RETURN_ROW + len(factor_coef.index)
                col = 1
            else:
                row = port_id + self.PLOT_RETURN_ROW + len(factor_coef.index) - 1
                col = 2
            x = self.factor_list
            y = list(factor_coef.loc[port_name, x])
            color_x = [factor_color_dict[factor] for factor in x]
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=y,
                    marker_color=color_x,
                    text=[key for key, val in self.config_factor_data.items() for j in self.factor_list if j in val],
                    name=port_name,
                    legendgroup='1',
                    showlegend=False,
                ),
                row=row,
                col=col,
            )
        
        return fig
            
    def plot_return(self, fig, df_port, df_port_hidden, theta):
        hidden_name = [i for i in df_port_hidden.columns if "hidden" in i]
        df_port_hidden = df_port_hidden.cumsum()
        for i, name_ in enumerate(["model", "bench"]):
            fig.add_trace(
                go.Scatter(
                    x=df_port.index,
                    y=df_port[name_],
                    name=name_,
                    line=dict(color=["red", "blue"][i]),
                    legendgroup='2',
                ),
                row=1,
                col=1
            )
        fig.add_trace(
            go.Scatter(
                x=df_port.index,
                y=df_port["active"],
                name="累積超過リターン(rhs)",
                fill="tozeroy",
                mode="none",
                line=dict(color="purple"),
                legendgroup='2',
            ),
            secondary_y=True,
            row=1,
            col=1,
        )
        hidden_color_list = self._set_color_setting("hidden_color")
        for j, name_hidden in enumerate(hidden_name):
            fig.add_trace(
                go.Scatter(
                    x=df_port_hidden.index,
                    y=df_port_hidden[name_hidden],
                    name=name_hidden,
                    legendgroup='3',
                    line=dict(
                        color=hidden_color_list[j],
                        dash='dot'
                    ),
                    xaxis="x2",
                ),
                row=2,
                col=1,
            )

        for j, name_hidden in enumerate(hidden_name):
            fig.add_trace(
                go.Bar(
                    x=df_port.index,
                    y=theta.iloc[:, j].values,
                    text=name_hidden,
                    name=name_hidden,
                    legendgroup='4',
                    showlegend=False,
                    marker=dict(
                        color=hidden_color_list[j],
                    ),
                    xaxis="x2",
                ),
                row=3,
                col=1,
            )

        return fig

    def update_layout(self, fig, data_type, pattern):
        fig.update_layout(
            title=dict(
                text="<b>[{}] <b>【{}】".format(data_type, pattern),
                font=dict(size=26, color="grey"),
                y=0.95,
            ),
            legend=dict(
                x=0,
                y=1,
                orientation="h"
            ),
            xaxis=dict(
                tickformat="%y/%m",
            ),
            xaxis2=dict(
                tickformat="%y/%m",
            ),
        )
        fig.update_xaxes(
            matches="x",
            showspikes=True
        )
        fig.update_yaxes(showspikes=True)

        return fig
