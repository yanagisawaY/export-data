# -*- coding: utf-8 -*-
"""
Notes:
    本コードで使用しているクラス
    StockSimulator
        株式リターンのシミュレーションデータ生成を実施するクラス
    Simulator　-> StockSimulatorを継承
        シミュレーションデータの生成を実施するクラス
"""
import numpy as np
import pandas as pd

class StockSimulator:
    def __init__(self, simulation_setting):
        '''
            株式リターンのシミュレーションデータ生成を実施するクラス

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        
        Notes
        -----
        * i -> 銘柄の添え字
        
        * t -> 時点の添え字
        
        * k -> 企業特性の添え字        
        '''
        self.simulation_setting = simulation_setting        
        self.random_seed = simulation_setting['random_seed']
        self.stock_num = simulation_setting['stock_num']        
        self.time_num = simulation_setting['time_num']
        self.factor_mean = simulation_setting["factor_mean"]
        self.factor_std = simulation_setting["factor_std"]
        self.epsilon_std = simulation_setting["epsilon_std"]
        self.rho = self.simulation_setting["rho"]
        self.phi = self.simulation_setting["phi"]
        np.random.seed(self.random_seed)                
        
    def generate_factor_return(self, factor_mean: float, factor_sigma: float):
        '''
        Returns
        -------
        factor_it : np.array
            ファクターリターン (銘柄，時点)
        '''
        np.random.seed(self.random_seed)
        factor_it = factor_mean + np.random.randn(self.stock_num, self.time_num)*factor_sigma
        
        return factor_it

    def generate_epsilon(self, epsilon_std: float):
        '''
        Returns
        -------
        epsilon_it : np.array
            非システマティックリスクの誤差項(銘柄, 時点)
        '''
        np.random.seed(self.random_seed)                
        epsilon_it = np.random.randn(self.stock_num, self.time_num)*epsilon_std
        
        return epsilon_it

    def generate_characteristic_correlated(self, chars_rho: float):
        '''
        Returns
        -------
        chars_itk : np.array
            相関をもつ企業特性(銘柄，年代, 企業特性数 = 2)
        '''
        np.random.seed(self.random_seed)
        chars_itk = np.zeros((self.stock_num, self.time_num, 2))
        mean = [0, 0]
        cov = [[1, chars_rho], [chars_rho, 1]]
        for i in range(self.stock_num):
            chars_itk[i,:,:] = np.random.multivariate_normal(mean, cov, size=self.time_num)
        
        return chars_itk
            
    def generate_characteristic_autocorrelated(self, phi: float):
        '''
        Returns
        -------
        chars_itk : np.array
            自己相関をもつ企業特性(銘柄，年代, 企業特性数 = 1)
        '''
        np.random.seed(self.random_seed)
        chars_itk = np.zeros((self.stock_num, self.time_num, 1))
        chars_itk[:,0,:] = np.expand_dims(np.random.randn(self.stock_num), axis=1) 
        for t in range(1, self.time_num):
            chars_itk[:,t,:] = phi*chars_itk[:,t-1,:] + np.expand_dims(np.random.randn(self.stock_num), axis=1)

        return chars_itk

    def generate_characteristic_normal(self):
        '''
        Returns
        -------
        chars_itk : np.array
            標準正規分布に従う企業特性(銘柄，年代, 企業特性数 = 1)
        '''
        np.random.seed(self.random_seed)
        chars_itk = np.zeros((self.stock_num, self.time_num, 1))
        for t in range(self.time_num):
            chars_itk[:,t,:] = np.expand_dims(np.random.randn(self.stock_num), axis=1)

        return chars_itk
    
    def get_characteristics(self, mode: int):
        '''企業特性の取得
        
        Parameters
        ----------
        mode : int
            [1] 非線形 + 依存関係
            [2] 非線形+ 依存関係 + 3ファクター
            [3] 非線形 + 依存関係 + 3ファクター + 自己相関
        
        Returns
        -------
        chars_itk : np.array
            ファクター感応度(銘柄，年代, 企業特性数)
        '''
        chrs_itk = self.generate_characteristic_correlated(chars_rho=self.rho)
        if mode==2:
            chrs_itk = np.concatenate([chrs_itk, self.generate_characteristic_normal()], axis=2)
            chrs_itk = np.concatenate([chrs_itk, self.generate_characteristic_normal()], axis=2)            
        elif mode==3:
            chrs_itk = np.concatenate([chrs_itk, self.generate_characteristic_normal()], axis=2)
            chrs_itk = np.concatenate([chrs_itk, self.generate_characteristic_autocorrelated(phi=self.phi)], axis=2)
            
        return chrs_itk

    def get_beta(self, chrs_itk, mode):
        '''
        Returns
        -------
        beta_it  : np.array
            ファクター感応度(銘柄, 時点)
        '''
        # beta_it = 1 + (1 - chrs_itk[:,:,0]**2)*(1 - chrs_itk[:,:,1]**2)
        beta_it = 1 + (1 - chrs_itk[:,:,0]**2)*(1 - chrs_itk[:,:,1]**2)        
        # beta_it = 1 + 100*chrs_itk[:,:,0] - 100*chrs_itk[:,:,1]
        # beta_it = 1 + 2*chrs_itk[:,:,0]*chrs_itk[:,:,1] - 0.3
        if mode==2 or mode==3:
            beta_it += chrs_itk[:,:,2]**2 - 1 + chrs_itk[:,:,3]

        beta_it = (1 + beta_it - np.mean(beta_it, 1, keepdims=True))/(np.std(beta_it, 1, keepdims=True))
                
        print(f"mean - {round(np.mean(np.mean(beta_it, 1)), 4)} std - {round(np.std(np.std(beta_it, 1)), 4)}")
        return beta_it
             
    def sample_return(self, beta_it):
        '''
        Returns
        -------
        r_it  : np.array
            銘柄リターン(銘柄, 時点)
        '''
        factor_it = self.generate_factor_return(self.factor_mean, self.factor_std)
        epsilon_it = self.generate_epsilon(self.epsilon_std)
        r_it = beta_it*factor_it + epsilon_it
         
        return r_it
    
    def sample(self, mode):
        """[summary]

        Parameters
        ----------
        mode : int
            [1] 非線形 + 依存関係
            [2] 非線形+ 依存関係 + 3ファクター
            [3] 非線形 + 依存関係 + 3ファクター + 自己相関

        Returns
        -------
        chrs_itk : np.array
            企業特性データ(銘柄, 時点, 企業特性数)
        r_it : np.array
            銘柄リターン(銘柄, 時点)
        """
        chrs_itk = self.get_characteristics(mode)       
        beta_it = self.get_beta(chrs_itk, mode)
        r_it = self.sample_return(beta_it)
    
        return chrs_itk, r_it


class Simulator(StockSimulator):
    def __init__(self, simulation_setting):
        '''
            シミュレーションデータ生成を実施するクラス

        Parameters
        ----------
        simulation_setting : dict
            シミュレーションデータ作成時の設定ファイル.
        '''
        super().__init__(simulation_setting)
        self.mode = simulation_setting["mode"]
        self.redundant_num = simulation_setting['redundant_num']
        self.redundant_noise = simulation_setting['redundant_noise']
        self.redundant_coef = simulation_setting['redundant_coef']
        self.factor_noise_num = simulation_setting['factor_noise_num']
        self.factor_noise = simulation_setting['factor_noise']
        
    def make_factor_dict(self, chrs_itk):
        '''
            企業特性データを辞書形式で保存

        Parameters
        ----------
        chrs_itk : np.array
            企業特性データ.(銘柄，時点, 企業特性数)

        Returns
        -------
        factor_dict : dict
            企業特性データが格納された辞書.
        factor_I : list
            企業特性データの名前（I_1，などの名前を設定）.
        '''
        factor_dict = {}
        factor_I = []
        for i in range(chrs_itk.shape[2]):
            name = 'I_'+str(i)
            factor_I.append(name)
            factor_dict[name] = pd.DataFrame(chrs_itk[:,:,i].T, columns=self.stock_names)

        return factor_dict, factor_I

    def generate_redundancy(self, factor_dict, factor_I):
        '''冗長な企業特性を生成

        Parameters
        ----------
        factor_dict : dict
            企業特性データの辞書.
        factor_I : list
            企業特性データの名前（I_1，などの名前を設定）.

        Returns
        -------
        factor_dict : dict
            冗長な特徴量が追加された企業特性データの辞書.
        
        Notes : 
            coef(有効な企業特性にかける係数)は0~0.8の一様乱数より設定    
            ➡SDFに含まれるファクターよりはシグナルが弱いという設定
        '''
        prob = [1/len(factor_I) for _ in range(len(factor_I))]
        
        coef_redundant = []
        redundant_chosen = {}
        for j in range(self.redundant_num):
            np.random.seed(self.random_seed + j)
            name_I = np.random.choice(factor_I, p=prob)
            name = 'R_' + str(j)
            coef = np.random.rand()*self.redundant_coef
            temp = factor_dict[name_I]*coef + np.random.randn(self.time_num, self.stock_num)*self.redundant_noise
            factor_dict[name] = pd.DataFrame(temp, columns=self.stock_names)   
            coef_redundant += [coef]
            redundant_chosen[name] = name_I
                    
        coef_redundant = pd.Series(coef_redundant)
        coef_redundant.index = list(redundant_chosen.keys())
        redundant_chosen = pd.DataFrame(redundant_chosen.values(), index=redundant_chosen.keys())
        self.redundant_chosen = pd.concat([redundant_chosen, coef_redundant], axis=1)
        self.redundant_chosen.columns = ['factor', 'coef']
        
        return factor_dict
    
    def generate_noise(self, factor_dict):
        '''無関係な企業特性を生成

        Parameters
        ----------
        factor_dict : dict
            企業特性データの辞書.

        Returns
        -------
        factor_dict : dict
            企業特性とは無関係なデータが追加された企業特性データの辞書.
        '''
        for j in range(self.factor_noise_num):
            np.random.seed(self.random_seed + j)                    
            name = 'N_' + str(j)
            temp = np.random.randn(self.time_num, self.stock_num)*self.factor_noise
            factor_dict[name] = pd.DataFrame(temp, columns=self.stock_names)
            
        return factor_dict
    
    def make_simulation_data(self):
        '''
            シミュレーションデータを生成

        Returns
        -------
        df_all : pd.DataFrame
            シミュレーションデータ.
        '''
        chrs_itk, r_it = self.sample(mode=self.mode)
        self.stock_names = ['stock_'+str(i) for i in range(self.stock_num)]
        r_ti = pd.DataFrame(r_it.T)
        r_ti.columns = self.stock_names
        factor_dict_, self.factor_I = self.make_factor_dict(chrs_itk)
        if self.redundant_num > 0:
            factor_dict_ = self.generate_redundancy(factor_dict_, self.factor_I)
        if self.factor_noise_num > 0:
            factor_dict = self.generate_noise(factor_dict_)
        else:
            factor_dict = factor_dict_
            
        from dateutil.relativedelta import relativedelta
        import datetime as dt
        today = dt.datetime.now()
        index_ = [dt.datetime(today.year, today.month, today.day)]
        for t in range(1, r_ti.shape[0]):
            index_before = index_[t-1] - relativedelta(months=1)
            index_ += [index_before]
        index_.reverse()
        r_ti["index"] = pd.to_datetime(index_)
        df_all = r_ti.melt(id_vars="index")
        df_all.columns = ["Date", "stock", "return"]        
        for key, df_factor in factor_dict.items():
            df_factor["index"] = index_
            temp = df_factor.melt(id_vars="index")
            temp.columns = ["Date", "stock", key]
            df_all = pd.merge(df_all, temp, how="left", on=["Date", "stock"])

        return df_all
    