hyperparms = {
    # ネットワークの設定
    "model": "UtilityTrader",  # モデル名(UtilityTrader以外は想定していない)
    "random_state": 1,  # 乱数シード
    "batch_size": None,  # バッチサイズ（1バッチは1か月データに相当．Noneの場合，全データを使用してバッチ学習を実施）
    "Norm_mode": "BatchNorm",  # XSNorm -> クロスセクション方向に0,1で基準化，BatchNorm -> バッチ正規化
    "layer_list": [64, 4], # [30, 20, 4],  # 深層学習の各レイヤーのユニット数(リストのサイズが中間層の数)
    "layer_dropout": 0.05,  # ドロップアウト(oncアルゴリズムに使用する場合，直交制約)
    "l2_norm": 0, # 1e-3,  # l2正則化項への罰則
    "lr": 1e-3,  # Adamに適用する学習率
    "epoch": 500,  # エポック数
    "newton_T": 8,  # ONCアルゴリズムを適z用する場合の繰り返し回数
    "best_params": True,  # バリデーションデータの評価値が最もよいハイパーパラメータを採用する場合True
    "network_type": "onc",  #"None", # ネットワーク構造の指定 onc -> ONCアルゴリズムを適用,しない場合は"None"
    "upper_patience_count": 10000, # バリデーションデータがupper_patience_count回連続して向上しないことが続いた場合，早期停止を実施
    "min_epoch": 10000, # upper_patience_countによる早期停止を適用しない最低学習回数    
    
    "val_ratio": 0.25,  # バリデーションデータに使用するデータ割合

    # 目的関数の設定(utility_type = 'SR', 'return_mode' = 'active'の場合，IR最大化となる)
    "utility_type" : "SR",  # SR -> シャープレシオ(R/R)最大化, MV -> 最小分散, CRRA -> CRRA型効用最大化
    "return_mode": "active",  # active -> アクティブリターンを使用して目的関数を最大化, all -> ベンチマーク含めたポートフォリオリターンを使用して目的関数最大化
    "gamma": 10,  # CRRA型効用を用いる場合のリスク回避係数
    
    # ネットワークの学習結果をもとに実施する最適化の設定
    # target_riskとturnoverの組み合わせの全パターンに対し，制約付きアクティブリターン最大化問題を実施
    # target_riskがNoneであり，turnoverもNoneであるパターンは制約付きアクティブリターン最大化問題を実施しない
    "target_risk": [
        None, 
        # 0.1
        ],  # 制約付きアクティブリターン最大化問題におけるターゲットリターン
    "turnover": [
        None,
        # 0.02,
        ],  # 制約付きアクティブリターン最大化問題におけるターンオーバー上限
    "stock_limit": [
        None, 
        250,
        ],  # リバランス時にウェイトが大きく変わる上位銘柄のみ取引する場合におけるリバランスする銘柄の上限数，Noneの場合制限を設けない

    # optunaの設定
    "is_tune": False,  # optunaによるハイパラ探索をする場合はTrue
    "is_prune": True,  # 枝刈りアルゴリズムを使用する場合はTrue
    'n_trials': 100,  # optunaによる試行回数
    'timeout': 3600*8,  # optunaによる探索の計算時間上限（秒）．timeout秒を超えると強制的に探索を打ち切る  
    
    # =============================================================================
    # # optunaのハイパーパラメータ探索範囲(models.base_estimator.tune or tune_pruneにて使用)
    # =============================================================================
    "optuna_scope":{
        "lr" : (1e-5, 1e-3),  # Adamに適用する学習率(trial.suggest_float, log=True)
        "layer_dropout": (0, 0.2),  # ドロップアウト(trial.suggest_uniform)
        "n_layers": (0, 2),  # ネットワークの層数(trial.suggest_int)
        "n_units": (4, 64),  # 中間層のユニット数(trial.suggest_int)
        "n_units_last": (3, 6),  # 最終層のユニット数(trial.suggest_int)
        },
}