import numpy as np

#######################################################################
def FFBS(Y,X,mu_alpha_0,sigma_alpha_0,G,sigma_1,sigma_2):
    #J.DURBIN&S.J.KOOPMAN(2002)
    #https://www.jstor.org/stable/4140605?seq=1
    #Y = X × alpha+ sigma_1(時変の重回帰)
    #alpha_t = G × alpha_t-1 + sigma_2を考える(Rは単位行列を仮定)
    
    #入力
    # Y         ---- 観測方程式のアウトプット (T期) 上から下に、過去から将来へなっているデータ
    # X         ---- 観測方程式の説明変数 (T期 ×　次元n) 上から下に、過去から将来へなっているデータ、事前に定数項を入れる必要あり
    # mu_alpha_0    ---- 時点0の回帰係数の平均(事前分布) (次元n) 
    # sigma_alpha_0 ---- 時点0の回帰係数の分散(事前分布) (次元n × 次元n)
    # G         ---- transition_matrices　(T期 ×　次元n ×　次元n)
    # sigma_1   ---- 観測方程式のボラ　(T期) 
    # sigma_2   ---- 状態方程式のボラ　(T期 ×次元n ×　次元n)
    
    #出力
    # smoothed_alpha     ---- スムージングされた回帰係数 (T期 ×　次元n)

    #見やすくするため文字の置き換え
    T=Y.shape[0] #データ期間
    n=sigma_2.shape[1] #説明変数の数
    
    #以下、Algorithm2の1
    alpha_0_plus = np.random.multivariate_normal(mu_alpha_0.T, sigma_alpha_0) #初期値の乱数生成
    
    omega  = np.zeros((T+T*n,T+T*n)) 
    for t in range(T):
        omega[t,t]=sigma_1[t]
    for t in range(T):
        for i in range(n):
            for s in range(n):
                omega[T+t*n+i,T+t*n+s]=sigma_2[t,i,s]       
    w_plus = np.random.multivariate_normal(np.zeros(T+T*n), omega) #omegaからwの乱数生成
    
    Y_plus = np.zeros(T)
    alpha_plus = np.zeros((T,n))
    alpha_plus[0,:]=alpha_0_plus
    for t in range(T):
        Y_plus[t]=X[t,:]@alpha_plus[t,:]+ w_plus[t]
        if t<T-1: #将来予測は使わないため
            alpha_plus[t+1,:]=G[t,:,:]@alpha_plus[t,:]+ w_plus[T+t*n:T+(t+1)*n]

    #以下、Algorithm2の2
    def Kalman_filter_and_smoother(Y):
        v = np.zeros(T)
        K = np.zeros((T,n))
        a = np.zeros((T,n))
        F = np.zeros(T)
        L = np.zeros((T,n,n))
        P = np.zeros((T,n,n))
        a[0,:] = mu_alpha_0
        P[0,:,:] = sigma_alpha_0
        for t in range(T): #Kalman filter 式(3)
            v[t] = Y[t]-X[t]@a[t,:]
            F[t] = X[t,:]@P[t,:,:]@X[t,:].T + sigma_1[t]
            K[t,:] = G[t,:,:]@P[t,:,:]@X[t,:].T/F[t]
            L[t,:,:] = G[t,:,:]-K[t,:]@X[t,:]
            if t<T-1:#将来予測は使わないため
                a[t+1,:] = G[t,:,:]@a[t,:] + K[t,:]*v[t]
                P[t+1,:,:] = G[t,:,:]@P[t,:,:]@L[t,:,:].T + sigma_2[t,:,:]
        r = np.zeros((T,n))
        for t in reversed(range(1,T)): # smoother 式(4)
            r[t-1,:] = X[t,:]/F[t]*v[t] + L[t,:,:].T@r[t,:]
        alpha_hat = np.zeros((T,n))
        alpha_hat[0,:] = a[0,:]+P[0,:,:]@(X[0,:]/F[0]*v[0] + L[0,:,:].T@r[0,:])
        for t in range(T-1):
            alpha_hat[t+1] = G[t,:,:]@alpha_hat[t] + sigma_2[t,:,:]@r[t,:]
        return alpha_hat
    alpha_hat = Kalman_filter_and_smoother(Y)
    alpha_hat_plus = Kalman_filter_and_smoother(Y_plus)
    
    #以下、Algorithm2の3
    smoothed_alpha = alpha_hat - alpha_hat_plus + alpha_plus
    return smoothed_alpha
    