# -*- coding: utf-8 -*-
"""
シミュレーション結果の集計に関する関数
Notes:
    本コードで使用しているクラス・関数
    convert_df
        シミュレーションごとの結果が格納されたdict型の結果からパフォーマンスに関する結果を抽出
"""
import pandas as pd

def convert_df(output, model_list, original_model_name = 'AE'):
    '''
        シミュレーションごとの結果が格納されたdict型の結果からパフォーマンスに関する結果を抽出

    Parameters
    ----------
    output : dict
        全てのシミュレーションパターンにおける結果が格納された辞書.
    model_list : list
        比較用のモデル名が格納されたリスト
    original_model_name : str
        オリジナルのモデルの名称(AEと呼称することにした)

    Returns
    -------
    df_all : pd.DataFrame
        全てのシミュレーションパターンにおける精度評価結果を格納したデータフレーム.
    '''
    df_all = []
    for key, val in output.items():
        temp = val['performance'].copy()
        df = pd.melt(temp)
        
        # シミュレーション番号の抽出
        df['sim'] = df['variable'].apply(lambda x: x.split('sim')[1].split('_')[0])

        # 精度指標の名称抽出 
        metric_col = []
        for _ in range(temp.shape[1]):
            metric_col += list(temp.index)                        
        df['metric'] = metric_col

        # モデルの名称設定
        model_col = []
        for model_name in ([original_model_name] + model_list):
            model_col += [model_name]*temp.shape[0]            
        df['model'] = model_col
        
        df_all.append(df)
        
    df_all = pd.concat(df_all).drop('variable', axis=1)
    col_names = ['sim', 'model', 'metric', 'value']        
    df_all = df_all[col_names]
    
    return df_all
