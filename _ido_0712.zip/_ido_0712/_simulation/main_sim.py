# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    Experimenterクラスよりシミュレーションデータを用いたモデル検証を実施
    ハイパーパラメータ設定やシミュレーション設定を本コードにて実施
"""
import os
import datetime as dt
# パスの設定
PATH_HEAD = r'C:\Users\猛\Desktop\yoshiki_study\cross_section_ensemble'
os.chdir(PATH_HEAD)
from _simulation.experimenter import Experimenter

#%%
# =============================================================================
# # モデルのハイパーパラメータ設定
# =============================================================================
hyperparms_company_common = {
    'N_trader'            : 500,
    'M_strategy'          : 2,
    'K_factor'            : 3,    
    'Aggregate'           : 'quantile', # 'average', 'quantile', 'cluster'
    'Q_quantile_educate'  : 0.5,
    'lag'                 : 1,        
    'rebalance_term'      : 20,
    'random_seed'         : 7777,
    'method_measure'      : 'SR', # 'CR', 'SR', 'DDR'
    'method_sampling'     : 'GMM',    
    'fit_times'           : 50,
    'GMM_n_components'    : 10,
    'trader_long'         : 0.90,
    'trader_short'        : 0.1,    
    'trader_type'         : 'LongShort',
    'cost'                : 0, # 0.005,
    'Aggregate_quantile'  : 0.5,
    'max_num_clusters'    : 5,
    'n_init_clusters'     : 3,
    'log_quantile'        : [10, 25, 50, 75, 90],
    }
'''
hyperparms_company_common : ハイパーパラメータ
    'N_trader_num'        : トレーダー数
    'Aggregate'           : 集約方法の指定
            'average'        : トレーダーのポートフォリオを等ウェイトでアンサンブル
            'quantile'       : 上位Aggregate_quantileのトレーダーのポートフォリオを等ウェイトでアンサンブル
            'clusetr'        : トレーダーをONCクラスタリングし，それぞれのクラスタごとに等ウェイトポートフォリオを形成
                                ⇒各インデックスのリターン，リスクよりシャープレシオ最大化を実施してウェイトを実施し，アンサンブルウェイトを決定
    'Q_quantile_educate'  : パフォーマンスの悪いトレーダーを生成する際の閾値割合
    'formula_num_max'     : 各トレーダーの戦略（公式）の候補数の最大値
    'lag'                 : 説明変数の時点と被説明変数の時点のラグ
    'rebalance_term'      : リバランスの頻度（説明変数のサンプリング頻度）
    'random_seed'         : ランダムシード
    'method_measure'      : トレーダーのパフォーマンス測定基準
            'CR'              : 累積リターン
            'SR'　　　　　　　　　　　: シャープレシオ
            'DDR'             : DDR(リスクが半分散)
    'method_sampling'     : トレーダー生成時のサンプリング方法
            'GMM'             : 混合正規分布によるサンプリング
    'fit_times'           : レーダー生成の繰り返し回数
    'GMM_n_components'    : 混合正規分布のフィット時におけるクラスター数
    'Aggregate_quantile'  : Aggregeteをquantileを選択した場合の閾値割合
    'max_num_clusters'　　　: Aggregeteをclusetrを選択した場合の最大クラスタ数
    'n_init_clusters'     : Aggregeteをclusetrを選択した場合の初期化計算繰り返し数
    'log_quantile'        : 各トレーダーのパフォーマンス指標のうち，指定したクオンタイル値に対しログをとる
'''

# =============================================================================
# # バックテスト時の設定
# =============================================================================
hyperparms_portfolio = {
    'cost_buy'               : 0,
    'cost_sell'              : 0,
    'calc_type'              : 'cumulative',    
    'wealth_init'            : 100,    
    }

'''
hyperparms_portfolio : dict
    wealth_init            : 初期富
    cost_buy               : 銘柄購入時のコスト
    cost_sell              : 銘柄売却時のコスト
    calc_type              : ポートフォリオの累積リターン(accumulation),累和リターン(cumulative)のいずれかで計算            
'''
    
# =============================================================================
# # シミュレーションデータの設定
# =============================================================================
simulation_setting = {
    # 乱数シード
    'random_seed'      : 1,
    
    # 訓練データとテストデータを分割するインデックスの数値. The default is 0.
    # 0を指定した場合，データの半分を訓練データ，残りをテストデータとするように分割
    'train_num'        : 0,
    
    # データセットサイズ関連(銘柄, 時点， 年代)
    'stock_num'        : 500,
    'time_span'        : 12,
    'year_term'        : 10,
    
    # 非システマティックリスクの誤差項(銘柄, 時点， 年代)
    'sigma_epsilon'    : 0.05,
    
    # マーケットリターンの平均と標準偏差(銘柄，年代)
    'market_u'         : 0.01,
    'market_sigma'     : 0.04,
    
    # マーケットリターンへの感応度(銘柄，年代)
    'beta_u'           : 1,
    'beta_sigma'       : 0.1,
    
    # アルファリターンの誤差項(銘柄，年代)
    'alpha_sigma'      : 0.01,

    # 期間yごとに変動する企業特性への感応度(年代, 企業特性)
    'regime0_mean'       : [0.01 for _ in range(10)],
    'regime0_sigma'      : 0.02,
    'regime1_mean'       : [0 for _ in range(10)],
    'regime1_sigma'      : 0.02,
    
    # レジームスイッチングの初期状態の所属確率
    'regime_0_init'      : 1,
    'regime_1_init'      : 0,
    # レジームスイッチングの推移確率行列の対角成分(同じ状態にとどまる確率)
    'regime_0_stay'      : 0.9,
    'regime_1_stay'      : 0.99,
     
    # 冗長な企業特性データの生成
    'redundant_num'    : 30,
    'redundant_noise'  : 0.5,
    # 有効な企業特性にかける係数の最大値 ➡1より小さくすることでアノマリーのあるファクターよりはシグナルが弱いという設定
    # 係数は0~redundant_coefの一様乱数より生成
    'redundant_coef'   : 0.3, 
    
    # ノイズな企業特性データの生成
    'factor_noise_num' : 30,
    'factor_noise'     : 1,
    }

# 比較モデルのハイパーパラメータ
hyperparms_comparative = {
    # 比較モデルの学習等を実施する場合はTrue
    'is_comparison'       : True,
    # 検証する比較モデルの名前
    'model_list'          : [
        'lasso', 
        'randomforest', 
        'lightgbm'
        ],
    
    # Lasso回帰のハイパーパラメータ    
    'params_lasso'        : 
        {
        'random_state'    : 1,
        'cv'              : 5,        
        },

    # ランダムフォレスト回帰のハイパーパラメータ            
    'params_randomforest' : 
        {
        'random_state'    : 1,
        'n_estimators'    : 100,        
        },

    # LightGBM回帰のハイパーパラメータ            
    'params_lightgbm' : 
        {
        'random_state'    : 1,
        'boosting_type'   : 'gbdt',
        'silent'          : False,
        'n_estimators'    : 100,        
        },
        
    # スコアに対してLS戦略を組む際のパーセンタイル
    'long_ratio'          : 0.90,
    'short_ratio'         : 0.1,
    
    # LongShort or Long / スコアに基づくポートフォリオ構築方法
    'portfolio_type'      : 'LongShort',    
    }

#%%
if __name__ == '__main__':
    time_now = dt.datetime.now().strftime("%y%m%d_%H%M%S")
    output = {}
    seed_pattern = 50
    
    sim_states = {}
    sim_coef = {}
    for seed in range(1, seed_pattern+1):
        output_name = 'sim' + str(seed)
        print(f'実行中 / {output_name}')
        simulation_setting['random_seed'] = seed
        hyperparms_company_common['random_seed'] = int(seed*2+1)
        ex = Experimenter(hyperparms_company_common)
        output.update(ex.get_simulation_result(simulation_setting, hyperparms_portfolio, hyperparms_comparative, output_name))
        
        # シミュレーションデータに関する情報
        sim_states[output_name] = ex.get_simulation_states()
        sim_coef[output_name] = ex.sim.redundant_chosen

    # 結果の出力
    output_all = {
        'output'                    : output,
        'hyperparms_company_common' : hyperparms_company_common,
        'hyperparms_portfolio'      : hyperparms_portfolio,
        'hyperparms_comparative'    : hyperparms_comparative,

        # シミュレーションデータに関するデータ
        'simulation_setting'        : simulation_setting,                
        'sim_states'                : sim_states,
        'sim_coef'                  : sim_coef,       
        }
    
    path_output = PATH_HEAD + '\\Result\\simulation\\' + time_now
    os.makedirs(path_output, exist_ok=True)    
    ex.output_result(output_all, path_output)
