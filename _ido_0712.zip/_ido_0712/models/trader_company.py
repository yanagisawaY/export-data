# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf
上記論文ををコンセプトに，これらをクロスセクションをベースにしたポートフォリオ構築モデルに拡張

Notes:
    
"""
import numpy as np
import pandas as pd
import time
from models.company import Company

class TraderCompany(Company):
    def __init__(self, hyperparms_company_common):
        self.hyperparms_company_common = hyperparms_company_common
        self.method_measure = hyperparms_company_common['method_measure']
        self.fit_times = hyperparms_company_common['fit_times']
        self.method_sampling = hyperparms_company_common['method_sampling']
        self.aggregate_method = hyperparms_company_common['Aggregate']
        self.factor_list = hyperparms_company_common['factor_list']
        self.stock_list = hyperparms_company_common['stock_list']
        self.random_seed = hyperparms_company_common['random_seed']
        self.log_quantile = hyperparms_company_common['log_quantile']
        assert isinstance(self.log_quantile, list)
        
    def check_df_columns(self, X_train, y_train=pd.DataFrame()):
        '''
            データの列名をstock_listに一致させる
        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : pandas.DataFrame
            被説明変数データ.
            
        Returns
        -------
        X_train, y_train --> 列名をstock_listと同一にする
        '''        
        assert isinstance(X_train, dict), f'X_trainはdict型として入力 : {type(X_train)}として入力されています'
        assert isinstance(y_train, pd.DataFrame), f'y_trainはpd.DataFrame型として入力 : {type(y_train)}として入力されています'
        assert len(self.stock_list)>0, 'stock_listが空です'
        
        X_train = {key : val[self.stock_list] for key, val in X_train.items()}
        
        if len(y_train) > 0:
            y_train = y_train[self.stock_list]
        
        return X_train, y_train
    
    def normalize_factor(self, X):
        '''
            各ファクターの値を0-1ランク化

        Parameters
        ----------
        X : dict(pandas.DataFrameによる辞書)
            特徴量データ.

        Returns
        -------
        X : dict(pandas.DataFrameによる辞書)
            0-1ランク化後特徴量データ.
        '''
        X_norm = np.array([np.argsort(np.argsort(df.values, axis=1), axis=1)/df.shape[1] for df in X.values()])
        
        return X_norm
        
    def learn_trader(self, X_train, y_train, ticker_info={}):
        '''
            トレーダーのパラメータを学習
        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : pandas.DataFrame
            被説明変数データ.
            
        Returns
        -------
        factor_weight : np.array
            トレーダーの各戦略におけるファクターウェイト (トレーダー, 戦略, ファクター)
        strategy_weight : np.array
            各トレーダーにおける各戦略への投資ウェイト (トレーダー, 戦略)        
        universe_mask : np.array
            ユニバースマスク(トレーダー, 時点，銘柄)
        traders_performance_log : pd.DataFrame
            トレーダーのfit_timesごとのパフォーマンス分位点            
        '''
        factor_num = len(X_train)
        super().__init__(self.hyperparms_company_common, factor_num)  
        start = time.time()
        
        # データの列名をstock_listに一致させる
        X_train, y_train = self.check_df_columns(X_train, y_train)

        # ユニバースマスクの作成 (トレーダー, 時点，　銘柄)
        screaning_mask, self.traders_sector = self.make_screaning_mask(ticker_info, y_train.shape[0], y_train.shape[1])
        universe_mask = self.make_universe_mask(screaning_mask = screaning_mask,
                                                tradable_mask = self.make_tradable_mask(y_train))
                
        # 各ファクターの値を0-1ランク化
        X_train = self.normalize_factor(X_train)
        
        # step1:パラメータの初期値取得
        factor_weight, strategy_weight, self.mask_factor, self.mask_strategy = self.get_all_traders_init()                
        traders_return = self.calc_return(factor_weight, strategy_weight, universe_mask, X_train, y_train)
        print('step1 : '+str(round(time.time() - start))+'sec')
        
        # step2:剪定，生成        
        traders_performance_log = []
        for f in range(self.fit_times):
            random_seed = f + self.hyperparms_company_common['random_seed']      
            factor_weight, strategy_weight, traders_performance_log_ = self.generate_traders(traders_return, factor_weight, strategy_weight, random_seed)
            traders_return = self.calc_return(factor_weight, strategy_weight, universe_mask, X_train, y_train)
            print(f'step2 {f+1}/{self.fit_times} : {str(round(time.time() - start))}sec')
            traders_performance_log.append(traders_performance_log_)
        
        self.traders_return = traders_return

        # step3 : 集約
        if self.aggregate_method == 'average':
            self.company_traders_weight = np.ones((traders_return.shape[1]))/traders_return.shape[1]
        elif self.aggregate_method == 'quantile':
            self.company_traders_weight = self.aggregate_traders_weight_quantile()
        elif self.aggregate_method =='cluster':
            traders_weight_train = self.calc_traders_weight_all(self.calc_traders_weight(\
                             *self.make_scores(factor_weight, universe_mask, X_train)), strategy_weight)
            self.company_traders_weight = self.aggregate_traders_weight_cluster(traders_return, traders_weight_train, y_train)
        else:
            raise ValueError(f'aggregate_methodは，{self.aggregate_method}には対応していません')
            
        print('step3 : '+str(round(time.time() - start))+'sec')
        
        return factor_weight, strategy_weight, universe_mask, traders_performance_log

    def generate_traders(self, traders_return, factor_weight, strategy_weight, random_seed):
        '''Good Tradersのパラメータ分布をもとにBad Tradersのパラメータを更新
        '''        
        # パフォーマンスの悪いトレーダーIDを抽出
        is_bad_traders, traders_performance = self.collect_bad_traders(traders_return, self.method_measure)                                   
        traders_performance_log = np.percentile(traders_performance, q=self.log_quantile)

        # パフォーマンスの良い・悪いトレーダーのパラメータを抽出
        df_params = self.make_parameters_list(factor_weight, strategy_weight, self.traders_sector)
        bad_traders_ID = np.where(is_bad_traders)[0]            
        bad_traders = self.extract_traders(df_params, bad_traders_ID)
        good_traders_ID = np.where([not x for x in is_bad_traders])[0] 
        good_traders = self.extract_traders(df_params, good_traders_ID)            
                
        # パフォーマンスのよいトレーダーのパラメータをもとに混合正規分布にフィットさせ，悪いトレーダーのパラメータをサンプリングにより更新
        bad_traders_new = self.sample_gaussian_mix(good_traders, bad_traders, random_seed)        
        df_params_new = np.concatenate([good_traders, bad_traders_new])                
        factor_weight, strategy_weight = self.make_tensor_from_params(df_params_new)
       
        return factor_weight, strategy_weight, traders_performance_log
            
    def aggregate(self, traders_weight_all):
        '''
            各トレーダの予測値を集約し，ポートフォリオのウェイト出力
            step3 : 集約で決定したself.company_traders_weightにより，トレーダーのウェイトを集約
            
        Parameters
        ----------
        traders_weight_all : numpy.array
            トレーダーの全戦略の投資ウェイト. : (トレーダー, 時点, 銘柄)
        Returns
        -------
        weight : numpy.array
            集約したポートフォリオのウェイト.
        '''
        weight = np.einsum("mts, m->ts", traders_weight_all, self.company_traders_weight)

        return weight
    
    def fit(self, X_train, y_train, ticker_info):
        '''
            パラメータの学習を実施

        Parameters
        ----------
        X_train : dict(pandas.DataFrameによる辞書)
            特徴量データ.
        y_train : np.array or pandas.DataFrame
            被説明変数データ.
        ticker_info : dict
            各銘柄の属性データ（セクター情報など）
        '''
        assert isinstance(ticker_info, dict), 'ticker_infoはdict形式として入力してください'
        assert isinstance(X_train, dict), 'X_trainはdict形式として入力してください'

        self.factor_weight, self.strategy_weight, \
            self.universe_mask, self.traders_performance_log = self.learn_trader(X_train, y_train, ticker_info)
    
    def predict(self, X, ticker_info, y_test=pd.DataFrame()):
        '''
            トレーダーの全戦略の投資ウェイトを算出

        Parameters
        ----------
        X : dict
            特徴量データ.
        ticker_info : dict
            各銘柄の属性データ（セクター情報など）            
        y_test : np.array or pandas.DataFrame
            テストデータにおける被説明変数データ.
            
        Returns
        -------
        traders_weight : np.array
            トレーダーの全戦略の投資ウェイト. : (時点, 銘柄)
            y_testをインプットした場合，traders_performance(テスト期間中の各トレーダーのパフォーマンス)も出力        
        '''
        X, y_test  = self.check_df_columns(X, y_test)
            
        X = np.array([df.values for df in X.values()])
        time_num = X.shape[1]
        stock_num = X.shape[2]
                
        # ユニバースマスクの作成 (トレーダー, 時点，　銘柄)
        screaning_mask, _ = self.make_screaning_mask(ticker_info, time_num, stock_num, self.traders_sector)
        universe_mask = self.make_universe_mask(screaning_mask = screaning_mask,
                                                tradable_mask = self.make_tradable_mask(X_test=X))
                
        traders_weight = self.aggregate(self.calc_traders_weight_all(self.calc_traders_weight(\
             *self.make_scores(self.factor_weight, universe_mask, X)), self.strategy_weight))
            
        if len(y_test) > 0:
            traders_return = self.calc_return(self.factor_weight, self.strategy_weight, universe_mask, X, y_test)
            traders_performance = self.measure_trader_return(traders_return, method_measure=self.method_measure)
            
            return traders_weight, traders_performance
        else:
            return traders_weight
        
    def predict_traders(self, X, ticker_info):
        '''
            トレーダーの全戦略の投資ウェイトを算出（統合しない）

        Parameters
        ----------
        X : dict
            特徴量データ.
        ticker_info : dict
            各銘柄の属性データ（セクター情報など）            
            
        Returns
        -------
        traders_weight_all : np.array
            トレーダーの全戦略の投資ウェイト. : (トレーダー, 時点, 銘柄)
        '''
        X = np.array([df.values for df in X.values()])
        time_num = X.shape[1]
        stock_num = X.shape[2]
                
        # ユニバースマスクの作成 (トレーダー, 時点，　銘柄)
        screaning_mask, _ = self.make_screaning_mask(ticker_info, time_num, stock_num, self.traders_sector)
        universe_mask = self.make_universe_mask(screaning_mask = screaning_mask,
                                                tradable_mask = self.make_tradable_mask(X_test=X))
                
        traders_weight_all = self.calc_traders_weight_all(self.calc_traders_weight(\
             *self.make_scores(self.factor_weight, universe_mask, X)), self.strategy_weight)
            
        return traders_weight_all
    
    def get_params_info(self, factor_weight, strategy_weight):
        '''
            各トレーダの戦略パラメータの情報を抽出

        Parameters
        ----------
        hyperparms_company_learned_all : dict
            トレーダーの学習済みパラメータ
            
        Returns
        -------
            df_params : pd.DataFrame
                各トレーダーの戦略パラメータ.        
        '''        
        df_params = pd.DataFrame(self.make_parameters_list(factor_weight, strategy_weight, self.traders_sector), 
                                 columns=['trader_ID', 'strategy_ID', 'sector', 'factor_ID', 'factor_weight', 'strategy_weight'])        
        factor_dict = dict(zip(list(range(len(self.factor_list))), self.factor_list))
        df_params['factor'] = [factor_dict[int(x)] for x in df_params['factor_ID']]        
        traders_formula = self.get_params_formula(df_params)
        performance = self.measure_trader_return(self.traders_return, self.hyperparms_company_common['method_measure'])        
        df_performance = pd.DataFrame([list(range(self.hyperparms_company_common['N_trader'])),
                                       traders_formula, self.company_traders_weight, performance],
                                      index=['trader_ID', 'formula', 'ensemble_weight', 'performance(train)']).T

        df_performance['trader_ID'] = df_performance['trader_ID'].astype(int)
        df_params['trader_ID'] = df_params['trader_ID'].astype(int)
        df_params = pd.merge(df_params, df_performance, on='trader_ID', how='left')
                
        return df_params

    def get_params_formula(self, df_params):
        '''
            各トレーダーの戦略のformulaを文字列形式のリストで出力

        Parameters
        ----------
        df_params : pd.DataFrame
            各トレーダーの戦略パラメータ.
        Returns
        -------
        traders_formula : list 
            各トレーダーの戦略のformula
        '''
        traders_formula = []
        for trader_ID in df_params['trader_ID'].unique():
            df_temp = df_params[df_params['trader_ID']==trader_ID]
            formula_sum = ''            
            for strategy_ID in df_temp['strategy_ID'].unique():
                df_temp2 = df_temp[df_temp['strategy_ID']==strategy_ID]
                formula = ''                            
                for i in range(df_temp2.shape[0]):
                    if i==0:
                        formula += str(round(float(df_temp2['factor_weight'].iloc[i]), 2)) + df_temp2['factor'].iloc[i]
                    else:
                        formula += ' + ' + str(round(float(df_temp2['factor_weight'].iloc[i]), 2)) + df_temp2['factor'].iloc[i]        
                
                if (strategy_ID == '0') or (strategy_ID == 0):
                    formula_sum += str(round(float(df_temp2['strategy_weight'].unique()[0]), 2)) + '[' + formula + ']'
                else:
                    formula_sum += ' + ' + str(round(float(df_temp2['strategy_weight'].unique()[0]), 2)) + '[' + formula + ']'
                    
            traders_formula.append(formula_sum)
        
        return traders_formula
