# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import numpy as np
import random
from sklearn.linear_model import LassoCV, Lasso

# traderのフォーミュラの設定
def func_x(x):
    return x

def func_x2(x):
    return x**2

def func_x4(x):
    return x**4

# xが0~1の範囲において，値域が[0,1]かつ下に凸な関数
def func_convex_downward(x):
    return 1/(100**x) - (1/100)*x

# xが0~1の範囲において，値域が[0,1]かつ対称な凸関数
def func_convex(x):
    return -4*(x-0.5)**2+1

# xが0~1の範囲において，値域が[0,1]かつ対称な凹関数
def func_concave(x):
    return 4*(x-0.5)**2

def func_sum(x, y):
    return x+y

def func_diff(x, y):
    return x-y

def func_prod(x, y):
    return x*y

def func_select_x(x, y):
    return x

def func_select_y(x, y):
    return y

def func_max(x, y):
    return x*(x>y)+y*(x<y)

def func_min(x, y):
    return y*(x>y)+x*(x<y)

activation_functions = {
    'x'        : func_x, 
    'x^2'      : func_x2,
#    'x^4'      : func_x4,
#    'convex_d' : func_convex_downward,
    'convex'   : func_convex,  
    'concave'  : func_concave,
    }

binary_operators = {
    'x+y'    : func_sum, 
    'x-y'    : func_diff,
    'x*y'    : func_prod,
    'x'      : func_select_x,
    'y'      : func_select_y,                    
    'max_xy' : func_max,
    'min_xy' : func_min,
    }

class Trader:
    def __init__(self, X_input):
        '''
           Traders - Simple Prediction Module
           M個のformulaをもつトレーダーの銘柄魅力度スコアを算出するクラス
    
        Parameters
        ----------
        X_input : dict
            各銘柄のファクター値
        '''
        self.X_input = X_input

    def make_one_formula(self, hyperparms_j):
        '''
            1戦略の銘柄魅力度スコアを算出

        Parameters
        ----------
        hyperparms_j : dict
            1戦略のハイパーパラメータ.

        Returns
        -------
        score : np.array
            1つのformulaから算出された銘柄魅力度スコア.(時点, 銘柄数)
        '''                      
        x = self.X_input[hyperparms_j['P_factor_id']]
        y = self.X_input[hyperparms_j['Q_factor_id']]
        binary_op = list(hyperparms_j['O_binary_operator'].values())[0]            
        activation_func = list(hyperparms_j['A_activation_func'].values())[0]  
        score = binary_op(activation_func(x), activation_func(y))
        
        return score

    def make_formulas(self, hyperparms_all_formula):
        '''
            M個のformulaの銘柄魅力度スコアを算出

        Parameters
        ----------
        hyperparms_all_formula : dict
            M個のformulaのハイパーパラメータ情報が階層的に格納された辞書
            formulaごとに以下の情報が格納
            'P_factor_id'    : ファクターPの0~1基準化後スコア
            'Q_factor_id'    : ファクターQの0~1基準化後スコア
            'A_activation_func'  : 活性化関数
            'O_binary_operator'  : 二項演算子の関数   

        Returns
        -------
        each_score : np.array
            M個のformulaの銘柄魅力度スコア(formula数, 時点, 銘柄数)
        '''
        each_score = np.array([self.make_one_formula(hyperparms_j) for hyperparms_j in hyperparms_all_formula.values()])
        return each_score
    
    def weight_formulas(self, weight, each_score):   
        '''
            M個のformulaをweightで重みづけした銘柄魅力度スコアを算出

        Parameters
        ----------
        weight : np.array
            各formulaのウェイト.次元数 ：　(M_formula_num)
        each_score : np.array
            M個のformulaの銘柄魅力度スコア(formula数, 時点, 銘柄数)
    
        Returns
        -------
        scores
            M個のformulaをもつトレーダーによる銘柄魅力度スコア (時点, 銘柄数)
        '''
        scores = np.einsum("i, ijk->jk", weight, each_score)
       
        return scores
    
    def make_stategy(self, weight, hyperparms_all_formula):   
        '''
            M個のformulaをweightで重みづけした銘柄魅力度スコアを算出

        Parameters
        ----------
        weight : np.array
            各formulaのウェイト.次元数 ：　(M_formula_num)
        each_score : np.array
            M個のformulaの銘柄魅力度スコア(formula数, 時点, 銘柄数)
    
        Returns
        -------
        scores
            M個のformulaをもつトレーダーによる銘柄魅力度スコア (時点, 銘柄数)
        '''
        each_score = self.make_formulas(hyperparms_all_formula)
        scores = self.weight_formulas(weight, each_score)
        
        return scores    

    def update_weight(self, hyperparms_all_formula, y, random_seed):
        score = self.make_formulas(hyperparms_all_formula)
        X = score.reshape(-1, score.shape[1]*score.shape[2]).T
        y = y.values.reshape(-1)        
        epsilon = 0.0001 # singular matrixが生じないための工夫
        if np.linalg.matrix_rank(X.T.dot(X) + epsilon) < score.shape[0]:
            np.random.seed(random_seed)
            weight = np.random.rand(score.shape[0])
        else:
            weight = np.linalg.inv(X.T.dot(X)+epsilon).dot(X.T).dot(y) # 最小二乗法で係数を求めている
        
        return weight
        
class TraderGenarator:
    def __init__(self, factor_list, formula_num_max):
        '''
            トレーダーの初期戦略の設定を生成

        Parameters
        ----------
        factor_list : list
            ファクターのインデックス探索範囲.ファクターインデックスP,Qの候補
        'formula_num_max' : int
            formulaの最大数
        '''
        self.factor_list = factor_list
            
        # 探索範囲の取得
        self.activation_functions, self.binary_operators, \
            self.formula_list = self.set_scope(formula_num_max)
                    
    def set_scope(self, formula_num):
        '''
            トレーダーの探索範囲の設定値を返す

        Returns
        -------
        activation_functions : list
            活性化関数の候補.（候補の設定はクラス外の同コード内にて実施）
        binary_operators : list
            二項演算子の関数の候補.（候補の設定はクラス外の同コード内にて実施）
        formula_list : list            
            戦略数の候補．
        '''                
        formula_list = list(range(1, formula_num+1))
                
        return activation_functions, binary_operators, formula_list

    def get_formula_uniform(self, random_seed):
        '''
            ランダムにformulaの数を抽出            
        '''
        random.seed(random_seed)
        formula_num = random.sample(self.formula_list, 1)[0]
        
        return formula_num

    def set_weight_init(self, formula_num):
        '''
            各戦略の重みづけの初期値を設定

        Parameters
        ----------
        formula_num : int
            formulaの数.

        Returns
        -------
        weight : list
            各formulaの重み.
        '''
        weight = [1/formula_num for _ in range(formula_num)]
        
        return weight
        
    def get_params_uniform(self, formula_num, random_seed):
        '''
            formulaの数の戦略のパラメータをランダムに抽出

        Parameters
        ----------
        formula_num : int
            formulaの数.
        random_seed : int
            ランダムシード

        Returns
        -------
        hyperparms_all_formula : dict
            formula_num個の予測式が格納されたリスト.
        '''
        hyperparms_all_formula = {}
        for j in range(formula_num):
            random.seed(random_seed+j)
            p_factor, q_factor = random.sample(self.factor_list, 2)
            active_func = dict(random.sample(list(self.activation_functions.items()), 1))
            binary_op = dict(random.sample(list(self.binary_operators.items()), 1))            
            
            hyperparms_j = { 
                'P_factor_id'       : p_factor,
                'Q_factor_id'       : q_factor,
                'A_activation_func' : active_func,
                'O_binary_operator' : binary_op,
                }
            
            hyperparms_all_formula[j] = hyperparms_j        
        
        return hyperparms_all_formula        

    def get_params_trader_init(self, random_seed):
        '''
            初期時点のトレーダーの戦略を一様分布（ランダム）で設定

        Parameters
        ----------
        random_seed : int
            ランダムシード
            
        Returns
        -------
        hyperparms_trader : dict
            各トレーダーのパラメータ.
            'weight'                 : formulaの重みづけ
            'hyperparms_all_formula' : 各formulaのパラメータ
        '''
        formula_num = self.get_formula_uniform(random_seed)
        weight = self.set_weight_init(formula_num)
        hyperparms_all_formula = self.get_params_uniform(formula_num, random_seed)
        hyperparms_trader = {
            'hyperparms_all_formula' : hyperparms_all_formula,
            'weight'                 : weight,            
            }
        
        return hyperparms_trader

