import numpy as np
import pandas as pd
import optuna
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor


class EnsembleLearner:
    """アンサンブル系モデルの学習を行うクラス
    """
    def __init__(self, hyperparms):
        """
        hyperparms : dict
        """
        self.hyperparms = hyperparms        
        self.model_name = self.hyperparms["model"]
         # モデルのclassに読み込ませるハイパーパラメータの辞書
         # →classの引数に関係のないハイパーパラメータは除外
        self.hyperparms_model = self._delete_key(
            hyperparms.copy(), 
            ["model", "loss"]
            )
            
        self.study = None
        self.is_fit_cv = False

    def _delete_key(self, hyperparms_model, delete_list):
        """指定したキーとその要素を辞書から削除

        Parameters
        ----------
        hyperparms_model : dict
            キー除外前の辞書データ.
        delete_list : list
            削除したいキーのリスト.

        Returns
        -------
        hyperparms_model : dict
            キーを削除した辞書.
        """
        assert sum([x not in list(hyperparms_model.keys()) for x in delete_list])==0,(
            "学習時に必要なパラメータが設定されていません"
            )
        for key in delete_list:
            del hyperparms_model[key]        
        
        return hyperparms_model

    def _call_model(self):
        """モデルの呼び出し(目的関数などの設定も更新)

        Returns
        -------
        model : class
            モデルクラス
 
        """        
        if self.model_name == "extratrees":
            if self.hyperparms["loss"] == "MSELoss":
                model = ExtraTreesRegressor
            elif "class" in self.hyperparms["loss"]:        
                model = ExtraTreesClassifier

        return model

    def _fit(self, X, y, hyperparms_model=[]):        
        if len(hyperparms_model)==0:
            hyperparms_model = self.hyperparms_model
            
        # FeatureSelecterにてval_ratioを付与するケースに対応
        if "val_ratio" in list(self.hyperparms_model.keys()):
            del self.hyperparms_model["val_ratio"]
        if isinstance(hyperparms_model, dict):
            if "val_ratio" in list(hyperparms_model.keys()):
                del hyperparms_model["val_ratio"]
                
        model = self._call_model()
        model_fit_params = {
            "X": X,
            "y": y,                 
        }                

        model = model(**hyperparms_model).fit(**model_fit_params)        
        
        return model

    def fit(self, X, y, is_val=None, hyperparms_model=[]):
        """モデル学習を実行

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ(時点, 特徴量)
        y : pd.Series
            被説明変数(時点,)
        is_val : None
            本クラスでは不要な引数(Backtesterなどで共通して使用するために引数を設定)
        hyperparms_model : dict
            モデルのハイパーパラメータが格納された辞書．何も入力がされていない場合，self.hyperparams_modelで実行される．

        Attributes
        ----------
        model : 
            学習済みモデル
        """            
        if len(hyperparms_model) > 0:
            self.model = self._fit(X, y, hyperparms_model)
        else:
            self.model = self._fit(X, y)                
                
    def fit_cv(self, dict_val, hyperparms_model=[]):
        """モデル学習を実行

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        models : 
            各ホールドのデータセットで学習したモデル
        evals_result_save : pd.DataFrame
            各ホールドのデータセットにおける学習回数ごとの目的関数値
        """
        models = {}
        loss_sum = 0
        for i, dict_ in dict_val.items():
            (X_train, y_train, X_val, y_val) = dict_.values()
            if len(hyperparms_model)>0:
                model = self._fit(X_train, y_train, hyperparms_model)
            else:
                model = self._fit(X_train, y_train)
            models.update({i: model})
            loss_sum += model.score(X_val, y_val)
            
        self.models = models
        self.is_fit_cv = True
        self.loss_sum = loss_sum/len(dict_val)
        
    def predict_cv(self, X, ensemble_weight=[]):
        """CVを用いて学習したモデルの予測値をアンサンブルした予測値を出力

        Parameters
        ----------
        X : pd.DataFrame
            特長量データ．
        ensemble_weight : list, optional
            各モデルの出力値の重みづけ．特に設定しない場合，等ウェイトの予測値を出力．

        Returns
        -------
        y_pred_ensembled : np.array
            アンサンブルした予測値
        """
        if len(ensemble_weight) == 0:
            ensemble_weight = [1/len(self.models)
                               for _ in range(len(self.models))]
        
        if self.hyperparms["loss"] == "3class":
            y_pred_ensembled = np.zeros((X.shape[0], 3)) 
        elif self.hyperparms["loss"] == "2class":
            y_pred_ensembled = np.zeros((X.shape[0], 2)) 
        elif self.hyperparms["loss"] == "MSELoss":
            y_pred_ensembled = np.zeros(X.shape[0])
        
        for i, model in enumerate(self.models.values()):
            if "class" in self.hyperparms["loss"]:
                y_pred = model.predict_proba(X)
            else:
                y_pred = model.predict(X)
            y_pred_ensembled += ensemble_weight[i]*y_pred
        
        return y_pred_ensembled

    def predict(self, X):
        """学習したパラメータをもとに予測値を出力
        
        Parameters
        ----------
        X : pandas.DataFrame
            特徴量データ(時点, 特徴量) 

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        assert isinstance(X, pd.DataFrame)

        if self.is_fit_cv:
            y_pred = self.predict_cv(X)
        else:    
            if "class" in self.hyperparms["loss"]:                                    
                y_pred = self.model.predict_proba(X)
            else:
                y_pred = self.model.predict(X)
        
        return y_pred

    def tune(self, X, y, X_val, y_val, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : pandas.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : pandas.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : pandas.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        study : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
            [1] https://optuna.org/
        """
        hyperparms_model = self.hyperparms_model

        def objective(trial):
            if self.model_name=="extratrees":
                hyperparms_model["n_estimators"] = trial.suggest_int("n_estimators", 10, 1000)
                hyperparms_model["min_samples_split"] = trial.suggest_int("min_samples_split", 3, 20)
                hyperparms_model["min_samples_leaf"] = trial.suggest_int("min_samples_leaf", 3, 20)           
                                
            model = self._fit(X, y, hyperparms_model=hyperparms_model)
            score = model.score(X_val, y_val)
        
            return score

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms["random_state"])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler)
        study.optimize(
            objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"])
        self.study = study

    def tune_Kfold_nonprune(self, dict_val, is_val=None, n_trials=100, timeout=60):
        """optunaによるハイパーパラメータの最適化をPurgedKfoldにより実施

        Parameters
        ----------
        dict_val : dict
            訓練期間データを用いて作成したKFoldのバリデーションデータセット

        Attributes
        ----------
        study : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
            [1] https://optuna.org/
        
        Notes
        -----
        現状の設定では，lightgbmもxgboostもどちらも早期停止した場合，
        最もバリデーションデータの評価値のよいパラメータをとっているわけではなく，早期停止した段階での結果を参照している．\n
        →最もバリデーションデータの評価値のよいパラメータをとる方法も場合によっては検討してもよい
        `xgboost docs<https://xgboost.readthedocs.io/en/stable/python/python_intro.html>`_ \n
        If early stopping occurs, the model will have two additional fields:   \n
        bst.best_score, bst.best_iteration. Note that xgboost.train() will return a model  \n
        from the last iteration, not the best one.
        
        * xgboostのハイパーパラメータの設定参照元 : `Kaggleで勝つデータ分析の技術<https://gihyo.jp/book/2019/978-4-297-10843-4>`_
        
        * lightgbmのハイパーパラメータの設定参照元 : `Optuna の拡張機能 LightGBM Tuner によるハイパーパラメータ自動最適化<https://tech.preferred.jp/ja/blog/hyperparameter-tuning-with-optuna-integration-lightgbm-tuner/>`_        
        
        -> 本来であれば．optunaの拡張機能が使えることが望ましいが，本件はバリデーションデータの分割が特殊であるため，これらを使用しなかった．
        
        -> lightgbmのオプションであるextra_treesをTrueにすることがパフォーマンス向上に(経験則的に)
        つながることが書かれた記事があったことを参考にし，ハイパーパラメータとして追加
        `(参照元)<https://note.com/j26/n/n64d9c37167a6>`_
        """
        hyperparms_model = self.hyperparms_model

        def objective(trial):
            if self.model_name=="extratrees":
                hyperparms_model["n_estimators"] = trial.suggest_int("n_estimators", 10, 1000)
                hyperparms_model["max_depth"] = trial.suggest_int("max_depth", 1, 30)
                hyperparms_model["min_samples_split"] = trial.suggest_int("min_samples_split", 3, 20)
                hyperparms_model["min_samples_leaf"] = trial.suggest_int("min_samples_leaf", 3, 20)           

            loss_all = 0
            for i, dict_ in enumerate(dict_val.values()):
                print(f"{i}/{len(dict_val)} fold")
                (X, y, X_val, y_val) = dict_.values()
                model = self._fit(X, y, hyperparms_model=hyperparms_model)
                score = model.score(X_val, y_val)                                
                loss_all += score

            loss_all = loss_all/len(dict_val)

            return loss_all

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms["random_state"])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler)
        study.optimize(objective, n_trials=n_trials, timeout=timeout)
        self.study = study

    def update_hyperparams(self, hyperparms_best_updated={}):
        """optunaにより調整したハイパーパラメータの辞書の更新

        Parameters
        ----------
        hyperparms_best_updated : dict
            更新されたハイパーパラメータ (チューニングされたパラメータのみ)

            指定しない場合，tuneにより調整されたstudyのbest_trialが参照される．

        Raises
        ----------
        optunaのハイパーパラメータ最適化( tune )を先に実行する

        Returns
        -------
        hyperparms_best : dict
            更新したハイパーパラメータの辞書
        """
        if len(hyperparms_best_updated) == 0:            
            if self.study is None:
                raise ValueError("tuneを実行してください")                    
            hyperparms_best = self.hyperparms
            hyperparms_best_updated = self.study.best_trial.params            
        else:
            assert isinstance(hyperparms_best_updated, dict)
            hyperparms_best = self.hyperparms
            
        for key, val in hyperparms_best_updated.items():
            hyperparms_best[key] = val
                        
        self.hyperparms = hyperparms_best

        return hyperparms_best