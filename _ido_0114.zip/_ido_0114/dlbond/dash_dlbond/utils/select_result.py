
import dash_core_components as dcc
import dash_html_components as html
import glob


def select_result(files):
    return html.Label([ 
        'Select result file',
        dcc.Dropdown(
            id='data_selected',
            options=[{'label' : i, 'value' : i} for i in files],  # 選択肢の設定
            value=files,
            multi=True,  # 複数の選択を可能にする
            clearable=True,  # 選択を削除できるように設定
            style={"textAlign": "left"},  # 文字を左に寄せる
            )
        ])