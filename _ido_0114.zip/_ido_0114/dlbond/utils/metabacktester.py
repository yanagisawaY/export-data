import pandas as pd
from .ensemble import get_models_info, ModelEnsembler


class MetaBacktester(ModelEnsembler):
    def __init__(self, dfs_input, models_info, mode="last_term", including_train=True):
        super().__init__(dfs_input, models_info)
        if including_train:
            self.set_ensemble_pattern(mode, start_date_test=None)
    
    def output_for_analysis(self, X, hyperparams_imp):
        import pdb
        pdb.set_trace()
        from .feature_importance import FeatureImportance
        from .unsupervised import UnsupervisedLearner
        
        fi = FeatureImportance(hyperparams_imp)
        figs_all = {}
        for i, (_, X_processed) in enumerate(self.generate_setting(X)):
            _ = fi.call_cluster(X_processed)
            usl = UnsupervisedLearner(
                X_processed,
                n_components=max(1, int(X.shape[1] / 2)),
                random_state=0,
                corr_distance=fi.corr_distance,
                clusters=fi.clusters,
            )
            figs = usl.get_all_figs()
            figs_all = {i: figs}
        
        return figs_all
    
    def output_shap_values(self, X, mode):
        shap_values_all = self.calc_shap_all(X, mode)
        for i, (_, X_processed) in enumerate(self.generate_setting(X)):
            shap_values_all[i] = pd.DataFrame(
                shap_values_all[i],
                index=X_processed.index,
                columns=X_processed.columns                
                )
        
        return shap_values_all        

    def backtest(self, start_date, end_date, mode):
        import pdb
        pdb.set_trace()
        X = self.X_raw.loc[start_date:end_date,]
        position = self.ensemble(X, mode)
        
        return position
    
    def report_all(self, start_date, end_date, mode, hyperparams_imp):
        X = self.X_raw.loc[start_date:end_date,]
        figs_all = self.output_for_analysis(X, hyperparams_imp)
        shap_values_all = self.output_shap_values(X, mode)
        
        return figs_all, shap_values_all


class ResultAnalyst:
    def __init__(self, path=None, is_feature_select=False):
        self.models_info_all = get_models_info("params", path, is_feature_select)
        self.models_result = get_models_info("result", path, is_feature_select)       
        
    def _add_config_all(self, config_, model_name, timestamp):
        index_name = [
            "モデル",
            "バリエーションパターン",
            "特徴量",
            "特徴量数",
            "開始時点",
            "終了時点",
            "訓練月数",
            "テスト月数",
            "再学習月間隔",
        ]
        config_add_ = pd.DataFrame(
            [
                config_["model"],
                config_["backtest_info"]["validation_type"],                
                str(list(config_["extracted_columns"])),
                len(config_["extracted_columns"]),
                config_["backtest_info"]["start_date"],
                config_["backtest_info"]["end_date"],
                config_["backtest_info"]["train_month"],
                config_["backtest_info"]["test_month"],
                config_["backtest_info"]["relearn_month"],
            ],
            index=[["設定" for _ in index_name], index_name],
            columns=[[model_name], [timestamp]],
        )

        return config_add_

    def _add_result_all(self, performance, model_name, timestamp, result_summary):
        performance_ = pd.DataFrame(
            performance.unstack(), columns=[[model_name], [timestamp]]
        )
        config_all_ = self.models_info_all[model_name][timestamp]["config"]
        config_all_add_ = self._add_config_all(config_all_, model_name, timestamp)
        output = pd.concat([performance_, config_all_add_])

        return output

    def report_result(self):
        """全試行のバックテスト結果のサマリーをデータフレーム形式で出力

        Returns
        -------
        result_summary : pd.DataFrame
           全試行のバックテスト結果
        """
        result_summary = []
        for model_name, dict_timestamp in self.models_result.items():
            for timestamp, results in dict_timestamp.items():
                results = self.models_result[model_name][timestamp]
                result_summary.append(
                    self._add_result_all(
                        results["result_all"][
                            "performance"
                        ],
                        model_name,
                        timestamp,
                        result_summary,
                    )
                )

        result_summary = pd.concat(result_summary, axis=1).T
        result_summary = result_summary.sort_values([("トータル", "総損益")], ascending=False)

        return result_summary

    def report_wealth(self):
        """全試行のバックテスト結果の損益推移をデータフレーム形式で出力

        Returns
        -------
        wealth_summary : pd.DataFrame
           全試行のバックテスト結果の損益推移
        """
        col_name = []
        wealth_summary = pd.DataFrame()
        for model_name, dict_timestamp in self.models_result.items():
            for timestamp, results in dict_timestamp.items():
                col_name += [[[model_name], [timestamp]]]
                results = self.models_result[model_name][timestamp]
                wealth_profit_ = pd.DataFrame(results["result_all"]["wealth"])
                wealth_profit_.columns = [[model_name], [timestamp]]
                if len(wealth_summary)==0:
                    wealth_summary = wealth_profit_
                else:
                    wealth_summary = pd.concat([wealth_summary, wealth_profit_], axis=1)
        
        return wealth_summary
    
    def extract_models_info(self, result_summary, model_num, sort_name="総損益"):
        """トータルの総損益がよかった上位モデルの情報を抽出
        (sort_nameを変更することで任意の値の上位モデルを抽出可能)

        Parameters
        ----------
        result_summary : pd.DataFrame
           全試行のバックテスト結果
        model_num : int
            抽出するモデル数.

        Returns
        -------
        models_info : dict
            抽出したモデルの情報
            以下の構造で辞書形式にモデル, config情報を保存
            
            Notes
            -----
            |- model1 : モデル名
                |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
                    |- config.pkl : 設定ファイル 
                |- feature_select : 変数選択による思考結果()
                    |- 2021212_172302 : 実行した時間に基づくタイムスタンプ 
        """
        result_summary = result_summary.sort_values([("トータル", sort_name)], ascending=False)
        model_num = min(model_num, result_summary.shape[0])
        extracted_index = result_summary.iloc[:model_num,:].index
        
        models_info = {}
        for model_name, timestamp in extracted_index:
            if model_name not in models_info.keys():
                models_info.update({model_name: {}})
                if timestamp not in models_info[model_name].keys():
                    models_info[model_name].update({timestamp: {}})
                    
            models_info[model_name][timestamp] = self.models_info_all[model_name][timestamp]

        return models_info        
    