"""

Notes
-----
* calc_shapメソッドについてはユニットテストが実施できるようになっている
-> shapのAPIの使用により，カスタマイズを行う必要性がある．ユニットテストも同時に搭載した
* テストコードの実施個所はコメントアウトしている

    calc_shapのユニットテスト
    Examples
    --------
    >>> from set_init import dfs_input
    >>> from dlbond.utils.ensemble import get_models_info, ModelEnsembler
    >>> models_info = get_models_info()
    >>> ensembler = ModelEnsembler(dfs_input, models_info)        
    >>> start_date = dt.datetime(2018, 1, 1)
    >>> end_date = dt.datetime(2018, 12, 31)
    >>> X = ensembler.X_raw.loc[start_date:end_date,]
    >>> mode = "term_last"
    >>> shap_values = ensembler.calc_shap(X, mode)
    # shap値を計算できるアンサンブルモデルの抽出
    >>> shap_values_all = ensembler.calc_shap_all(X, mode)
    >>> ensemble_weight = 1 / len(shap_values_all) for i in range(len(shap_values_all))
    ユニットテストの実施(shapのアンサンブル出力合計値と予測確率のアンサンブル出力合計値は一致する)
    >>> ensembler._test_shap_values_ensembled(shap_values_ensembled, X, mode, ensemble_weight)
    assertが出力されなければ問題なし
"""
import copy
import pandas as pd
import numpy as np
import os
import glob
import shap
import torch
from .split import Splitter


# =============================================================================
# def get_models_result(path=None):
#     """experiment直下のresultフォルダーに格納されたモデル，configを全パターン抽出
# 
#     Parameters
#     ----------
#     path : str
#         experiment/resultのフォルダパス
# 
#     Returns
#     -------
#     models_result : dict
#         以下の構造で辞書形式にモデル, config情報を保存
#         
#         Notes
#         -----
#         |- model1
#             |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
#                 |- termX : model.pkl, term_info.pklをタームごとにtupleで保存
#                 |- config.pkl : 設定ファイル 
#     """
#     if path is None:
#         path = os.getcwd() + "\\experiment\\result"
# 
#     model_files = [x.split("\\")[-1] for x in glob.glob(path + "/**")]
#     models_result = {model_: {} for model_ in model_files}
#     for model_ in model_files:
#         path_model = path + "\\" + model_
#         timestamp_files = [x.split("\\")[-1] for x in glob.glob(path_model + "/**")]
#         models_result[model_] = {timestamp: {} for timestamp in timestamp_files}
#         for timestamp in timestamp_files:
#             path_stamp = path_model + "\\" + timestamp
#             dir_all = os.walk(path_stamp)
#             for dirs, _, files in dir_all:
#                 key_ = dirs.split("\\params")[0].split("\\")[-1]
#                 if len(files) > 0 and "result.pkl" == files[0]:
#                     result = dirs.split("\\params")[0] + "\\result.pkl"
#                     models_result[model_][timestamp].update(
#                         {key_: (pd.read_pickle(result))}
#                     )
#                 elif len(files) > 0 and "config.pkl" == files[0]:
#                     models_result[model_][timestamp].update(
#                         {"result_all": pd.read_pickle(dirs + "/" + files[1])}
#                     )
# 
#     return models_result
# =============================================================================


def get_models_info(info="params", path=None, is_feature_select=False):
    """experiment直下のresultフォルダーに格納されたモデル，configを全パターン抽出

    Parameters
    ----------
    info : str
        paramsかresult入力
        * params : resultフォルダーに格納されたモデル，configを全パターン抽出
        * result : resultフォルダーに格納されたresultファイル(バックテスト結果)を全パターン抽出
            
    path : str
        experiment/resultのフォルダパス
    is_feature_select : bool
        変数選択の結果も含めて情報を取得する場合はTrue

    Returns
    -------
    models_info : dict
        以下の構造で辞書形式にモデル, config情報を保存
        
        Notes
        -----
        |- model1 : モデル名
            |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
                |- config.pkl : 設定ファイル 
            |- feature_select : 変数選択による思考結果()
                |- 2021212_172302 : 実行した時間に基づくタイムスタンプ  
    """

    def _find_files_params(model_, timestamp, dirs, files, models_info):
        if len(files) > 0 and "model.pkl" == files[0]:
            key_ = dirs.split("\\params")[0].split("\\")[-1]
            term = dirs.split("\\params")[0] + "\\term_info.pkl"
            models_info[model_][timestamp].update(
                {key_: (pd.read_pickle(dirs + "/" + files[0]), pd.read_pickle(term),)}
            )
        elif len(files) > 0 and "config.pkl" == files[0]:
            models_info[model_][timestamp].update(
                {"config": pd.read_pickle(dirs + "/" + files[0])}
            )

        return models_info
    
    def _find_files_result(model_, timestamp, dirs, files, models_info):
        if len(files) > 0 and "result.pkl" == files[0]:
            key_ = dirs.split("\\params")[0].split("\\")[-1]
            result = dirs.split("\\params")[0] + "\\result.pkl"
            models_info[model_][timestamp].update(
                {key_: (pd.read_pickle(result))}
            )
        elif len(files) > 0 and "config.pkl" == files[0]:
            models_info[model_][timestamp].update(
                {"result_all": pd.read_pickle(dirs + "/" + files[1])}
            )
        
        return models_info
            
    if info == "params":
        _find_files = _find_files_params
    elif info == "result":
        _find_files = _find_files_result
    else:
        raise ValueError("infoは'params'か'result'と入力")

    if path is None:
        path = os.getcwd() + "\\experiment\\result"

    model_files = [x.split("\\")[-1] for x in glob.glob(path + "/**")]
    models_info = {model_: {} for model_ in model_files}
    for model_ in model_files:
        path_model = path + "\\" + model_
        timestamp_files = [
            x.split("\\")[-1]
            for x in glob.glob(path_model + "/**")
            if "feature_select" not in x.split("\\")[-1]
        ]

        path_fs = path_model + "\\feature_select"
        is_feature_select_fold = glob.glob(path_fs + "/**")
        if is_feature_select and len(is_feature_select_fold) > 0:
            dir_fs_all = os.walk(path_fs)
            for dirs, _, files in dir_fs_all:
                if "\\trial" in dirs:
                    timestamp_ = dirs.split("feature_select")[1].split("\\")
                    timestamp = (
                        timestamp_[1]
                        + "_l"
                        + timestamp_[2].split("_")[1]
                        + "t"
                        + timestamp_[3].split("trial")[1]
                    )
                    if timestamp not in models_info[model_].keys():
                        models_info[model_].update({timestamp: {}})
                    models_info = _find_files(
                        model_, timestamp, dirs, files, models_info
                    )

        models_info[model_].update(
            {
                timestamp: {}
                for timestamp in timestamp_files
                if timestamp not in models_info[model_].keys()
            }
        )
        for timestamp in timestamp_files:
            path_stamp = path_model + "\\" + timestamp
            dir_all = os.walk(path_stamp)
            for dirs, _, files in dir_all:
                models_info = _find_files(model_, timestamp, dirs, files, models_info)

    return models_info


class ModelEnsembler(Splitter):
    def __init__(self, dfs_input, models_info):
        self.models_info_init = models_info.copy()
        self.super_max_features(dfs_input, models_info)
        self.is_purmit_including_leak = False

    def super_max_features(self, dfs_input, models_info):
        """モデルが使用するデータの和集合を抽出し，Splitterクラスへ継承する

        Parameters
        ----------
        dfs_input : dict
            入力データ
        config : dict
            設定ファイル
        models_info : dict
            モデル情報
        
        Notes
        -----
        テクニカル指標の作成をモデルごとに行わないために，必要となるテクニカル指標をすべて初期段階でまとめて作成する
        
        ただし，PCAの変換とCODEに基づく変換はモデルごとの設定に基づくため，モデルごとに処理を行う
        """
        features = 1
        features_ohlcv = 1

        for model_ in models_info.values():
            for i, models_timestamp in enumerate(model_.values()):
                if i == 0:
                    config = models_timestamp["config"]

                features_ = models_timestamp["config"]["features"]
                features = (features_ == 0) * features
                features_ohlcv_ = models_timestamp["config"]["features_ohlcv"]
                features_ohlcv = (features_ohlcv_ == 0) * features_ohlcv

        config["features"] = config["features"] * (features == 0)
        config["features_ohlcv"] = config["features_ohlcv"] * (features_ohlcv == 0)

        return super().__init__(dfs_input, config)

    def process_code(self, X, features):
        """CODEに基づいて特徴量を変換

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ
        features : pd.DataFrame
            特徴量データの設定に関するデータフレーム

        Returns
        -------
        X_output : pd.DataFrame
            CODEに基づいて変換した特徴量データ
        """
        X_ = X.copy(deep=True)
        explained_names = list(features.loc[features["CODE"] > 0, :].index)

        code_list = features.loc[explained_names, "CODE"]

        df_explained = []
        for explained_name in explained_names:
            df_explained.append(
                self.convert_raws(X[explained_name], code=code_list[explained_name])
            )

        df_explained = pd.concat(df_explained, axis=1)
        X_.loc[:, df_explained.columns] = df_explained
        X_output = self.fill_na(X_)

        return X_output

    def process(self, X, model, pca_features):
        """標準化やPCAにより前処理を実施する

        Parameters
        ----------
        X : pd.DataFrame
            CODEに基づいて変換した特徴量データ
        model : model
            学習済みモデルデータ
        pca_features : list
            PCA変換を実施する変数名

        Returns
        -------
        X : pd.DataFrame
            前処理済みの特徴量データ
        """
        for process in model.processor_save:
            if "PCA" in str(type(process)):
                col_pca = ["PCA" + str(i + 1) for i in range(process.n_components)]
                temp = pd.DataFrame(
                    process.transform(X[pca_features]), columns=col_pca, index=X.index
                )
                X = pd.concat([temp, X.drop(pca_features, axis=1)], axis=1)
            elif "StandardScaler" in str(type(process)):
                X = pd.DataFrame(process.transform(X), columns=X.columns, index=X.index)

        return X
    
    def _set_start_date_test(self, X):
        if self.is_purmit_including_leak:
            print("ModelEnsemblerの予測期間にリークを含めることを許可します")
            start_date_test = None
        else:
            start_date_test = X.index[0]
        
        return start_date_test

    def generate_setting(self, X):
        """学習済みモデルを用いて予測値を出力

        Parameters
        ----------
        X : pd.DataFrame
            前処理済みの特徴量データ

        Yields
        -------
        model : 
            モデル
        X_processed : pd.DataFrame
            加工済み特徴量データ
        """
        start_date_test = self._set_start_date_test(X)
        for model_ in self.models_info.values():
            for models_timestamp in model_.values():
                config = models_timestamp["config"]
                extracted_columns = config["extracted_columns"]
                X_ = X.copy(deep=True)[extracted_columns]
                features = config["features"]
                X_code = self.process_code(X_, features).fillna(0)
                pca_features = list(features.loc[features["PCA"] == 1, :].index)
                for key, tuple_ in models_timestamp.items():
                    if key != "config":
                        model, term_info, is_model = tuple_

                        if is_model:
                            end_date_train = term_info["end_date_train"].values[0]

                            if end_date_train > start_date_test:
                                break

                            X_processed = self.process(X_code, model, pca_features)

                            yield model, X_processed

    def generate_pred(self, model, X_processed, random_state=0):
        """学習済みモデルを用いて予測値を出力

        Parameters
        ----------
        model : 
            モデル
        X_processed : pd.DataFrame
            加工済み特徴量データ

        Returns
        -------
        y_pred : np.ndarray
            予測値
        """
        y_pred = model.predict(X_processed)
        if len(y_pred.shape) > 1:
            y_pred = y_pred[:, 1]

        return y_pred

    def generate_potision(self, y_pred, model, X_processed):
        """学習済みモデルを用いて予測値を出力

        Parameters
        ----------
        model : 
            モデル
        X_processed : pd.DataFrame
            加工済み特徴量データ

        Returns
        -------
        position : pd.Series
            ポジション(-1, 0, 1)
        """
        position = pd.Series(model.trader.make_signal(y_pred), index=X_processed.index)

        return position

    def set_ensemble_pattern(self, mode, start_date_test):
        """予測に使用する学習済みモデルの選択

        Parameters
        ----------
        mode : str
            使用する学習済みモデルの選択
            
            * all : 全termの学習モデルを使用
            
            * term_last : 最終期間の学習モデルを使用(リークのない範囲でモデルを選択)
                        
        start_date_test : datetime
            テストデータの開始時点
        """
        assert mode == "all" or mode == "term_last"
        if start_date_test is None:
            self.is_purmit_including_leak = True
            print("ModelEnsemblerの予測期間にリークを含めることを許可します")
        else:
            self.is_purmit_including_leak = False

        self.ensemble_cols = []
        self.models_info = copy.deepcopy(self.models_info_init)
        for model_, models in self.models_info.items():
            for timestamp, models_timestamp in models.items():
                end_date_trains = {}
                for term, tuple_ in models_timestamp.items():
                    if term != "config":
                        _, term_info = tuple_
                        end_date_train = term_info["end_date_train"].values[0]

                        end_date_trains.update({term: end_date_train})

                        if mode == "all" and end_date_train <= start_date_test:
                            self.models_info[model_][timestamp][term] += (True,)
                            self.ensemble_cols.append(
                                model_ + "_" + timestamp + "_" + term
                            )
                        else:
                            self.models_info[model_][timestamp][term] += (False,)

                if mode == "term_last":
                    last_term = [
                        key
                        for key, val in end_date_trains.items()
                        if val <= start_date_test
                    ][-1]
                    temp = self.models_info[model_][timestamp][last_term]
                    temp = list(temp)
                    temp[2] = True
                    self.models_info[model_][timestamp][last_term] = tuple(temp)
                    self.ensemble_cols.append(
                        model_ + "_" + timestamp + "_" + last_term
                    )

    def predict_prob_all(self, X, mode):
        """各学習モデルの予測確率を出力

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
            
        Returns
        -------
        position : pd.DataFrame
            各学習モデルの予測確率
        """
        start_date_test = self._set_start_date_test(X)
        self.set_ensemble_pattern(mode, start_date_test)
        y_pred_all = [
            pd.Series(self.generate_pred(model, X_processed))
            for model, X_processed in self.generate_setting(X)
        ]
        y_pred_all = pd.concat(y_pred_all, axis=1)
        y_pred_all.columns = self.ensemble_cols
        y_pred_all.index = X.index

        return y_pred_all

    def predict_all(self, X, mode):
        """各学習モデルの予測確率から算出したポジションを出力

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
            
        Returns
        -------
        position_all : pd.DataFrame
            各学習モデルの予測値(時点, モデル)
        """
        start_date_test = self._set_start_date_test(X)
        self.set_ensemble_pattern(mode, start_date_test)
        position_all = [
            self.generate_position(
                self.generate_pred(model, X_processed), model, X_processed
            )
            for model, X_processed in self.generate_setting(X)
        ]
        position_all = pd.concat(position_all, axis=1)
        position_all.columns = self.ensemble_cols

        return position_all

    def ensemble(self, X, mode, method="vote"):
        """methodでの指定方法に応じて，各モデルの予測結果を集約したポジション結果を返す

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
        method : str
            vote
            各モデルの予測値と閾値より算出したポジション結果をもとに，ポジションの最頻値を返す
            (出力値は-1, 0, 1)
            ensemble_betsize
            予測確率をもとに，アンサンブル・ベットサイジングによりポジションを算出．
            (出力値は-1~1の連続値)

        Returns
        -------
        position : pd.Series
            予測値
        
        References
        ----------
        * アセットマネージャーのためのファイナンス機械学習 5.5.2 アンサンブル・ベットサイジング
        """
        if method == "vote":
            position_all = self.predict_all(X, mode)
            position = position_all.mode(1)
            if position.shape[1] > 1:
                position = position.iloc[:, 0]
        elif method == "ensemble_betsize":
            # y_pred_all = self.predict_prob_all(X, mode)
            raise ValueError("未実装")

        return position

    def _generate_shap_explainer_fold(self, model, X_processed, model_fold):
        if model.model_name in ["xgboost", "lightgbm", "extratrees"]:
            if model.model_name == "lightgbm":
                # lightgbmのAPIにおける例外処理，以下のissueを参考に引数を追加．
                # KeyError: 'objective' with LGBMRegressor Model #1042
                # https://github.com/slundberg/shap/issues/1042
                model_fold.booster_.params.update({"objective": "binary"})

            if model.model_name in ["xgboost", "lightgbm"]:
                # xgboost(lightgbm)の場合，以下の引数を設定しないとbase_valuesとvaluesが確率として出力されない
                # https://qiita.com/Derek/items/262f1ea39c6298cdd1bb
                explainer = shap.TreeExplainer(
                    model_fold,
                    # feature_dependence='independent',
                    model_output="probability",
                    data=X_processed,
                )
            else:
                explainer = shap.TreeExplainer(model_fold)
        elif model.model_name in ["dnn"]:
            X_processed_ = torch.Tensor(X_processed.values)
            explainer = shap.DeepExplainer(model_fold, X_processed_)
        else:
            raise ValueError(
                "current version only supports xgboost/lightgbm/dnn/extratrees"
            )

        return explainer

    def generate_shap_explainer(self, model, X_processed):
        """学習済みモデルを用いてshap値を出力

        Parameters
        ----------
        model : 
            学習済みのモデル.
        X_processed : pd.DataFrame
            加工済み特徴量データ

        Raises
        ------
        ValueError
            current version only supports xgboost/lightgbm/dnn/extratrees.
            
        Returns
        -------
        explainer : shap.explainers
            shapの計算結果
        
        Notes
        -----
        * modelクラスのpredict_cvにて，ensemble_weightが等ウェイトであることを前提としていることに注意\n
        * 2class分類以外は想定外として計算しない
        """
        if model.hyperparms["loss"] == "2class":
            explainers = []
            if model.is_fit_cv:
                for model_fold in model.models.values():
                    explainers += [
                        self._generate_shap_explainer_fold(
                            model, X_processed, model_fold
                        )
                    ]
            else:
                explainers += [
                    self._generate_shap_explainer_fold(model, X_processed, model)
                ]

            return explainers
        else:
            # 2class分類以外は想定外として計算しない
            return None

    def update_shap_values(self, shap_values_, shap_values_new, ensemble_weight_new):
        """ensemble_weight_newに基づき，重みづけした値を加算する形でshapの結果を更新\n
        -> shap._explanation.Explanationのbase_values, values, feature_names, dataを更新        
        
        Notes
        -----
        1. shap_valuesのbase_valuesに重みづけした値(ensemble_weight_new)をかけ合わせたshap_values_newbase_valuesを加算\n
        -> base_valuesは全特徴量で周辺化されたモデル予測値の期待値のため，特徴量の次元をもたない\n
        2. 同じ特徴量を使用していた場合，特徴量の並び順にあわせて，重みづけした値(ensemble_weight_new)をかけ合わせたvaluesを加算して更新\n
        3. 新しい特徴量が追加された場合，重みづけした値(ensemble_weight_new)をかけ合わせたvaluesを加算することに加え，feature_namesとdataも更新\n     
        -> ただし，dataはSHAP計算に用いた元データであるため，重みづけの加算処理などを実施せず，データを結合させる
        * shap_valuesとshap_values_newは同じ予測タスク(2クラス分類のみに現バージョンは対応)である必要がある
        
        Parameters
        ----------
        shap_values_ : dict
            更新前のshap結果.
        shap_values_new : dict
            更新後のshap結果.
        ensemble_weight_new : float
            重みづけの値.(0<= ensemble_weight_new <=1)

        Returns
        -------
        shap_values : dict
            更新されたshap値の結果.
            
        References
        ----------
        1. A Unified Approach to Interpreting Model Predictions : https://arxiv.org/abs/1705.07874
        2. Consistent Individualized Feature Attribution for Tree Ensembles : https://arxiv.org/abs/1802.03888
        3. (参考) なぜ決定木だとSHAP値を正確に計算できるの? : https://qiita.com/hyt-sasaki/items/49355cb6e9775fe998a6#fn3            
        """
        shap_values_new_copy = shap_values_new.copy()

        if len(shap_values_new["values"].shape) == 3:
            shap_values_new_copy["values"] = shap_values_new_copy["values"][:, :, 1]
            shap_values_new_copy["base_values"] = shap_values_new_copy["base_values"][
                :, 1
            ]

        assert ensemble_weight_new >= 0 and ensemble_weight_new <= 1

        if len(shap_values_) == 0:
            shap_values = copy.deepcopy(shap_values_new_copy)
            shap_values["values"] = shap_values_new_copy["values"] * ensemble_weight_new
            shap_values["base_values"] = (
                shap_values_new_copy["base_values"] * ensemble_weight_new
            )
        else:
            shap_values = shap_values_.copy()
            feature = shap_values["feature_names"]
            feature_new = shap_values_new_copy["feature_names"]
            feature_common = [f_ for f_ in feature_new if f_ in feature]
            feature_add = [f_ for f_ in feature_new if f_ not in feature]

            # base_valuesに重みづけした値を加算
            # base_valuesは特徴量の次元をもたない
            shap_values["base_values"] += (
                shap_values_new_copy["base_values"] * ensemble_weight_new
            )

            # 同じ特徴量を使用していた場合，特徴量の並び順にあわせて，valuesを更新
            index_ = [shap_values["feature_names"].index(f_) for f_ in feature_common]
            index_new = [
                shap_values_new_copy["feature_names"].index(f_) for f_ in feature_common
            ]
            # ensemble_weight_newにより重みづけした値を加算
            shap_values["values"][:, index_] += (
                shap_values_new_copy["values"][:, index_new] * ensemble_weight_new
            )

            if len(feature_add) > 0:
                # 新しい特徴量が追加された場合，valuesに加え，feature_namesとdataも更新
                for f_ in feature_add:
                    shap_values["feature_names"].append(f_)

                index_new = [
                    shap_values_new_copy["feature_names"].index(f_)
                    for f_ in feature_add
                ]
                # shap.valuesは重みづけした値を結合
                shap_values["values"] = np.concatenate(
                    [
                        shap_values["values"],
                        shap_values_new_copy["values"][:, index_new]
                        * ensemble_weight_new,
                    ],
                    axis=1,
                )
                # shap.dataは元データのため，重みづけを行わずにデータを結合
                shap_values["data"] = np.concatenate(
                    [shap_values["data"], shap_values_new_copy["data"][:, index_new]],
                    axis=1,
                )

        return shap_values

    def generate_shap_values(self, explainers, model, X_processed):
        """explainersをもとにSHAP値を加算する

        Parameters
        ----------
        explainers : shap.explainers
            DESCRIPTION.
        model : 
            学習済みのモデル.
        X_processed : pd.DataFrame
            加工済みデータ.

        Raises
        ------
        ValueError
            current version only supports xgboost/lightgbm/dnn/extratrees.

        Returns
        -------
        shap_values : dict
            各学習モデルの予測値
        
        Notes
        -----
        * cvの結果を等ウェイトでアンサンブルしているため，fold数でvaluesを除算
        * モデルによって出力されるshap_valuesの次元が異なるため，モデルごとに異なる処理を実施
        
        """
        if explainers is None:
            # 2class分類以外は想定外として計算しない
            return None

        shap_values = []
        for i, explainer in enumerate(explainers):
            if model.model_name in ["dnn", "xgboost", "lightgbm", "extratrees"]:
                if model.model_name in ["dnn"]:
                    X_processed_ = torch.Tensor(X_processed.values)
                    shap_values_new_ = explainer.shap_values(X_processed_)
                    temp = explainer.expected_value[1]
                    shap_values_new = {
                        "base_values": np.repeat(temp, X_processed_.shape[0], axis=0),
                        "values": shap_values_new_[1],
                        "data": X_processed.values,
                        "feature_names": list(X_processed.columns),
                    }
                    shap_values = self.update_shap_values(
                        shap_values,
                        shap_values_new=shap_values_new,
                        ensemble_weight_new=1 / len(explainers),
                    )
                else:
                    shap_values_new_ = explainer(X_processed)
                    shap_values_new = {
                        "base_values": shap_values_new_.base_values,
                        "values": shap_values_new_.values,
                        "data": shap_values_new_.data,
                        "feature_names": shap_values_new_.feature_names,
                    }
                    # cvの結果を等ウェイトでアンサンブルしているため，fold数でvaluesを重みづけする
                    shap_values = self.update_shap_values(
                        shap_values,
                        shap_values_new=shap_values_new,
                        ensemble_weight_new=1 / len(explainers),
                    )
            else:
                raise ValueError(
                    "current version only supports xgboost/lightgbm/dnn/extratrees"
                )

        # テスト用
        # self._test_shap_values(shap_values, model, X_processed)

        return shap_values

    def calc_shap_all(self, X, mode):
        """各学習モデルの予測値を出力

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
        
        Returns
        -------
        shap_values_all : dict
            各学習モデルを用いて算出したSHAP値
        """
        start_date_test = self._set_start_date_test(X)
        self.set_ensemble_pattern(mode, start_date_test)
        shap_values_all = [
            self.generate_shap_values(
                self.generate_shap_explainer(model, X_processed), model, X_processed
            )
            for model, X_processed in self.generate_setting(X)
        ]

        # テスト用
        # self._test_shap_values_all(shap_values_all, X)

        return shap_values_all

    def _calc_shap(self, shap_values_all, X, mode, ensemble_weight=[]):
        """各モデルのSHAP値を重みづけし，アンサンブルしたモデルにおけるSHAP値を算出する

        Parameters
        ----------
        shap_values_all : dict
            各学習モデルを用いて算出したSHAP値
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
        ensemble_weight : list, optional
            各モデルのSHAP値に対する重みづけ．特に設定しない場合，等ウェイトで重みづけする．

        Returns
        -------
        shap_values_ensembled : dict
            全学習モデルのSHAP値を重みづけした値
            
            Notes
            -----
            * SHAPの加法性により，ensemble_weightに応じて重みづけした2値分類の予測確率と各特徴量のSHAP値合計(base_valuesと全特徴量のvaluesを加算した結果)は一致する
        
        Notes
        -----
        * ensemble_weightの重みづけに応じて，SHAPのbase_value(予測の平均値(全特徴量で周辺した予測値))とvalues(各特徴量のSHAP値)を加算する\n
        * ensemble_weightの重みづけに応じたSHAPの加算は，SHAPのもつ加法性の性質を満たす
        """
        shap_values_all = self.calc_shap_all(X, mode)
        if len(ensemble_weight) == 0:
            ensemble_weight = [
                1 / len(shap_values_all) for i in range(len(shap_values_all))
            ]
        else:
            assert len(ensemble_weight) == len(shap_values_all)
            assert isinstance(ensemble_weight, list)

        shap_values_ensembled = []
        for i, shap_values in enumerate(shap_values_all):
            if shap_values is not None:
                shap_values_ensembled = self.update_shap_values(
                    shap_values_ensembled,
                    shap_values_new=shap_values,
                    ensemble_weight_new=ensemble_weight[i],
                )

        return shap_values_ensembled

    def calc_shap(self, X, mode, ensemble_weight=[]):
        """各モデルのSHAP値を重みづけし，アンサンブルしたモデルにおけるSHAP値を算出する

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'set_ensemble_pattern' method)
        ensemble_weight : list, optional
            各モデルのSHAP値に対する重みづけ．特に設定しない場合，等ウェイトで重みづけする．

        Returns
        -------
        shap_values_ensembled : dict
            全学習モデルのSHAP値を重みづけした値
            
            Notes
            -----
            * SHAPの加法性により，ensemble_weightに応じて重みづけした2値分類の予測確率と各特徴量のSHAP値合計(base_valuesと全特徴量のvaluesを加算した結果)は一致する
        
        Notes
        -----
        * ensemble_weightの重みづけに応じて，SHAPのbase_value(予測の平均値(全特徴量で周辺した予測値))とvalues(各特徴量のSHAP値)を加算する\n
        * ensemble_weightの重みづけに応じたSHAPの加算は，SHAPのもつ加法性の性質を満たす
        """
        shap_values_all = self.calc_shap_all(X, mode)
        shap_values_ensembled = self._calc_shap(
            shap_values_all, X, mode, ensemble_weight
        )

        # テスト用
        # self._test_shap_values_ensembled(shap_values_ensembled, X, mode, ensemble_weight)

        return shap_values_ensembled

    def _summary_plot_shap(self, shap_values, X):
        df_ = pd.DataFrame(
            shap_values["data"], index=X.index, columns=shap_values["feature_names"]
        )
        fig = shap.summary_plot(shap_values["values"], df_)

        return fig

    def report_shap(self, X, mode, ensemble_weight=[]):
        shap_values_all = self.calc_shap_all(X, mode)
        shap_values_ensembled = self._calc_shap(
            shap_values_all, X, mode, ensemble_weight
        )
        figs_all = [
            self._summary_plot_shap(shap_values_, X) for shap_values_ in shap_values_all
        ]
        fig = self._summary_plot_shap(shap_values_ensembled, X)

        return figs_all, fig

    def _test_shap_values(self, shap_values, model, X_processed):
        """テスト用メソッド
        
        shap値の合計値と予測確率が一致することを確認
        """
        if model.is_fit_cv:
            pred_ = 0
            for i, model_fold in model.models.items():
                if model.model_name == "dnn":
                    X_processed_ = torch.Tensor(X_processed.values)
                    y_pred = model_fold.forward(X_processed_).detach().numpy().copy()
                else:
                    y_pred = model_fold.predict_proba(X_processed)
                if len(y_pred.shape) > 1:
                    pred_ += y_pred[0, 1]
                else:
                    pred_ += y_pred[0]

            pred_ /= len(model.models)
        else:
            if model.model_name == "dnn":
                X_processed_ = torch.Tensor(X_processed.values)
                y_pred = model.forward(X_processed_).detach().numpy().copy()
            else:
                y_pred = model.predict_proba(X_processed)
            if len(y_pred.shape) > 1:
                pred_ = y_pred[0, 1]
            else:
                pred_ = y_pred[0]

        if len(shap_values["values"].shape) == 2:
            chech_pred = (
                shap_values["base_values"][0] + shap_values["values"][0, :].sum()
            )
        else:
            chech_pred = (
                shap_values["base_values"][0, 1] + shap_values["values"][0, :, 1].sum()
            )

        temp = np.round(np.round(chech_pred, 4) - np.round(pred_, 4), 4)
        assert temp == 0 or shap_values["base_values"].min() >= 0, print(
            f"{model.model_name} / {np.round(chech_pred, 4)} - {np.round(pred_, 4)} - Error"
        )

        print(f"{model.model_name} / {np.round(chech_pred, 4)} - {np.round(pred_, 4)}")

    def _test_shap_values_all(self, shap_values_all, X):
        """テスト用メソッド
        
        shap_allに対し，shap値の合計値と予測確率が一致することを確認
        """
        for i, (model, X_processed) in enumerate(self.generate_setting(X)):
            self._test_shap_values(shap_values_all[i], model, X_processed)

        print("clear - shap_values_all")

    def _test_shap_values_ensembled(
        self, shap_values_ensembled, X, mode, ensemble_weight
    ):
        """テスト用メソッド
        
        アンサンブルしたSHAP値の合計とアンサンブルした予測確率がすべて一致することを確認
        """
        pred_all = self.predict_prob_all(X, mode)

        pred_ensembled = 0
        for i in range(len(ensemble_weight)):
            pred_ensembled += pred_all.iloc[:, i] * ensemble_weight[i]

        chech_pred = shap_values_ensembled["base_values"] + shap_values_ensembled[
            "values"
        ].sum(1)

        assert round(sum(pred_ensembled - chech_pred), 2) == 0, (
            "shap値のアンサンブル合計値とアンサンブルの予測確率の出力は一致する必要がある\n"
            + f" {round(sum(pred_ensembled - chech_pred), 2)} != 0"
        )

        print("アンサンブルした予測の出力値とSHAPのアンサンブル合計が一致しました")
