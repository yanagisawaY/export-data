import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.preprocessing import StandardScaler
from ...utils.cluster import cluster_kmeans_top

import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


class UnsupervisedLearner:
    def __init__(self, X_train, n_components, random_state):
        self.X_train = X_train
        self.X_train_scaled = self._scale(X_train)        
        self.X_train_pca = self._pca_fit(self.X_train_scaled, n_components, random_state)

    def _scale(self, X_train):
        self._scaler = StandardScaler()
        X_train_scaled = self._scaler.fit_transform(X_train)
        X_train_scaled = pd.DataFrame(X_train_scaled)
        X_train_scaled.columns = self.X_train.columns
        X_train_scaled.index = self.X_train.index        
        
        return X_train_scaled
        
    def _pca_fit(self, X_train_scaled, n_components, random_state):
        self._pca = PCA(n_components, random_state)
        X_train_pca = self._pca.fit_transform(X_train_scaled)
        self.pca_name = ["PC"+str(i+1) for i in range(len(self._pca.explained_variance_ratio_))]
        
        return X_train_pca
    
    def extract_pca_explained(self):
        pca_explained_variance_ratio = pd.Series(self._pca.explained_variance_ratio_, index=self.pca_name)
        
        return pca_explained_variance_ratio
    
    def extract_pca_info(self):
        pc_all = pd.DataFrame(self._pca.components_, columns=self.X_train.columns, index=self.pca_name).T
        extract_names = ["PC1", "PC2"]
        pc_extracted = pc_all[extract_names].reset_index()
        pc_extracted.columns = ["feature"] + extract_names
        
        return pc_extracted
        
    def _cluster(self, 
           X_train_scaled,
           min_num_clusters=3,
           max_num_clusters=10,
           n_init=5,
           random_state=0
            ):
        corr_distance, clusters, silh = cluster_kmeans_top(
                    corr_distance=X_train_scaled.corr(),
                    min_num_clusters=min_num_clusters,
                    max_num_clusters=max_num_clusters,
                    n_init=n_init,
                    random_state=random_state)
        
        cols = []
        for key, val in clusters.items():
            cols += val
            
        corr_info = pd.DataFrame([corr_distance.index, cols], index=["cluster", "feature"]).T
        corr_distance.columns = cols
        corr_distance.index = cols
        
        return corr_distance, corr_info

    def _calc_corr_num(self, corr_distance, corr_info):       
        corr_num = np.zeros((corr_distance.shape[0], corr_distance.shape[1], 2))
        for i in range(corr_num.shape[0]):
            for j in range(corr_num.shape[1]):
                corr_num[j][i][0] = str(corr_info.iloc[i,0])
                corr_num[i][j][1] = str(corr_info.iloc[i,0])
        
        return corr_num

    def _update_pca(self, corr_info):
        pc_extracted = self.extract_pca_info()
        corr_info_reindex = corr_info.set_index("feature").loc[list(pc_extracted["feature"])]
        corr_info_reindex = corr_info_reindex.reset_index()
        pc_extracted["cluster"] = corr_info_reindex.values[:,1].astype(str)

        return pc_extracted, corr_info_reindex
    
    def fig_pc_explained(self):
        pca_explained_variance_ratio = self.extract_pca_explained()
        
        fig = make_subplots(specs=[[{"secondary_y": True}]])        
        fig.add_trace(
            go.Bar(
                   x=pca_explained_variance_ratio.index, 
                   y=pca_explained_variance_ratio.values, 
                   name="寄与率")
            )
        fig.add_trace(
               go.Scatter(
                      x=pca_explained_variance_ratio.index, 
                      y=pca_explained_variance_ratio.cumsum(),
                      name="累積寄与率"
                      ),
               secondary_y=True,       
               )

        return fig
    
    def fig_corr(self, corr_distance, corr_num):
        fig = go.Figure(data=go.Heatmap(
            x=corr_distance.columns,
            y=corr_distance.columns,
            z=corr_distance,
            customdata=corr_num,
            hovertemplate='<b>corr:%{z:.3f}</b><br>feature1:%{x}</b><br><b>feature2:%{y}</b><br>cluster1:%{customdata[0]}</b><br>cluster2:%{customdata[1]}',
            hoverongaps = False,
            name="",
            )
        )
        fig.update_xaxes(side="top")
        return fig
    
    def fig_pc_scatter(self, pc_extracted):
        fig = px.scatter(
            pc_extracted,
            x="PC1",
            y="PC2",
            color="cluster",
            hover_data=["cluster", "feature"],    
            )
        fig.update_layout(
            xaxis={'title': 'PC1'},
            yaxis={'title': 'PC2'},
            hovermode="closest",
            title="第一主成分と第二主成分における観測変数の寄与度"
            )
        
        return fig
            
    def fig_corr_tSNE(
            self,
            corr_distance, 
            corr_info_reindex,
            n_components=2,
            learning_rate=300,
            perplexity=30,
            early_exaggeration=12,
            init='random',
            random_state=0
            ):
        tSNE = TSNE(n_components=n_components, learning_rate=learning_rate, \
                    perplexity=perplexity, early_exaggeration=early_exaggeration, \
                    init=init, random_state=random_state)
    
        tSNE_extracted = tSNE.fit_transform(corr_distance)
        tSNE_extracted = pd.DataFrame(data=tSNE_extracted, columns=["first",  "second"])
        tSNE_extracted["cluster"] = corr_info_reindex.values[:,1].astype(str)
        tSNE_extracted["feature"] = corr_distance.columns
    
        fig = px.scatter(
            tSNE_extracted,
            x="first",
            y="second",
            color="cluster",
            hover_data=["cluster", "feature"],    
            )
        fig.update_layout(
            xaxis={'title': 'first'},
            yaxis={'title': 'second'},
            hovermode="closest",
            title="t-SNEによる相関係数行列の次元削減"
            )
    
        return fig
            
    def get_all_figs(self):
        corr_distance, corr_info = self._cluster(
            self.X_train_scaled,
            min_num_clusters=3,
            max_num_clusters=10,
            n_init=5,
            random_state=0            
            )
        pc_extracted, corr_info_reindex = self._update_pca(corr_info)        
        corr_num = self._calc_corr_num(corr_distance, corr_info)
        pc_extracted, corr_info_reindex = self._update_pca(corr_info)   
        figs = [
            self.fig_pc_explained(),
            self.fig_pc_scatter(pc_extracted),
            self.fig_corr(corr_distance, corr_num),
            self.fig_corr_tSNE(
                corr_distance, 
                corr_info_reindex,
                n_components=2,
                learning_rate=300,
                perplexity=30,
                early_exaggeration=12,
                init='random',
                random_state=0
                )
            ]
        
        return figs