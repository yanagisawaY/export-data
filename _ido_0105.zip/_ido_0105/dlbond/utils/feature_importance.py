"""変数重要度を求めるクラス

Notes
-------
以下の命名略称
* f_imp -> 'feature_importance'
"""

import numpy as np
import pandas as pd
from sklearn.metrics import log_loss
import shap

from .cluster import cluster_kmeans_top
from .backtester import BackTester
from .variation_info import VarInfo


def group_mean_sd(f_imp, clusters):
    """クラスター単位で変数重要度の平均と標準偏差を求める

    Parameters
    ----------
    f_imp : pd.DataFrame
        特徴量ごとのMDI
    clusters : dict
        各クラスターに属するID番号.

    Returns
    -------
    out : pd.DataFrame
        クラスターごとの変数重要度(行方向にクラスター, 列方向に[mean, sd])\n
        クラスター単位の変数重要度の平均と標準偏差を算出
    """
    out = pd.DataFrame(columns=["mean", "std"])
    for i, features_ in clusters.items():
        f_imp_cluster = f_imp[features_].sum(axis=1)
        out.loc["C_" + str(i), "mean"] = f_imp_cluster.mean()
        out.loc["C_" + str(i), "std"] = (
            f_imp_cluster.std() * f_imp_cluster.shape[0] ** -0.5
        )

    return out


def group_imp_booster(f_imp, clusters):
    """クラスター単位で変数重要度を求める(ブースティングベースのツリーで使用)

    Parameters
    ----------
    f_imp : pd.DataFrame
        特徴量ごとのMDI
    clusters : dict
        各クラスターに属するID番号.

    Returns
    -------
    out : pd.DataFrame
        クラスターごとの変数重要度(行方向にクラスター, 列方向に[mean, sd])\n
        クラスター単位の変数重要度の平均と標準偏差を算出
    """
    out = pd.DataFrame(
        index=["C_" + str(i) for i in clusters.keys()],
        columns=["mean_cluster", "sd_cluster"],
    )
    for i, features_ in clusters.items():
        out.loc["C_" + str(i), "mean_cluster"] = f_imp.loc[features_].mean()
        out.loc["C_" + str(i), "sd_cluster"] = f_imp.loc[features_].std()

    return out


def _update_clf_params(clf, val_ratio=0.1):
    clf.hyperparms.update(
        {"val_ratio": val_ratio,}
    )

    return clf


def _calc_f_imp_mdi(fit, feature_names, clusters={}):
    """MDIを算出する関数

    Parameters
    ----------
    fit : 
        学習済みモデル(ツリーベースのモデル)
    feature_names : list
        特徴量の名前リスト
    clusters : dict, optional
        各クラスターに属するID番号, by default {}

    Returns
    -------
    f_imp : pd.DataFrame
        クラスターごとの変数重要度(行方向にクラスター(or 特徴量), 列方向に[mean, sd])
    
    Notes
    -----
    * MDIはツリーベースモデルでのみ算出可能
    
    * estimators_を使用できるアンサンブルベースのモデルの場合，treeごとの変数重要度の平均と標準偏差を算出
    
    * ブースティングベースモデルの場合,変数重要度の平均と標準偏差は算出しない
    """
    if "estimators_" in dir(fit):
        f_imp_ = {
            i: tree.feature_importances_ for i, tree in enumerate(fit.estimators_)
        }
        f_imp = pd.DataFrame.from_dict(f_imp_, orient="index")
        f_imp.columns = feature_names
        f_imp = f_imp.replace(0, np.nan)  # because max_features = 1

        if len(clusters) == 0:
            f_imp = pd.concat(
                {"mean": f_imp.mean(), "std": f_imp.std() * f_imp.shape[0] ** -0.5},
                axis=1,
            )
        else:
            f_imp = group_mean_sd(f_imp, clusters)

        f_imp /= f_imp["mean"].sum()
    else:
        f_imp = fit.feature_importances_
        f_imp = pd.Series(f_imp, index=feature_names)
        if len(clusters) == 0:
            f_imp = f_imp.sort_values(ascending=False)
        else:
            f_imp = group_imp_booster(f_imp, clusters)

    return f_imp


def _calc_f_imp_mda(clf, dict_val, val_ratio=None, clusters={}):
    """MDAを算出する関数

    Parameters
    ----------
    clf : 
        モデルクラス(学習済みである必要はない)
    dict_val : dict
        KFoldのバリデーションデータセット
    val_ratio : float, optional
        バリデーションデータを使用する割合, Noneの場合はバリデーションデータを作成しない．
    clusters : dict, optional
        各クラスターに属するID番号\n
        {}とした場合，クラスター単位でのMDAを算出せず，各特徴量に対するMDAを算出

    Returns
    -------
    f_imp : pd.DataFrame
        クラスターごとの変数重要度(行方向にクラスター(or 特徴量), 列方向に[mean, sd])
    
    Notes
    -----
    * 2値分類予測のタスクのみに対応
    """
    if len(clusters):
        imp_name = clusters.keys()
        is_cluster = True
        scr1 = pd.DataFrame(columns=imp_name)
    else:
        is_cluster = False
        temp = dict_val[0]["X_train"]
        imp_name = temp.columns
        scr1 = pd.DataFrame(columns=temp.columns)

    is_val = isinstance(val_ratio, float)
    if val_ratio is not None:
        clf = _update_clf_params(clf, val_ratio=val_ratio)

    scr0 = pd.Series()
    for i, val in dict_val.items():
        X_train, y_train, X_val, y_val = val.values()
        clf.fit(X_train, y_train, is_val=is_val, hyperparms_model=[])
        prob = clf.predict(X_val)
        scr0.loc[i] = -log_loss(y_val, prob)
        for j in imp_name:
            X_val_ = X_val.copy(deep=True)
            if is_cluster:
                for k in clusters[j]:
                    np.random.shuffle(X_val_[k].values)
            else:
                np.random.shuffle(X_val_[j].values)

            prob = clf.predict(X_val_)
            scr1.loc[i, j] = -log_loss(y_val, prob)

    imp = (-1 * scr1).add(scr0, axis=0)
    imp = pd.concat(
        {"mean": imp.mean(), "std": imp.std() * imp.shape[0] ** -0.5}, axis=1
    )
    if is_cluster:
        imp.index = ["C_" + str(i) for i in imp.index]

    return imp


def _calc_corr(X, mode="distance"):
    """相関係数行列を返す関数

    Parameters
    ----------
    X : pd.DataFrame
        特徴量データ
    mode : str, optional
        distanceとした場合，相関係数行列を距離の公理を満たすように変換

    Returns
    -------
    out : pd.DataFrame
        相関係数行列(mode=distanceとした場合，距離の公理を満たすように変換)
    
    References
    ----------
    * アセットマネージャーのためのファイナンス機械学習3.2「相関に基づく測度」
    
    * 相関係数の値xを(0.5*(1 - x))**0.5として変換
    """
    if mode == "distance":
        out = (0.5 * (1 - X.corr())) ** 0.5
    elif mode is None:
        out = X.corr()
    else:
        raise ValueError(
            "current version only supports 'mode'='distance' or 'mode'=None."
        )

    return out


class FeatureImportance:
    def __init__(self, hyperparams_imp):
        self.hyperparams_imp = hyperparams_imp

    def _set_default_params(self):
        """hyperparamsで設定されていないパラメータに対し，デフォルトのパラメータを設定
        """
        params_default = {
            "min_num_clusters": 5,
            "max_num_clusters": 10,
            "n_init": 5,
            "random_state": 0,
            "pct_embargo": 0.01,
            "lookback_window": 0,
            "n_splits": 10,
            "val_ratio": 0.2,
        }
        for key in params_default.keys():
            if key not in list(self.hyperparams_imp.keys()):
                self.hyperparams_imp[key] = params_default[key]

    def calc_distance(self, X):
        """距離行列を算出
        
        * hyperparams -> distance_typeに応じた距離行列を算出
            * VarInfo : Variation of Information\n
            * corr : 相関行列        

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ

        Returns
        -------
        distance : pd.DataFrame
            距離行列
        
        Notes
        -----
        * Variation of Informationについては，アセットマネージャーのためのファイナンス機械学習3.8を参照
        """
        self.distance_type = self.hyperparams_imp["distance_type"]
        args = self.hyperparams_imp[self.distance_type]
        args.update({"X": X})
        if self.distance_type == "VarInfo":
            distance = VarInfo(**args)
        elif self.distance_type == "corr":
            distance = _calc_corr(**args)
        else:
            raise ValueError("VarInfoかcorrのどちらかにしか対応していません")

        return distance

    def call_cluster(self, X):
        """クラスターの分類結果を取得

        Parameters
        ----------

        X : pd.DataFrame
            特徴量データ

        Returns
        -------
        clusters : dict
            各特徴量が属するクラスターのID番号.
        """
        corr_distance = self.calc_distance(X)
        _, clusters, _ = cluster_kmeans_top(
            corr_distance=corr_distance,
            min_num_clusters=self.hyperparams_imp["min_num_clusters"],
            max_num_clusters=self.hyperparams_imp["max_num_clusters"],
            n_init=self.hyperparams_imp["n_init"],
            random_state=self.hyperparams_imp["random_state"],
        )

        return clusters

    def calc_f_imp_mda(
        self, clf, dict_val, clusters={},
    ):
        """MDAを算出する関数

        Parameters
        ----------
        clf : 
            モデルクラス(学習済みである必要はない)
        dict_val : dict
            KFoldのバリデーションデータセット
        clusters : dict, optional
            各クラスターに属するID番号\n
            {}とした場合，クラスター単位でのMDAを算出せず，各特徴量に対するMDAを算出

        Returns
        -------
        f_imp : pd.DataFrame
            クラスターごとの変数重要度(行方向にクラスター(or 特徴量), 列方向に[mean, sd])
        
        Notes
        -----
        * 2値分類予測のタスクのみに対応
        """
        return _calc_f_imp_mda(
            clf, dict_val, self.hyperparams_imp["val_ratio"], clusters
        )

    def calc_f_imp_mdi(self, fit, feature_names, clusters={}):
        """MDIを算出する関数
    
        Parameters
        ----------
        fit : 
            学習済みモデル(ツリーベースのモデル)
        feature_names : list
            特徴量の名前リスト
        clusters : dict, optional
            各クラスターに属するID番号, by default {}
    
        Returns
        -------
        f_imp : pd.DataFrame
            クラスターごとの変数重要度(行方向にクラスター(or 特徴量), 列方向に[mean, sd])
        
        Notes
        -----
        * MDIはツリーベースモデルでのみ算出可能
        """
        return _calc_f_imp_mdi(fit, feature_names, clusters)


class FeatureImportanceChecker(BackTester):
    def __init__(self, dfs_input, config):
        super().__init__(dfs_input, config)
        self.fi = FeatureImportance(config["hyperparams_imp"])
        self.clusters = {}
        self._check_start_date = None
        self._check_end_date = None
        self.model_name = config["model"]
        self.is_tune = config["hyperparams_imp"]["is_tune"]
        self._model_estimated = None

    def _call_cluster(self, start_date, end_date):
        """クラスター分類を実行

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点
        
        Notes
        -----
        * Splitterクラスのmake_datesetメソッドを用いることで，
        configにて設定したPCAや基準化処理後のデータを取得．\n
        -> これらデータに対しクラスターを算出

        * クラスターの計算結果はMDIやMDAで共通して参照する可能性があるため，クラスとして保持\n
        -> ただし，データの期間の変更した際はクラスターの計算をしなおすため，
        一度計算を実施した際に使用したデータの期間情報(開始，終了)を_check_start_date等で保持．\n
        """
        start_date_train = start_date_test = start_date
        end_date_train = end_date_test = end_date
        X, _, _, _, _ = self.make_dataset(
            start_date_train, end_date_train, start_date_test, end_date_test
        )
        self.clusters = self.fi.call_cluster(X)
        self._check_start_date = start_date
        self._check_end_date = end_date

    def _set_dataset(self, start_date, end_date):
        """バリデーションデータを作成

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点

        Returns
        -------
        dict_val : dict
            KFoldのバリデーションデータセット
        """
        X, y, t1 = self.make_trainset(start_date, end_date)
        dict_val = self.make_dict_valid(X, y, t1)

        return dict_val

    def _set_cluster(self, start_date, end_date, is_cluster):
        """クラスターの計算を実行

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点
        is_cluster : bool
            クラスター単位の変数重要度を求める場合はTrue
        
        Notes
        -----
        * 計算負荷を考慮し，以下のいずれかの場合にクラスターの計算を実行.
            1. clusterの呼び出しをしていない場合
            2. 以前にクラスターを呼び出した際に使用したデータ期間と異なる期間を指定した場合
            上記二点に該当せず，is_cluster=Trueである場合はすでにクラス内で保持したself.clustersが参照される
        """
        if is_cluster:
            _bool = (
                self._check_start_date == start_date
                and self._check_end_date == end_date
            )
            if len(self.clusters) == 0 or not _bool:
                # 以下のいずれかの場合にクラスターの計算を実行
                # clusterの呼び出しをしていない場合，
                # 以前にクラスターを呼び出した際に使用したデータ期間と異なる期間を指定した場合，
                print("cluster")
                self._call_cluster(start_date, end_date)
                print("cluster...end")
        else:
            self.clusters = {}

    def _set_estimator(self, start_date, end_date, is_tune=False):
        _bool = (
            self._check_start_date == start_date and self._check_end_date == end_date
        )
        if self._model_estimated is None == 0 or not _bool:
            self._model_estimated, self._feature_names = self._fit_estimator(
                start_date, end_date, is_tune
            )
        else:
            pass

    def _tune_hyperparams(self, dict_val):
        self.estimator.tune_Kfold_nonprune(
            dict_val,
            self.config[self.config["model"]]["is_val"],
            self.config["config_optuna"]["n_trials"],
            self.config["config_optuna"]["timeout"],
        )
        _ = self.estimator.update_hyperparams()

    def _make_dataset(self, start_date, end_date):
        """全期間のデータに対し，前処理を実施したデータを取得

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点

        Returns
        -------
        X : pd.DataFrame
            特徴量データ        
        y : pd.DataFrame
            説明変数データ
        """
        start_date_train = start_date_test = start_date
        end_date_train = end_date_test = end_date
        X, y, _, _, _ = self.make_dataset(
            start_date_train, end_date_train, start_date_test, end_date_test
        )

        return X, y

    def _fit_estimator(self, start_date, end_date, is_tune=False):
        """モデルの学習を実施

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点
        is_tune : bool
            Trueの場合，tune_Kfold_nonpruneによりハイパーパラメータのチューニングを実施

        Returns
        -------
        clf.model : model
            学習済みモデル.
        feature_names : list
             特徴量のリスト
        
        Notes
        -----
        * MDIでは学習済みモデルを使用することから，本機能ではMDIでの使用を想定している
        """
        X, y = self._make_dataset(start_date, end_date)

        if is_tune:
            print("モデルのチューニング開始...")
            dict_val = self._set_dataset(start_date, end_date)
            self._tune_hyperparams(dict_val)

        is_val = self.fi.hyperparams_imp["val_ratio"] is not None
        if is_val:
            clf = _update_clf_params(
                self.estimator, val_ratio=self.fi.hyperparams_imp["val_ratio"]
            )
        else:
            clf = self.estimator

        print("モデルの学習開始...")
        clf.fit(X, y, is_val)
        print("モデルの学習完了...")
        feature_names = X.columns

        return clf.model, feature_names

    def report_mda(self, start_date, end_date, is_cluster=True):
        """指定した期間のデータを使用してMDAを実施

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点
        is_cluster : bool
            クラスター単位の変数重要度を求める場合はTrue

        Returns
        -------
        imp_mda : pd.DataFrame
            (クラスターごとの)MDAによる変数重要度(行方向にクラスター(or 特徴量), 列方向に[mean, sd])
        """
        dict_val = self._set_dataset(start_date, end_date)
        self._set_cluster(start_date, end_date, is_cluster)
        imp_mda = self.fi.calc_f_imp_mda(
            self.estimator, dict_val, clusters=self.clusters
        )

        return imp_mda

    def report_mdi(self, start_date, end_date, is_cluster=True):
        """指定した期間のデータを使用してMDIを実施

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点
        is_cluster : bool
            クラスター単位の変数重要度を求める場合はTrue

        Returns
        -------
        imp_mdi : pd.DataFrame
            (クラスターごとの)MDIよる変数重要度(行方向にクラスター(or 特徴量), 列方向に[mean, sd])
        
        Notes
        -----
        * クラスター単位で変数重要度を求める場合，meanとsdを算出．(クラスター内の平均と標準偏差を算出)
        
        * is_cluster=False，かつブースティングベースのモデル(xgboost,lightgbm)の場合，sdは算出されない
        """
        assert self.model_name in [
            "xgboost",
            "lightgbm",
        ], "MDIはツリーベースモデルでのみ算出可能です"
        self._set_estimator(start_date, end_date, self.is_tune)
        self._set_cluster(start_date, end_date, is_cluster)
        imp_mdi = self.fi.calc_f_imp_mdi(
            self._model_estimated, self._feature_names, self.clusters
        )

        return imp_mdi

    def get_shap_explainer(self, start_date, end_date):
        self._set_estimator(start_date, end_date, self.is_tune)
        if self.model_name in ["xgboost", "lightgbm"]:
            explainer = shap.Explainer(self._model_estimated)
        elif self.model_name in ["dnn"]:
            X, y = self._make_dataset(start_date, end_date)
            X, y = self.estimator.get_tensor(X, y)
            explainer = shap.DeepExplainer(self._model_estimated, X)
        else:
            raise ValueError("current version only supports xgboost/lightgbm/dnn")

        return explainer

    def get_shap_values(self, explainer, start_date, end_date):
        X, y = self._make_dataset(start_date, end_date)
        if self.model_name == "xgboost":
            shap_values = explainer(X)
        elif self.model_name == "lightgbm":
            shap_values = explainer(X)
            shap_values = shap_values[:,:,1]
        elif self.model_name in ["dnn"]:
            X, y = self.estimator.get_tensor(X, y)            
            shap_values = explainer.shap_values(X)
        else:
            raise ValueError("current version only supports xgboost/lightgbm/dnn")   
        
        return shap_values
    
    def report_shap(self, start_date, end_date):
        """shap値を取得

        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点

        Returns
        -------
        shap_values
            shap値
        
        References
        ----------
        1.https://github.com/slundberg/shap

        Notes
        -----
        * ツリーアンサンブルモデルとDNNで参照するSHAPの算出方法が異なる
        
        * 本メソッドを参照した場合，shap値は全訓練データに対して算出されることに注意
        """
        explainer = self.get_shap_explainer(start_date, end_date)
        shap_values = self.get_shap_values(explainer, start_date, end_date)
        
        return shap_values