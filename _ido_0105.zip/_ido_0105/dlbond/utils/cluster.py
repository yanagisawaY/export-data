"""
    ONCベースクラスタリング
    アセットマネージャーのためのファイナンス機械学習 P.78
"""
import numpy as np
import pandas as pd
from scipy.sparse.construct import rand
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples


def cluster_KMeans_base(
    corr_distance, min_num_clusters, max_num_clusters, n_init, random_state=0
):
    """ONCベースクラスタリングを実施する関数
    アセットマネージャーのためのファイナンス機械学習 P.78

    Parameters
    ----------
    corr_distance : np.array or pd.DataFrame
        相関係数行列(あるいは相関係数以外の距離行列)
    max_num_clusters : int
        クラスター数の最小値.        
    max_num_clusters : int
        クラスター数の最大値.
    n_init : int
        初期化計算の繰り返し回数. (k_means++におけるn_initではない)
    random_state : init
        ランダムシード

    Returns 
    -------
    corr_distance : pd.DataFrame
        クラスターごとに並び変えた相関係数行列.
    clusters : dict
        各特徴量が属するクラスターのID番号.
    silh : pd.Series
        シルエットスコア.
    """
    # corrの行方向に対し，相関係数行列を作成する
    if not isinstance(corr_distance, pd.DataFrame):
        corr_distance = pd.DataFrame(corr_distance)

    index_corr = corr_distance.copy().index
    silh = pd.DataFrame()

    for init in range(n_init):
        for i in range(min_num_clusters, max_num_clusters + 1):
            kmeans_ = KMeans(n_clusters=i, n_init=10, random_state=random_state + init)
            kmeans_ = kmeans_.fit(corr_distance)
            silh_ = silhouette_samples(corr_distance, kmeans_.labels_)
            stat = (silh_.mean() / silh_.std(), silh.mean() / silh.std())

            if isinstance(stat[1], pd.Series) or (stat[0] > stat[1]):
                # print(f"####### cluster{i} #######")
                silh, kmeans = silh_, kmeans_

    clusters = {
        i: corr_distance.columns[np.where(kmeans.labels_ == i)[0]].tolist()
        for i in np.unique(kmeans.labels_)
    }


    idx_new = np.argsort(kmeans.labels_)
    corr_distance = corr_distance.iloc[idx_new, :]
    corr_distance = corr_distance.iloc[:, idx_new]
    silh = pd.Series(silh, index=index_corr)

    corr_distance.index = (
        corr_distance.columns
    ) = (
        index_corr[idx_new]
    )        

    return corr_distance, clusters, silh


def update_output(corr_distance, clusters, clusters2):
    """更新した下位クラスターの結果(clusters2)を上位クラスターの結果(clusters)に反映させる関数

    Parameters
    ----------
    corr_distance : pd.DataFrame
        クラスターごとに並び変えた相関係数行列.
    clusters : dict
        各特徴量が属するクラスターのID番号(更新前).
    clusters2 : dict
        各特徴量が属するクラスターのID番号(更新後).

    Returns
    -------
    corr_distance_new : pd.DataFrame
        clusters_newのクラスター番号順に並び変えた相関係数行列.
    clusters_new : dict
        各特徴量が属するクラスターのID番号(clustersとclusters2を結合した辞書).
    silh_new : pd.Series
        clusters_newに基づき求めたシルエットスコア.  
    """
    clusters_new = {}
    for i in clusters.keys():
        clusters_new[len((clusters_new.keys()))] = list(clusters[i])
    for i in clusters2.keys():
        clusters_new[len((clusters_new.keys()))] = list(clusters2[i])
    
    index_new = [j for i in clusters_new for j in clusters_new[i]]
    corr_distance_new = corr_distance.loc[index_new, index_new]
    kmeans_labels = np.zeros(len(corr_distance.columns))
    for i in clusters_new.keys():
        idxs = [corr_distance.index.get_loc(k) for k in clusters_new[i]]
        kmeans_labels[idxs] = i
        
    silh_new = pd.Series(
        silhouette_samples(corr_distance, kmeans_labels), index=corr_distance.index
    )

    return corr_distance_new, clusters_new, silh_new


def cluster_kmeans_top(
    corr_distance, min_num_clusters=2, max_num_clusters=None, n_init=10, random_state=0
):
    """上位クラスタリングを実施する関数
            
    Parameters
    ----------
    corr_distance : np.array or pd.DataFrame
        相関係数行列(あるいは相関係数以外の距離行列)
    max_num_clusters : int
        クラスター数の最小値.        
    max_num_clusters : int
        クラスター数の最大値.
    n_init : int
        初期化計算の繰り返し回数. (k_means++におけるn_initではない)
    random_state : init
        ランダムシード

    Returns 
    -------
    corr_distance : pd.DataFrame
        クラスターごとに並び変えた相関係数行列.
    clusters : dict
        各特徴量が属するクラスターのID番号.
    silh : pd.Series
        シルエットスコア.
    
    Notes
    -----
    * 再帰関数となっていることに注意
        
    References
    ----------
    * アセットマネージャーのためのファイナンス機械学習 4.4.3   
    """    
    if max_num_clusters is None:
        max_num_clusters = corr_distance.shape[1] - 1

    corr_distance1, clusters, silh = cluster_KMeans_base(
        corr_distance,
        min_num_clusters=min(min_num_clusters, corr_distance.shape[1] - 1),
        max_num_clusters=min(max_num_clusters, corr_distance.shape[1] - 1),
        n_init=n_init,
        random_state=random_state,
    )
    cluster_tstat = {
        i: np.mean(silh[clusters[i]]) / (np.std(silh[clusters[i]]) + 1e-10)
        for i in clusters.keys()
    }
    tstat_mean = sum(cluster_tstat.values()) / len(cluster_tstat)
    redo_clusters = [i for i in cluster_tstat.keys() if cluster_tstat[i] < tstat_mean]
    
    if len(redo_clusters) <= 1:
        return corr_distance1, clusters, silh
    else:
        keys_redo = [j for i in redo_clusters for j in clusters[i]]
        corr_distance_redo = corr_distance.loc[keys_redo, keys_redo]
        tstat_mean = np.mean([cluster_tstat[i] for i in redo_clusters])
        # 再帰的に関数を実行
        corr_distance2, clusters2, silh2 = cluster_kmeans_top(
            corr_distance_redo,
            min_num_clusters=min(min_num_clusters, corr_distance_redo.shape[1] - 1),
            max_num_clusters=min(max_num_clusters, corr_distance_redo.shape[1] - 1),
            n_init=n_init,
            random_state=random_state,
        )
        # len(redo_clusters) <= 1となり下位のクラスタリングを更新
        corr_distance_new, clusters_new, silh_new = update_output(
            corr_distance,
            {i: clusters[i] for i in clusters.keys() if i not in redo_clusters},
            clusters2,
        )
        tstat_mean_new = np.mean(
            [
                np.mean(silh_new[clusters_new[i]]) / (np.std(silh_new[clusters_new[i]]) + 1e-10)
                for i in clusters_new.keys()
            ]
        )
        if tstat_mean_new <= tstat_mean:
            return corr_distance1, clusters, silh
        else:
            return corr_distance_new, clusters_new, silh_new

