"""
テクニカル指標作成のコード群

Notes:
    1.関数の命名はta-libにあわせ，すべて大文字で設定
    2.テクニカル指標作成に関わるものはconfigフォルダにて設定
    3.以下の引数は固定(TA-Libの仕様にあわせた)
        close  : 終値
        open   : 始値
        high   : 高値
        low    : 安値
        volume : 取引高    
"""
from datetime import time
import numpy as np
import pandas as pd

def SMA(close, timeperiod, mode):
    """調整後終値ベースの移動平均を算出（modeにて加工方法を指定)
    
    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    timeperiod : int
        スライド期間.
    mode : str
        加工方法の選択
        raw   : 原形列 -> 調整後終値ベースの移動平均
        range : 乖離幅 -> 調整後終値ベースの移動平均乖離幅
        ratio : 乖離率 -> 調整後終値ベースの移動平均乖離率

    Returns
    -------
    output : pd.DataFrame or pd.Series       
        調整後終値ベースの移動平均（原形列 or 乖離幅 or 乖離率）

    Raises
    ------
    ValueError
        modeにて例外が入力された場合，警告文とともに処理を停止
    """
    if mode == 'raw':
        output = close.rolling(timeperiod).mean()
    elif mode == 'range':
        output = close - (close.rolling(timeperiod).mean())
    elif mode == 'ratio':
        output = close/(close.rolling(timeperiod).mean())        
    else:
        raise ValueError('Current version is only available for "raw" or "range" or "ratio" as input for mode')
    
    return output

def VOL(close, rollperiod, mode, meanperiod=None):
    '''調整後終値ベースのボラティリティを算出（modeにて加工方法を指定)

    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    rollperiod : int
        ボラティリティ算出時のスライド期間.
    meanperiod : int
        ボラティリティの移動平均値算出時のスライド期間.
        modeがrange,ratioのときのみ指定が必要
    mode : str
        加工方法の選択
        raw   : 原形列 -> 調整後終値ベースのボラティリティ
        range : 乖離幅 -> 調整後終値ベースのボラティリティと移動平均との乖離幅
        ratio : 乖離率 -> 調整後終値ベースのボラティリティと移動平均との乖離率

    Returns
    -------
    output : pd.DataFrame or pd.Series       
        調整後終値ベースのボラティリティ （原形列 or 移動平均乖離幅 or 移動平均乖離率）   
    '''    
    if mode == 'raw':
        output = np.log(close).diff().rolling(rollperiod).std()
    elif mode == 'range':
        vol = np.log(close).diff().rolling(rollperiod).std()
        output = vol - vol.rolling(meanperiod).mean()
    elif mode == 'ratio':
        vol = close/(close.rolling(rollperiod).std())        
        output = vol - vol.rolling(meanperiod).mean()        
    else:
        raise ValueError('Current version is only available for "raw" or "range" or "ratio" as input for mode')

    return output

def MACD(close, fastperiod=12, slowperiod=26, signalperiod=9):
    '''調整後終値ベースのMACDを算出

    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    fastperiod : int
        短期EMA（指数移動平均）における平均期間
    slowperiod : int
        長期EMAにおける平均期間    
    signalperiod : int
        MACDのEMAにおける平均期間

    Returns
    -------
    output : pd.DataFrame or pd.Series
        macd-signalの値(一般にhistgramと呼ばれるもの)

    Notes
    -----
    References 
    https://www.moneypartners.co.jp/support/tech/macd.html   
    https://qiita.com/MuAuan/items/b08616a841be25d29817
    '''    
    ema_fast = close.ewm(span=fastperiod).mean()
    ema_slow = close.ewm(span=slowperiod).mean()
    macd = ema_fast - ema_slow
    signal = macd.ewm(span=signalperiod).mean()
    output = macd - signal

    return output

def ROC(close, timeperiod=10):
    """ROC(Rate of Change)を算出する関数

    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値
    timeperiod : int
        何日前の終値を参照するか, by default 10

    Returns
    -------
    output : pd.DataFrame or pd.Series
        ROC(Rate of Change)

    Notes
    -----
    https://www.moneypartners.co.jp/support/tech/roc.html
    """
    output = (close/close.shift(timeperiod))/close.shift(timeperiod)*100

    return output

def RSI(close, timeperiod=14):
    """RSI(Relative Strength Index)を算出する関数

    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値
    timeperiod : int, optional
        上昇(下落)幅の算出期間, by default 14

    Returns
    -------
    output : pd.DataFrame or pd.Series
        RSI(Relative Strength Index)

    Notes
    -----        
    https://www.moneypartners.co.jp/support/tech/rsi.html
    """
    rs_up = (close.diff()*(close.diff()>=0)).rolling(timeperiod).sum()/timeperiod
    rs_up_mean = (rs_up.shift(1)*(timeperiod-1) + rs_up)/timeperiod
    rs_down = -1*(close.diff()*(close.diff()<0)).rolling(timeperiod).sum()/timeperiod    
    rs_down_mean = (rs_down.shift(1)*(timeperiod-1) + rs_down)/timeperiod
    rs = rs_up_mean/rs_down_mean
    output = 100 - 100/(1+rs)

    return output

def SKEW(close, rollperiod, mode, meanperiod=None):
    '''調整後終値ベースのスキューを算出（modeにて加工方法を指定)

    Parameters
    ----------
    close : pd.DataFrame or pd.Series
        調整後終値.
    rollperiod : int
        スキュー算出時のスライド期間.
    meanperiod : int
        スキューの移動平均値算出時のスライド期間.
        modeがrange,ratioのときのみ指定が必要
    mode : str
        加工方法の選択
        raw   : 原形列 -> 調整後終値ベースのスキュー
        range : 乖離幅 -> 調整後終値ベースのスキューと移動平均との乖離幅
        ratio : 乖離率 -> 調整後終値ベースのスキューと移動平均との乖離率

    Returns
    -------
    output : pd.DataFrame or pd.Series       
        調整後終値ベースのスキュー （原形列 or 移動平均乖離幅 or 移動平均乖離率）   
    '''    
    if mode == 'raw':
        output = np.log(close).diff().rolling(rollperiod).skew()
    elif mode == 'range':
        vol = np.log(close).diff().rolling(rollperiod).skew()
        output = vol - vol.rolling(meanperiod).mean()
    elif mode == 'ratio':
        vol = close/(close.rolling(rollperiod).skew())        
        output = vol - vol.rolling(meanperiod).mean()        
    else:
        raise ValueError('Current version is only available for "raw" or "range" or "ratio" as input for mode')

    return output    

def RCI(close, timeperiod):
    """調整後終値ベースのRCI(Rank Correlation Index)を算出

    Parameters
    ----------
    close : pd.Series
        調整後終値.
    timeperiod : int
        スライド期間.
    Returns
    -------
    output : pd.Series
        調整後終値ベースのRCI

    Notes
    -----
    https://kabu.com/investment/guide/technical/14.html
    実行速度が他の関数よりも遅い．
    参考 : Pearsonの相関係数の場合は以下にて算出(spearmanの相関係数に対応していない)
    df = pd.concat([pd.Series(list(reversed(range(1, len(close)+1)))), close.reset_index(drop=True)], axis=1)
    rci = pd.Series(df.rolling(timeperiod).corr().loc[::2, close.name].values, index=close.index)    
    """       
    output = []    
    for i in range(timeperiod, len(close)):
        index_ = pd.Series(list(reversed(range(1, timeperiod+1))))
        corr = pd.DataFrame([close[i-timeperiod:i].values, index_.values]).T.corr(method='spearman').values[1, 0]
        output += [corr]

    temp = pd.Series([np.nan for _ in range(timeperiod)], index=close[:timeperiod].index)    
    output = pd.Series(output, index=close[timeperiod:].index)
    output = pd.concat([temp, output])

    return output

def ATR(close, high, low, timeperiod=14):
    """ATR(Averaget True Range)を算出

    Parameters
    ----------
    close : pd.Series
        調整後終値.
    high : pd.Series
        高値.
    low : pd.Series
        安値.
    timeperiod : int, optional
        移動平均計算時のウィンドウ, by default 14

    Returns
    -------
    output : pd.Series
        ATR

    Note
    -------
    https://www.rakuten-sec.co.jp/MarketSpeed/onLineHelp/msman2_5_2_21.html
    """
    a = high - low
    b = high - close.shift(1)
    c = close.shift(1) - low
    tr = pd.concat([a, b, c], axis=1).max(axis=1)
    output = tr.rolling(window=timeperiod).mean()

    return output

def STOCH(close, high, low, timeperiod=14):
    """ストキャスティクスを算出

    Parameters
    ----------
    close : pd.Series
        調整後終値.
    high : pd.Series
        高値.
    low : pd.Series
        安値.
    timeperiod : int, optional
        ストキャスティクスを算出する際の過去参照時点, by default 14

    Returns
    -------
    output : pd.Series
        ストキャスティクス
    Note
    -------        
    http://www.algo-fx-blog.com/stochastics-python/    
    """
    output = (close - low.shift(timeperiod))/(high.shift(timeperiod) - low.shift(timeperiod))

    return output

# def VR(close, volume, timeperiod):
#     # https://www.sevendata.co.jp/shihyou/jukyuu/vr.html
#     # https://www.sevendata.co.jp/shihyou/jukyuu/vr.html
#     price_diff = close.rolling(timeperiod).diff().apply(lambda x:)
#     VR = ((close.diff()>0)*volume + 0.5*(close.diff()==0)*volume)/((close.diff()<0)*volume + 0.5*(close.diff()==0)*volume)

# def ADX(close, high, low, timeperiod=14):
#     # https://www.moneypartners.co.jp/support/tech/dmi-adx.html
#     plus_dm = high.diff()
#     minus_dm = low.diff()
#     a = high - low
#     b = high - close.shift(1)
#     c = close.shift(1) - low
#     tr = max(a, b, c)
#     plus_di = 


