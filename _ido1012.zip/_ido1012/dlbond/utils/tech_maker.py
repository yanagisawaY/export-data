"""
Notes:
    1.テクニカル指標のデータ作成のコード
    2.テクニカル指標作成に関わる設定はconfig.py（別コード）にて実施
    3.tech_funcにて定めたテクニカル指標作成関数を用いて処理を実施
"""
import pandas as pd
import itertools
from ..config.config import tech_config, tech_ohlcv_config
from . import tech_func

class DataMaker:
    def __init__(self, dfs_input : dict, config : dict):
        self.dfs_input = dfs_input
        self.features = config['features']
        self.config_ohlcv_features = config['features_ohlcv']
        self.ohlcv_names = {
            # 変数名の変換
            'LAST' : 'close',
            'OPEN' : 'open',
            'HIGH' : 'high',
            'LOW'  : 'low',            
            }
        
    def check_input(self):
        """入力値の形式の確認

        Assert
        ------        
        this version must include ["daily", "month", "irregular"] in dict`s name of dfs_input.
        Please input config["target_name"] as list even if only using one target.
        """
        assert isinstance(self.dfs_input, dict)
        for val in self.dfs_input.values():
            assert isinstance(val.index, pd.core.indexes.datetimes.DatetimeIndex)

        df_list_names = list(self.dfs_input.keys())
        assert sum([x in ['daily', 'month', 'irregular'] for x in df_list_names])==3, (
            'this version must include ["daily", "month", "irregular"] in dict`s name of dfs_input'
        )

    def combine_datas(self):
        """日別，月別，不定期データを日付をキーに結合

        Returns
        -------
        df_combined : pd.DataFrame
            日別，月別，不定期データを日付をキーに結合したデータ
        """
        df_combined = pd.merge(self.dfs_input['daily'], self.dfs_input['ohlcv'], on='Date', how='left')        
        df_combined = pd.merge(df_combined, self.dfs_input['month'], on='Date', how='left')
        df_combined = pd.merge(df_combined, self.dfs_input['irregular'], on='Date', how='left')

        return df_combined
    
    def extract_explained_names(self):
        """分析に使用するデータ列名をリストとして返す
        config_featuresのCODE列において1以上の値が入っているデータ列名を抽出

        Returns
        -------
        explained_names : list
            分析に使用するデータ列名
        """        
        explained_names = list(self.features.loc[self.features['CODE']>0,:].index)

        return explained_names

    def extract_tech_features_list(self, name_i):
        """テクニカル指標への変換を実施するデータ系列のリストを返す

        Parameters
        ----------
        name_i : str
            テクニカル指標の名称(MACD, ROC...)

        Returns
        -------
        tech_features : list
            テクニカル指標への変換を実施するデータ系列のリスト
        """
        tech_features = list(self.features.loc[self.features[name_i]==1,:].index)

        return tech_features

    def extract_ohlcv_features_list(self, name_i):
        """ohlcvデータを用いてテクニカル指標への変換を実施するデータ系列のリストを返す

        Parameters
        ----------
        name_i : str
            テクニカル指標の名称(ATR, ADX...)

        Returns
        -------
        tech_features : list
            テクニカル指標への変換を実施するデータ系列のリスト
        """
        tech_features = list(self.config_ohlcv_features.loc[self.config_ohlcv_features[name_i]==1,:].index)

        return tech_features

    @staticmethod    
    def _product(args):
        if 'None' in args:
            result = args.copy()
        else:   
            product = [x for x in itertools.product(*args.values())]
            result = [dict(zip(args.keys(), r)) for r in product]
        
        return result
        
    def make_technical(self, X):
        """テクニカル指標を作成

        Parameters
        ----------
        X : pd.DataFrame
            説明変数が加工されたデータセット.

        Returns
        -------
        X_talib : pd.DataFrame
            テクニカル指標データ.
            
        Notes
        -------
        tech_func.pyで作成した関数を用いてテクニカルを指標
        tech_func.pyでは関数の命名に「_」を使用しない（raw, range, ratioの区別に使用しているため）
        """
        X_talib = []
        for name_i, args in tech_config.items():
            names_list = name_i.split('_')            
            if len(names_list) > 1:
                name_input = name_i.split('_')[0]
                mode = name_i.split('_')[1]
            else:
                name_input = name_i
                mode = []
            
            tech_features = self.extract_tech_features_list(name_i)
            
            if len(tech_features)>0:
                procuct_list = self._product(args)          
                for dict_i in procuct_list:
                    key = name_i + '_' + '_'.join(map(str, list(dict_i.values())))
                    
                    if len(mode)>0:
                        dict_i.update({'mode' : mode})
                    
                    X_tech = X[tech_features].apply(eval('tech_func.'+name_input), **dict_i)
                    X_tech.columns = [i+'_'+key for i in tech_features]
                    X_talib.append(X_tech)

        X_talib = pd.concat(X_talib, axis=1)

        return X_talib

    def make_technical_ohlcv(self, X):
        """日次のOHLCVデータを用いたテクニカル指標を作成

        Parameters
        ----------
        X : pd.DataFrame
            OHLCVのデータセット.

        Returns
        -------
        X_talib : pd.DataFrame
            テクニカル指標データ.
            
        Notes
        -------
        tech_func.pyで作成した関数を用いてテクニカルを指標
        tech_func.pyでは関数の命名に「_」を使用しない（raw, range, ratioの区別に使用しているため）
        """
        X_talib = []
        for name_i, args in tech_ohlcv_config.items():
            names_list = name_i.split('_')            
            if len(names_list) > 1:
                name_input = name_i.split('_')[0]
                mode = name_i.split('_')[1]
            else:
                name_input = name_i
                mode = []
            
            tech_features = self.extract_ohlcv_features_list(name_i)

            if len(tech_features)>0:
                ohlcv_list = args['args']
                args_temp = {i : val for i, val in args.items() if i!='args'}
                df_dict = {}                              
                    
                for tech_feature in tech_features:
                    for name_ in ohlcv_list:
                        ohlcv_name = tech_feature + '_' + name_
                        df_dict[name_] = X[ohlcv_name]
                        
                    df_dict = {self.ohlcv_names[i] : val for i,val in df_dict.items() if i in self.ohlcv_names}                    
                    procuct_list = self._product(args_temp)      
                    for dict_i in procuct_list:
                        key = name_i + '_' + '_'.join(map(str, list(dict_i.values())))
                        
                        if len(mode)>0:
                            dict_i.update({'mode' : mode})
                        
                        dict_i.update(df_dict)
                        func_temp = eval('tech_func.'+name_input)
                        X_tech = func_temp(**dict_i)                       
                        X_tech.name = tech_feature+'_'+key
                        X_talib.append(X_tech)

        X_talib = pd.concat(X_talib, axis=1)

        return X_talib

    def convert_raws(self, x, code):
        """CODEの値に沿って原形列データの値を変換

        Parameters
        ----------
        x : pd.Series
            説明変数のデータ（1系列）
        code : int
            1 : 変化率, 2 : 変化幅, 3 : 変換なし

        Returns
        -------
        X : pd.Series
            変換後のデータ（1系列）

        Raises
        ------
        ValueError
            Current version is only available for 1,2,3 as input for code
        """
        if code == 1:
            x = x.pct_change()
        elif code == 2:
            x = x.diff()
        elif code == 3:
            pass
        else:
            raise ValueError('current version is only available for 1,2,3 as input for code')
        return x
            
    def fill_na(self, X):
        """欠損値をゼロに置き換える

        Parameters
        ----------
        X : pd.DataFrame
            欠損値を含むデータフレーム

        Returns
        -------
        X_out : pd.DataFrame
            欠損値をゼロに置き換えたデータフレーム
        """
        self.na_info = X.isnull().sum()
        X_out = X.fillna(0)

        return X_out

    def build_dataset(self):
        """テクニカル指標への変換後のデータを加えた特長量データセットを作成(全データ期間でテクニカル指標を作成)

        self.X     : pd.DataFrame
            テクニカル指標を加えた特長量データセット
        """
        explained_names = self.extract_explained_names()        
        df_explained_raw = self.combine_datas()[explained_names]
        X_talib = self.make_technical(df_explained_raw)
        X_ohlcv = self.make_technical_ohlcv(self.dfs_input['ohlcv'])

        code_list = self.features.loc[explained_names, 'CODE']
        df_explained = []
        for explained_name in explained_names:
            df_explained.append(self.convert_raws(df_explained_raw[explained_name], code=code_list[explained_name]))

        df_explained = pd.concat(df_explained, axis=1)
        X = pd.concat([df_explained, X_talib], axis=1)
        X = pd.merge(X, X_ohlcv, on='Date', how='left')
        self.X = self.fill_na(X)
        self.index_date = self.X.index
