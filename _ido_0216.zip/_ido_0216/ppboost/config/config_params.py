

params_scope = {
        "lightgbm": {
            "feature_fraction": {
                "dist" : "uniform",
                "scope": (3, 9)
            },
            "lambda_l1": {
                "dist": "loguniform",
                "scope": (1e-8, 10.0),
            },
            "lambda_l2": {
                "dist": "loguniform",
                "scope": (1e-8, 10.0),
            },
            "num_leaves": {
                "dist": "int",
                "scope": (2, 256),
            },
            "bagging_fraction": {
                "dist": "uniform",
                "scope": (0.4, 1.0),
            },
            "bagging_freq": {
                "dist": "int",
                "scope": (1, 7),
            }, 
            "min_child_samples": {
                "dist": "int",
                "scope": (5, 100),
            },                 
            "extra_trees": {
                "dist": "categorical",
                "scope": ([True, False]),
            },
        },
}
