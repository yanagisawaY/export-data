import copy
import numpy as np
import torch

from ..utils.optimizer import adjust_weight_under_stocklimit

import optuna
import random


class ModelBase:
    '''DNNの学習を行うクラス
    '''

    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
            ・・・(see also config.py)
        '''
        self.hyperparms = hyperparms
        self.optuna_scope = hyperparms["optuna_scope"]
        self.study = None

    def adjust_weight(self, weight, rt, stock_limit, weight_init=None):
        return adjust_weight_under_stocklimit(weight, rt, stock_limit, weight_init)

    def tune(self, X, y, X_val, y_val):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : pd.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : pd.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : pd.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : pd.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
        [1] https://optuna.org/
            
        Notes
        -----
        * hyperparamsでbest_paramsをTrueとした場合，バリデーションデータの評価値が最もよい値を採用                    
        """
        torch.manual_seed(self.hyperparms['random_state'])
        random.seed(self.hyperparms['random_state'])
        np.random.seed(self.hyperparms['random_state'])

        hyperparms = copy.deepcopy(self.hyperparms)

        def objective(trial):
            hyperparms['lr'] = trial.suggest_float("lr", *self.optuna_scope["lr"], log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform(
                'layer_dropout', *self.optuna_scope["layer_dropout"])
            n_layers = trial.suggest_int("n_layers", *self.optuna_scope["n_layers"])
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [
                    trial.suggest_int("n_units_l{}".format(i), *self.optuna_scope["n_units"])
                ]

            hyperparms['layer_list'] += [trial.suggest_int(
                "n_units_l{}".format(n_layers), *self.optuna_scope["n_units_last"])]
            self._fit(X, y, X_val, y_val, hyperparms)
            
            if hyperparms["best_params"]:
                # バリデーションデータの評価値が最もよいハイパーパラメータを採用する場合
                loss_val = self.loss_save["val"].max()
            else:
                loss_val = self.loss_save["val"].iloc[-1]

            return loss_val

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="maximize",
                                    sampler=sampler)
        study.optimize(
            objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"]
        )
        self.study = study

    def tune_prune(self, X, y, X_val, y_val):
        """optunaによるハイパーパラメータの最適化を実施(枝刈りアルゴリズムを使用)

        Parameters
        ----------
        X : pd.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : pd.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : pd.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : pd.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
        [1] https://optuna.org/
        [2] 枝刈りアルゴリズムの実装例 : https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        
        Notes
        -----
        * hyperparamsでbest_paramsをTrueとした場合，バリデーションデータの評価値が最もよい値を採用
        """
        torch.manual_seed(self.hyperparms['random_state'])
        random.seed(self.hyperparms['random_state'])
        np.random.seed(self.hyperparms['random_state'])

        hyperparms = copy.deepcopy(self.hyperparms)
        # 枝刈りアルゴリズムを使用する場合は早期停止を_fit_yield内で実施しない
        hyperparms["min_epoch"] = hyperparms["epoch"]        

        def objective(trial):
            hyperparms['lr'] = trial.suggest_float("lr", *self.optuna_scope["lr"], log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform(
                'layer_dropout', *self.optuna_scope["layer_dropout"])
            n_layers = trial.suggest_int("n_layers", *self.optuna_scope["n_layers"])
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [
                    trial.suggest_int("n_units_l{}".format(i), *self.optuna_scope["n_units"])
                ]

            hyperparms['layer_list'] += [trial.suggest_int(
                "n_units_l{}".format(n_layers), *self.optuna_scope["n_units_last"])]

            if hyperparms["best_params"]:
                loss_val_best = -10**1000

            for epoch, loss_list in enumerate(self._fit_yield(X, y, X_val, y_val, hyperparms)):
                
                loss_val = loss_list[1]
                
                if hyperparms["best_params"]:
                    # バリデーションデータの評価値が最もよいハイパーパラメータを採用する場合
                    if loss_val_best < loss_val:
                        loss_val_best = loss_val
                    else:
                        loss_val = loss_val_best
                        
                trial.report(loss_val, epoch)

                # Handle pruning based on the intermediate value.
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()
                            
            return loss_val

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms['random_state']
            )
        study = optuna.create_study(
            direction="maximize",
            sampler=sampler,
            pruner=optuna.pruners.SuccessiveHalvingPruner()
            )
        study.optimize(
            objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"]
            )
        self.study = study
        
    def update_hyperparams(self, hyperparms_best_updated={}):
        """optunaにより調整したハイパーパラメータの辞書の更新

        Parameters
        ----------
        hyperparms_best_updated : dict
            更新されたハイパーパラメータ (チューニングされたパラメータのみ)

            指定しない場合，tuneにより調整されたstudyのbest_trialが参照される．

        Raises
        ------
        optunaのハイパーパラメータ最適化(tune or tune_prune)を先に実行する

        Returns
        -------
        hyperparms_best : dict
            更新したハイパーパラメータの辞書
        """
        if len(hyperparms_best_updated) == 0:
            if self.study is None:
                raise ValueError('tuneかtune_pruneを実行してください')
            hyperparms_best = copy.deepcopy(self.hyperparms)
            hyperparms_best_updated = self.study.best_trial.params
        else:
            assert isinstance(hyperparms_best_updated, dict)
            hyperparms_best = copy.deepcopy(self.hyperparms)

        hyperparms_best['layer_list'] = []
        for layer in range(hyperparms_best_updated['n_layers'] + 1):
            hyperparms_best['layer_list'] += [
                hyperparms_best_updated['n_units_l'+str(layer)]]
        hyperparms_best['lr'] = hyperparms_best_updated['lr']
        hyperparms_best['layer_dropout'] = hyperparms_best_updated['layer_dropout']
        self.hyperparms = hyperparms_best

        return hyperparms_best
