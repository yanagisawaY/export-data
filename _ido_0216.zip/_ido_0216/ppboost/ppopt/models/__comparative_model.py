"""
Notes:
    本コードで使用しているクラス
    ComparativeModel
        比較モデルを実施するクラス
"""
import numpy as np
import pandas as pd
from ..utils.processor import scale_xs
from sklearn.linear_model import LassoCV
from sklearn.ensemble import RandomForestRegressor, ExtraTreesRegressor
import lightgbm as lgb
from .deep_net import DeepLearner


class BoostLearner:
    """ブースティング系モデルの学習を行うクラス
    """
    def __init__(self, hyperparms):
        """
        hyperparms : dict
        """
        self.hyperparms = hyperparms        
        self.model_name = self.hyperparms["model"]
         # lightgbm, xgboostのclassに読み込ませるハイパーパラメータの辞書
         # →classの引数に関係のないハイパーパラメータは除外
        self.hyperparms_model = self._delete_key(
            hyperparms.copy(), 
            ["val_ratio", "model", "is_val", "early_stopping_rounds", "loss", "is_best_ntree"]
            )
        self.hyperparms_fit = {
            "early_stopping_rounds": hyperparms["early_stopping_rounds"],            
            }
        self.study = None
        self.is_fit_cv = False

    def _delete_key(self, hyperparms_model, delete_list):
        """指定したキーとその要素を辞書から削除

        Parameters
        ----------
        hyperparms_model : dict
            キー除外前の辞書データ.
        delete_list : list
            削除したいキーのリスト.

        Returns
        -------
        hyperparms_model : dict
            キーを削除した辞書.
        """
        assert sum([x not in list(hyperparms_model.keys()) for x in delete_list])==0,(
            "学習時に必要なパラメータが設定されていません"
            )
        for key in delete_list:
            del hyperparms_model[key]        
        
        return hyperparms_model

    def _call_categorical_features(self):
        self.categorical_features = ""

    def _call_criterion_lgb(self):
        """回帰問題や多クラス分類などにあわせ，目的関数・評価関数を設定(lightgbmの設定)
        """
        if self.hyperparms["loss"] == "MSELoss":
            self.hyperparms_model["objective"] = "regression"
            self.hyperparms_fit["eval_metric"] = "l2"
        elif self.hyperparms["loss"] == "2class":
            self.hyperparms_model["objective"] = "binary"
            self.hyperparms_fit["eval_metric"] = "logloss"
        elif self.hyperparms["loss"] == "3class":
            self.hyperparms_model["objective"] = "multiclass"
            self.hyperparms_fit["eval_metric"] = "logloss"

    def _call_criterion_xgb(self):
        """回帰問題や多クラス分類などにあわせ，目的関数・評価関数を設定(xgboostの設定)
        """        
        if self.hyperparms["loss"] == "MSELoss":
            self.hyperparms_model["objective"] = "reg:squarederror"
            self.hyperparms_fit["eval_metric"] = "rmse"
        elif self.hyperparms["loss"] == "2class":
            self.hyperparms_model["objective"] = "binary:logistic"
            self.hyperparms_fit["eval_metric"] = "logloss"
            self.hyperparms_model["use_label_encoder"] = False # エラーメッセージの回避
        elif self.hyperparms["loss"] == "3class":
            self.hyperparms_model["objective"] = "multi:softmax"
            self.hyperparms_fit["eval_metric"] = "mlogloss"
            self.hyperparms_model["num_class"] = 3

    def _call_model(self):
        """モデルの呼び出し(目的関数などの設定も更新)

        Returns
        -------
        model : class
            モデルクラス
        
        Notes
        -----
        * Scikit-Learn Wrapper interfaceを使用
        """
        if self.model_name == "lightgbm":
            self._call_criterion_lgb()
        elif self.model_name == "xgboost":
            self._call_criterion_xgb()

        self._call_categorical_features()
        
        if self.model_name == "lightgbm":
            if self.hyperparms["loss"] == "MSELoss":
                model = lgb.LGBMRegressor
            elif "class" in self.hyperparms["loss"]:
                model = lgb.LGBMClassifier
        elif self.model_name == "xgboost":
            if self.hyperparms["loss"] == "MSELoss":
                model = xgb.XGBRegressor
            elif "class" in self.hyperparms["loss"]:        
                model = xgb.XGBClassifier

        return model

    def _fit(self, X, y, X_val=[], y_val=[], hyperparms_model=[]):        
        if len(hyperparms_model)==0:
            hyperparms_model = self.hyperparms_model
        model = self._call_model()
        if len(X_val) > 0 and len(y_val) > 0:
            model_fit_params = {
                "X": X,
                "y": y,
                "eval_set": [(X, y), (X_val, y_val)],
                "eval_metric": self.hyperparms_fit["eval_metric"],
                "early_stopping_rounds": self.hyperparms_fit["early_stopping_rounds"],
                "verbose": False,  # 学習の経過の非表示
            }
        else:     
            model_fit_params = {
                "X": X,
                "y": y,
                "eval_set": [(X, y),],
                "eval_metric": self.hyperparms_fit["eval_metric"],
                "verbose": False,  # 学習の経過の非表示                    
            }
                
        model = model(**hyperparms_model).fit(**model_fit_params)        
        evals_result = model.evals_result_

        return model, evals_result
    
    def _to_pandas_frame(self, evals_result : dict):
        if len(evals_result) == 2:
            evals_result = pd.concat([
                pd.DataFrame.from_records(evals_result["train"]),
                pd.DataFrame.from_records(evals_result["ation_1"])
                ], axis=1)
            evals_result.columns = ["train", "ation_1"]
        else:
            evals_result = pd.DataFrame.from_records(evals_result["train"])
            evals_result.columns = ["train"]          
        
        return evals_result

    def fit(self, X, y, is_val=False, hyperparms_model=[]):
        """モデル学習を実行

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ(時点, 特徴量)
        y : pd.Series
            被説明変数(時点,)            
        is_val : bool, optional
            バリデーションデータを用いた早期停止条件を課す場合はTrue, by default False
        hyperparms_model : dict
            モデルのハイパーパラメータが格納された辞書．何も入力がされていない場合，self.hyperparams_modelで実行される．

        Attributes
        ----------
        model : 
            学習済みモデル
        evals_result : pd.DataFrame
            学習回数ごとの目的関数値
        """
        if is_val:
            val_num = int(X.shape[0]*(1-self.hyperparms["val_ratio"]))
            X_, y_ = X, y
            X = X_.iloc[:val_num, :]
            y = y_.iloc[:val_num]
            X_val = X_.iloc[val_num:, :]
            y_val = y_.iloc[val_num:]
            if len(hyperparms_model)>0:            
                self.model, self.evals_result = self._fit(X, y, X_val, y_val, hyperparms_model)
            else:
                self.model, self.evals_result = self._fit(X, y, X_val, y_val)                
        else:
            if len(hyperparms_model)>0:
                self.model, self.evals_result = self._fit(X, y, hyperparms_model)
            else:
                self.model, self.evals_result = self._fit(X, y)                
                