import time

def mystopwatch(func):
    def inner_func(*args):
        start = time.time()
        print(f'start...    {func.__name__}')
        result = func(*args)
        print(f'complete... {func.__name__}' +
              f" : {round(time.time()-start)}sec")
        return result
    return inner_func