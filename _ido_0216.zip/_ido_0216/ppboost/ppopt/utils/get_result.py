import pandas as pd

PATH_DATA = r"C:\Users\yana\Desktop\yoshiki_study\data\asset_pricing\datasets"
df_train = pd.read_csv(PATH_DATA + "/train.csv.gz", index_col=0)


