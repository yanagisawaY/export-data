import numpy as np
import pandas as pd
import torch


def scale_xs(X : pd.DataFrame, universe : pd.DataFrame, factor_list : list):
    """データの基準化

    * クロスセクション方向にランク化 → 平均0，標準偏差1に基準化

    Parameters
    ----------
    X : pd.DataFrame
        基準化前のデータ.
    universe : pd.DataFrame
        投資銘柄にTrueが格納されたデータフレーム(時点, 銘柄)
    factor_list : list
        ファクターのリスト

    Returns
    -------
    X_scale : pd.DataFrame
        基準化後のデータ.
    """
    assert isinstance(X, pd.DataFrame)
    date_indices = sorted(X["Date"].unique())
    
    X_scale = []
    for date_index in date_indices:
        X_ = X.loc[X["Date"] == date_index, :].copy(deep=True)
        X_ = X_.loc[X_["stock"].isin(universe.loc[date_index].index), :]
        for factor in factor_list:
            temp = X_[factor].dropna()
            temp = np.argsort(np.argsort(temp))
            temp = (temp - temp.mean())/temp.std()
            X_.loc[temp.index, factor] = temp.values

        X_scale.append(X_)

    X_scale = pd.concat(X_scale).fillna(0)

    return X_scale


def make_torch_scaled_xs(X : pd.DataFrame, universe : pd.DataFrame, factor_list : list, stock_list : list):
    """基準化したデータセットを作成

    Parameters
    ----------
    X : pd.DataFrame
        基準化前のデータ.
        ※ Dateとstockを列名にもつデータセット
    universe : pd.DataFrame
        投資銘柄にTrueが格納されたデータフレーム(時点, 銘柄)        
    factor_list : list
        ファクターのリスト
    stock_list : list
        銘柄のリスト.

    Returns
    -------
    X : torch.tensor
        クロスセクション方向にランク化処理した基準化後のデータセット.
    """
    X = scale_xs(X, universe, factor_list)
    time_ = len(X["Date"].unique())
    array_t = np.zeros((
        time_,
        len(stock_list),
        len(factor_list))
    )
    date_index = sorted(X["Date"].unique())
    for i, index_ in enumerate(range(time_)):
        temp = X.loc[X["Date"] == date_index[index_], :].drop( 
            ["Date"], axis=1).set_index("stock")
        stock_list_t = temp.index
        stock_index_t = [i for i, stock in enumerate(stock_list) if stock in stock_list_t]
        array_t[i, stock_index_t, :] = temp.values
        
    X = torch.tensor(array_t).float()

    return X
