import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots


class Visualizer:
    def __init__(self, all_result : dict):
        self.all_result = all_result
        self.patterns = list(self.all_result.keys())

    def plot_loss(self, output : dict, title : str):
        fig = pd.line(output["loss_info"], title=title)
        fig.update_xaxes(title_text="epoch")
        fig.update_yaxes(title_text="Sharpe Ratio(月率)")
        
        return fig
    
    def plot_feature_importance(self, output : dict, data_type : str = "train"):
        import pdb
        pdb.set_trace()
        fig = go.Figure()
        K = output

    def plot_lrp(self, start, end, port_lrp_dict, data_type, factor_category_dict):
        def extract_lrp(start, end, port_lrp_dict, data_type):
            dict_selected = port_lrp_dict[data_type]
            term_candidate = [i for i in dict_selected.keys() if i != "all"]
            term_selected = [i for i in term_candidate if (pd.to_datetime(i)>=start)&(pd.to_datetime(i)<=end)]
            df_lrp = 0
            for term in term_selected:
                df_lrp += dict_selected[term]
            df_lrp /= len(term_selected)
            
            return df_lrp    
        
        def make_factor_color(factor_category_dict):
            factor_category_unique = sorted(list(set(factor_category_dict.values())))
            color_list = px.colors.qualitative.Light24
            assert len(factor_category_unique) <= len(color_list)
            category_color = {category: color_list[i] for i, category in enumerate(factor_category_unique)}
            factor_color_dict = {feature: category_color[category] for feature, category in factor_category_dict.items()}
            
            return factor_color_dict
        
        df_lrp = extract_lrp(start, end, port_lrp_dict, data_type)    
        factor_color_dict = make_factor_color(factor_category_dict)
        
        fig = go.Figure()
        port_num = df_lrp.shape[0]
    
        fig = make_subplots(
            rows=port_num-1,
            cols=2,
            shared_xaxes="all",
            specs=[
                [{"rowspan": port_num - 1}, {}]] + [[None, {}] for _ in range(port_num - 2)],
            subplot_titles=(list(df_lrp.index)),
        )
    
        fig.update_layout(
            autosize=False,
            width=1300,
            height=900,
        )
    
        for port_id in range(port_num):
            if port_id == 0:
                row = port_id + 1
                col = 1
            else:
                row = port_id
                col = 2
            x = list(df_lrp.columns)
            y = df_lrp.iloc[port_id, :]
            color_x = [factor_color_dict[factor] for factor in x]
            fig.add_trace(
                go.Bar(
                    x=x,
                    y=list(y),
                    marker_color=color_x,
                    text=list(factor_category_dict.values()),                
                    name=list(df_lrp.index)[port_id],
                ),
                row=row,
                col=col,
            )
            try:
                fig.add_annotation(
                    x=y.idxmax(),
                    y=y.max(),
                    text=y.idxmax(),
                    showarrow=True,
                    arrowhead=1,
                    row=row,
                    col=col,
                )
            except Exception as e:
                print(e)
                pass
            
        fig.update_layout(
            title=dict(
                text="<b>[" + data_type + "]" + " <b>" + start.strftime("%y/%m") + " - <b>"+ str(end.strftime("%y/%m")),
                font=dict(size=26, color="grey"),
                y=0.95,
            ),
            showlegend=False,
        )
        fig.update_xaxes(matches="x")
    
        return fig
    
    def plot_return(df_port_org, start, end, data_type):
        df_port = df_port_org.loc[(df_port_org.index>=start)&(df_port_org.index<=end), :].cumsum()
        hidden_name = [i for i in df_port.columns if "hidden" in i]
    
        fig = go.Figure()
        fig = make_subplots(
            rows=2,
            cols=1,
            specs=[[{"secondary_y": True}], [{"secondary_y": True}]],
        )
    
        fig.update_layout(
            autosize=False,
            width=1300,
            height=900,
        )
    
        for i, name_ in enumerate(["all", "bench"]):
            fig.add_trace(
                go.Scatter(
                    x=df_port.index,
                    y=df_port[name_],
                    name=name_,
                    line=dict(color=["red", "blue"][i])
                ),
                row=1,
                col=1
            )
        fig.add_trace(
            go.Scatter(
                x=df_port.index,
                y=df_port["active"],
                name="累積超過リターン",
                fill="tozeroy",
                mode="none",
                line=dict(color="purple"),
            ),
            secondary_y=True,
            row=1,
            col=1,
        )
        color_list = px.colors.qualitative.Pastel2
        for j, name_hidden in enumerate(hidden_name):
            fig.add_trace(
                go.Scatter(
                    x=df_port.index,
                    y=df_port[name_hidden],
                    name=name_hidden,
                    line=dict(color=color_list[j])
                ),
                row=2,
                col=1,        
            )
    
        fig.update_layout(
            title=dict(
                text="<b>[" + data_type + "]" + " <b>" + start.strftime("%y/%m") + " - <b>"+ str(end.strftime("%y/%m")),
                font=dict(size=26, color="grey"),
                y=0.95,
            ),
            showlegend=True,
        )
        fig.update_xaxes(matches="x")
    
        return fig
