import numpy as np
import pandas as pd
import torch


def scale_xs(X, factor_list):
    """データの基準化

    * クロスセクション方向にランク化 → 平均0，標準偏差1に基準化

    Parameters
    ----------
    X : pd.DataFrame
        基準化前のデータ.
    factor_list : list
        ファクターのリスト

    Returns
    -------
    X_scale : pd.DataFrame
        基準化後のデータ.
    """
    assert isinstance(X, pd.DataFrame)
    date_indices = sorted(X["Date"].unique())
    X_scale = []
    for date_index in date_indices:
        X_ = X.loc[X["Date"] == date_index, :].copy(deep=True)
        for factor in factor_list:
            temp = X_[factor].dropna()
            temp = np.argsort(np.argsort(temp))
            temp = (temp - temp.mean())/temp.std()
            X_.loc[temp.index, factor] = temp.values

        X_scale.append(X_)

    X_scale = pd.concat(X_scale).fillna(0)

    return X_scale


def make_torch_scaled_xs(X, factor_list, stock_list):
    """基準化したデータセットを作成

    Parameters
    ----------
    X : pd.DataFrame
        基準化前のデータ.
        ※ Dateとstockを列名にもつデータセット
    factor_list : list
        ファクターのリスト
    stock_list : list
        銘柄のリスト.

    Returns
    -------
    X : torch.tensor
        クロスセクション方向にランク化処理した基準化後のデータセット.
    """
    X = scale_xs(X, factor_list)
    time_ = int(X.shape[0]/len(stock_list))
    array_t = np.zeros((
        time_,
        len(stock_list),
        len(factor_list))
    )
    date_index = sorted(X["Date"].unique())
    for i, index_ in enumerate(range(time_)):
        array_t[i, :, :] = X.loc[X["Date"] == date_index[index_], :].drop(
            ["Date"], axis=1).set_index("stock").values

    X = torch.tensor(array_t).float()

    return X
