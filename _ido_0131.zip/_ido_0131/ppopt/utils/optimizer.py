import pulp
import numpy as np
import pandas as pd


def solve_opt(
    weight_bench: np.array,
    weights_char: np.array,
    weight_hold: np.array,
    rit: np.array,
    target_risk: float,
    turnover: float,
    stock_name: list,
    is_print: bool = True,
):
    """リスク制約,売買回転率制約,空売り禁止制約のもとでアクティブリターンが最大となるポートフォリオのウェイトを算出

    Parameters
    ----------
    weight_bench : np.array
        リバランス時点におけるベンチマークポートフォリオのウェイト (銘柄数)
    weights_char : list
        企業特性合成ポートフォリオのウェイト [(合成ポートフォリオの数, t時点の銘柄数) for t in range(時点)]
    weight_hold : np.array
        リバランス時点における保有ポートフォリオのウェイト(銘柄数)
    rit : list
        各銘柄のリターン [(t時点の銘柄数) for t in range(時点)]
    target_risk : float
        リスク制約の上限値
    turnover : float
        売買回転率の上限
    stock_name: list
        銘柄名のリスト
    is_print : bool
        最適化結果のプリント(任意設定)

    Return
    ------
    weight : pd.DataFrame
        各資産へのウェイト    
    theta : list
        企業特性合成ポートフォリオへのウェイト
    is_status : bool
        最適解が求まった場合はTrueを返す
    Notes
    -----
    * 線形計画法により定式化

    * オメガレシオは，アクティブリターンのアップサイド/アクティブリターンのダウンサイドとして定義

    * 時点ごとにユニバースに含まれる銘柄数が異なる場合にも対応

    * 変数z_tは最適化に不要であるが，これを入れることで解が安定する様子が確認された（原因は不明...)
    """
    stock_num = len(weight_bench)
    T = len(rit)
    K = weights_char[0].shape[0]
    stock_num_list = [rit[t].shape[0] for t in range(T)]
    stock_num_list.append(stock_num)
    problem = pulp.LpProblem('ActiveOpt', pulp.LpMaximize)

    # 決定変数
    theta = [pulp.LpVariable(name='theta_{}'.format(
        k), cat="Continuous") for k in range(K)]
    # 補助変数
    yt = [pulp.LpVariable(name='yt_{}'.format(t), lowBound=0,
                          cat="Continuous") for t in range(T)]
    dti = [pulp.LpVariable(name='dti_{}'.format(
        i), lowBound=0, cat="Continuous") for i in range(stock_num)]
    alpha = pulp.LpVariable(name='alpha', cat="Continuous")

    # 目的関数
    problem += alpha, "Objective"

    # リスク制約
    problem += pulp.lpSum([yt[t] for t in range(T)])/T <= target_risk

    # アクティブリターンからの不足分
    for t in range(T):
        problem += pulp.lpSum([(theta[k]*weights_char[t][k, i])*rit[t][i]
                               for k in range(K) for i in range(stock_num_list[t])]) + yt[t] >= 0

    # 期待アクティブリターン
    sum_at = []
    for t in range(T):
        sum_at += [(theta[k]*weights_char[t][k, i])*rit[t][i]
                   for k in range(K) for i in range(stock_num_list[t])]
    problem += pulp.lpSum(sum_at)/T == alpha

    # 投資制約
    # リバランス時点の売買回転率上限制約
    problem += pulp.lpSum([dti[i]
                          for i in range(stock_num_list[T])]) <= turnover
    for i in range(stock_num):
        # # リバランス時点の空売り禁止制約
        problem += weight_bench[i] + pulp.lpSum(
            [theta[k]*weights_char[T][k, i] for k in range(K)]) >= 0
        # # リバランス時点の購入ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) - weight_hold[i] - dti[i] <= 0
        # リバランス時点の売却ウェイトの上限制約
        problem += weight_bench[i] + pulp.lpSum([theta[k]*weights_char[T][k, i]
                                                for k in range(K)]) - weight_hold[i] + dti[i] >= 0

    status = problem.solve()
    weight_add = [sum([pulp.value(theta[k])*weights_char[T][k, i]
                       for k in range(K)]) for i in range(stock_num)]

    weight = pd.Series(
        [weight_bench[i] + weight_add[i] for i in range(stock_num)],
        index=stock_name)

    status = pulp.LpStatus[status]
    theta = [pulp.value(theta[k]) for k in range(K)]

    if is_print:
        turnover_ = np.sum(np.abs(weight-weight_hold))
        print(
            f'Status {status} 目的関数値 = {pulp.value(problem.objective)} turnover {round(turnover_, 3)}')

    is_status = status == "Optimal"

    return weight, theta, is_status


def weight_under_leverage(hidden_weight_current, hidden_weight_past, rt_train, rt_test, stock_list, turnover, target_risk):
    """制約条件のもと各企業特性合成ポートフォリオのエクスポージャーを最適化

    Parameters
    ----------
    hidden_weight_current : np.array
        将来時点における企業特性合成ポートフォリオのウェイト
        (バッチ(時点), 合成ポートフォリオの数, 銘柄)
    hidden_weight_past : np.array
        過去時点における企業特性合成ポートフォリオのウェイト    
        (バッチ(時点), 合成ポートフォリオの数, 銘柄)
    rt_train : np.array
        訓練データの銘柄リターン
    rt_test : np.array
        テストデータの銘柄リターン
    stock_list : list
        銘柄のリスト
    turnover : float
        売買回転率の上限制約．
    target_risk : float
        リスク制約の上限値            

    Returns
    -------
    weight : np.array
        最適化後のポートフォリオのウェイト
    theta : pd.Series
        各企業特性合成ポートフォリオにおけるエクスポージャー
    status_all : list
        最適化が成功したかどうかを格納したリスト

    Notes
    -----
    * t時点においてユニバースに含まれているかどうかはリターンがゼロかどうかで判別している
    -> ユニバースに含まれない銘柄はリターンをゼロ置きしているため
    * ユニバースの判定方法については他の方法を検討した方がよい（が近似的に今回は算出）        
    """
    test_time = rt_test.shape[0]
    theta = []
    weight = []
    weight_ = None
    status_all = []
    for t_roll in range(test_time):
        hidden_weight = np.concatenate(
            [hidden_weight_past, hidden_weight_current[:(t_roll+1), :, :]], axis=0)
        rit_ = np.concatenate(
            [rt_train, rt_test[:(t_roll), :]], axis=0)
        T = hidden_weight.shape[0]
        K = hidden_weight.shape[1]

        # （要改善）ユニバースに含めない銘柄かどうかはリターンがゼロか否かで判断しているため不正確ではある
        weights_char = [hidden_weight[t, :, rit_[t, :]
                                      != 0].reshape(K, -1) for t in range(T-1)]
        weights_char.append(
            hidden_weight[T-1, :, rt_test[t_roll, :] != 0].reshape(K, -1))
        rit = [rit_[t, rit_[t, :] != 0] for t in range(T-1)]
        stock_list_t = stock_list[rt_test[t_roll, :] != 0]
        weight_bench = np.ones(len(stock_list_t))/len(stock_list_t)

        weight_hold = np.ones(len(stock_list_t))/len(stock_list_t)
        weight_, theta_, is_status = solve_opt(
            weight_bench,
            weights_char,
            weight_hold,
            rit,
            target_risk,
            turnover,
            stock_list_t,
            is_print=True,
        )

        if not is_status:
            # 最適化に失敗した場合，リバランスを実施しない
            weight_ = pd.Series(weight_hold, index=stock_list_t)

        status_all.append(is_status)
        weight_t_roll = pd.Series(
            np.zeros(len(stock_list)),
            index=stock_list
        )
        weight_t_roll[stock_list_t] = weight_
        weight.append(weight_t_roll)
        theta.append(pd.Series(theta_, index=[
            "port"+str(k) for k in range(len(theta_))]))

    weight = pd.concat(weight, axis=1).T.values
    theta = pd.concat(theta, axis=1).T

    return weight, theta, status_all


def adjust_weight_under_stocklimit(weight, rt, stock_limit, weight_init=None):
    """売買銘柄数の上限数を課した場合のポートフォリオのウェイトを計算

    Parameters
    ----------
    weight : pd.DataFrame
        各時点における各銘柄への投資ウェイト(時点, 銘柄).
    rt : pd.DataFrame
        各時点における各銘柄のリターン(時点, 銘柄).
    stock_limit : int
        売買銘柄数の上限数.
    weight_init : pd.Series
        初期のリバランス時点のにおけるポートフォリオの保有ウェイト(銘柄, ).\n
        特に設定しない場合(デフォルト)は，等ウェイトポートフォリオを設定

    Returns
    -------
    weight_adjusted : pd.DataFrame
        各時点における各銘柄への投資ウェイト(時点, 銘柄).
    
    Notes
    -----
    * t時点においてユニバースに含まれているかどうかはリターンがゼロかどうかで判別している
    -> ユニバースに含まれない銘柄はリターンをゼロ置きしているため
    * ユニバースの判定方法については他の方法を検討した方がよい（が近似的に今回は算出）
    """
    if not isinstance(weight_init, pd.Series):
        weight_init = pd.Series(
            [1/weight.shape[1] for i in range(weight.shape[1])],
            index=weight.columns)
    
    weight_adjusted = weight.copy(deep=True)
    for t in range(weight.shape[0]):
        # （要改善）ユニバースに含めない銘柄かどうかはリターンがゼロか否かで判断しているため不正確ではある
        is_universe = rt.iloc[t, :]!= 0
        
        if t == 0:
            weight_hold = weight_init.copy(deep=True)[is_universe]
        else:
            weight_t_1 = weight_adjusted.iloc[t-1, :].copy(deep=True)[is_universe]
            weight_hold = weight_t_1 * (1+rt.iloc[t-1, :][is_universe])
            
        weight_t = weight.iloc[t, :][is_universe]
        weight_diff = weight_t - weight_hold
        is_extracted_set = weight_diff.abs() > weight_diff.abs().quantile(1 - stock_limit/len(weight_diff))        
        weight_adjusted.iloc[t, :][is_universe & ~is_extracted_set] = weight_hold[~is_extracted_set]        
        weight_adjusted.iloc[t, :][is_universe & is_extracted_set] = (1 - weight_hold[~is_extracted_set].sum()) * (weight_t[is_extracted_set]/weight_t[is_extracted_set].sum())
        
        # 確認用
        # import seaborn as sns
        # sns.set()
        # sns.set_style("whitegrid", {'grid.linestyle': '--'})
        # weight_diff.hist(bins=50)
        # (weight_adjusted.iloc[t, :] - weight_hold).hist(bins=50)
        # weight_adjusted.iloc[t, :].hist(bins=50)
        # weight.iloc[t, :].hist(bins=50)        
            
    return weight_adjusted


        
        