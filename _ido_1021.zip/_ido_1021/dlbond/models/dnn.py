"""
Standard Deep model
"""
from torch import nn
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import OneHotEncoder
import pandas as pd
import optuna
from optuna.trial import TrialState

class DeepNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''
    def __init__(self, hyperparms, input_num, output_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(DeepNet, self).__init__()
        layer_units = hyperparms['layer_list']        
        layer_num = len(layer_units)
        layer = []
        layer.append(nn.Dropout(hyperparms['layer_dropout']))
        layer.append(nn.Linear(input_num, layer_units[0]))
        layer.append(nn.BatchNorm1d(layer_units[0]))
        layer.append(nn.ReLU())
        if layer_num > 1:
            for i in range(layer_num-1):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))
                layer.append(nn.Linear(layer_units[i], layer_units[i+1]))
                layer.append(nn.BatchNorm1d(layer_units[i+1]))
                layer.append(nn.ReLU())

        layer.append(nn.Dropout(hyperparms['layer_dropout']))                    
        layer.append(nn.Linear(layer_units[-1], output_num))
        if output_num == 3:
            layer.append(nn.Softmax(dim=1))
        self.full = nn.Sequential(*layer)
                            
    def forward(self, X):        
        output = self.full(X)
        
        return output.squeeze()


class DeepLearner:
    '''DNNの学習を行うクラス
    '''    
    def __init__(self, hyperparms):
        '''
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout  : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        '''
        self.hyperparms = hyperparms
        self.study = None                            
        assert hyperparms['min_ephoch'] < hyperparms['epoch']

    def get_tensor(self, X, y):
        """テンソル型に変換

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            被説明変数(時点,)

        Returns
        -------
        X : torch.tensor
            特徴量データ(時点, 特徴量)
        y : torch.tensor
            被説明変数(時点,)
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(y, pd.DataFrame):
            y = y.values
            
        X = torch.Tensor(X)
        if self.hyperparms['loss'] == 'MSELoss':            
            y = torch.Tensor(y)
        elif self.hyperparms['loss'] == '3class':            
            y = torch.Tensor(y).squeeze().long()            

        return X, y
    
    def _criterion(self):
        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()
            
        return criterion
        
    def fit(self, X, y):
        """モデル学習を実行

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            被説明変数(時点,)
        """  
        torch.manual_seed(self.hyperparms['random_state'])
        X, y = self.get_tensor(X, y)
        
        if self.hyperparms["val_early_stop"] > 0:
            val_num = int(X.shape[0]*(1-self.hyperparms["val_early_stop"]))
            X_, y_ = X, y
            X = X_[:val_num,:]
            y = y_[:val_num]
            X_val = X_[val_num:,:]
            y_val = y_[val_num:]
            
        df = TensorDataset(X, y)
        loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=False)
        input_num = X.size(1)

        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
            model = DeepNet(self.hyperparms, input_num, output_num=1)  
        elif self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()
            model = DeepNet(self.hyperparms, input_num, output_num=3) 

        loss_val_min = 10000**1000
        patience_count = 0
        loss_save = []
        optimizer = torch.optim.Adam(model.parameters(), lr = self.hyperparms['lr'])               
        for epoch in range(self.hyperparms['epoch']):
            for X_, y_ in loader:
                if X_.shape[0] > 1:
                    y_pred = model.forward(X_)
                    loss = criterion(y_pred, y_)
                    loss.backward()
                    optimizer.step()
            
            if self.hyperparms["val_early_stop"] > 0 and epoch > self.hyperparms['min_ephoch']:
                with torch.no_grad():
                    y_pred_val = model.forward(X_val)
                    loss_val = criterion(y_pred_val, y_val).item()
                    if loss_val_min > loss_val:
                        loss_val_min = loss_val
                        patience_count = 0
                    else:
                        patience_count += 1
                    loss_save += [loss.item(), loss_val]
                
                if (epoch+1)%100==0:
                    print(f'{epoch+1}/{self.hyperparms["epoch"]} : train {round(loss.item(), 3)} - val {round(loss_val, 3)}')

                if patience_count >= self.hyperparms["patience_max"]:
                    print(f'{epoch+1}/{self.hyperparms["epoch"]} (early stop): train {round(loss.item(), 3)} - val {round(loss_val, 3)}')                    
                    break
            else:                
                loss_save += [loss.item()]                
                if (epoch+1)%100==0:
                    print(f'{epoch+1}/{self.hyperparms["epoch"]} : {round(loss.item(), 4)}')

        self.model = model
        self.loss_save = pd.DataFrame(loss_save)

    def predict(self, X):
        """学習したパラメータをもとに予測値を出力

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            特徴量データ(時点, 特徴量) 

        Returns
        -------
        y_pred : np.array
            予測値(時点,)     
        """
        if isinstance(X, pd.DataFrame):
            X = X.values
            
        X = torch.Tensor(X)        
        y_pred = self.model.forward(X)
        y_pred = y_pred.detach().numpy().copy()

        return y_pred

    def tune(self, X, y, X_val, y_val):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : np.array or pandas.DataFrame
            訓練期間における特徴量データ(時点, 特徴量)
        y : np.array or pandas.DataFrame
            訓練期間における被説明変数(時点,)
        X_val : np.array or pandas.DataFrame
            バリデーション期間における特徴量データ(時点, 特徴量)
        y_val : np.array or pandas.DataFrame
            バリデーション期間における被説明変数(時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        Raises
        ------
        optuna.exceptions.TrialPruned
            Handle pruning based on the intermediate value.

        References
        ----------
            [1] https://optuna.org/
            [2] https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        """
        torch.manual_seed(self.hyperparms['random_state'])
        X, y = self.get_tensor(X, y)
        df = TensorDataset(X, y)
        loader = DataLoader(df, batch_size=self.hyperparms['batch_size'], shuffle=True)
        X_val, y_val = self.get_tensor(X_val, y_val)
        input_num = X.size(1)

        if self.hyperparms['loss'] == 'MSELoss':
            criterion = nn.MSELoss()
        elif self.hyperparms['loss'] == '3class':
            criterion = nn.CrossEntropyLoss()

        hyperparms = self.hyperparms

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform('layer_dropout', 0, 1.0)

            n_layers = trial.suggest_int("n_layers", 1, 3)
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [trial.suggest_int("n_units_l{}".format(i), 4, 128)]

            if self.hyperparms['loss'] == 'MSELoss':            
                model = DeepNet(hyperparms, input_num, output_num=1)  
            elif self.hyperparms['loss'] == '3class':
                model = DeepNet(hyperparms, input_num, output_num=3) 

            optimizer = torch.optim.Adam(model.parameters(), lr)               
            for epoch in range(hyperparms['epoch']):
                for X_, y_ in loader:
                    if X_.shape[0] > 1:
                        y_pred = model.forward(X_)                    
                        loss = criterion(y_pred, y_)
                        loss.backward()
                        optimizer.step()

                with torch.no_grad():
                    y_pred_val = model.forward(X_val)
                    loss = criterion(y_pred_val, y_val).item()

                trial.report(loss, epoch)

                # Handle pruning based on the intermediate value.
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()

            return loss

        sampler = optuna.samplers.TPESampler(seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="minimize",
                                    sampler=sampler,
                                    pruner=optuna.pruners.SuccessiveHalvingPruner())
        study.optimize(objective, n_trials=100, timeout=600)
        self.study = study

    def update_hyperparams(self, hyperparms_best_updated={}):
        """optunaにより調整したハイパーパラメータの辞書の更新

        Parameters
        ----------
        hyperparms_best_updated : dict
            更新されたハイパーパラメータ (チューニングされたパラメータのみ)

            指定しない場合，tuneにより調整されたstudyのbest_trialが参照される．

        Raises
        ----------
        optunaのハイパーパラメータ最適化( tune )を先に実行する

        Returns
        -------
        hyperparms_best : dict
            更新したハイパーパラメータの辞書
        """
        if len(hyperparms_best_updated) == 0:            
            if self.study is None:
                raise ValueError('tuneを実行してください')                    
            hyperparms_best = self.hyperparms
            hyperparms_best_updated = self.study.best_trial.params            
        else:
            assert isinstance(hyperparms_best_updated, dict)
            hyperparms_best = self.hyperparms            
        
        hyperparms_best['layer_list'] = []
        for layer in range(hyperparms_best_updated['n_layers']):
            hyperparms_best['layer_list'] += [hyperparms_best_updated['n_units_l'+str(layer)]]            
        hyperparms_best['lr'] = hyperparms_best_updated['lr']
        hyperparms_best['layer_dropout'] = hyperparms_best_updated['layer_dropout']        

        return hyperparms_best

