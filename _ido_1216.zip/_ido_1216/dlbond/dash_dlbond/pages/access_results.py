import pandas as pd
import dash_core_components as dcc
import dash_html_components as html
import dash_table
from dash.dependencies import Input, Output, State, MATCH
from ...utils.ensemble import get_models_result
from ..utils.generate_table import generate_table
from ..app import app

# モデル情報の読み込み
models_info = get_models_result()
model_list = list(models_info.keys())

style_common = {
    "width": "100%", 
    "display": "inline-block",
    "style": {
        "margin": "10%",
        'margin-bottom': '8%',
        },
    }

@app.callback(
    Output("model_dropdown", "children"),
    Input("add_drop", "n_clicks"),
    State("model_dropdown", "children"),
    prevent_initial_call=True,
)

def get_model_select(n_clicks, children):
    new_layout = html.Div([
        dcc.Dropdown(
        id={"type": "model_select", "index": n_clicks},
        options=[{"label": i, "value": i} for i in model_list],
        placeholder=model_list[0],
    ),
    html.Div(id={"type": "timestamp_dropdown", "index": n_clicks}, children=[])
    ], style=style_common)
    children.append(new_layout)
    
    return children

@app.callback(
    Output({"type": "timestamp_dropdown", "index": MATCH}, "children"),
    Input({"type": "model_select", "index": MATCH}, "value"),
    State("add_drop", "n_clicks"),            
    prevent_initial_call=True,    
)
    
def get_timestamp_select(model, n_clicks):
    timestamps = list(models_info[model].keys())
    new_layout = html.Div([
        dcc.Dropdown(
        id={"type": "timestamp_select", "index": n_clicks},
        options=[{"label": i, "value": i} for i in timestamps],
        placeholder=timestamps[0],
    ),
    html.Div(
        id={"type": "result_all_table", "index": n_clicks}, children=[],
        )
    ], style=style_common)
    
    return new_layout

@app.callback(
    Output({"type": "result_all_table", "index": MATCH}, "children"),
    Input({"type": "model_select", "index": MATCH}, "value"),
    Input({"type": "timestamp_select", "index": MATCH}, "value"),
    State("add_drop", "n_clicks"),            
    prevent_initial_call=True,    
)

def get_result(model, timestamp, n_clicks):
    df = models_info[model][timestamp]["result_all"]["performance"]
    
    df = df.reset_index()
    for i in range(df.iloc[:-4,:].shape[0]):
        df.iloc[i,1:] = df.iloc[i,1:].apply(lambda x:round(x, 2))
        
    for i in range(1, 5):
        for j in range(2, df.shape[1]):
            df.iloc[-i, j] = pd.to_datetime(df.iloc[-i, j]).strftime("%y/%m/%d")
    
    new_layout = html.Div([
        html.H2(""),
        dash_table.DataTable(
        id={"type": 'result_table', "index": n_clicks},
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict("records"),
        style_header={
            'backgroundColor': "rgb(0, 0, 118)",
            'color': 'white',
            'fontWeight': 'bold',
            'textAlign': 'center',
            'maxHeight': '300px',
        },
        style_data_conditional=[
            {
                'if': {'row_index': 'odd'},
                'backgroundColor': 'rgb(220, 220, 220)',
            }
        ],      
        export_format='csv',
        ),
        html.H2(""),        
    ], style=style_common)
    
    return new_layout


