"""torchを用いて作成した深層学習モデルへインプットするデータセットの作成
"""
import math
import torch
from .util import get_universe_slice_list


class XSDataLoader:
    """torch型のデータセットを作成するクラス
    """

    def __init__(self, X, y, batch_size):
        """
        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
            -> データの全要素はfloat型へ変換可能であることを想定
        y : pd.Series
            リターンデータ(銘柄×時点,)
            -> データの全要素はfloat型へ変換可能であることを想定
        batch_size : int
            バッチサイズ（1バッチは1か月データに相当．Noneの場合，全データを使用してバッチ学習を実施）
        """
        self.X, self.y = X, y
        self.date_index = sorted(y.index.get_level_values("Date").unique())
        
        if batch_size is None:
            self.batch_size = len(self.date_index)        
        else:
            self.batch_size = batch_size

    def _iter_t(self, index_start, index_end):
        """各バッチにおける特徴量データ，リターンデータ，各時点のユニバースのスライス番号のリストを出力

        Parameters
        ----------
        index_start : int
            バッチ開始時点
        index_end : int
            バッチ終了時点

        Returns
        -------
        X_t_torch : torch.tensor
            t時点における各銘柄の特徴量データセット
            (銘柄, 時点, バッチサイズ)
        y_torch : torch.tensor
            各時点における各銘柄のリターンデータ
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]
        """
        df_batch = self.X.loc[(self.X.index.get_level_values("Date") >= self.date_index[index_start]) & (
            self.X.index.get_level_values("Date") <= self.date_index[index_end-1]), :]
        X_t_torch = torch.tensor(df_batch.values).float()
        date_batch = self.date_index[index_start:index_end]
        y_batch = self.y.loc[self.y.index.get_level_values(
            "Date").isin(date_batch)]
        y_torch = torch.tensor(y_batch.values).float()
        
        # ユニバースの情報をlistで保存
        universe_index = get_universe_slice_list(y_batch.index, date_batch)

        return X_t_torch, y_torch, universe_index

    def __iter__(self):
        """torch変換されたデータを作成するクラス

        Yields
        -------
        X_t_torch : torch.tensor
            t時点における各銘柄の特徴量データセット
            (銘柄, 時点, バッチサイズ)
        y_torch : torch.tensor
            各時点における各銘柄のリターンデータ
        """
        batch_set = max(1, math.floor(len(self.date_index)/self.batch_size))

        for t in range(batch_set):
            index_start = int(self.batch_size * t)
            if t+1 == batch_set:
                index_end = len(self.date_index)
            else:
                index_end = int(self.batch_size * (t+1))

            yield self._iter_t(index_start, index_end)
