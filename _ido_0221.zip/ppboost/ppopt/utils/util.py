import numpy as np
import pandas as pd
import torch


def check_input(X: pd.DataFrame = None, y: pd.Series = None):
    """特徴量データ(X)とリターンデータ(y)の入力形式の確認
    (X, yのどちらのみを入力することも可．その場合，入力されたデータのみ型チェックを実施)

    Parameters
    ----------
    X : pd.DataFrame (MultiIndex("Date", "stock"))
        特徴量データ(銘柄×時点, 特徴量)
    y : pd.Series (MultiIndex("Date", "stock"))
        リターンデータ(銘柄×時点,)

    Raises
    ------
    * Xとyのどちらも，Date, stockの順に2列のマルチインデックスを設定
    * Xの行数とyの列数は同一
    * Xの全要素はfloat型
    """
    if X is not None:
        assert isinstance(X, pd.DataFrame), (
            "Xの型はpd.DataFrame．"
        )
        assert len(X.shape) == 2, (
            "Xの次元は(銘柄×時点, 特徴量)を想定"
        )
        for i in X.dtypes:
            assert i == float, (
                "Xの全要素はfloat型を想定"
            )
        assert X.index.names == ["Date", "stock"], (
            "Xは，Date, stockの順に2列のマルチインデックスを設定"
        )

    if y is not None:
        assert isinstance(y, pd.Series), (
            "型はpd.Series．次元は(銘柄×時点, )を想定"
        )
        assert y.index.names == ["Date", "stock"], (
            "yは，Date, stockの順に2列のマルチインデックスを設定"
        )

    if X is not None and y is not None:
        assert X.shape[0] == len(y), (
            "Xの行数とyの列数は同一を想定\n"
            + f"X.shape[0] = {X.shape[0]} : len(y) = {len(y)}"
        )


def base_port_return(rt, universe_index):
    """ベンチマークポートフォリオのリターンを算出（ベンチマークは等ウェイトポートフォリオ）

    Parameters
    ----------
    rt : torch.tensor, optional
        リターンデータ.(銘柄*時点,)
    universe_index : List[slice]
        各時点におけるユニバース銘柄のスライス番号を格納したリスト
        ex) [slice(0, 430, None), slice(430, 860, None),...]    

    Returns
    -------
    rt_bench : torch.tensor
        ベンチマークポートフォリオのリターン.    
    """
    rt_bench = torch.zeros(len(universe_index))
    for t, universe in enumerate(universe_index):
        stock_num = len(rt[universe])
        weight_bench = torch.ones(stock_num)/stock_num
        rt_bench[t] = (rt[universe]*weight_bench).sum()

    return rt_bench


def calc_active_return(weight_t, rt, universe_index):
    """LSポートフォリオのウェイトからアクティブリターンを算出

    Parameters
    ----------
    weight_t : torch.tensor
        LSポートフォリオのウェイト.
    rt : torch.tensor, optional
        リターンデータ.(銘柄*時点,)
    universe_index : List[slice]
        各時点におけるユニバース銘柄のスライス番号を格納したリスト
        ex) [slice(0, 430, None), slice(430, 860, None),...]

    Returns
    -------
    rt_active : torch.tensor
        ポートフォリオのアクティブリターン.
    """
    rt_active = torch.zeros(len(universe_index))
    for t, universe in enumerate(universe_index):
        rt_active[t] = (rt[universe]*weight_t[universe]).sum()

    return rt_active


def calc_port_return(weight, rt, universe_index):
    """ポートフォリオのウェイトからアクティブリターンを算出

    Parameters
    ----------
    weight : pd.Series (MultiIndex("Date", "stock"))
        ポートフォリオのウェイト行列(銘柄*各時点)
    rt : pd.Series (MultiIndex("Date", "stock"))
        リターンデータ.(銘柄*時点)
    universe_index : List[slice]
        各時点におけるユニバース銘柄のスライス番号を格納したリスト
        ex) [slice(0, 430, None), slice(430, 860, None),...]

    Returns
    -------
    port_rt : pd.Series(Index = "Date")
        ポートフォリオのリターン.(時点)
    """
    port_rt = (weight*rt).groupby("Date").sum()

    return port_rt


def get_universe_slice_list(multiindex, date_index):
    """各時点におけるユニバース銘柄のスライス番号を格納したリストを返す

    Parameters
    ----------
    multiindex : pd.MultiIndex
        マルチインデックス("Date", "stock"の2つの列が格納).
    date_index : list
        日付インデックスが格納されたリスト.

    Returns
    -------
    universe_index : List[slice]
        各時点におけるユニバース銘柄のスライス番号を格納したリスト
        ex) [slice(0, 430, None), slice(430, 860, None),...]
    """
    # ユニバースの情報をlistで保存
    universe_index = [multiindex.get_loc(date_) for date_ in date_index]

    return universe_index


def calc_hold_weight(weight_t, weight_t_1, rt):
    """t-1時点のポートフォリオをt時点まで保有した際のウェイトを計算

    Parameters
    ----------
    weight_t : pd.Series(Index = "stock")
        t時点における各銘柄への投資ウェイト
    weight_t_1 : pd.Series(Index = "stock")
        t-1時点における各銘柄への投資ウェイト
    rt : pd.Series : pd.Series(Index = "stock")
        t時点に確定する各銘柄への投資ウェイト(ユニバースはt-1時点のもの)

    Returns
    -------
    weight_hold_t: pd.Series(Index = "stock")
        t時点まで保有した際の各銘柄への投資ウェイト
    """
    universe_t_1_t = sorted(list(set(weight_t_1.index) & set(weight_t.index)))        
    port_rt_1 = (weight_t_1.loc[universe_t_1_t]*rt.loc[universe_t_1_t])
    weight_hold_t = weight_t_1.loc[universe_t_1_t]*(1 + port_rt_1)/(1 + port_rt_1.sum())
    
    return weight_hold_t


def calc_weight_diff_yield(weight, rt):
    """t-1時点のポートフォリオをt時点まで保有した際のウェイトとt時点のポートフォリオウェイトの変化分を算出

    Parameters
    ----------
    weight : pd.Series (MultiIndex("Date", "stock"))
        各時点におけるポートフォリオの投資ウェイト
    rt : pd.Series (MultiIndex("Date", "stock"))
        各時点における銘柄のリターン

    Yields
    ------
    weight_diff_t: pd.Series (MultiIndex("Date", "stock"))
        t時点におけるポートフォリオウェイトの変化分
    weight_hold_t: pd.Series(Index = "stock")
        t時点まで保有した際の各銘柄への投資ウェイト        
    weight_t :  pd.Series (MultiIndex("Date", "stock"))
        t時点における各銘柄への投資ウェイト    
    weight_t_1 :  pd.Series (MultiIndex("Date", "stock"))
        t-1時点における各銘柄への投資ウェイト
        
    Notes
    -----
    * t-1時点のポートフォリオをt時点まで保有した際のウェイトはt時点で確定するリターンの情報をもとに算出
    """
    date_indexes = sorted(weight.index.get_level_values("Date").unique())
    universe_index = get_universe_slice_list(weight.index, date_indexes)        
        
    for date_index, date_index_next in zip(universe_index[:-1], universe_index[1:]):
        weight_t_1 = weight.iloc[date_index]
        weight_t = weight.iloc[date_index_next]        
        weight_t_1_dropped = weight_t_1.droplevel("Date")   
        weight_t_dropped = weight_t.droplevel("Date")
       
        # t-1時点のポートフォリオをt時点まで保有した際のウェイト
        weight_hold_t = calc_hold_weight(
            weight_t_dropped,
            weight_t_1_dropped,
            rt.iloc[date_index].droplevel("Date"))
        weight_hold_t.index = weight_t.index

        # ウェイト変化の算出
        weight_combined = pd.concat([weight_hold_t, weight_t],
                                    axis=1, join="outer").fillna(0)
        weight_diff_t_ = weight_combined.diff(axis=1).dropna(axis=1).squeeze()
        weight_diff_t = weight_diff_t_.loc[weight_t.index]
        
        yield weight_diff_t, weight_hold_t, weight_t, weight_t_1