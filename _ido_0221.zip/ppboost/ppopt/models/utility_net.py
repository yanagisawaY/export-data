from torch import nn
import torch


class ONINorm(nn.Module):
    """L-1層のLSポートフォリオのリターンをもとに直交変換を実施

    Notes
    -----    
    `Controllable Orthogonalization in Training DNNs <https://openaccess.thecvf.com/content_CVPR_2020/html/Huang_Controllable_Orthogonalization_in_Training_DNNs_CVPR_2020_paper.html>`_

    `コード参照元 <https://github.com/huangleiBuaa/ONI>`_    
    """

    def __init__(self, T=10, norm_groups=1, *args, **kwargs):
        super(ONINorm, self).__init__()
        self.T = T
        self.norm_groups = norm_groups
        self.eps = 1e-5

    def forward(self, port_rt: torch.Tensor, is_train=True):
        """
            ウェイトを変換させる行列Bを出力

        Parameters
        ----------
        port_rt : torch.Tensor
            直交変換前の特性ポートフォリオのリターン.
        is_train: bool
            学習フェイズであるか

        Returns
        -------
        convert_ht : torch.Tensor
            ウェイトに掛け合わせる直交変換用の行列.

        convert_ht@(直交返還前の隠れ層の合成ポートフォリオのウェイト)をかけることで，
        各々のポートフォリオを直交させる(ニュートン法を用いた直交変換)

        Notes
        -----
        * 先行研究と異なり，Zをセンタリングしない

        centeringなくすことで収束は遅くなると予測されるが，
        (つまり特異値の初期値が悪くなる?ただポートフォリオの平均は-1<1に収まるためそこまでの劣化はないとも考えている)，
        先行研究と違い，パラメータの直交化ではなく，ポートフォリオの直交化が目的のため，
        convert_htの計算においてセンタリング値を戻す処理を実施しなくてもよい変換をする        
        """
        assert port_rt.shape[0] % self.norm_groups == 0

        Zc = port_rt.view(self.norm_groups,
                          port_rt.shape[0] // self.norm_groups, -1)
        S = torch.matmul(Zc, Zc.transpose(1, 2))
        eye = torch.eye(S.shape[-1]).to(S).expand(S.shape)
        S = S + self.eps*eye

        norm_S = S.norm(p='fro', dim=(1, 2), keepdim=True)
        S = S.div(norm_S)
        B = [torch.Tensor([]) for _ in range(self.T + 1)]
        W = [torch.Tensor([]) for _ in range(self.T + 1)]
        B[0] = torch.eye(S.shape[-1]).to(S).expand(S.shape)
        W[0] = B[0].matmul(Zc).div_(norm_S.sqrt())
        min_W = 10*100000
        for t in range(self.T):
            B[t + 1] = 1.5 * B[t] - 0.5 * (B[t]@B[t]@B[t]@S)
            W[t + 1] = B[t+1].matmul(Zc).div_(norm_S.sqrt())
            min_W_temp = (W[t + 1].squeeze()@W[t + 1].squeeze().T -
                          torch.eye(S.shape[-1])).abs().sum()
            if min_W > min_W_temp:
                min_W = min_W_temp
                best_t = t + 1
                # print(W[t + 1].squeeze(0)@W[t + 1].squeeze(0).T)  # 直交化している様子の確認
                # print(f"{t} : {min_W.item()}") # 0に収束しているかの確認

        # W = B[self.T].matmul(Zc).div_(norm_S.sqrt())
        # W.view_as(port_rt)

        convert_ht = B[best_t].div_(norm_S.sqrt()).squeeze(0)

        return convert_ht

    def extra_repr(self):
        fmt_str = ['T={}'.format(self.T)]
        if self.norm_groups > 1:
            fmt_str.append('groups={}'.format(self.norm_groups))
        return ', '.join(fmt_str)


class XSNorm(nn.Module):
    def __init__(self):
        super().__init__()
    
    def forward(self, hidden, universe_index):
        """ロスセクション方向に平均ゼロ，標準偏差1に標準化し，その期における銘柄数で除算
        

        Parameters
        ----------
        hidden : torch.tensor
            基準化前の合成ポートフォリオ(L-1層のポートフォリオ)のウェイト
            (バッチ(時点)*(各時点の)銘柄, 合成ポートフォリオの数)
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]

        Returns
        -------
        hidden_scaled : torch.tensor
            基準化後の合成ポートフォリオ(L-1層のポートフォリオ)のウェイト
            (バッチ(時点)*(各時点の)銘柄, 合成ポートフォリオの数)
            
        Notes
        -----
        * 出力層はクロスセクション方向に平均ゼロ，標準偏差1に標準化し，その期における銘柄数で除算
        -> 出力層の各ユニットの値はLSポートフォリオとみなすことができる
        * L-1層の出力に対し，この基準化を実施することで，ポートフォリオフォリオの総ウェイトが1となることが保証
        """
        # クロスセクション方向に平均ゼロ，標準偏差1に標準化
        hidden_scaled = torch.zeros(hidden.size())
        for universe in universe_index:
            stock_num = hidden[universe, :].shape[0]
            hidden_scaled[universe, :] = (hidden[universe, :] - hidden[universe, :].mean(
                dim=0, keepdim=True))/(stock_num*hidden[universe, :].std(dim=0, keepdim=True))
    
        return hidden_scaled


class MultiPortNet(nn.Module):
    '''pytorchベースのDeep Neural Netwark
    '''

    def __init__(self, hyperparms, input_num):
        '''
        Parameters
        ----------
        hyperparms : dict
            深層学習のハイパーパラメータ.
            layer_dropout : ドロップアウト
            layer_list     : 層のユニット数が格納されたリスト
        input_num : int
            入力変数のサイズ            
        '''
        super(MultiPortNet, self).__init__()
        layer_units = hyperparms['layer_list']
        layer_num = len(layer_units)
        layer = []
        if layer_num > 0:

            for i in range(layer_num):
                layer.append(nn.Dropout(hyperparms['layer_dropout']))

                if i >= 1:
                    input_num_layer = layer_units[i-1]
                elif layer_num == 1 or i == 0:
                    input_num_layer = input_num

                layer.append(nn.Linear(input_num_layer,
                             layer_units[i], bias=False))
                    
                layer.append(XSNorm())                    

                if i < layer_num-1:
                    layer.append(nn.ReLU())
                
            self.is_linear = False
            self.last_unit = layer_units[-1]
        else:
            layer.append(nn.Dropout(hyperparms['layer_dropout']))
            self.is_linear = True

        self.full = nn.ModuleList(layer)

    def forward(self, X, universe_index):
        """順伝搬

        Parameters
        ----------
        X : torch.tensor
            (バッチ(時点)*(各時点の)銘柄, 特徴量)
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]

        Returns
        -------
        hidden : torch.tensor
            基準化後の合成ポートフォリオ(L-1層のポートフォリオ)のウェイト
            (バッチ(時点)*(各時点の)銘柄, 合成ポートフォリオの数)

        Notes
        -----
        L-1層はクロスセクション方向に平均ゼロ，標準偏差1に標準化
        ->　ポートフォリオフォリオの総ウェイトが1となることが保証
        """
        hidden = X
        for module in self.full:
            if str(module) == "XSNorm()":
                hidden = module(hidden, universe_index)
            else:
                hidden = module(hidden)

        return hidden


class UtilityNet(nn.Module):
    def __init__(self, hyperparms, input_num):
        super(UtilityNet, self).__init__()
        self.layer_units = hyperparms['layer_list']
        if len(self.layer_units) > 0:
            last_unit = self.layer_units[-1]
        else:
            last_unit = input_num
        self.last = nn.Linear(last_unit, 1, bias=False)
        self.oln = ONINorm(T=hyperparms["newton_T"], norm_groups=1)
        self.mpn = MultiPortNet(hyperparms, input_num)
        self.network_type = hyperparms["network_type"]

    def forward(self, X, universe_index, rt=None, mode="train"):
        """最終的なLSポートフォリオのウェイトを出力

        Parameters
        ----------
        X : torch.tensor
            基準化後の特徴量データ.(銘柄*時点, 特徴量)
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]
        rt : torch.tensor, optional
            リターンデータ.(銘柄*時点,)
        mode : str, optional
            oncアルゴリズムを使用する場合に学習済みの直交行列を使用するため，訓練か推論かを切り替える
            "train" -> 訓練モード
            "test" -> 推論モード

        Returns
        -------
        weight_t : torch.tensor
            LSポートフォリオのウェイト.
        """
        weight_ht = self.call_hidden_weight(X, universe_index, rt, mode)

        # calculate last layer
        weight_t = self.last(weight_ht).squeeze()

        return weight_t

    def call_hidden_weight(self, X, universe_index, rt=None, mode="train"):
        """L-1層におけるLSポートフォリオのウェイトを出力

        Parameters
        ----------
        X : torch.tensor
            基準化後の特徴量データ.(銘柄*時点, 特徴量)
        universe_index : List[slice]
            各時点におけるユニバース銘柄のスライス番号を格納したリスト
            ex) [slice(0, 430, None), slice(430, 860, None),...]
        rt : torch.tensor, optional
            リターンデータ.(銘柄*時点,)
        mode : str, optional
            oncアルゴリズムを使用する場合に学習済みの直交行列を使用するため，訓練か推論かを切り替える
            "train" -> 訓練モード
            "test" -> 推論モード

        Returns
        -------
        weight_ht : torch.tensor
            L-1層におけるLSポートフォリオのウェイト.(銘柄*時点,)

        Notes
        -----
        * network_type = "onc"の場合，直交変換させた際にウェイトが小さくスケーリングされるため，
        クロスセクション方向に標準偏差が1となるようリスケーリングしている        
        """
        # calculate L-1 layer
        weight_ht = self.mpn.forward(X, universe_index)

        if self.network_type == "onc":
            if mode == "train":
                hidden_rt_all = torch.einsum('tk,t->tk', weight_ht, rt)
                hidden_rt = torch.zeros(
                    len(universe_index), weight_ht.shape[1])
                for t, universe in enumerate(universe_index):
                    hidden_rt[t, :] = torch.sum(hidden_rt_all[universe, :], 0).squeeze()

                convert_ht = self.oln(hidden_rt.T)
                self.convert_ht = convert_ht.detach()
                # temp = pd.DataFrame((hidden_rt@self.convert_ht).detach().numpy().copy())
                # print(temp.corr())
            elif mode == "predict":
                convert_ht = self.convert_ht
            else:
                raise ValueError(
                    r"mode is {mode} : Enter 'train or 'test' for mode")

            weight_ht_scaled = torch.zeros(weight_ht.size())
            for universe in universe_index:
                temp = weight_ht[universe, :]@convert_ht
                # 直交変換させた際にウェイトが小さくスケーリングされるため，
                # クロスセクション方向に標準偏差が1となるようリスケーリングする
                # ### (要チェック)　直交変換では，スケールは本来変わらないはず?(元論文参照)
                weight_ht_scaled[universe, :] = temp / \
                    (temp.shape[0]*temp.std(dim=0, keepdim=True))

            return weight_ht_scaled
        else:
            return weight_ht
