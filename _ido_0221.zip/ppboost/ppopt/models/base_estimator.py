import copy
import numpy as np
import pandas as pd
import torch

from ..utils.optimizer import adjust_weight_under_stocklimit

import optuna
import random


class ModelBase:
    '''モデルのベースクラス

    Paramters
    ---------
    hyperparms : Dict[str: Any]
    ハイパーパラメータの辞書(以下の項目を設定)

        Examples
        --------
        >>> hyperparams = {
        >>>     # optunaの設定
        >>>     "is_tune": True,  # optunaによるハイパラ探索をする場合はTrue
        >>>     "is_prune": True,  # 枝刈りアルゴリズムを使用する場合はTrue
        >>>     'n_trials': 100,  # optunaによる試行回数
        >>>     'timeout': 3600*8,  # optunaによる探索の計算時間上限（秒）．timeout秒を超えると強制的に探索を打ち切る  
        >>>     
        >>>     # optunaのハイパーパラメータ探索範囲(models.base_estimator.tune or tune_pruneにて使用)
        >>>     "optuna_scope":{
        >>>         "lr" : (1e-4, 1e-3),  # Adamに適用する学習率(trial.suggest_float, log=True)
        >>>         "layer_dropout": (0, 0.1),  # ドロップアウト(trial.suggest_uniform)
        >>>         "n_layers": (0, 2),  # ネットワークの層数(trial.suggest_int)
        >>>         "n_units": (4, 64),  # 中間層のユニット数(trial.suggest_int)
        >>>         "n_units_last": (3, 6),  # 最終層のユニット数(trial.suggest_int)
        >>>         }, 
        >>> }    
    '''
    def __init__(self, hyperparms):
        self.hyperparms = hyperparms        
        self.study = None
         
    def adjust_weight(self, weight, rt, stock_limit):
        return adjust_weight_under_stocklimit(weight, rt, stock_limit)

    def tune(self, X, y, X_val, y_val):
        """optunaによるハイパーパラメータの最適化を実施

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series
            リターンデータ(銘柄×時点,)
        X_val : pd.DataFrame
            バリデーション期間における特徴量データ(銘柄×時点, 特徴量)
        y_val : pd.DataFrame
            バリデーション期間におけるリターンデータ(銘柄×時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
        [1] https://optuna.org/
            
        Notes
        -----
        * hyperparamsでbest_paramsをTrueとした場合，バリデーションデータの評価値が最もよい値を採用                    
        """
        optuna_scope = hyperparms["optuna_scope"]        
        torch.manual_seed(self.hyperparms['random_state'])
        random.seed(self.hyperparms['random_state'])
        np.random.seed(self.hyperparms['random_state'])

        hyperparms = copy.deepcopy(self.hyperparms)

        def objective(trial):
            hyperparms['lr'] = trial.suggest_float("lr", *optuna_scope["lr"], log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform(
                'layer_dropout', *optuna_scope["layer_dropout"])
            n_layers = trial.suggest_int("n_layers", *optuna_scope["n_layers"])
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [
                    trial.suggest_int("n_units_l{}".format(i), *optuna_scope["n_units"])
                ]

            hyperparms['layer_list'] += [trial.suggest_int(
                "n_units_l{}".format(n_layers), *optuna_scope["n_units_last"])]
            self.fit(X, y, X_val, y_val, hyperparms)
            
            if hyperparms["best_params"]:
                # バリデーションデータの評価値が最もよいハイパーパラメータを採用する場合
                loss_val = self.loss_save["val"].max()
            else:
                loss_val = self.loss_save["val"].iloc[-1]

            return loss_val

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms['random_state'])
        study = optuna.create_study(direction="maximize",
                                    sampler=sampler)
        study.optimize(
            objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"]
        )
        self.study = study

    def tune_prune(self, X, y, X_val, y_val):
        """optunaによるハイパーパラメータの最適化を実施(枝刈りアルゴリズムを使用)

        Parameters
        ----------
        X : pd.DataFrame
            特徴量データ(銘柄×時点, 特徴量)
        y : pd.Series
            リターンデータ(銘柄×時点,)
        X_val : pd.DataFrame
            バリデーション期間における特徴量データ(銘柄×時点, 特徴量)
        y_val : pd.DataFrame
            バリデーション期間におけるリターンデータ(銘柄×時点,)

        Attributes
        ----------
        trial : optuna.trial._frozen.FrozenTrial
            optunaのハイパーパラメータ最適化結果

        References
        ----------
        [1] https://optuna.org/
        [2] 枝刈りアルゴリズムの実装例 : https://github.com/optuna/optuna-examples/blob/main/pytorch/pytorch_simple.py#L125
        
        Notes
        -----
        * hyperparamsでbest_paramsをTrueとした場合，バリデーションデータの評価値が最もよい値を採用
        """
        optuna_scope = hyperparms["optuna_scope"]        
        torch.manual_seed(self.hyperparms['random_state'])
        random.seed(self.hyperparms['random_state'])
        np.random.seed(self.hyperparms['random_state'])

        hyperparms = copy.deepcopy(self.hyperparms)
        # 枝刈りアルゴリズムを使用する場合は早期停止を_fit_yield内で実施しない
        hyperparms["min_epoch"] = hyperparms["epoch"]        

        def objective(trial):
            hyperparms['lr'] = trial.suggest_float("lr", *optuna_scope["lr"], log=True)
            hyperparms['layer_dropout'] = trial.suggest_uniform(
                'layer_dropout', *optuna_scope["layer_dropout"])
            n_layers = trial.suggest_int("n_layers", *optuna_scope["n_layers"])
            hyperparms['layer_list'] = []
            for i in range(n_layers):
                hyperparms['layer_list'] += [
                    trial.suggest_int("n_units_l{}".format(i), *optuna_scope["n_units"])
                ]

            hyperparms['layer_list'] += [trial.suggest_int(
                "n_units_l{}".format(n_layers), *optuna_scope["n_units_last"])]

            if hyperparms["best_params"]:
                loss_val_best = -10**1000

            for epoch, loss_list in enumerate(self.fit_yield(X, y, X_val, y_val, hyperparms)):
                
                loss_val = loss_list[1]
                
                if hyperparms["best_params"]:
                    # バリデーションデータの評価値が最もよいハイパーパラメータを採用する場合
                    if loss_val_best < loss_val:
                        loss_val_best = loss_val
                    else:
                        loss_val = loss_val_best
                        
                trial.report(loss_val, epoch)

                # Handle pruning based on the intermediate value.
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()
                            
            return loss_val

        sampler = optuna.samplers.TPESampler(
            seed=self.hyperparms['random_state']
            )
        study = optuna.create_study(
            direction="maximize",
            sampler=sampler,
            pruner=optuna.pruners.SuccessiveHalvingPruner()
            )
        study.optimize(
            objective, n_trials=self.hyperparms["n_trials"], timeout=self.hyperparms["timeout"]
            )
        self.study = study
        
    def update_hyperparams(self, hyperparms_best_updated={}):
        """optunaにより調整したハイパーパラメータの辞書の更新

        Parameters
        ----------
        hyperparms_best_updated : dict
            更新されたハイパーパラメータ (チューニングされたパラメータのみ)

            指定しない場合，tuneにより調整されたstudyのbest_trialが参照される．

        Raises
        ------
        optunaのハイパーパラメータ最適化(tune or tune_prune)を先に実行する

        Returns
        -------
        hyperparms_best : dict
            更新したハイパーパラメータの辞書
        """
        if len(hyperparms_best_updated) == 0:
            if self.study is None:
                raise ValueError('tuneかtune_pruneを実行してください')
            hyperparms_best = copy.deepcopy(self.hyperparms)
            hyperparms_best_updated = self.study.best_trial.params
        else:
            assert isinstance(hyperparms_best_updated, dict)
            hyperparms_best = copy.deepcopy(self.hyperparms)

        hyperparms_best['layer_list'] = []
        for layer in range(hyperparms_best_updated['n_layers'] + 1):
            hyperparms_best['layer_list'] += [
                hyperparms_best_updated['n_units_l'+str(layer)]]
        hyperparms_best['lr'] = hyperparms_best_updated['lr']
        hyperparms_best['layer_dropout'] = hyperparms_best_updated['layer_dropout']
        self.hyperparms = hyperparms_best

        return hyperparms_best
