# -*- coding: utf-8 -*-
"""
「Trader-Company Method: A Metaheuristic for InterpretableStock Price Prediction」
https://arxiv.org/pdf/2012.10215.pdf

Notes:
    1.変数名は論文内容と整合性を持たせるよう「論文記載の変数名_変数の意味」となるように統一
    2.「活性関数の探索範囲（activation_functions）」と「二項演算子の関数の探索範囲（binary_operators）」
    　　は，config.pyにて設定
"""
import numpy as np
import random
from sklearn.ensemble import RandomForestRegressor as RFR
from config.config import *

class Trader:
    def __init__(self, hyperparms_all_formula, X_input, lookback_window_max):
        '''
           3.1  Traders - Simple Prediction Module
           M個の戦略をもつトレーダーの予測を実施するクラス
    
        Parameters
        ----------
        hyperparms_all_formula : dict
            M個の戦略のハイパーパラメータ情報が階層的に格納された辞書
            'M_formula_num' : 戦略の数
                戦略ごとに以下の情報が格納
                'P_stock_return'     : 対象銘柄Pのリターン
                'Q_stock_return'     : 対象銘柄Qのリターン
                'D_lookback_for_P'   : 対象銘柄Pのルックバック期間    
                'F_lookback_for_Q'   : 対象銘柄Qのルックバック期間
                'A_activation_func'  : 活性化関数
                'O_binary_operator'  : 二項演算子の関数   
        X_input : pandas.DataFrame or numpy.ndarray
            投資対象のリターン行列.(説明変数群)                    
        lookback_window_max : int
            各銘柄のリターンの参照期間候補の最大値
        '''
        try:
            self.X_input = X_input.values
        except:
            self.X_input = X_input
            
        self.hyperparms_all_formula = hyperparms_all_formula
        self.lookback_window_max = lookback_window_max
        
    def make_one_strategy(self, hyperparms_j):
        '''
            1戦略の予測結果を返す（学習は行わない）

        Parameters
        ----------
        hyperparms_j : TYPE
            1戦略のハイパーパラメータ.

        Returns
        -------
        one_strategy
            1戦略の予測結果.
        '''               
        if int(hyperparms_j['D_lookback_for_P']) > 1:
            x = self.X_input[(self.lookback_window_max-int(hyperparms_j['D_lookback_for_P'])):(-int(hyperparms_j['D_lookback_for_P'])+1), int(hyperparms_j['P_stock_id'])]
        else:  
            x = self.X_input[(self.lookback_window_max-int(hyperparms_j['D_lookback_for_P'])):, int(hyperparms_j['P_stock_id'])]
        
        if int(hyperparms_j['F_lookback_for_Q']) > 1:
            y = self.X_input[(self.lookback_window_max-int(hyperparms_j['F_lookback_for_Q'])):(-int(hyperparms_j['F_lookback_for_Q'])+1), int(hyperparms_j['Q_stock_id'])]
        else:
            y = self.X_input[(self.lookback_window_max-int(hyperparms_j['F_lookback_for_Q'])):, int(hyperparms_j['Q_stock_id'])]

        binary_op = list(hyperparms_j['O_binary_operator'].values())[0]            
        activation_func = list(hyperparms_j['A_activation_func'].values())[0]                        
        one_strategy = activation_func(binary_op(x, y))

        return one_strategy

    def fit_one_strategy(self, hyperparms_j, y_input, trader_parms):
        '''
            データの半分を使用してモデル学習を行い，その結果をもとに1戦略の予測結果を返す

        Parameters
        ----------
        hyperparms_j : TYPE
            1戦略のハイパーパラメータ.

        Returns
        -------
        one_strategy
            1戦略の予測結果.
        '''                                     
        one_strategy = self.make_one_strategy(hyperparms_j)
        len_train = round(len(y_input)/2)
        rg = RFR(**trader_parms) 
        try:
            rg.fit(one_strategy[:len_train].reshape(-1, 1), y_input[:len_train])            
        except:
            import pdb
            pdb.set_trace()
        hyperparms_j['model'] = rg
        
        return hyperparms_j

    def make_one_strategy_fitted(self, hyperparms_j_learned):
        '''
            1戦略の予測結果を返す（学習済みモデルを使用）

        Parameters
        ----------
        hyperparms_j : TYPE
            1戦略のハイパーパラメータ.

        Returns
        -------
        one_strategy
            1戦略の予測結果.
        '''
        one_strategy = self.make_one_strategy(hyperparms_j_learned)
        rg = hyperparms_j_learned['model']
        one_strategy = rg.predict(one_strategy.reshape(-1, 1))
    
        return one_strategy
    
    def make_strategy(self, y_input={}, trader_parms={}, is_fit=True, is_save=False):
        '''
            M個の戦略の予測結果を返す

        Returns
        -------
        each_strategy : list
            M個の戦略の予測結果. (時点, 戦略数)
        '''
        if len(y_input) == 0 and len(trader_parms) == 0:
            each_strategy = [self.make_one_strategy(hyperparms_j) for hyperparms_j in self.hyperparms_all_formula.values()]
        else:
            if is_fit:
                hyperparms_all_formula_learned = {key:self.fit_one_strategy(hyperparms_j, y_input, trader_parms) for key, hyperparms_j in self.hyperparms_all_formula.items()}                
                each_strategy = [self.make_one_strategy_fitted(hyperparms_j) for hyperparms_j in hyperparms_all_formula_learned.values()]         
            else:
                each_strategy = [self.make_one_strategy_fitted(hyperparms_j) for hyperparms_j in self.hyperparms_all_formula.values()]
                
        each_strategy = np.array(each_strategy).T

        if is_fit and is_save:
            # 学習したモデルパラメータも出力
            return each_strategy, hyperparms_all_formula_learned
        else:
            return each_strategy
    
    def predict(self, weight, each_strategy):        
        '''
            M個の戦略をweightで重みづけした予測結果を返す

        Parameters
        ----------
        weight : np.array
            各戦略のウェイト.次元数 ：　(M_formula_num)
    
        Returns
        -------
        trader_prediction
            M個の戦略をもつトレーダーの予測結果
        '''
        trader_prediction = np.dot(each_strategy, weight)# /len(weight)
        
        return trader_prediction    

class TraderGenarator:
    def __init__(self, stock_list, hyperparms_trader):
        '''
            トレーダーの初期戦略の設定を生成

        Parameters
        ----------
        stock_list : list
            銘柄のインデックス探索範囲.(5)式のリターンインデックスP,Qの候補
        hyperparms_trader : dict
            トレーダーに関するハイパーパラメータ.
            'formula_num_max'     : 戦略の最大数
            'lookback_window_max' : ルックバックウィンドウの最大数  
            'random_seed'         : ランダムシード 
        '''        
        self.hyperparms_trader = hyperparms_trader
        self.random_seed = self.hyperparms_trader['random_seed']
        self.stock_list = stock_list
            
        # 探索範囲の取得
        self.activation_functions, self.binary_operators, \
            self.formula_list, self.lookback_window_list \
                = self.set_scope()
                    
    def set_scope(self):
        '''
            トレーダーの探索範囲の設定値を返す

        Returns
        -------
        activation_functions : list
            活性化関数の候補.
        binary_operators : list
            二項演算子の関数の候補.
        formula_list : list            
            戦略数の候補．
        lookback_window_list : list
            ルックバックウィンドウの候補．        
        '''                
        formula_list = list(range(1, self.hyperparms_trader['formula_num_max']+1))
        lookback_window_list = list(range(1, self.hyperparms_trader['lookback_window_max']+1))
                
        return activation_functions, binary_operators, formula_list, lookback_window_list

    def set_weight_init(self, formula_num):
        '''
            各戦略の重みづけの初期値を設定

        Parameters
        ----------
        formula_num : TYPE
            戦略（公式）の数.

        Returns
        -------
        weight : TYPE
            各戦略の重み.
        '''
        weight = [1/formula_num for _ in range(formula_num)]
        
        return weight
        
    def get_formula_uniform(self):
        '''
            ランダムに戦略（公式）の数を抽出            
            
        Returns
        -------
        formula_num :
            戦略（公式）の数.
        '''
        random.seed(self.random_seed)
        formula_num = random.sample(self.formula_list, 1)[0]
        
        return formula_num

    def get_parm_uniform(self, formula_num):
        '''
            戦略（公式）の数の戦略のパラメータをランダムに抽出

        Parameters
        ----------
        formula_num : TYPE
            戦略（公式）の数.

        Returns
        -------
        hyperparms_all_formula : dict
            formula_num個の戦略が格納されたリスト.
        '''
        hyperparms_all_formula = {}
        for j in range(formula_num):
            random.seed(self.random_seed+j)
            p_stock, q_stock = random.sample(self.stock_list, 2)
            d_lookback, f_lookback = random.sample(self.lookback_window_list, 2)
            active_func = dict(random.sample(list(self.activation_functions.items()), 1))
            binary_op = dict(random.sample(list(self.binary_operators.items()), 1))            
            
            hyperparms_j = { 
                'P_stock_id'        : p_stock,
                'Q_stock_id'        : q_stock,
                'D_lookback_for_P'  : d_lookback,
                'F_lookback_for_Q'  : f_lookback,
                'A_activation_func' : active_func,
                'O_binary_operator' : binary_op,
                }
            
            hyperparms_all_formula[j] = hyperparms_j        
        
        return hyperparms_all_formula        

    def get_parm_trader_init(self):
        '''
            初期時点のトレーダーの戦略を一様分布（ランダム）で設定

        Returns
        -------
        hyperparms_trader : dict
            戦略のパラメータ.
            'M_formula_num'          : 戦略の数
            'weight'                 : 戦略の重みづけ
            'hyperparms_all_formula' : 各戦略のパラメータ
        '''
        formula_num = self.get_formula_uniform()
        weight = self.set_weight_init(formula_num)
        hyperparms_all_formula = self.get_parm_uniform(formula_num)
        hyperparms_trader = {
            'hyperparms_all_formula' : hyperparms_all_formula,
            'weight'                 : weight,            
            }
        
        return hyperparms_trader


def get_all_traders_init(hyperparms_company_common, stock_list):  
    '''
        全てのトレーダーの戦略の初期値を得る

    Parameters
    ----------
    stock_list : list
        銘柄のインデックス探索範囲.(5)式のリターンインデックスP,Qの候補
    hyperparms_company_common : TYPE
        トレーダに関する共通のハイパーパラメータ.
        
    Returns
    -------
    hyperparms_company : dict
        全てのトレーダーの戦略が格納された辞書.

    '''
    hyperparms_traders = {}
    for j in range(hyperparms_company_common['N_trader_num']):
        hyperparms_trader_j = {
            'formula_num_max'     : hyperparms_company_common['formula_num_max'],
            'lookback_window_max' : hyperparms_company_common['lookback_window_max'],        
            'random_seed'         : hyperparms_company_common['random_seed']+j,    
            }
        
        cpg = TraderGenarator(stock_list, hyperparms_trader_j)
        hyperparms_traders[j] = cpg.get_parm_trader_init()

    hyperparms_company = hyperparms_company_common.copy()    
    hyperparms_company['hyperparms_traders'] = hyperparms_traders        
    
    return hyperparms_company