import pandas as pd
from .ensemble import get_models_info, ModelEnsembler
from .evaluator import Evaluator
from .trader import Trader


class MetaBacktester(ModelEnsembler):
    def __init__(self, dfs_input, models_info, is_purmit_including_leak=False):
        super().__init__(dfs_input, models_info)
        self.is_purmit_including_leak = is_purmit_including_leak

    def _call_set_ensemble_pattern(self, X, mode):
        start_date_test = self._set_start_date_test(X)
        self.set_ensemble_pattern(mode, start_date_test)

    def _output_for_analysis(self, X, mode, hyperparams_imp):
        """教師なし学習(PCA, t-SNE, クラスター分析)による可視化結果を返す

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'ensemble.set_ensemble_pattern' method)
        hyperparams_imp : dict
            FeatureImportanceクラスで使用するハイパーパラメーターの辞書
            (クラスター分析の際のcluster_kmeans_top関数実行時の設定項目として使用).

        Returns
        -------
        figs_all : dict
            モデルごとのデータ(+ アンサンブル全体のデータ和集合)に対する可視化結果のfigs
            plotlyによる可視化情報の辞書            
        """
        from .feature_importance import FeatureImportance
        from .unsupervised import UnsupervisedLearner
        self._call_set_ensemble_pattern(X, mode)
        fi = FeatureImportance(hyperparams_imp)
        figs_all = {}
        for i, (_, X_processed) in enumerate(self.generate_setting(X)):
            print(f"unsupervised learning {i+1}")
            _ = fi.call_cluster(X_processed)
            usl = UnsupervisedLearner(
                X_processed,
                n_components=max(1, int(X_processed.shape[1] / 2)),
                random_state=0,
                corr_distance=fi.corr_distance,
                clusters=fi.clusters,
            )
            figs = usl.get_all_figs()
            figs_all[self.ensemble_cols[i]] = figs

        _ = fi.call_cluster(self.X)
        usl = UnsupervisedLearner(
            self.X,
            n_components=max(1, int(X.shape[1] / 2)),
            random_state=0,
            corr_distance=fi.corr_distance,
            clusters=fi.clusters,
        )
        figs = usl.get_all_figs()
        figs_all["ensembled"] = figs

        return figs_all

    def _output_shap_values(self, X, mode):
        """shap値の計算結果を取得        

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'ensemble.set_ensemble_pattern' method)

        Returns
        -------
        shap_values_all : dict
            モデルごとの予測確率(+ アンサンブル全体の予測確率)に対するshap_valuesの結果
        """
        self._call_set_ensemble_pattern(X, mode)
        shap_values_all = self.calc_shap_all(X, mode)
        shap_values_ensembled = self._calc_shap(
            shap_values_all, X, mode
        )
        shap_values_all = {
            self.ensemble_cols[i]: shap_values_ for i, shap_values_ in enumerate(shap_values_all)}
        shap_values_all["ensembled"] = shap_values_ensembled

        return shap_values_all

    def _metabacktest(self, X, mode):
        """ensembler.pyを用いたバックテスト．(パラメータのチューニングは実施しないメタ的なバックテスト) 

        Parameters
        ----------
        X : pd.DataFrame
            テストデータ
        mode : str
            使用する学習済みモデルの選択 (see also 'ensemble.set_ensemble_pattern' method)

        Returns
        -------
        y_pred_all : dict
            モデルごとの予測確率(+ アンサンブル全体の平均予測確率)
        position_all : dict
            モデルごとの予測ポジション(+ アンサンブル全体の予測ポジション, アンサンブル全体のアンサンブルベットサイジング)
        profit_all : dict
            モデルごとの累積損益(+ アンサンブルしたモデルの累積損益)
        performance_all : dict
            モデルごとのパフォーマンス指標(+ アンサンブルしたモデルのパフォーマンス指標)        
        cm_all : dict
            モデルごとの混同行列(+ アンサンブルしたモデルの混同行列)
        """
        tr = Trader(self.config)  # configに依存しない機能しか使わない
        ev = Evaluator()

        self._call_set_ensemble_pattern(X, mode)
        y_pred_all_ = self.predict_prob_all(X, mode)
        y_pred_all = {}
        for i in range(y_pred_all_.shape[1]):
            y_pred_all[self.ensemble_cols[i]] = y_pred_all_.iloc[:, i]

        y_pred_all["ensembled"] = y_pred_all_.mean(1)

        # 取引資産のリターン/取引価格
        futures_return = self.futures_return.loc[
            X.index,
            self.config['trade_target'][0]
        ]

        position_all_ = self.predict_all(X, mode)
        position_all = {}
        profit_all = {}
        performance_all = {}
        cm_all = {}
        for i in range(position_all_.shape[1]):
            postion_ = position_all_.iloc[:, i]
            position_all[self.ensemble_cols[i]] = postion_
            trade_return_, wealth_ = tr.calc_wealth(futures_return, postion_)
            profit_all[self.ensemble_cols[i]] = wealth_
            _, performance_all[self.ensemble_cols[i]], cm_all[self.ensemble_cols[i]] = ev.calc_performance_all(
                trade_return_,
                wealth_,
                futures_return,
                postion_,
                self.ensemble_cols[i],
                business_days=250
            )

        position_all["ensembled"] = self.ensemble(X, mode, method="vote")
        position_all["ensembled_betsize"] = self.ensemble(
            X, mode, method="ensemble_betsize")

        trade_return_, wealth_ = tr.calc_wealth(
            futures_return, position_all["ensembled"])
        profit_all["ensembled"] = wealth_
        _, performance_all["ensembled"], cm_all["ensembled"] = ev.calc_performance_all(
            trade_return_,
            wealth_,
            futures_return,
            position_all["ensembled"],
            "ensembled",
            business_days=250
        )

        return y_pred_all, position_all, profit_all, performance_all, cm_all

    def _summarize_result(self, figs_all, shap_values_all, y_pred_all, position_all, profit_all, performance_all, cm_all):
        """_output_for_analysis, _output_shap_values, _metabacktestのメソッドの結果を集約する

        Parameters
        ----------
        figs_all : dict
            _output_for_analysisメソッドの出力結果..
        shap_values_all : dict
            _output_shap_valuesメソッドの出力結果.
        y_pred_all : dict
            _metabacktestメソッドの出力結果.
        position_all : dict
            _metabacktestメソッドの出力結果.
        profit_all : dict
            モデルごとの累積損益(+ アンサンブルしたモデルの累積損益)
        performance_all : dict
            モデルごとのパフォーマンス指標(+ アンサンブルしたモデルのパフォーマンス指標)        
        cm_all : dict
            モデルごとの混同行列(+ アンサンブルしたモデルの混同行列)

        Returns
        -------
        report_result : dict
            モデルごと + アンサンブル全体で結果が集約された辞書.
        """
        report_result = {}
        for key in self.ensemble_cols + ["ensembled"]:
            report_result.update({
                key: {
                    "unsupervised": figs_all[key],
                    "shap_values": shap_values_all[key],
                    "probability": y_pred_all[key],
                    "position": position_all[key],
                    "profit": profit_all[key],
                    "performance": performance_all[key],
                    "confusion matrix": cm_all[key],
                }
            })

        report_result["ensembled"].update(
            {"position_betsize": position_all["ensembled_betsize"]}
        )

        return report_result

    def report_all(self, start_date, end_date, mode, hyperparams_imp):
        """指定された期間における，教師なし学習，ポジションや予測確率，shap値を算出

        Parameters
        ----------        
        start_date : dt.datetime
            開始時点. ( ex.) dt.datetime(2021, 7, 1))
        end_date : TYPE
            終了時点. ( ex.) dt.datetime(2021, 10, 1))
        mode : str
            使用する学習済みモデルの選択 (see also 'ensemble.set_ensemble_pattern' method)
        hyperparams_imp : dict
            FeatureImportanceクラスで使用するハイパーパラメーターの辞書
            (クラスター分析の際のcluster_kmeans_top関数実行時の設定項目として使用).

        Returns
        -------
        report_result : dict
           モデルごと + アンサンブル全体で結果が集約された辞書.
        """
        X = self.X_raw.loc[start_date:end_date, ]
        # 教師なし学習の結果
        figs_all = self._output_for_analysis(X, mode, hyperparams_imp)
        # Shapの結果
        shap_values_all = self._output_shap_values(X, mode)
        # バックテストの結果
        y_pred_all, position_all, profit_all, performance_all, cm_all = self._metabacktest(
            X, mode)

        report_result = self._summarize_result(
            figs_all, shap_values_all, y_pred_all, position_all, profit_all, performance_all, cm_all)

        return report_result


class ResultAnalyst:
    def __init__(self, path=None, is_feature_select=False):
        self.models_info_all = get_models_info(
            "params", path, is_feature_select)
        self.models_result = get_models_info("result", path, is_feature_select)
        assert len(self.models_result) > 0, (
            f"path : {path}\n"
            + "参照先のフォルダが空です"
        )

    def _add_config_all(self, config_, model_name, timestamp):
        index_name = [
            "モデル",
            "バリエーションパターン",
            "特徴量",
            "特徴量数",
            "開始時点",
            "終了時点",
            "訓練月数",
            "テスト月数",
            "再学習月間隔",
        ]
        config_add_ = pd.DataFrame(
            [
                config_["model"],
                config_["backtest_info"]["validation_type"],
                str(list(config_["extracted_columns"])),
                len(config_["extracted_columns"]),
                config_["backtest_info"]["start_date"],
                config_["backtest_info"]["end_date"],
                config_["backtest_info"]["train_month"],
                config_["backtest_info"]["test_month"],
                config_["backtest_info"]["relearn_month"],
            ],
            index=[["設定" for _ in index_name], index_name],
            columns=[[model_name], [timestamp]],
        )

        return config_add_

    def _add_result_all(self, performance, model_name, timestamp, result_summary):
        performance_ = pd.DataFrame(
            performance.unstack(), columns=[[model_name], [timestamp]]
        )
        config_all_ = self.models_info_all[model_name][timestamp]["config"]
        config_all_add_ = self._add_config_all(
            config_all_, model_name, timestamp)
        output = pd.concat([performance_, config_all_add_])

        return output

    def report_result(self):
        """全試行のバックテスト結果のサマリーをデータフレーム形式で出力

        Returns
        -------
        result_summary : pd.DataFrame
           全試行のバックテスト結果
        """
        result_summary = []
        for model_name, dict_timestamp in self.models_result.items():
            for timestamp, results in dict_timestamp.items():
                results = self.models_result[model_name][timestamp]
                result_summary.append(
                    self._add_result_all(
                        results["result_all"][
                            "performance"
                        ],
                        model_name,
                        timestamp,
                        result_summary,
                    )
                )

        result_summary = pd.concat(result_summary, axis=1).T
        result_summary = result_summary.sort_values(
            [("トータル", "総損益")], ascending=False)

        return result_summary

    def report_wealth(self):
        """全試行のバックテスト結果の損益推移をデータフレーム形式で出力

        Returns
        -------
        wealth_summary : pd.DataFrame
           全試行のバックテスト結果の損益推移
        """
        col_name = []
        wealth_summary = pd.DataFrame()
        for model_name, dict_timestamp in self.models_result.items():
            for timestamp, results in dict_timestamp.items():
                col_name += [[[model_name], [timestamp]]]
                results = self.models_result[model_name][timestamp]
                wealth_profit_ = pd.DataFrame(results["result_all"]["wealth"])
                wealth_profit_.columns = [[model_name], [timestamp]]
                if len(wealth_summary) == 0:
                    wealth_summary = wealth_profit_
                else:
                    wealth_summary = pd.concat(
                        [wealth_summary, wealth_profit_], axis=1)

        total_profit_rank = wealth_summary.iloc[-1,
                                                :].sort_values(ascending=False)
        wealth_summary = wealth_summary[total_profit_rank.index]

        return wealth_summary

    def extract_models_info(self, result_summary, model_num, sort_name="総損益"):
        """トータルの総損益がよかった上位モデルの情報を抽出
        (sort_nameを変更することで任意の値の上位モデルを抽出可能)

        Parameters
        ----------
        result_summary : pd.DataFrame
           全試行のバックテスト結果
        model_num : int
            抽出するモデル数.

        Returns
        -------
        models_info : dict
            抽出したモデルの情報
            以下の構造で辞書形式にモデル, config情報を保存

            Notes
            -----
            |- model1 : モデル名
                |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
                    |- config.pkl : 設定ファイル 
                |- feature_select : 変数選択による思考結果()
                    |- 2021212_172302 : 実行した時間に基づくタイムスタンプ 
        """
        result_summary = result_summary.sort_values(
            [("トータル", sort_name)], ascending=False)
        model_num = min(model_num, result_summary.shape[0])
        extracted_index = result_summary.iloc[:model_num, :].index

        models_info = {}
        for model_name, timestamp in extracted_index:
            if model_name not in models_info.keys():
                models_info.update({model_name: {}})
                if timestamp not in models_info[model_name].keys():
                    models_info[model_name].update({timestamp: {}})

            models_info[model_name][timestamp] = self.models_info_all[model_name][timestamp]

        return models_info
