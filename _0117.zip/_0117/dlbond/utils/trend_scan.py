import glob
import os
import pickle
import pandas as pd
import numpy as np
import statsmodels.api as sm1


def tval_linear(close):
    """線形トレンドからt値を算出

    Parameters
    ----------
    close : pd.Series
        予測対象の原形列値

    Returns
    -------
    tvalues
        線形トレンドから算出したt値

    Note
    -------        
    本関数はアセットマネージャーのためのファイナンス機械学習のスニペット5.2に記載されたコードである．
    命名もこちらの本に従い設定．
    """
    x = np.ones((close.shape[0], 2))
    x[:, 1] = np.arange(close.shape[0])
    ols = sm1.OLS(close, x).fit()
    tvalues = ols.tvalues[1]

    return tvalues


def _trend_scan(molecule, close, span):
    """線形トレンドのt値の符合からラベルを作成

    Parameters
    ----------
    molecule : pd.core.indexes.datetimes.DatetimeIndex
        ラベルづけしたい観測値のインデックス
    close : pd.Series
        X_tの時系列
    span : list
        絶対値が最大のt値を探索する際にアルゴリズムが評価するLの値(ウィンドウ)の集合
        組み込み関数であるrange関数の引数として渡すリスト

    Returns
    -------
    output : pd.DataFrame
        t1   : 発見されたトレンドの終了時点
        tVal : 推定トレンド回帰係数のt値
        bin  : トレンドの符合 

    Note
    -------        
    本関数はアセットマネージャーのためのファイナンス機械学習のスニペット5.2に記載されたコードである．
    命名もこちらの本に従い設定．
    ※ 元コードからリーケージの期間を1つスライドしていることに注意．
    """
    out = pd.DataFrame(index=molecule, columns=['t1', 'tVal', 'bin'])
    hrzns = range(*span)

    for dt0 in molecule:
        df0 = pd.Series()
        iloc0 = close.index.get_loc(dt0)
        if iloc0+max(hrzns) > close.shape[0]:
            continue
        for hrzn in hrzns:
            dt1 = close.index[iloc0+hrzn-1]
            df1 = close.loc[dt0:dt1]
            df0.loc[dt1] = tval_linear(df1.values)

        dt1 = df0.replace([-np.inf, np.inf, np.nan], 0).abs().idxmax()
        out.loc[dt0, ['t1', 'tVal', 'bin']
                ] = df0.index[-1], df0[dt1], np.sign(df0[dt1])
    out['t1'] = pd.to_datetime(out['t1'])
    out['bin'] = pd.to_numeric(out['bin'], downcast='signed')
    output = out.dropna(subset=['bin'])
    
    return output


def trend_scan(molecule, close, span, IS_READING_TREND_SCAN=False):
    """線形トレンドのt値の符合からラベルを作成

    Parameters
    ----------
    molecule : pd.core.indexes.datetimes.DatetimeIndex
        ラベルづけしたい観測値のインデックス
    close : pd.Series
        X_tの時系列
    span : list
        絶対値が最大のt値を探索する際にアルゴリズムが評価するLの値(ウィンドウ)の集合
        組み込み関数であるrange関数の引数として渡すリスト
    IS_READING_TREND_SCAN :bool
        Trueの場合，trend scan法により変換されたデータではないダミーデータが出力される
        推論時にはtrend_scan法の出力値は不要のため，tValとbinが0，t1がindexと同じデータであるダミーデータを返す\n
        
    Returns
    -------
    output : pd.DataFrame
        t1   : 発見されたトレンドの終了時点
        tVal : 推定トレンド回帰係数のt値
        bin  : トレンドの符合 

    Note
    -------        
    本関数はアセットマネージャーのためのファイナンス機械学習のスニペット5.2に記載されたコードである．
    命名もこちらの本に従い設定．
    ※ 元コードからリーケージの期間を1つスライドしていることに注意．
    
    * 処理時間の短縮のため，trendscan法により算出した結果は外部に掃き出す
    """
    path_ = __file__.split("\\dlbond\\utils\\trend_scan")[0] + "\\data"
    folders = os.listdir(path_)   

    path_trend_scan = path_ + "\\.trend_scan"
    
    if IS_READING_TREND_SCAN:
        # 本機能は推論時に参照することを想定した分岐
        # 推論時にはtrend_scan方による教師ラベルは不要であるため，計算時間短縮のため空の結果を返す
        try:
            print("trend scan法のラベリングの値は参照しないでください\n(入力したデータ期間と関係ない値が出力されます)")
            output = pd.concat([pd.DataFrame(molecule), pd.DataFrame(np.zeros((len(molecule), 2)))], axis=1)
            output.columns=["t1", "tVal", "bin"]
            output.index = molecule
        except FileNotFoundError:
            raise FileNotFoundError(
                "data\\.trend_scan\\trend_scan_preserve.pklが存在しません\n"
                + "trend_scan_preserve.pklを先に作成する必要があります\n"
                + "IS_READING_TREND_SCANを一度FALSEにしてtrend_scanを一度実行する必要があります"
                )
    else: 
        is_copy = False        
        if ".trend_scan" in folders:
            # print(f"trend scan法の変換値は，作成済みの\n{path_trend_scan}\nにあるデータを使用します")
            try:
                result = pickle.load(open(path_trend_scan + "\\trend_scan_preserve.pkl", "rb"))
            except FileNotFoundError:
                raise FileNotFoundError(
                    "data\\.trend_scan\\trend_scan_preserve.pklが存在しません\n"
                    + ".trend_scanを一度削除のうえ，IS_READING_TREND_SCANを一度FALSEにしてtrend_scanを一度実行してください"
                    ) 
            span_ = result["span"]
            close_ = result["close"]
            molecule_ = result["molecule"]
            if span == span_ and close.columns[0] == close_.columns[0]:
                index_ = [i for i in molecule if i in molecule_]
                close_temp = close.loc[index_, :]
                close_temp_ = close_.loc[index_, :]
                if (close_temp == close_temp_).sum().values[0] == len(close_temp):
                    is_copy = True
                    output = result["output"].copy()
        
        if not is_copy:
            os.makedirs(path_trend_scan, exist_ok=True)
            import time
            start_ = time.time()            
            print("trend scan : 計算中...")
            output = _trend_scan(molecule, close, span)
            print(f"trend scan -- {round(time.time() - start_)}sec")
            result_ = {
                "molecule": molecule, 
                "close": close, 
                "span": span,
                "output": output,
                }
            pickle.dump(result_, open(path_trend_scan + "\\trend_scan_preserve.pkl", "wb"))
            
    return output

