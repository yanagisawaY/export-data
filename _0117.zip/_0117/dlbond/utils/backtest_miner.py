import copy
import numpy as np
import pandas as pd
import time
from .feature_importance import FeatureSelecter


class BacktestMiner(FeatureSelecter):
    def __init__(self, dfs_input, config, config_meta):
        self.dfs_input = dfs_input
        self.hyperparams_imp = config_meta["hyperparams_imp"]
        self.hyperparams_minig = config_meta["hyperparams_minig"]        
        self.config_meta = config_meta
        self._super_class(dfs_input, config)
        self.timestamp = self.storage.now
    
    def _super_class(self, dfs_input, config):
        """FeatureSelecterのインスタンスを呼び出し
        (FeatureSelecterが継承しているBacktesterのconfigを更新)

        Parameters
        ----------
        dfs_input : dict
            入力データ
        config : dict
            BackTesterに入力する設定ファイル
        """        
        if hasattr(self, "clusters"):
            # FeatureSelecterインスタンス生成時にself.clusters={}となるため，一時保存
            clusters_save_ = copy.deepcopy(self.clusters)
        else:
            clusters_save_ = {}            
        super().__init__(dfs_input, config, self.hyperparams_imp)
        assert hasattr(self, "clusters")
        if len(self.clusters) == 0:
            self.clusters = copy.deepcopy(clusters_save_)

    def weight_features(self, start_date, end_date):
        """変数重要度に基づき特徴量を重みづけする
        
        【処理手順】
        1. report_mdaメソッドを用いて，MDA(特徴量単位でのシャッフル)を計算\n
        2. MDA(特徴量単位でのシャッフル)の結果をもとに，特徴量ごとのウェイトを算出
            * 特徴量ごとにMDAの平均/MDAの標準偏差を算出(欠損値(標準偏差が0であったもの)は最小値に置換) 
            * 各ウェイトに対し，さらに(クラスターの所属数)**.5/sum((クラスターの所属数)**.5)で重みづけ
        3. report_mdaメソッドを用いて，クラスターMDA(クラスター単位でのシャッフル)を計算\n
        4. クラスターMDA(クラスター単位でのシャッフル)の結果をもとに，クラスターごとのウェイトを算出\n
            * クラスターMDAの平均/クラスターMDAの標準偏差(欠損値(標準偏差が0であったもの)は最小値に置換) に対し，ソフトマックス変換を実施
            * (ソフトマックス変換により)全クラスターで合計が1かつ正値となるようにソフトマックス変換により基準化
        5. クラスターMDAのウェイトをクラスターごとに合計が1かつ正値となるようにソフトマックス変換により基準化
        
        Parameters
        ----------
        start_date : datetime
            データの開始時点
        end_date : datetime
            データの終了時点

        Returns
        -------
        features_weight : pd.DataFrame
            cluster : 特徴量のクラスター
            cluster_prob : クラスター単位のカテゴリ確率ウェイト(クラスター単位で合計が1かつ正値となるよう基準化)
            feature_prob : 特徴量単位のカテゴリ確率ウェイト(クラスターごとに合計が1かつ正値となるよう基準化)            
        imp_mda_all : pd.DataFrame
            特徴量ごとの変数重要度(行方向に特徴量, 列方向に[mean, sd])
        imp_mda_cluster : pd.DataFrame
            クラスターごとの変数重要度(行方向にクラスター, 列方向に[mean, sd])
        """

        def _softmax(x):
            return np.exp(x) / sum(np.exp(x))

        # MDA(特徴量単位でのシャッフル)
        imp_mda_all = self.report_mda(start_date, end_date, is_cluster=False)
        imp_mda_all_score = imp_mda_all["mean"]
        imp_mda_all_score = imp_mda_all_score.fillna(imp_mda_all_score.min())

        # クラスターMDA(クラスター単位でのシャッフル)
        self.is_tune = False  # クラスターMDA算出時にはハイパラ探索を実施しない(計算時間短縮のため)
        imp_mda_cluster = self.report_mda(start_date, end_date, is_cluster=True)
        clusters_weight = imp_mda_cluster["mean"]
        clusters_weight = clusters_weight.fillna(clusters_weight.min())
        clusters_weight = _softmax(clusters_weight)
        clusters_size = np.array([len(val) for val in self.clusters.values()])
        clusters_size = clusters_size ** 0.5
        clusters_size = clusters_size / sum(clusters_size)
        clusters_weight = clusters_size * clusters_weight
        clusters_weight = clusters_weight / clusters_weight.sum()
        clusters_weight.index = [i.split("_")[1] for i in clusters_weight.index]

        features_weight = []
        assert len(self.clusters) > 0
        for cluster_, feature_ in self.clusters.items():
            temp = pd.DataFrame(
                [
                    [int(cluster_)] * len(feature_),
                    [clusters_weight[cluster_]] * len(feature_),
                    imp_mda_all_score[feature_].values,
                ],
                columns=feature_,
                index=["cluster", "cluster_prob", "feature_prob"],
            ).T
            features_weight.append(temp)

        features_weight = pd.concat(features_weight)
        features_weight["feature_prob"] = features_weight.groupby("cluster")[
            "feature_prob"
        ].apply(_softmax)

        return features_weight, imp_mda_all, imp_mda_cluster

    def sampling_features(self, features_weight, max_features_num, random_state=0):
        """features_weightをもとに，特徴量の（重複なし）サンプリングを実施
        
        【処理手順】
        1. features_weightに収録されたcluster_probの確率をもとに，クラスター番号の重複ありサンプリングを実施
            * クラスター番号のサンプリング数がそのクラスターに含まれる特徴量数以上にサンプリングされないようにする
        2. サンプリングされた各クラスターに対し，そのクラスター番号の数の分だけ，
        features_weightに収録されたfeatures_probのクラスター単位の確率に従い，重複ありサンプリングを実施               

        Parameters
        ----------
        features_weight : pd.DataFrame
                cluster : 特徴量のクラスター
                cluster_prob : クラスター単位のカテゴリ確率ウェイト(クラスター単位で合計が1かつ正値となるよう基準化)
                feature_prob : 特徴量単位のカテゴリ確率ウェイト(クラスターごとに合計が1かつ正値となるよう基準化)            
        max_features_num : int
            サンプリングする特徴量の数.
        random_state : int, optional
            乱数シード. The default is 0.

        Returns
        -------
        sampling_features : list
            サンプリングした特徴量のリスト.
        """
        assert features_weight.shape[0] > max_features_num
        assert len(self.clusters) > 0
        cluster_prob = features_weight.groupby("cluster")["cluster_prob"].first()
        cluster_prob.index = cluster_prob.index.astype(int)
        clusters_size = pd.Series(
            np.array([len(val) for val in self.clusters.values()]),
            index=self.clusters.keys(),
        )

        np.random.seed(random_state)
        sampling_cluster = list(
            np.random.choice(
                list(cluster_prob.index), p=list(cluster_prob), size=max_features_num
            )
        )
        sampling_cluster = sorted(sampling_cluster)

        def _redo_sampling(sampling_cluster, count_=0):
            """クラスターに含まれる特徴量数以上にサンプリングされないようになるまで再帰関数を実行
            """
            count_cluster = pd.DataFrame(
                np.unique(sampling_cluster, return_counts=True),
                index=["cluster", "count"],
            ).T.set_index("cluster")["count"]
            check_ = count_cluster - clusters_size[count_cluster.index]
            
            if sum(check_ > 0) > 0:
                renew_cluster = check_[check_ > 0]
                cluster_prob_new = cluster_prob.drop(list(renew_cluster.index))
                cluster_prob_new = cluster_prob_new / cluster_prob_new.sum()
                for i, cluster_ in enumerate(renew_cluster.index):
                    size_ = renew_cluster[cluster_]
                    np.random.seed(random_state + count_ + i)
                    sampling_new = list(
                        np.random.choice(
                            list(cluster_prob_new.index),
                            p=list(cluster_prob_new),
                            size=size_,
                        )
                    )
                    for val_new in sampling_new:
                        sampling_cluster[sampling_cluster.index(cluster_)] = val_new
                sampling_cluster = sorted(sampling_cluster)
                count_ += 1
                return _redo_sampling(sampling_cluster, count_)
            else:
                return sampling_cluster

        sampling_cluster = _redo_sampling(sampling_cluster)
        sampling_features = []
        count_cluster = pd.DataFrame(
            np.unique(sampling_cluster, return_counts=True), index=["cluster", "count"]
        ).T.set_index("cluster")["count"]
        for cluster_ in count_cluster.index:
            feature_prob_cluster = features_weight.loc[
                features_weight["cluster"] == cluster_, "feature_prob"
            ]
            sampling_feature = list(
                np.random.choice(
                    list(feature_prob_cluster.index),
                    p=list(feature_prob_cluster),
                    replace=False,
                    size=count_cluster[cluster_],
                )
            )
            sampling_feature = [str(i) for i in sampling_feature]
            sampling_features += sampling_feature

        return sampling_features
    
    def _update_config_features(self, config, sampling_features):
        """config内のfeaturesとfeatures_ohlcvをsampling_featuresの特徴量作成に必要なもののみに更新
        """        
        config_updated = copy.deepcopy(self.config)
        code_features = [i for i in sampling_features if i in config["features"].index]
        config_updated["features"]["CODE"] = 0
        config_updated["features"]["CODE"][code_features] += config["features"]["CODE"][code_features].values
        
        code_tech = config_updated["features"].columns[1:]
        for code_tech_i in code_tech:
            feature_ = np.unique([j.split("_" + code_tech_i)[0] for j in sampling_features if code_tech_i in j])
            config_updated["features"][code_tech_i] = 0 
            if len(feature_) > 0:
                config_updated["features"][code_tech_i][feature_] += config["features"][code_tech_i][feature_].values

        code_tech_ohlcv = config_updated["features_ohlcv"].columns
        for code_tech_ohlcv_i in code_tech_ohlcv:
            feature_ = np.unique([j.split("_" + code_tech_ohlcv_i)[0] for j in sampling_features if code_tech_ohlcv_i in j])
            config_updated["features_ohlcv"][code_tech_ohlcv_i] = 0
            if len(feature_) > 0:
                config_updated["features_ohlcv"][code_tech_ohlcv_i][feature_] += config["features_ohlcv"][code_tech_ohlcv_i][feature_].values
        
        return config_updated
    
    def _backtest_from_sampling_trial(
            self, 
            features_weight, 
            max_features_num: int,
            sampling_iter: int,
            purgedKfold_interval,            
            trial: int,
            output_name: str,
            result_trial: dict
            ):                
        sampling_features = self.sampling_features(
            features_weight,
            max_features_num,
            random_state=self.hyperparams_minig["random_state"] + trial + 1,
        )

        # 使用する特徴量の更新
        self.config.update(
            {"extracted_columns": sampling_features,}
        )
        
        if len(self.sp.extract_pca_names()) == 0:
            # PCAにより生成された特徴量が存在しない場合，インスタンスを呼び出し
            # Backtesterクラスを継承したFeatureSelecterクラスのインスタンス生成
            # config_updated = self._update_config_features(self.config, sampling_features)
            # self._super_class(self.dfs_input, config_updated)
            self._super_class(self.dfs_input, self.config)
        
        output_name_ = output_name.split("_layer")[0]
        layer_name = "/layer_" + output_name.split("_layer")[1]
        self.storage.add_path = layer_name + "/trial" + str(trial)
        self.storage.now = self.timestamp
        results, result_all = self.backtest_all(output_name_)

        # スコアはトータルの総損益として設定
        score = result_all["performance"].loc["総損益", "トータル"]        
        result_trial[trial].update(
            {
                "feature": sampling_features,
                "score": score,
                "results": results,
                "result_all": result_all,
            }
        )

        return result_trial

    def backtest_from_sampling(
        self,
        start_date,
        end_date,
        output_name: str,
        max_features_num: int,
        sampling_iter: int,
        purgedKfold_interval=None,
        timeout=3600,
    ):
        """クラスターMDA(+ 各特徴量のMDA)を用いて算出したウェイトをもとに使用する特徴量をサンプリング
        sampling_iter回サンプリング -> バックテストを繰り返し，バックテスト期間中の総損益が最も高かった特徴量のサンプリングパターンを返す

        Parameters
        ----------
        start_date : dt.datetime
            MDAを算出する際のデータの開始時点(バックテストの開始時点とは異なることに注意)
        end_date : dt.datetime
            MDAを算出する際のデータの終了時点(バックテストの開始時点とは異なることに注意)
        output_name : str
            ファイルの出力名称.
        max_features_num : int
            サンプリングする特徴量の数.
        sampling_iter : int
            サンプリング回数.(サンプリング回数分Backtester.backtest_allが呼び出される)
        purgedKfold_interval : int
            * purgedKfold_interval回サンプリングが実施される度にハイパーパラメータのチューニングを実施する\n
            -> config内のbacktestinfo->validation_typeがPurgedKFold_nonpruneに変更される\n
            * チューニングが実施されてから，purgedKfold_interval回目までのサンプリングにおいては，
            更新されたハイパーパラメータをもとにバックテストを実施する（ハイパラのチューニングを実施しない）
            * Noneの場合，configで設定したパラメータに従い，バックテストが実施される
        timeout : int
            計算時間がtimeout(秒数)を超えた場合，サンプリングを終了する(for文を終了させる)
            * MDIとMDAの計算（weight_featuresメソッド）の計算時間は含めない

        Returns
        -------
        result_trial : dict
            * features_weight, imp_mda_all, imp_mda_cluster -> sampling_featuresメソッド参照
            * best_feature : list
                総損益が最も高かった特徴量のサンプリングパターン
            * trial_numごと(各サンプリングパターン)でのバックテスト結果 \n
            -> experiment/result/output_name/feature_selectにタイムスタンプとともに結果を保存
        
        Raises
        ------
        ValueError
            max_features_numが元の特徴量数よりも大きい値が指定されていた場合はassertにより実行を停止
                
        Notes
        -----
        * purgedKfold_intervalをNoneにしたうえ，Backtesterでのconfigでハイパーパラメータのチューニングを実施する状態で指定した場合，計算時間が膨大になることに注意．\n
        -> 「sampling_iter × バックテストの期間数」の回数分，optunaが実行される
        """
        features_weight, imp_mda_all, imp_mda_cluster = self.weight_features(
            start_date, end_date
        )

        if features_weight.shape[0] < max_features_num:
            raise ValueError(
                f"feature_num = {features_weight.shape[0]} > max_features_num = {max_features_num}"
                + "max_features_numが元の特徴量数よりも大きい値が指定されています"
            )

        if purgedKfold_interval is None:
            # Noneの場合，configで設定したパラメータに従い，バックテストを実施
            purgedKfold_interval = sampling_iter + 1
            if self.config["backtest_info"]["validation_type"] == "None":
                print("optunaによるハイパラ探索をサンプリングごとに実施するため，計算時間が多くかかります")
        else:
            assert sampling_iter >= purgedKfold_interval

        result_trial = {trial: {} for trial in range(sampling_iter)}
        result_trial["cluster_info"] = {
            "features_weight": features_weight,
            "imp_mda_all": imp_mda_all,
            "imp_mda_cluster": imp_mda_cluster,
        }
        trial_score = []
        validation_type_init = self.config["backtest_info"]["validation_type"]
        start_time = time.time()
        for trial in range(sampling_iter):
            print(f"sampling... {trial+1} / {sampling_iter}")

            if trial % purgedKfold_interval == 0:
                print(f"TUNING sampling... {trial+1} / {sampling_iter}")
                self.config["backtest_info"]["validation_type"] = "PurgedKFold_nonprune"
            else:
                self.config["backtest_info"]["validation_type"] = validation_type_init

            result_trial = self._backtest_from_sampling_trial(
                features_weight, 
                max_features_num,
                sampling_iter,
                purgedKfold_interval,            
                trial,
                output_name,
                result_trial
            )
            score = result_trial[trial]["score"]
            trial_score += [score]
            print(f"{trial+1} / {sampling_iter} : {score}")
            
            elapsed_time = time.time() - start_time
            if elapsed_time >= timeout:
                print(f"{round(elapsed_time)} sec : サンプリングによる計算時間がtimeoutを超えました")
                break

        trial_score = pd.Series(trial_score, index=list(range(len(trial_score))))
        result_trial["trial_score"] = trial_score
        self.storage.save_result_feature_select(result_trial)

        return result_trial

    def _mining_layer(self, result_trial, layer_i, output_name, random_state):
        """特徴量のサンプリングとバックテストを再帰的に実施する関数        

        サンプリングをsampling_iter回繰り返したうち，パフォーマンスの最もよいモデルの特徴量を新たにサンプリングの対象として，さらにサンプリングとバックテストを再帰的に実行する
        
        Parameters
        ----------
        result_trial : dict
            検証結果をまとめた辞書(experiment/resultにも出力される情報).
        layer_i : int
            .
        output_name : str
            モデル名.
        random_state : int
            乱数シード.

        Returns
        -------
        result_trial : dict
            再帰的に実行した検証結果をまとめた辞書(experiment/resultにも出力される情報)
        
        Notes
        -----
        * 再帰的に実行される回数はhyperparams_minigのlayerにある辞書のキーの回数分\n
        """
        output_name_layer = output_name + "_layer" + str(layer_i)
        
        if layer_i in self.hyperparams_minig["layer"].keys():
            val = self.hyperparams_minig["layer"][layer_i]
        else:
            return result_trial
        
        max_features_num = val["max_features_num"]
        sampling_iter = val["sampling_iter"]
        purgedKfold_interval = val["purgedKfold_interval"]
        print(
            f"model_name : {output_name_layer}\n"
            + f"{self.config_meta['start_date'].strftime('%y%m%d')} - "
            + f"{self.config_meta['end_date'].strftime('%y%m%d')}\n"
            + f"抽出する特徴量数 {max_features_num}\n"
            + f"サンプリング数 {sampling_iter}\n"
            + f"チューニング頻度 {purgedKfold_interval}\n"
            + f"timeout {self.hyperparams_minig['timeout']}sec\n"
        )

        if len(result_trial) > 0:
            key_before = output_name + "_layer" + str(layer_i-1)
            trial_num_top = (
                result_trial[key_before]["trial_score"]
                .sort_values(ascending=False).index[0]
            )
            extracted_columns_population = result_trial[key_before][trial_num_top]["feature"]
            # 使用する特徴量を更新
            # サンプリングの母集団特徴量の情報を保存
            self.config["extracted_columns_population"].update({layer_i: extracted_columns_population})
            # この時点のextracted_columnsを使って前処理を実施
            # -> processorの情報もこの時点のextracted_columnsにより実施されるため，            
        else:
            try:
                extracted_columns_population = self.config["extracted_columns"]
            except KeyError:
                extracted_columns_population = self.sp.X.columns
            
            # 初期サンプリングの母集団特徴量の情報を保存
            self.config["extracted_columns_population"] = {layer_i: list(extracted_columns_population)}
            
            self.timestamp = self.storage.now

        if max_features_num < len(extracted_columns_population):
            result_trial_new = self.backtest_from_sampling(
                start_date=self.config_meta["start_date"],
                end_date=self.config_meta["end_date"],
                output_name=output_name_layer,
                max_features_num=max_features_num,
                sampling_iter=sampling_iter,
                purgedKfold_interval=purgedKfold_interval,
                timeout=self.hyperparams_minig["timeout"],
            )
            result_trial.update(
                {output_name_layer: result_trial_new,}
            )

        return self._mining_layer(
                result_trial=result_trial,
                layer_i=layer_i + 1,
                output_name=output_name,
                random_state=random_state + 1,
            )

    def mining(self, output_name):
        """MDAによる変数重要度に基づき特徴量をサンプリングに対し，バックテストを実施

        Parameters
        ----------
        output_name : str
            モデル名.

        Returns
        -------
        result_trial : dict
            再帰的に実行した検証結果をまとめた辞書(experiment/resultにも出力される情報).
        """
        assert 0 in self.hyperparams_minig["layer"].keys()
        result_trial = self._mining_layer(
            result_trial={},
            layer_i=0,
            output_name=output_name,
            random_state=self.hyperparams_minig["random_state"],
        )

        return result_trial