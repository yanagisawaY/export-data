import pandas as pd
import os
import glob

def get_models_result(path=None):
    """experiment直下のresultフォルダーに格納されたモデル，configを全パターン抽出

    Parameters
    ----------
    path : str
        experiment/resultのフォルダパス

    Returns
    -------
    models_result : dict
        以下の構造で辞書形式にモデル, config情報を保存
        
        Notes
        -----
        |- model1
            |- 20211113_173830 : 実行した時間に基づくタイムスタンプ
                |- termX : model.pkl, term_info.pklをタームごとにtupleで保存
                |- config.pkl : 設定ファイル 
    """
    if path is None:
        path = os.getcwd()+"\\experiment\\result"
        
    model_files = [x.split("\\")[-1] for x in glob.glob(path + "/**")]
    models_result = {model_:{} for model_ in model_files}
    for model_ in model_files:
        path_model = path + "\\" + model_
        timestamp_files = [x.split("\\")[-1] for x in glob.glob(path_model + "/**")]
        models_result[model_] = {timestamp:{} for timestamp in timestamp_files}
        for timestamp in timestamp_files:
            path_stamp = path_model + "\\" + timestamp        
            dir_all = os.walk(path_stamp)    
            for dirs, _, files in dir_all:
                key_ = dirs.split("\\params")[0].split("\\")[-1]           
                if len(files)>0 and "result.pkl" == files[0]:
                    result = dirs.split("\\params")[0] + "\\result.pkl"
                    models_result[model_][timestamp].update({
                        key_: (
                            pd.read_pickle(result)
                            )})
                elif len(files)>0 and "result_all.pkl" == files[0]:
                    models_result[model_][timestamp].update({
                        "result_all": pd.read_pickle(dirs + "/" + files[0])            
                    })
                    
    return models_result
