from .app import app
from dash.dependencies import Input, Output, State, MATCH
import dash_html_components as html
from .utils.set_path import TreePath
from .pages.access_results import get_model_select, get_timestamp_select

@app.callback(
    Output(component_id='folder-structure', component_property='children'),
    [
        Input('my-botton_1', 'n_clicks')
        ],
    State(component_id='path-temp', component_property='value'),
)

def update_output_div(n_clicks, path):
    tp = TreePath()    
    tp.tree(path)
    folder_text = f"""
    --------------------------------------------------
    {tp.text}
    """

    return folder_text
