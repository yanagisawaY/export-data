from dlbond.dash_dlbond.app import app
from dlbond.dash_dlbond.layout import this_layout
import dlbond.dash_dlbond.callback
from dash_extensions import Mermaid
app.layout = this_layout

if __name__ == "__main__":
    app.run_server(host='127.0.0.1', port=8070)