import pandas as pd
import plotly.express as px


def plot_target_hist(y_train, y_test):
    y_train_ = y_train.reset_index()
    y_train_["type"] = "train"
    y_test_ = y_test.reset_index()
    y_test_["type"] = "test"
    df = pd.concat([y_train_, y_test_])
    df.columns = ["Date", "target", "type"]

    fig = px.histogram(
        df, 
        x="target", 
        color="type", 
        marginal="box", 
        title="訓練データとテストデータの目的変数のヒストグラム",            
        barmode="overlay",
        histnorm="probability",
        )
    return fig

def plot_target_previous(y_train, y_test):
    def combine_yesterday(y):
        df = pd.concat([y, y.shift(-1)], axis=1).dropna().reset_index()
        df.columns = ["Date", "当日", "前営業日"]
        
        return df

    df_train_ = combine_yesterday(y_train)
    df_test_ = combine_yesterday(y_test)
    df_train_["type"] = "train"
    df_test_["type"] = "test"
    df = pd.concat([df_train_, df_test_])

    fig = px.scatter(
        df, 
        x="前営業日", 
        y="当日", 
        color="type", 
        title="前日と当日の目的変数の散布図",        
        marginal_x="histogram",
        marginal_y="histogram",       
        trendline='ols', 
        )
    return fig