import numpy as np
import pandas as pd
import torch


def convert_numpy(rt_):
    if isinstance(rt_, pd.DataFrame):
        rt_ = rt_.values
    assert isinstance(rt_, np.ndarray)

    return rt_


def base_port_return(rt):
    """ベンチマークポートフォリオのリターンを算出（ベンチマークは等ウェイトポートフォリオ）
    """
    weight_bench = torch.ones(rt.size())/rt.shape[1]
    rt_bench = torch.einsum('nm,nm->n', rt, weight_bench)

    return rt_bench
